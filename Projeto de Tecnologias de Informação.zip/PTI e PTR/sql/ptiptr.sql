-- phpMyAdmin SQL Dump
-- version 4.8.3
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1:3306
-- Generation Time: 12-Maio-2019 às 14:17
-- Versão do servidor: 5.7.23
-- versão do PHP: 7.2.10

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `ptiptr`
--
CREATE DATABASE IF NOT EXISTS `ptiptr` DEFAULT CHARACTER SET utf8 COLLATE utf8_general_ci;
USE `ptiptr`;

-- --------------------------------------------------------

--
-- Estrutura da tabela `aluno`
--

DROP TABLE IF EXISTS `aluno`;
CREATE TABLE IF NOT EXISTS `aluno` (
  `aluno_id` int(4) UNSIGNED NOT NULL,
  `curriculo` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`aluno_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Extraindo dados da tabela `aluno`
--

INSERT INTO `aluno` (`aluno_id`, `curriculo`) VALUES
(1234, '');

-- --------------------------------------------------------

--
-- Estrutura da tabela `ano_letivo`
--

DROP TABLE IF EXISTS `ano_letivo`;
CREATE TABLE IF NOT EXISTS `ano_letivo` (
  `id` int(4) UNSIGNED NOT NULL AUTO_INCREMENT,
  `ano_inicio` int(4) DEFAULT NULL,
  `ano_final` int(4) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Estrutura da tabela `curso`
--

DROP TABLE IF EXISTS `curso`;
CREATE TABLE IF NOT EXISTS `curso` (
  `id` int(4) UNSIGNED NOT NULL,
  `departamento` int(4) DEFAULT NULL,
  `nome` varchar(100) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `departamento` (`departamento`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Estrutura da tabela `departamento`
--

DROP TABLE IF EXISTS `departamento`;
CREATE TABLE IF NOT EXISTS `departamento` (
  `id` int(4) UNSIGNED NOT NULL AUTO_INCREMENT,
  `faculdade` int(4) DEFAULT NULL,
  `nome` varchar(50) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `faculdade` (`faculdade`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Estrutura da tabela `exame`
--

DROP TABLE IF EXISTS `exame`;
CREATE TABLE IF NOT EXISTS `exame` (
  `id` int(4) UNSIGNED NOT NULL AUTO_INCREMENT,
  `uc` int(4) DEFAULT NULL,
  `data` date DEFAULT NULL,
  `hora` time DEFAULT NULL,
  `duracao` float DEFAULT NULL,
  `fase` int(1) DEFAULT NULL,
  `ano_letivo` int(4) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `uc` (`uc`),
  KEY `ano_letivo` (`ano_letivo`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Estrutura da tabela `faculdade`
--

DROP TABLE IF EXISTS `faculdade`;
CREATE TABLE IF NOT EXISTS `faculdade` (
  `id` int(4) UNSIGNED NOT NULL AUTO_INCREMENT,
  `nome` varchar(50) DEFAULT NULL,
  `edificios` varchar(50) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8;

--
-- Extraindo dados da tabela `faculdade`
--

INSERT INTO `faculdade` (`id`, `nome`, `edificios`) VALUES
(1, 'Faculdade de Ciências', 'C1,C2,C3,C4,C5,C6');

-- --------------------------------------------------------

--
-- Estrutura da tabela `inscritos`
--

DROP TABLE IF EXISTS `inscritos`;
CREATE TABLE IF NOT EXISTS `inscritos` (
  `id` int(4) UNSIGNED NOT NULL AUTO_INCREMENT,
  `aluno_id` int(4) NOT NULL,
  `turma_id` int(4) NOT NULL,
  `uc_id` int(4) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `aluno_id` (`aluno_id`),
  KEY `turma_id` (`turma_id`),
  KEY `uc_id` (`uc_id`)
) ENGINE=InnoDB AUTO_INCREMENT=16 DEFAULT CHARSET=utf8;

--
-- Extraindo dados da tabela `inscritos`
--

INSERT INTO `inscritos` (`id`, `aluno_id`, `turma_id`, `uc_id`) VALUES
(14, 1234, 1, 1),
(15, 1234, 3, 1);

-- --------------------------------------------------------

--
-- Estrutura da tabela `pedido`
--

DROP TABLE IF EXISTS `pedido`;
CREATE TABLE IF NOT EXISTS `pedido` (
  `id` int(4) UNSIGNED NOT NULL AUTO_INCREMENT,
  `aluno_id` int(4) NOT NULL,
  `uc_id` int(4) NOT NULL,
  `turma_antiga` int(5) NOT NULL,
  `turma_nova` int(5) NOT NULL,
  `status` varchar(15) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `aluno_id` (`aluno_id`)
) ENGINE=InnoDB AUTO_INCREMENT=10 DEFAULT CHARSET=utf8;

--
-- Extraindo dados da tabela `pedido`
--

INSERT INTO `pedido` (`id`, `aluno_id`, `uc_id`, `turma_antiga`, `turma_nova`, `status`) VALUES
(8, 1234, 1, 3, 4, 'Aceite'),
(9, 1234, 1, 4, 3, 'Aceite');

-- --------------------------------------------------------

--
-- Estrutura da tabela `pessoa`
--

DROP TABLE IF EXISTS `pessoa`;
CREATE TABLE IF NOT EXISTS `pessoa` (
  `numero` int(4) NOT NULL AUTO_INCREMENT,
  `email` varchar(255) DEFAULT NULL,
  `nome` varchar(255) DEFAULT NULL,
  `pass` varchar(255) DEFAULT NULL,
  `horario1` varchar(255) DEFAULT NULL,
  `horario2` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`numero`)
) ENGINE=InnoDB AUTO_INCREMENT=4445 DEFAULT CHARSET=utf8;

--
-- Extraindo dados da tabela `pessoa`
--

INSERT INTO `pessoa` (`numero`, `email`, `nome`, `pass`, `horario1`, `horario2`) VALUES
(1234, 'abc@abc.com', 'nome', 'pass', 'horario', 'horarido'),
(4444, 'prof@fcul.com', 'Antonio Ferreira', '1234', '', '');

-- --------------------------------------------------------

--
-- Estrutura da tabela `presenca`
--

DROP TABLE IF EXISTS `presenca`;
CREATE TABLE IF NOT EXISTS `presenca` (
  `id` int(4) UNSIGNED NOT NULL,
  `uc` int(4) DEFAULT NULL,
  `aluno` int(4) DEFAULT NULL,
  `turma` int(4) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `uc` (`uc`),
  KEY `aluno` (`aluno`),
  KEY `turma` (`turma`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Estrutura da tabela `professor`
--

DROP TABLE IF EXISTS `professor`;
CREATE TABLE IF NOT EXISTS `professor` (
  `prof_id` int(4) UNSIGNED NOT NULL,
  `departamento` varchar(100) DEFAULT NULL,
  `gabinete` varchar(20) DEFAULT NULL,
  PRIMARY KEY (`prof_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Extraindo dados da tabela `professor`
--

INSERT INTO `professor` (`prof_id`, `departamento`, `gabinete`) VALUES
(4444, 'Informática', '6.2.23');

-- --------------------------------------------------------

--
-- Estrutura da tabela `sala`
--

DROP TABLE IF EXISTS `sala`;
CREATE TABLE IF NOT EXISTS `sala` (
  `id` int(5) UNSIGNED NOT NULL AUTO_INCREMENT,
  `edificio` int(1) DEFAULT NULL,
  `piso` int(1) DEFAULT NULL,
  `num_sala` int(2) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8;

--
-- Extraindo dados da tabela `sala`
--

INSERT INTO `sala` (`id`, `edificio`, `piso`, `num_sala`) VALUES
(1, 1, 2, 3),
(2, 3, 3, 43);

-- --------------------------------------------------------

--
-- Estrutura da tabela `turma`
--

DROP TABLE IF EXISTS `turma`;
CREATE TABLE IF NOT EXISTS `turma` (
  `id` int(5) UNSIGNED NOT NULL AUTO_INCREMENT,
  `uc_id` int(4) DEFAULT NULL,
  `tipo` varchar(2) DEFAULT NULL,
  `dia_semana` varchar(15) DEFAULT NULL,
  `hora_inicio` varchar(5) DEFAULT NULL,
  `hora_fim` varchar(5) DEFAULT NULL,
  `duracao` float DEFAULT NULL,
  `sala` int(4) DEFAULT NULL,
  `ano_letivo` int(4) DEFAULT NULL,
  `max_alunos` int(4) DEFAULT NULL,
  `status` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `sala` (`sala`),
  KEY `ano_letivo` (`ano_letivo`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8;

--
-- Extraindo dados da tabela `turma`
--

INSERT INTO `turma` (`id`, `uc_id`, `tipo`, `dia_semana`, `hora_inicio`, `hora_fim`, `duracao`, `sala`, `ano_letivo`, `max_alunos`, `status`) VALUES
(1, 1, 'T', 'Segunda', '14:30', '16:00', 1.5, 1, 1, 60, 'Aberta'),
(2, 2, 'TP', 'Sexta', '10:00', '11:30', 1.5, 2, 1, 30, 'Aberta'),
(3, 1, 'TP', 'Terça', '16:00', '17:30', 1.5, 7, 1, 15, 'Aberta'),
(4, 1, 'TP', 'Quinta', '8:00', '9:30', 1.5, 3, 1, 15, 'Aberta');

-- --------------------------------------------------------

--
-- Estrutura da tabela `uc`
--

DROP TABLE IF EXISTS `uc`;
CREATE TABLE IF NOT EXISTS `uc` (
  `id` int(4) UNSIGNED NOT NULL AUTO_INCREMENT,
  `nome` varchar(100) DEFAULT NULL,
  `ects` int(5) DEFAULT NULL,
  `semestre` int(1) DEFAULT NULL,
  `professores` varchar(255) DEFAULT NULL,
  `coordenador` int(4) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `coordenador` (`coordenador`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8;

--
-- Extraindo dados da tabela `uc`
--

INSERT INTO `uc` (`id`, `nome`, `ects`, `semestre`, `professores`, `coordenador`) VALUES
(1, 'Planeamento e Gestao de Projetos', 6, 1, 'Antonio Ferreira', 4444),
(2, 'Construcao de Sistemas de Software', 6, 1, 'Marta Duarte', 4398);

--
-- Constraints for dumped tables
--

--
-- Limitadores para a tabela `pedido`
--
ALTER TABLE `pedido`
  ADD CONSTRAINT `pedido_ibfk_1` FOREIGN KEY (`aluno_id`) REFERENCES `pessoa` (`numero`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
