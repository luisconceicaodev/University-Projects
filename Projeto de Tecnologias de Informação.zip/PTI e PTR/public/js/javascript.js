    // Get the modal
    var modal = document.getElementById('id01');

    // When the user clicks anywhere outside of the modal, close it
    window.onclick = function(event) {
        if (event.target == modal) {
            modal.style.display = "none";
        }
    }

    // Accordion 
    function myAccFunc() {
        var x = document.getElementById("demoAcc");
        if (x.className.indexOf("w3-show") == -1) {
            x.className += " w3-show";
        } else {
            x.className = x.className.replace(" w3-show", "");
        }
    }

    function myAccFunc2() {
        var x = document.getElementById("demoAcc2");
        if (x.className.indexOf("w3-show") == -1) {
            x.className += " w3-show";
        } else {
            x.className = x.className.replace(" w3-show", "");
        }
    }

    function myAccFunc3() {
        var x = document.getElementById("demoAcc3");
        if (x.className.indexOf("w3-show") == -1) {
            x.className += " w3-show";
        } else {
            x.className = x.className.replace(" w3-show", "");
        }
    }

    function myAccFunc4() {
        var x = document.getElementById("demoAcc4");
        if (x.className.indexOf("w3-show") == -1) {
            x.className += " w3-show";
        } else {
            x.className = x.className.replace(" w3-show", "");
        }
    }

    // Click on the "Jeans" link on page load to open the accordion for demo purposes
    //document.getElementById("myBtn").click();


    // Open and close sidebar
    function w3_open() {
        document.getElementById("mySidebar").style.display = "block";
        document.getElementById("myOverlay").style.display = "block";
    }

    function w3_close() {
        document.getElementById("mySidebar").style.display = "none";
        document.getElementById("myOverlay").style.display = "none";
    }

    function showmarcar() {
        document.getElementById("consultar").style.display = "none";
        document.getElementById("pconsultar").style.display = "none";
        document.getElementById("MC").innerHTML = "Marcação de Presenças";
        document.getElementById("marcar").style.display = "table";
        document.getElementById("pmarcar").style.display = "table";
    }

    function showconsultar() {
        document.getElementById("marcar").style.display = "none";
        document.getElementById("pmarcar").style.display = "none";
        document.getElementById("MC").innerHTML = "Consulta de Presenças";
        document.getElementById("consultar").style.display = "table";
        document.getElementById("pconsultar").style.display = "table";
    }