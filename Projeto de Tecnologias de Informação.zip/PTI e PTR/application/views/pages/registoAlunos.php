<?php
    include('../application/controllers/openconn.php');
    include('../application/controllers/adminController.php');
?>
<html>

<head>
    <title>Registar Manualmente Alunos</title>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="description" content="Registar alunos.">
    <meta name="author" content="Grupo 07">
    <link rel="stylesheet" href="https://www.w3schools.com/w3css/4/w3.css">
    <link rel="stylesheet" href="https://fonts.googleapis.com/css?family=Roboto">
    <link rel="stylesheet" href="https://fonts.googleapis.com/css?family=Montserrat">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
    <link rel="stylesheet" type="text/css"
        href="https://rawcdn.githack.com/luisconceicaodev/PTIPTR/e91a26e54b23ed0b9733e17815954965c63d33c5/assets/css/template.css">
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/css/bootstrap.min.css"
        integrity="sha384-Gn5384xqQ1aoWXA+058RXPxPg6fy4IWvTNh0E263XmFcJlSAwiGgFAW/dAiS6JXm" crossorigin="anonymous">
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.4.0/jquery.min.js"></script>
    <script src="https://code.jquery.com/jquery-3.4.1.js"
        integrity="sha256-WpOohJOqMqqyKL9FccASB9O0KwACQJpFTUBLTYOVvVU=" crossorigin="anonymous"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.12.9/umd/popper.min.js"
        integrity="sha384-ApNbgh9B+Y1QKtv3Rn7W3mgPxhU9K/ScQsAP7hUibX39j7fakFPskvXusvfa0b4Q" crossorigin="anonymous">
    </script>
    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/js/bootstrap.min.js"
        integrity="sha384-JZR6Spejh4U02d8jOt6vLEHfe/JQGiRRSQQxSfFWpi1MquVdAyjUar5+76PVCmYl" crossorigin="anonymous">
    </script>
    <script src="https://rawcdn.githack.com/luisconceicaodev/PTIPTR/e91a26e54b23ed0b9733e17815954965c63d33c5/assets/js/javascript.js"></script>
</head>


<body class="w3-content" style="background-size:cover;background-repeat:no-repeat;"
    background="https://i.imgur.com/A377rwe.jpg">

    <!-- Sidebar/menu -->
    <nav class="w3-sidebar w3-bar-block w3-white w3-collapse w3-top container-fluid col-xs-2"
        style="z-index:3;width:20%;height:100%;position:fixed;top:0;left:0;" id="mySidebar">
        <i onclick="w3_close()" class="fa fa-remove w3-hide-large w3-button w3-display-topright"></i>
        <h3 class="w3-wide"><a href="<?php echo base_url(); ?>admin"><img src="https://i.imgur.com/8irrbgV.png"
                    height="350px"></a></h3>
        <div class="w3-large w3-text-grey countainer-fluid" style="font-weight:bold">

            <button type="button" id="login" class="btn btn-primary" data-toggle="modal"
                data-target="#myModal">Login</button>

            <div id="divlogoff" style="display:none">
                <span id="user" class="w3-bar-item w3-button w3-right" style="margin-right:-1.4%"></span>
                <form action="<?php echo base_url();?>admin?off=true" method="POST">
                    <button id="logoff" href="<?php echo base_url();?>admin?off=true" class="btn btn-primary"></button>
                </form>
            </div>

            <div id='sub-menu-admin' style='display:none;'>
                <a onclick="myAccFunc5()" href="javascript:void(0)" class="w3-button w3-block w3-left-align">
                    Menu de Administrador <i class="fa fa-caret-down"></i>
                </a>
                <div id="demoAcc5" class="w3-bar-block w3-hide w3-padding-large w3-medium">
                    <a href="<?php echo base_url(); ?>registoAlunos" class="w3-bar-item w3-button">Registo de alunos</a>
                    <a href="<?php echo base_url(); ?>registoProfessores" class="w3-bar-item w3-button">Registo de
                        professores</a>
                    <a href="<?php echo base_url(); ?>verDados" class="w3-bar-item w3-button">Ver todos os dados</a>
                </div>
            </div>
        </div>
        </div>
    </nav>

    <!-- Top menu on small screens -->
    <header class="w3-bar w3-top w3-hide-large w3-white w3-xlarge">
        <div class="w3-bar-item w3-padding-24 w3-wide"><a href="<?php echo base_url(); ?>admin"
                style='text-decoration:none;color : #000;'>FCUL</a></div>
        <a href="javascript:void(0)" class="w3-bar-item w3-button w3-padding-24 w3-right" onclick="w3_open()"><i
                class="fa fa-bars"></i></a>
    </header>

    <!-- Overlay effect when opening sidebar on small screens -->
    <div class="w3-overlay w3-hide-large" onclick="w3_close()" style="cursor:pointer" title="close side menu"
        id="myOverlay"></div>

    <!-- !PAGE CONTENT! -->
    <!-- Push down content on small screens -->
    <div class="w3-container mainbox col-xs-2" style='margin-top: 6em !important'>
        <form class="animate" action="<?php echo base_url();?>registoAlunos" style="padding: 2% 2% 2% 2%" method="POST">
            <label for="uname" style="text-align: center;"><b>
                    <h1>Registo Manual de Aluno</h1>
                </b></label>

            <div class="container">

                <label for="text"><b>Nº de Aluno:</b></label><br>
                <input type="number" min="10000" max="99999" placeholder="Indique o nº do aluno" name="numero" required>
                <br>
                <label for="text"><b>Nome:</b></label>
                <input type="text" placeholder="Indique o nome do aluno" name="nome" required>
                <br>
                <label for="email"><b>Email:</b></label><br>
                <input type="email" placeholder="Indique o email do aluno" name="email" required>
                <br>
                <label for="curso" class="light"><b>Curso:</b></label>
                <select style='width:100%' required id="curso" name="curso">
                    <option value="" selected>Selecione um curso</option>
                    <option value="Licenciatura em Biologia">Licenciatura em Biologia</option>
                    <option value="Licenciatura em Bioquímica">Licenciatura em Bioquímica</option>
                    <option value="Licenciatura em Ciências da Saúde">Licenciatura em Ciências da Saúde</option>
                    <option value="Licenciatura em Engenharia Geoespacial">Licenciatura em Engenharia Geoespacial
                    </option>
                    <option value="Licenciatura em Engenharia Informática">Licenciatura em Engenharia Informática
                    </option>
                    <option value="Licenciatura em Estatística Aplicada">Licenciatura em Estatística Aplicada</option>
                    <option value="Licenciatura em Estudos Gerais">Licenciatura em Estudos Gerais</option>
                    <option value="Licenciatura em Física">Licenciatura em Física</option>
                    <option value="Licenciatura em Geologia">Licenciatura em Geologia</option>
                    <option value="Licenciatura em Matemática">Licenciatura em Matemática</option>
                    <option value="Licenciatura em Matemática Aplicada">Licenciatura em Matemática Aplicada</option>
                    <option value="Licenciatura em Meteologia, Oceanografia e Geofísica">Licenciatura em Meteologia,
                        Oceanografia e Geofísica</option>
                    <option value="Licenciatura em Química">Licenciatura em Química</option>
                    <option value="Licenciatura em Química Tecnológica">Licenciatura em Química Tecnológica</option>
                    <option value="Licenciatura em Tecnologias de Informação">Licenciatura em Tecnologias de Informação
                    </option>
                    <option value="Mestrado Integrado em Engenharia Biomédica e Biofísica">Mestrado Integrado em
                        Engenharia Biomédica e Biofísica</option>
                    <option value="Mestrado Integrado em Engenharia da Energia e do Ambiente">Mestrado Integrado em
                        Engenharia da Energia e do Ambiente</option>
                    <option value="Mestrado Integrado em Engenharia Física">Mestrado Integrado em Engenharia Física
                    </option>
                    <option value="Mestrado em Bioestatística">Mestrado em Bioestatística</option>
                    <option value="Mestrado em Bioinformática e Biologia Computacional">Mestrado em Bioinformática e
                        Biologia Computacional</option>
                    <option value="Mestrado em Biologia da Conservação">Mestrado em Biologia da Conservação</option>
                    <option value="Mestrado em Biologia dos Recursos Vegetais">Mestrado em Biologia dos Recursos
                        Vegetais</option>
                    <option value="Mestrado em Biologia Evolutiva e do Desenvolvimento">Mestrado em Biologia Evolutiva e
                        do Desenvolvimento</option>
                    <option value="Mestrado em Biologia Humana e Ambiente">Mestrado em Biologia Humana e Ambiente
                    </option>
                    <option value="Mestrado em Biologia Molecular e Genética">Mestrado em Biologia Molecular e Genética
                    </option>
                    <option value="Mestrado em Bioquímica">Mestrado em Bioquímica</option>
                    <option value="Mestrado em Ciência Cognitiva">Mestrado em Ciência Cognitiva</option>
                    <option value="Mestrado em Ciência de Dados">Mestrado em Ciência de Dados</option>
                    <option value="Mestrado em Ciências do Mar">Mestrado em Ciências do Mar</option>
                    <option value="Mestrado em Ciências Geofísicas">Mestrado em Ciências Geofísicas</option>
                    <option value="Mestrado em Cultura Científica e Divulgação das Ciências">Mestrado em Cultura
                        Científica e Divulgação das Ciências</option>
                    <option value="Mestrado em Ecologia e Gestão Ambiental">Mestrado em Ecologia e Gestão Ambiental
                    </option>
                    <option value="Mestrado em Ecologia Marinha">Mestrado em Ecologia Marinha</option>
                    <option value="Mestrado em Engenharia Geoespacial">Mestrado em Engenharia Geoespacial</option>
                    <option value="Mestrado em Engenharia Informática">Mestrado em Engenharia Informática</option>
                    <option
                        value="Mestrado em Ensino de Biologia e Geologia no 3.º ciclo do Ensino Básico e no Ensino Secundário">
                        Mestrado em Ensino de Biologia e Geologia no 3.º ciclo do Ensino Básico e no Ensino Secundário
                    </option>
                    <option
                        value="Mestrado em Ensino de Física e de Química no 3.º Ciclo do Ensino Básico e no Ensino Secundário">
                        Mestrado em Ensino de Física e de Química no 3.º Ciclo do Ensino Básico e no Ensino Secundário
                    </option>
                    <option value="Mestrado em Ensino de Informática">Mestrado em Ensino de Informática</option>
                    <option value="Mestrado em Ensino de Matemática no 3.º Ciclo do Ensino Básico e no Secundário">
                        Mestrado em Ensino de Matemática no 3.º Ciclo do Ensino Básico e no Secundário</option>
                    <option value="Mestrado em Estatística e Investigação Operacional">Mestrado em Estatística e
                        Investigação Operacional</option>
                    <option value="Mestrado em Física">Mestrado em Física</option>
                    <option value="Mestrado em Geologia">Mestrado em Geologia</option>
                    <option value="Mestrado em Geologia Aplicada">Mestrado em Geologia Aplicada</option>
                    <option value="Mestrado em Geologia do Ambiente, Riscos Geológicos e Ordenamento do Território">
                        Mestrado em Geologia do Ambiente, Riscos Geológicos e Ordenamento do Território</option>
                    <option value="Mestrado em Geologia Económica">Mestrado em Geologia Económica</option>
                    <option value="Mestrado em História e Filosofia das Ciências">Mestrado em História e Filosofia das
                        Ciências</option>
                    <option value="Mestrado em Informática">Mestrado em Informática</option>
                    <option value="Mestrado em Matemática">Mestrado em Matemática</option>
                    <option value="Mestrado em Matemática Aplicada à Economia e Gestão">Mestrado em Matemática Aplicada
                        à Economia e Gestão</option>
                    <option value="Mestrado em Matemática Financeira">Mestrado em Matemática Financeira</option>
                    <option value="Mestrado em Matemática para Professores">Mestrado em Matemática para Professores
                    </option>
                    <option value="Mestrado em Microbiologia">Mestrado em Microbiologia</option>
                    <option value="Mestrado em Microbiologia Aplicada">Mestrado em Microbiologia Aplicada</option>
                    <option value="Mestrado em Navegação e Geomática">Mestrado em Navegação e Geomática</option>
                    <option value="Mestrado em Química">Mestrado em Química</option>
                    <option value="Mestrado em Química Tecnológica">Mestrado em Química Tecnológica</option>
                    <option value="Mestrado em Segurança Informática">Mestrado em Segurança Informática</option>
                    <option value="Mestrado em Sistemas de Informação Geográfica - Tecnologias e Aplicações">Mestrado em
                        Sistemas de Informação Geográfica - Tecnologias e Aplicações</option>
                    <option value="Doutoramento em Alterações Climáticas e Políticas de Desenvolvimento Sustentável">
                        Doutoramento em Alterações Climáticas e Políticas de Desenvolvimento Sustentável</option>
                    <option value="Doutoramento em Astronomia e Astrofísica">Doutoramento em Astronomia e Astrofísica
                    </option>
                    <option value="Doutoramento em Biodiversidade, Genética e Evolução">Doutoramento em Biodiversidade,
                        Genética e Evolução</option>
                    <option value="Doutoramento em Biologia">Doutoramento em Biologia</option>
                    <option value="Doutoramento em Biologia e Ecologia das Alterações Globais">Doutoramento em Biologia
                        e Ecologia das Alterações Globais</option>
                    <option value="Doutoramento em Bioquímica">Doutoramento em Bioquímica</option>
                    <option value="Doutoramento em Ciência Cognitiva">Doutoramento em Ciência Cognitiva</option>
                    <option value="Doutoramento em Ciências da Complexidade">Doutoramento em Ciências da Complexidade
                    </option>
                    <option value="Doutoramento em Ciências da Sustentabilidade">Doutoramento em Ciências da
                        Sustentabilidade</option>
                    <option value="Doutoramento em Ciências do Mar">Doutoramento em Ciências do Mar</option>
                    <option value="Doutoramento em Ciências Geofísicas e da Geoinformação">Doutoramento em Ciências
                        Geofísicas e da Geoinformação</option>
                    <option value="Doutoramento em Energia e Desenvolvimento Sustentável">Doutoramento em Energia e
                        Desenvolvimento Sustentável</option>
                    <option value="Doutoramento em Engenharia Biomédica e Biofísica">Doutoramento em Engenharia
                        Biomédica e Biofísica</option>
                    <option value="Doutoramento em Engenharia Física">Doutoramento em Engenharia Física</option>
                    <option value="Doutoramento em e-Planeamento">Doutoramento em e-Planeamento</option>
                    <option value="Doutoramento em Estatística e Investigação Operacional">Doutoramento em Estatística e
                        Investigação Operacional</option>
                    <option value="Doutoramento em Filosofia da Ciência, Tecnologia, Arte e Sociedade">Doutoramento em
                        Filosofia da Ciência, Tecnologia, Arte e Sociedade</option>
                    <option value="Doutoramento em Física">Doutoramento em Física</option>
                    <option value="Doutoramento em Geologia">Doutoramento em Geologia</option>
                    <option value="Doutoramento em História e Filosofia das Ciências">Doutoramento em História e
                        Filosofia das Ciências</option>
                    <option value="Doutoramento em Informática">Doutoramento em Informática</option>
                    <option value="Doutoramento em Matemática">Doutoramento em Matemática</option>
                    <option value="Doutoramento em Otimização de Sistemas Industriais e de Serviços">Doutoramento em
                        Otimização de Sistemas Industriais e de Serviços</option>
                    <option value="Doutoramento em Química">Doutoramento em Química</option>
                    <option value="Doutoramento em Sistemas Sustentáveis de Energia">Doutoramento em Sistemas
                        Sustentáveis de Energia</option>
                </select>
                <br>
                <label for="pass"><b>Password:</b></label>
                <input type="password" placeholder="Indique a password do aluno" name="pass" required>
                <br>
                <button type="submit" name="Registo_Aluno" value="Registar">Registar</button>

            </div>
        </form>
    </div>

    <!-- Login -->
    <div id="myModal" class="modal fade" tabindex="-1" role="dialog" aria-labelledby="exampleModalCenterTitle"
        aria-hidden="true">
        <div class="modal-dialog modal-dialog-centered" role="document">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title" id="exampleModalLongTitle">Autenticação de Utilizador</h5>
                    <button type="button" id="fecharmod" class="close" data-dismiss="modal" aria-label="Close">
                        <span aria-hidden="true">&times;</span>
                    </button>
                </div>
                <div class="modal-body">
                    <form action="<?php echo base_url();?>admin" method="POST">
                        <label for="email"><b>Email:</b></label>
                        <input type="text" placeholder="Indique o seu email" name="email" required>
                        <label for="pass"><b>Password:</b></label>
                        <input type="password" placeholder="Indique a sua password" name="pass" required>
                </div>
                <div class="modal-footer">
                    <button type="submit" class="btn btn-primary" name="Login_Admin" value="Login">Entrar</button>
                </div>
                </form>
            </div>
        </div>
    </div>
</body>

</html>