<?php
    include('../application/controllers/openconn.php');
    include('../application/controllers/presencasController.php');
?>
<!DOCTYPE html>
<html>

<head>
    <title>Presenças</title>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="author" content="Grupo 07">
    <link rel="stylesheet" href="https://www.w3schools.com/w3css/4/w3.css">
    <link rel="stylesheet" href="https://fonts.googleapis.com/css?family=Roboto">
    <link rel="stylesheet" href="https://fonts.googleapis.com/css?family=Montserrat">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
    <link rel="stylesheet" type="text/css" href="https://rawcdn.githack.com/luisconceicaodev/PTIPTR/e91a26e54b23ed0b9733e17815954965c63d33c5/assets/css/template.css">
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/css/bootstrap.min.css"
        integrity="sha384-Gn5384xqQ1aoWXA+058RXPxPg6fy4IWvTNh0E263XmFcJlSAwiGgFAW/dAiS6JXm" crossorigin="anonymous">
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.4.0/jquery.min.js"></script>
    <script src="https://code.jquery.com/jquery-3.4.1.js"
    integrity="sha256-WpOohJOqMqqyKL9FccASB9O0KwACQJpFTUBLTYOVvVU="
    crossorigin="anonymous"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.12.9/umd/popper.min.js"
        integrity="sha384-ApNbgh9B+Y1QKtv3Rn7W3mgPxhU9K/ScQsAP7hUibX39j7fakFPskvXusvfa0b4Q" crossorigin="anonymous">
    </script>
    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/js/bootstrap.min.js"
        integrity="sha384-JZR6Spejh4U02d8jOt6vLEHfe/JQGiRRSQQxSfFWpi1MquVdAyjUar5+76PVCmYl" crossorigin="anonymous">
    </script>
    <script src="https://rawcdn.githack.com/luisconceicaodev/PTIPTR/e91a26e54b23ed0b9733e17815954965c63d33c5/assets/js/javascript.js"></script>
</head>

<body class="w3-content" style="background-size: cover;background-repeat: no-repeat;"
    background="https://i.imgur.com/A377rwe.jpg">

    <!-- Sidebar/menu -->
        <nav class="w3-sidebar w3-bar-block w3-white w3-collapse w3-top container-fluid col-xs-2"
        style="z-index:3;width:20%;height:100%;position:fixed;top:0;left:0;" id="mySidebar">
        <i onclick="w3_close()" class="fa fa-remove w3-hide-large w3-button w3-display-topright"></i>
        <h3 class="w3-wide"><a href="<?php echo base_url(); ?>"><img src="https://i.imgur.com/8irrbgV.png"
                    height="350px"></a></h3>
        <div class="w3-large w3-text-grey countainer-fluid" style="font-weight:bold">

            <button type="button" id="login" class="btn btn-primary" data-toggle="modal"
                data-target="#myModal">Login</button>

            <div id="divlogoff" style="display:none">
                <span id="user" class="w3-bar-item w3-button w3-right" style="margin-right:-1.4%"></span>
                <form action="<?php echo base_url();?>home?off=true" method="POST">
                    <button id="logoff" href="<?php echo base_url();?>home?off=true" class="btn btn-primary"></button>
                </form>
            </div>

            <div id='menu-aluno' style='display:none'>
                <a href="<?php echo base_url(); ?>infoPessoa" class="w3-bar-item w3-button">Área Pessoal</a>

                <div id='aluno-1' style=''>
                    <a onclick="myAccFunc()" href="javascript:void(0)" class="w3-button w3-block w3-left-align">
                        Consultar <i class="fa fa-caret-down"></i>
                    </a>
                    <div id="demoAcc" class="w3-bar-block w3-hide w3-padding-large w3-medium">
                        <a href="<?php echo base_url(); ?>horario" class="w3-bar-item w3-button">Horário</a>
                        <a href="<?php echo base_url(); ?>classificacoes" class="w3-bar-item w3-button">Classificações</a>
                    </div>
                </div>

                <div id='aluno-2' style=''>
                    <a onclick="myAccFunc2()" href="javascript:void(0)" class="w3-button w3-block w3-left-align">
                        Inscrever <i class="fa fa-caret-down"></i>
                    </a>
                    <div id="demoAcc2" class="w3-bar-block w3-hide w3-padding-large w3-medium">
                        <a href="<?php echo base_url(); ?>inscricaoUC" class="w3-bar-item w3-button">Disciplinas</a>
                        <a href="<?php echo base_url(); ?>inscricaoExames" class="w3-bar-item w3-button">Exames</a>
                    </div>
                </div>

                <div id='aluno-3' style=''>
                    <a onclick="myAccFunc3()" href="javascript:void(0)" class="w3-button w3-block w3-left-align">
                        Gerir Disciplinas <i class="fa fa-caret-down"></i>
                    </a>
                    <div id="demoAcc3" class="w3-bar-block w3-hide w3-padding-large w3-medium">
					<a href="<?php echo base_url(); ?>presencas" class="w3-bar-item w3-button">Presenças</a>
                        <a href="<?php echo base_url(); ?>grupos" class="w3-bar-item w3-button">Formação de
                            grupos</a>
                        <a href="<?php echo base_url(); ?>mudancasTurma" class="w3-bar-item w3-button">Solicitar
                            mudança de turma</a>
                    </div>
                </div>
            </div>

            <div id='menu-prof' style='display:none'>
                <a href="<?php echo base_url(); ?>infoPessoa" class="w3-bar-item w3-button">Área Pessoal</a>

                <div id='prof-1'>
                    <a onclick="myAccFunc4()" href="javascript:void(0)" class="w3-button w3-block w3-left-align">
                        Consultar <i class="fa fa-caret-down"></i>
                    </a>
                    <div id="demoAcc4" class="w3-bar-block w3-hide w3-padding-large w3-medium">
                        <a href="<?php echo base_url(); ?>horario" class="w3-bar-item w3-button">Horário</a>
                        <a href="<?php echo base_url(); ?>inscritosProfessor" class="w3-bar-item w3-button">Inscritos nas disciplinas</a>
                        <a href="<?php echo base_url(); ?>verinscritosexames" class="w3-bar-item w3-button">Inscritos nos exames</a>
                        <a href="<?php echo base_url(); ?>presencasProfessor" class="w3-bar-item w3-button">Presenças</a>
                    </div>
                </div>

                <div id='prof-2'>
                    <a onclick="myAccFunc5()" href="javascript:void(0)" class="w3-button w3-block w3-left-align">
                        Gerir Disciplinas <i class="fa fa-caret-down"></i>
                    </a>
                    <div id="demoAcc5" class="w3-bar-block w3-hide w3-padding-large w3-medium">
                        <a href="<?php echo base_url(); ?>gerirturmas" class="w3-bar-item w3-button">Gerir
                            turmas</a>
                        <a href="<?php echo base_url(); ?>pedidosProfessor" class="w3-bar-item w3-button">Gerir
                            pedidos</a>
							<a href="<?php echo base_url(); ?>gruposProfessor" class="w3-bar-item w3-button">Grupos de
                            trabalho</a>
						<a href="<?php echo base_url(); ?>auladeapoio" class="w3-bar-item w3-button">Marcar aula de apoio</a>
                        <a href="<?php echo base_url(); ?>gerirclassificacoes" class="w3-bar-item w3-button">Atribuir
                            classificações</a>
                    </div>
                </div>

                <div id='prof-3'>
                    <a onclick="myAccFunc6()" href="javascript:void(0)" class="w3-button w3-block w3-left-align">
                        Gerir Conflitos <i class="fa fa-caret-down"></i>
                    </a>
                    <div id="demoAcc6" class="w3-bar-block w3-hide w3-padding-large w3-medium">
                        <a href="<?php echo base_url(); ?>conflitohorario" class="w3-bar-item w3-button">Incompatibilidade de horário</a>
                        <a href="<?php echo base_url(); ?>conflitogrupo" class="w3-bar-item w3-button">Alunos sem grupo</a>
                    </div>
                </div>
            </div>

        </div>
    </nav>

    <!-- Top menu on small screens -->
    <header class="w3-bar w3-top w3-hide-large w3-white w3-xlarge">
        <div class="w3-bar-item w3-padding-24 w3-wide"><a href="<?php echo base_url(); ?>" style='text-decoration:none;color : #000;'>FCUL</a></div>
        <a href="javascript:void(0)" class="w3-bar-item w3-button w3-padding-24 w3-right" onclick="w3_open()"><i
                class="fa fa-bars"></i></a>
    </header>

    <!-- Overlay effect when opening sidebar on small screens -->
    <div class="w3-overlay w3-hide-large" onclick="w3_close()" style="cursor:pointer" title="close side menu"
        id="myOverlay"></div>

    <!-- Login -->
    <div id="myModal" class="modal fade" tabindex="-1" role="dialog" aria-labelledby="exampleModalCenterTitle"
        aria-hidden="true">
        <div class="modal-dialog modal-dialog-centered" role="document">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title" id="exampleModalLongTitle">Autenticação de Utilizador</h5>
                    <button type="button" id="fecharmod" class="close" data-dismiss="modal" aria-label="Close">
                        <span aria-hidden="true">&times;</span>
                    </button>
                </div>
                <div class="modal-body">
                    <form action="<?php echo base_url();?>infoPessoa" method="POST">
                        <label for="email"><b>Email:</b></label>
                        <input type="text" placeholder="Indique o seu email" name="email" required>
                        <label for="pass"><b>Password:</b></label>
                        <input type="password" placeholder="Indique a sua password" name="pass" required>
                </div>
                <div class="modal-footer">
                    <button type="submit" class="btn btn-primary" name="Login" value="Login">Entrar</button>
                </div>
                </form>
            </div>
        </div>
    </div>

</body>

</html>