<html>

<head>
    <title>PTI PTR Grupo 007</title>
    <link rel="stylesheet" href="https://bootswatch.com/4/flatly/bootstrap.min.css">
</head>

<body>
    <div class="navbar fixed-left">
        <a href="<?php echo base_url(); ?>/about">About</a>
    </div>