<?php
$url = $_SERVER['REQUEST_URI'];
if ($url === '/gerirclassificacoes') {
    echo "<div class='w3-container mainbox' id='AC'>
    <h1 id='MC'>Atribuir Classificações</h1>
    <br>";
    echo "<p>Selecione a disciplina à qual pretende atribuir classificações.</p>";
    $sql = "SELECT id, nome
    FROM uc
    WHERE coordenador = $numero";
    $connect = $conn->query($sql);
    if ($connect == TRUE) {
        if($connect->num_rows > 0) {
            echo "<table class='w3-table-all table-responsive table' id='consultar'>
            <tr class='w3-indigo'>
            <th>" . "Disciplina" . "</th>";
            while($row = mysqli_fetch_array($connect,MYSQLI_ASSOC)){
                echo "<tr>";
            foreach ($row as $chave => $valor){
                if ($chave !== 'id'){
                    echo "<td>" . $valor . "</td>";
                }
            }
            echo "<td><form action='classificacoesalunos' method='POST'>
                <input type='submit' class='btn btn-primary' name='ucclass' value='Selecionar'/>
                <input type='hidden' name='ucprof' href='' value='$row[id]'>
                <input type='hidden' name='ucnomeprof' href='' value='$row[nome]'>
                </form></td>";
            echo "</tr>";
            }   
            echo "</table>";
            echo "</div>";
        }else{ # se professor não for coordenador de nenhuma UC 
            echo "</div>";
            echo "<script type='text/javascript'>",
                    "document.getElementById('AC').style.display='none';",
                "</script>";
                echo "<div class='w3-container mainbox'><h1>Você não tem permissões de coordenador nas unidades curriculares.</h1></div>";
        }
    }else {
        echo "Error creating table: " . $conn->error;
    }
}elseif($url === '/classificacoesalunos') {
    if(isset($_POST ['ucprof']) && isset($_POST ['ucnomeprof'])) {
        $_SESSION['iddauc'] =  $_POST ['ucprof'];
        $_SESSION['nomedauc'] = $_POST ['ucnomeprof'];
    }
    if(isset($_SESSION['iddauc']) && isset($_SESSION['nomedauc'])) {
        $id_uc = $_SESSION['iddauc'];
        $nome_uc = $_SESSION['nomedauc'];
        $sql = "SELECT DISTINCT aluno_id, NULL
        FROM inscritos
        WHERE NOT EXISTS(
        SELECT uc_id, aluno_id 
            FROM classificacoes
            WHERE classificacoes.aluno_id = inscritos.aluno_id AND classificacoes.uc_id = inscritos.uc_id
        ) AND inscritos.uc_id = '$id_uc'";
        $connect = $conn->query($sql);
        if ($connect == TRUE) {
            if($connect->num_rows > 0) {
                echo "<div class='w3-container mainbox'>
                    <h1>Atribuir Classificações</h1>
                <br>";
                echo "<table class='w3-table-all table-responsive table' id='consultar'>
                <tr class='w3-indigo'>
                <th>" . "Aluno" . "</th>
                <th>" . "Aval. Contínua" . "</th>
                <th>" . "Aval. Periódica" . "</th>
                <th>" . "Exame 1ª Freq." . "</th>
                <th>" . "Exame 2ª Freq." . "</th>
                <th>" . "Exame 1ª Fase" . "</th>
                <th>" . "Exame 2ª Fase" . "</th>
                <th>" . "Classificação Final" . "</th>";
                while($row = mysqli_fetch_array($connect,MYSQLI_ASSOC)){
                    $cycle = 0;
                    echo "<tr id='$row[aluno_id]'>";
                foreach ($row as $chave => $valor){
                    if ($chave == 'aluno_id') {
                        echo "<td>" . $valor . "</td>";
                    }else{
                        echo "<form action='classificacoesalunos' method='POST'>";
                        echo "<td><input type='number' name='continua' style='width: 4em;' min='0' max='20' step='0.01'></td>";
                        echo "<td><input type='number' name='periodica' style='width: 4em;' min='0' max='20' step='0.01'></td>";
                        echo "<td><input type='number' name='examefreq1' style='width: 4em;' min='0' max='20' step='0.01'></td>";
                        echo "<td><input type='number' name='examefreq2' style='width: 4em;' min='0' max='20' step='0.01'></td>";
                        echo "<td><input type='number' name='exame1' style='width: 4em;' min='0' max='20' step='0.01'></td>";
                        echo "<td><input type='number' name='exame2' style='width: 4em;' min='0' max='20' step='0.01'></td>";
                        echo "<td><input type='number' name='final' style='width: 4em;' min='0' max='20' step='0.01' required></td>";
                        echo "<td><input type='submit' class='btn btn-primary' name='atribuir' value='Atribuir Nota/s'/>
                        <input type='hidden' name='ucid' href='' value='$id_uc'>
                        <input type='hidden' name='ucname' href='' id='join' value='$nome_uc'>
                        <input type='hidden' name='aluno' href='' value='$row[aluno_id]'>
                        </td></form>";
                    }
                }
                echo "</tr>";
                }
            }else{
                echo "<div class='w3-container mainbox'><h1>Não há alunos sem classificação atribuida nesta disciplina.</h1></div>";
            }
            }else{
                echo "<div class='w3-container mainbox'><h1>Não há alunos inscritos nesta disciplina.</h1></div>";
            }
            echo "</table>";
            echo "</div>";
    
            if(isset($_POST['atribuir'])){
                $id_uc = $_POST ['ucid'];
                $nome_uc = $_POST ['ucname'];
                $aluno = $_POST ['aluno'];
                $continua = $_POST ['continua'];
                $periodica = $_POST ['periodica'];
                $examefreq1 = $_POST ['examefreq1'];
                $examefreq2 = $_POST ['examefreq2'];
                $exame1 = $_POST ['exame1'];
                $exame2 = $_POST ['exame2'];
                $final = $_POST ['final'];
                
                $sql = "INSERT INTO classificacoes (uc_id,aluno_id,continua,periodica,examefreq1,examefreq2,exame1,exame2,final) 
                VALUES('$id_uc','$aluno','$continua','$periodica','$examefreq1','$examefreq2','$exame1','$exame2','$final')";
                if ($conn->query($sql) == TRUE) {
                    $sql = "INSERT INTO notificacao (para,de,mensagem) VALUES('$aluno','$nome','Foram publicadas classificações para a disciplina de $nome_uc, poderá as consultar através da opção Consultar->Classificações do menu.')";
                        $result = mysqli_query($conn, $sql);
                        echo "<div class='toast__container'>
                <div class='toast__cell mainbox'>
                    <div class='toast toast--green'>
                        <div class='toast__icon'>
                        </div>
                        <div class='toast__content'>
                            <p class='toast__type'>Sucesso</p>
                            <p class='toast__message'>Nota(s) atribuída(s).</p>
                        </div>
                        <div class='toast__close'>
                            X
                        </div>
                    </div>
                </div>
            </div>";
            echo "<script type='text/javascript'>",
        "document.getElementById('$aluno').style.display='none';",
        "</script>";
                        }else {
                            echo "<div class='toast__container'>
                <div class='toast__cell mainbox'>
                <div class='toast toast--yellow'>
                  <div class='toast__icon'>
                  </div>
                  <div class='toast__content'>
                    <p class='toast__type'>Erro</p>
                    <p class='toast__message'>A atribuição de nota falhou.</p>
                  </div>
                  <div class='toast__close'>
                    X
                  </div>
                </div>
                </div>
                </div>";
                    }
            }
    }
}
?>