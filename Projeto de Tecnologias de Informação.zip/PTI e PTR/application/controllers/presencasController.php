<?php
header('Content-Type: text/html; charset=utf-8');
$url = $_SERVER['REQUEST_URI'];
if ($url === '/presencas') {
    echo "<div class='w3-container mainbox' id='firstbox'>
    <h1 id='MC'>Marcação de Presenças</h1>
    <br>
    <div class='w3-bar w3-border w3-light-grey'>
        <button onclick='showmarcar()' class='w3-bar-item w3-button w3-indigo' style='margin-right:1em'>Marcar Presenças</button>
        <button onclick='showconsultar()' class='w3-bar-item w3-button w3-indigo'>Consultar Presenças</button>
    </div>
    ";
    echo "<p id='pmarcar'>Selecione a Unidade à qual pretende marcar presença:</p>";
    $sql = "SELECT id,nome
    FROM uc
    WHERE EXISTS (
        SELECT *
        FROM inscritos AS i 
        WHERE uc.id=i.uc_id AND '$numero' = i.aluno_id
    )";
    $connect = $conn->query($sql);
    if ($connect == TRUE) {
        if($connect->num_rows > 0) {
        echo "<table class='w3-table-all table-responsive table' id='marcar'>
        <tr class='w3-indigo'>
        <th>" . "Unidade Curricular" . "</th>";
        while($row = mysqli_fetch_array($connect,MYSQLI_ASSOC)){
            echo "<tr>";
        foreach ($row as $chave => $valor){
            if ($chave !== 'id'){
                echo "<td>" . $valor . "</td>";
            }
        }
            echo "<td><form action='presencas' method='POST'>
                <input type='submit' class='btn btn-primary' name='marcar' value='Marcar'/>
                <input type='hidden' name='marcar' href='' value='$row[id]'>
                </form></td>";
            echo "</tr>";
        }
    }else{
        echo "</div></table>";
        echo "<script type='text/javascript'>",
                    "document.getElementById('firstbox').style.display='none';",
                    "</script>";
        echo "<div class='toast__container'>
        <div class='toast__cell mainbox'>
        <div class='toast toast--yellow'>
          <div class='toast__icon'>
          </div>
          <div class='toast__content'>
            <p class='toast__type'>Erro</p>
            <p class='toast__message'>Você não está inscrito em disciplinas.</p>
          </div>
          <div class='toast__close'>
            X
          </div>
        </div>
        </div>
        </div>";
    }

} else {
            echo "Error creating table: " . $conn->error;
}
echo "</table>";

echo "<p id='pconsultar' style='display:none'>Selecione a Unidade à qual pretende consultar as suas presenças:</p>";
$sql = "SELECT id,nome
    FROM uc
    WHERE EXISTS (
        SELECT *
        FROM inscritos AS i 
        WHERE uc.id=i.uc_id AND '$numero' = i.aluno_id
    )";
$connect = $conn->query($sql);
if ($connect == TRUE) {
    echo "<table class='w3-table-all table-responsive table' id='consultar' style='display:none'>
    <tr class='w3-indigo'>
    <th>" . "Unidade Curricular" . "</th>";
while($row = mysqli_fetch_array($connect,MYSQLI_ASSOC)){
    echo "<tr>";
foreach ($row as $chave => $valor){
    if ($chave !== 'id'){
        echo "<td>" . $valor . "</td>";
    }
}
    echo "<td><form action='presencas' method='POST'>
        <input type='submit' class='btn btn-primary' name='consultar' value='Consultar'/>
        <input type='hidden' name='consultar' href='' id='join' value='$row[id]'>
        </form></td>";
    echo "</tr>";
}

} else {
            echo "Error creating table: " . $conn->error;
}
echo "</table>";
echo "<p id='notification' style='display:none'></p>";
echo "</div>";
}

if(isset($_POST['marcar'])){
    echo "<script type='text/javascript'>",
        "document.getElementById('marcar').style.display='none';",
        "document.getElementById('consultar').style.display='none';",
        "document.getElementById('firstbox').style.display='none';",
    "</script>";
    $id_uc = $_POST ['marcar'];
    echo "<div class='w3-container mainbox'>
        <h1 id='MC'>Marcação de Presenças</h1>
        <br>
        ";
        echo "<p id='pmarcar'>Horários da unidade curricular a que está inscrito e que ainda não marcou presença hoje:</p>";
        $sql = "SELECT id, tipo, dia_semana, hora_inicio, hora_fim, sala
        FROM turma
        WHERE EXISTS (
          SELECT *
          FROM inscritos AS i 
          WHERE turma.id=i.turma_id AND '$numero' = i.aluno_id and i.uc_id = '$id_uc'
        )";
        $connect = $conn->query($sql);
        if ($connect == TRUE) {
        echo "<table class='w3-table-all table-responsive table' id='marcar'>
        <tr class='w3-indigo'>
        <th>" . "Tipo" . "</th>
        <th>" . "Dia da semana" . "</th>
        <th>" . "Hora de Inicio" . "</th>
        <th>" . "Hora de Terminio" . "</th>
        <th>" . "Sala" . "</th>
        <th>" . "Marcação" . "</th>";
        while($row = mysqli_fetch_array($connect,MYSQLI_ASSOC)){
            echo "<tr>";
        foreach ($row as $chave => $valor){
            if ($chave !== 'id'){
                echo "<td>" . $valor . "</td>";
            }
        }
        date_default_timezone_set('Europe/Lisbon');
        if ($row['dia_semana'] == 'Segunda' && date('D') == 'Mon'){
            $agora = DateTime::createFromFormat('H:i', date('H:i'));
            $inicio = DateTime::createFromFormat('H:i', $row['hora_inicio']);
            $fim = DateTime::createFromFormat('H:i', $row['hora_fim']);
            if ($agora >= $inicio && $agora <= $fim){
                $sql2 = "SELECT *
                FROM presenca
                WHERE turma = $row[id] AND date(data_hora) = date(now())";
                $result = mysqli_query($conn, $sql2);
                if (mysqli_num_rows($result)==0) {
                    echo "<td><form action='presencas' method='POST'>
                <input type='submit' class='btn btn-primary' name='marcar2' value='Marcar'>
                <input type='hidden' name='turma' href='' id='' value='$row[id]'>
                <input type='hidden' name='uc' href='' id='' value='$id_uc'>
                </form></td></tr>";
                }else{
                    echo "<td><p>Já marcou presença</p></td></tr>";
                }
            }elseif ($agora > $inicio && $agora > $fim) {
                echo "<td><p>Aula já terminou</p></td></tr>";
            }elseif ($agora < $inicio && $agora < $fim) {
                echo "<td><p>Aula não começou</p></td></tr>";
            }
        }elseif ($row['dia_semana'] == 'Terça' && date('D') == 'Tue'){
            $agora = DateTime::createFromFormat('H:i', date('H:i'));
            $inicio = DateTime::createFromFormat('H:i', $row['hora_inicio']);
            $fim = DateTime::createFromFormat('H:i', $row['hora_fim']);
            if ($agora >= $inicio && $agora <= $fim){
                $sql2 = "SELECT *
                FROM presenca
                WHERE turma = $row[id] AND date(data_hora) = date(now())";
                $result = mysqli_query($conn, $sql2);
                if (mysqli_num_rows($result)==0) {
                    echo "<td><form action='presencas' method='POST'>
                <input type='submit' class='btn btn-primary' name='marcar2' value='Marcar'>
                <input type='hidden' name='turma' href='' id='' value='$row[id]'>
                <input type='hidden' name='uc' href='' id='' value='$id_uc'>
                </form></td></tr>";
                }else{
                    echo "<td><p>Já marcou presença</p></td></tr>";
                }
            }elseif ($agora > $inicio && $agora > $fim) {
                echo "<td><p>Aula já terminou</p></td></tr>";
            }elseif ($agora < $inicio && $agora < $fim) {
                echo "<td><p>Aula não começou</p></td></tr>";
            }
        }elseif ($row['dia_semana'] == 'Quarta' && date('D') == 'Wed'){
            $agora = DateTime::createFromFormat('H:i', date('H:i'));
            $inicio = DateTime::createFromFormat('H:i', $row['hora_inicio']);
            $fim = DateTime::createFromFormat('H:i', $row['hora_fim']);
            if ($agora >= $inicio && $agora <= $fim){
                $sql2 = "SELECT *
                FROM presenca
                WHERE turma = $row[id] AND date(data_hora) = date(now())";
                $result = mysqli_query($conn, $sql2);
                if (mysqli_num_rows($result)==0) {
                    echo "<td><form action='presencas' method='POST'>
                <input type='submit' class='btn btn-primary' name='marcar2' value='Marcar'>
                <input type='hidden' name='turma' href='' id='' value='$row[id]'>
                <input type='hidden' name='uc' href='' id='' value='$id_uc'>
                </form></td></tr>";
                }else{
                    echo "<td><p>Já marcou presença</p></td></tr>";
                }
            }elseif ($agora > $inicio && $agora > $fim) {
                echo "<td><p>Aula já terminou</p></td></tr>";
            }elseif ($agora < $inicio && $agora < $fim) {
                echo "<td><p>Aula não começou</p></td></tr>";
            }
        }elseif ($row['dia_semana'] == 'Quinta' && date('D') == 'Thu'){
            $agora = DateTime::createFromFormat('H:i', date('H:i'));
            $inicio = DateTime::createFromFormat('H:i', $row['hora_inicio']);
            $fim = DateTime::createFromFormat('H:i', $row['hora_fim']);
            if ($agora >= $inicio && $agora <= $fim){
                $sql2 = "SELECT *
                FROM presenca
                WHERE turma = $row[id] AND date(data_hora) = date(now())";
                $result = mysqli_query($conn, $sql2);
                if (mysqli_num_rows($result)==0) {
                    echo "<td><form action='presencas' method='POST'>
                <input type='submit' class='btn btn-primary' name='marcar2' value='Marcar'>
                <input type='hidden' name='turma' href='' id='' value='$row[id]'>
                <input type='hidden' name='uc' href='' id='' value='$id_uc'>
                </form></td></tr>";
                }else{
                    echo "<td><p>Já marcou presença</p></td></tr>";
                }
            }elseif ($agora > $inicio && $agora > $fim) {
                echo "<td><p>Aula já terminou</p></td></tr>";
            }elseif ($agora < $inicio && $agora < $fim) {
                echo "<td><p>Aula não começou</p></td></tr>";
            }
        }elseif ($row['dia_semana'] == 'Sexta' && date('D') == 'Fri'){
            $agora = DateTime::createFromFormat('H:i', date('H:i'));
            $inicio = DateTime::createFromFormat('H:i', $row['hora_inicio']);
            $fim = DateTime::createFromFormat('H:i', $row['hora_fim']);
            if ($agora >= $inicio && $agora <= $fim){
                $sql2 = "SELECT *
                FROM presenca
                WHERE turma = $row[id] AND date(data_hora) = date(now())";
                $result = mysqli_query($conn, $sql2);
                if (mysqli_num_rows($result)==0) {
                    echo "<td><form action='presencas' method='POST'>
                <input type='submit' class='btn btn-primary' name='marcar2' value='Marcar'>
                <input type='hidden' name='turma' href='' id='' value='$row[id]'>
                <input type='hidden' name='uc' href='' id='' value='$id_uc'>
                </form></td></tr>";
                }else{
                    echo "<td><p>Já marcou presença</p></td></tr>";
                }
            }elseif ($agora > $inicio && $agora > $fim) {
                echo "<td><p>Aula já terminou</p></td></tr>";
            }elseif ($agora < $inicio && $agora < $fim) {
                echo "<td><p>Aula não começou</p></td></tr>";
            }
        }else{
            echo "<td><p>Indisponível</p></td></tr>";
            # ---- NOS FINS DE SEMANA NÃO DÁ PARA MARCAR PRESENÇAS ------
           /*$agora = DateTime::createFromFormat('H:i', date('H:i'));
            $inicio = DateTime::createFromFormat('H:i', $row['hora_inicio']);
            $fim = DateTime::createFromFormat('H:i', $row['hora_fim']);
            if ($agora >= $inicio && $agora <= $fim){
                echo "<td><form action='presencas' method='POST'>
                <input type='submit' name='marcar2' value='Marcar'>
                <input type='hidden' name='turma' href='' id='' value='$row[id]'>
                <input type='hidden' name='uc' href='' id='' value='$id_uc'>
                </form></td></tr>"; 
            }elseif ($agora > $inicio && $agora > $fim) {
                echo "<td><p>Aula já terminou</p></td></tr>";
            }elseif ($agora < $inicio && $agora < $fim) {
                echo "<td><p>Aula não começou</p></td></tr>";
            } */
        }
    }

    } else {
                echo "Error creating table: " . $conn->error;
    }
    echo "</table>";
    echo "</div>";
}

if(isset($_POST['marcar2'])){
    date_default_timezone_set('Europe/Lisbon');
    $turma = $_POST ['turma'];
    $uc = $_POST ['uc'];
    $now = date("Y-m-d H:i:s");
    $sql = "INSERT INTO presenca (uc, aluno, turma, data_hora) VALUES ($uc, $numero, $turma, NOW() + INTERVAL 1 HOUR)";
    if ($conn->query($sql) == TRUE) {
        echo "<div class='toast__container'>
    <div class='toast__cell mainbox'>
        <div class='toast toast--green'>
            <div class='toast__icon'>
            </div>
            <div class='toast__content'>
                <p class='toast__type'>Sucesso</p>
                <p class='toast__message'>Marcação de presença efetuada com sucesso.</p>
            </div>
            <div class='toast__close'>
                X
            </div>
        </div>
        </div>
    </div>";
    }else{
        echo "<div class='toast__container'>
        <div class='toast__cell mainbox'>
        <div class='toast toast--yellow'>
          <div class='toast__icon'>
          </div>
          <div class='toast__content'>
            <p class='toast__type'>Erro</p>
            <p class='toast__message'>Ocorreu um erro ao marcar a presença.</p>
          </div>
          <div class='toast__close'>
            X
          </div>
        </div>
        </div>
        </div>";
    }
}

if(isset($_POST['consultar'])){
    echo "<script type='text/javascript'>",
        "document.getElementById('marcar').style.display='none';",
        "document.getElementById('consultar').style.display='none';",
        "document.getElementById('firstbox').style.display='none';",
    "</script>";
    $uc = $_POST ['consultar'];
    echo "<div class='w3-container mainbox' id='consultbox'>
    <h1 id='MC'>Consulta de Presenças</h1>
    <br>
    ";
    $sql = "SELECT nome, tipo, dia_semana, hora_inicio, hora_fim, data_hora 
    FROM turma, uc, presenca
    WHERE aluno = $numero AND uc.id = $uc AND turma.uc_id = uc.id AND presenca.turma = turma.id";
    $connect = $conn->query($sql);
    if ($connect == TRUE) {
        if($connect->num_rows > 0) {
            echo "<table class='w3-table-all table-responsive table' id='marcar'>
            <tr class='w3-indigo'>
            <th>" . "Nome" . "</th>
            <th>" . "Tipo" . "</th>
            <th>" . "Dia da Semana" . "</th>
            <th>" . "Hora de Inicio" . "</th>
            <th>" . "Hora de Terminio" . "</th>
            <th>" . "Data da presença" . "</th>";
            while($row = mysqli_fetch_array($connect,MYSQLI_ASSOC)){
                echo "<tr>";
                foreach ($row as $chave => $valor){
                    if ($chave !== 'id'){
                        echo "<td>" . $valor . "</td>";
                    }
                }
            }
            echo "</table>";
            echo "</div>";
        }else{
                echo "<script type='text/javascript'>",
                    "document.getElementById('marcar').style.display='none';",
                    "document.getElementById('consultar').style.display='none';",
                    "document.getElementById('firstbox').style.display='none';",
                "</script>";
                echo "<h1>De momento não tem presenças nesta unidade curricular.</h1></div>";
            }
        }
    }

if ($url === '/presencasProfessor') {
    echo "<div class='w3-container mainbox' id='SUCP'>
    <h1 id='MC'>Consultar Presenças</h1>
    <br>";
    echo "<p id='pconsultar' style='display:none'>Selecione a Unidade à qual pretende consultar as presenças:</p>";
    $sql = "SELECT id, nome
    FROM uc
    WHERE coordenador = $numero";
    $connect = $conn->query($sql);
    if ($connect == TRUE) {
        if($connect->num_rows > 0) {
            echo "<table class='w3-table-all table-responsive table' id='consultar'>
            <tr class='w3-indigo'>
            <th>" . "Unidade Curricular" . "</th>";
            while($row = mysqli_fetch_array($connect,MYSQLI_ASSOC)){
                echo "<tr>";
            foreach ($row as $chave => $valor){
                if ($chave !== 'id'){
                    echo "<td>" . $valor . "</td>";
                }
            }
            echo "<td><form action='presencasProfessor' method='POST'>
                <input type='submit' class='btn btn-primary' name='consultarprof' value='Consultar'/>
                <input type='hidden' name='ucprof' href='' id='join' value='$row[id]'>
                <input type='hidden' name='ucnomeprof' href='' id='join' value='$row[nome]'>
                </form></td>";
            echo "</tr>";
            }   
            echo "</table>";
            echo "</div>";
        }else{
            echo "</div>";
            echo "<script type='text/javascript'>",
                        "document.getElementById('SUCP').style.display='none';",
                    "</script>";
                    echo "<div class='w3-container mainbox'><h1>Você não tem permissões de coordenador nas unidades curriculares.</h1></div>";
        }
    } else {
        echo "Error creating table: " . $conn->error;
    }
}

if(isset($_POST['consultarprof'])){
    echo "<script type='text/javascript'>",
        "document.getElementById('SUCP').style.display='none';",
    "</script>";
    $id_uc = $_POST ['ucprof'];
    $nome_uc = $_POST ['ucnomeprof'];
    echo "<div class='w3-container mainbox'>
    <h1 id='MC'>$nome_uc: Consulta de Presenças</h1>
    <br>
    ";
    $sql = "SELECT aluno, tipo, dia_semana, hora_inicio, hora_fim, data_hora 
    FROM turma, uc, presenca
    WHERE uc.id = $id_uc AND turma.uc_id = uc.id AND presenca.turma = turma.id";
    $connect = $conn->query($sql);
    if ($connect == TRUE) {
        if($connect->num_rows > 0) {
            echo "<table class='w3-table-all table-responsive table' id='marcar'>
            <tr class='w3-indigo'>
            <th>" . "Nº Aluno" . "</th>
            <th>" . "Tipo" . "</th>
            <th>" . "Dia da Semana" . "</th>
            <th>" . "Hora de Inicio" . "</th>
            <th>" . "Hora de Terminio" . "</th>
            <th>" . "Data da presença" . "</th>";
            while($row = mysqli_fetch_array($connect,MYSQLI_ASSOC)){
                echo "<tr>";
                foreach ($row as $chave => $valor){
                    if ($chave !== 'id'){
                        echo "<td>" . $valor . "</td>";
                    }
                }
            }
            echo "</table>";
            echo "</div>";
        }else{
            echo "<p>Ainda nenhum aluno marcou presença nesta disciplina.</p>";
            echo "</table>";
            echo "</div>";
        }
    }else {
        echo "Error creating table: " . $conn->error;
    }
}
?>