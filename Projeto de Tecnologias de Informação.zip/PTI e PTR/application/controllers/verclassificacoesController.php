<?php
echo "<div class='w3-container mainbox' id='CC'>
<h1 id='MC'>Consultar Classificações</h1>
<br>";
echo "<p id='pconsultar'>Selecione a disciplina à qual pretende consultar as suas classificações.</p>";
$sql = "SELECT id,nome
    FROM uc
    WHERE EXISTS (
        SELECT *
        FROM inscritos AS i 
        WHERE uc.id=i.uc_id AND '$numero' = i.aluno_id
    )";
$connect = $conn->query($sql);
if ($connect == TRUE) {
    if($connect->num_rows > 0) {
        echo "<table class='w3-table-all table-responsive table'>
        <tr class='w3-indigo'>
        <th>" . "Disciplina" . "</th>";
        while($row = mysqli_fetch_array($connect,MYSQLI_ASSOC)){
            echo "<tr>";
        foreach ($row as $chave => $valor){
            if ($chave !== 'id'){
                echo "<td>" . $valor . "</td>";
            }
        }
        echo "<td><form action='classificacoes' method='POST'>
            <input type='submit' class='btn btn-primary' name='verclass' value='Selecionar'/>
            <input type='hidden' name='uc' value='$row[id]'>
            <input type='hidden' name='ucnome' value='$row[nome]'>
            </form></td>";
        echo "</tr>";
        }   
        echo "</table>";
        echo "</div>";
    }else{ # se aluno não estiver inscrito a disciplinas
        echo "</div>";
        echo "<script type='text/javascript'>",
                "document.getElementById('CC').style.display='none';",
            "</script>";
            echo "<div class='toast__container'>
        <div class='toast__cell mainbox'>
        <div class='toast toast--yellow'>
          <div class='toast__icon'>
          </div>
          <div class='toast__content'>
            <p class='toast__type'>Erro</p>
            <p class='toast__message'>Você não está inscrito a unidades curriculares.</p>
          </div>
          <div class='toast__close'>
            X
          </div>
        </div>
        </div>
        </div>";
    }
}else {
    echo "Error accessing table: " . $conn->error;
}

if(isset($_POST['verclass'])){
    echo "<script type='text/javascript'>",
                    "document.getElementById('CC').style.display='none';",
                "</script>";
    $id_uc = $_POST ['uc'];
    $nome_uc = $_POST ['ucnome'];
    echo "<div class='w3-container mainbox' id='CC'>
    <h1 id='MC'>Consultar Classificações</h1>
    <h3>$nome_uc</h3>
    <br>";
    $sql = "SELECT *
    FROM classificacoes
    WHERE aluno_id = '$numero' AND uc_id = '$id_uc'";
    $connect = $conn->query($sql);
    if ($connect == TRUE) {
        if($connect->num_rows > 0) {
            echo "<table class='w3-table-all table-responsive table' class='jogo'>
            <tr class='w3-indigo'>
            <th>" . "Avaliação Contínua" . "</th>
            <th>" . "Avaliação Períodica" . "</th>
            <th>" . "Exame de 1ª Frequência" . "</th>
            <th>" . "Exame de 2ª Frequência" . "</th>
            <th>" . "Exame 1ª Fase" . "</th>
            <th>" . "Exame 2ª Fase" . "</th>
            <th>" . "Classificação Final" . "</th>";
            while($row = mysqli_fetch_array($connect,MYSQLI_ASSOC)){
                echo "<tr>";
            foreach ($row as $chave => $valor){
                if ($chave !== 'id' && $chave !== 'uc_id' && $chave !== 'aluno_id') {
                    echo "<td>" . $valor . "</td>";
                }
            }
                echo "</tr>";
            }
            echo "</table>";
            echo "</div>";
        }else{
            echo "<script type='text/javascript'>",
                    "document.getElementById('CC').style.display='none';",
                "</script>";
                echo "<div class='w3-container mainbox'><h1>Ainda não foram atribuidas classificações para este disciplina.</h1></div>";
        }
    }
}
?>