<?php
header('Content-Type: text/html; charset=utf-8');
    $a1 = "";
    $a2 = "";
    $a3 = "";
    $a4 = "";
    $a5 = "";
    $a6 = "";
    $a7 = "";
    $a8 = "";
    $a9 = "";
    $a10 = "";
    $a11 = "";
    $a12 = "";
    $a13 = "";
    $a14 = "";
    $a15 = "";
    $a16 = "";
    $a17 = "";
    $a18 = "";
    $a19 = "";
    $a20 = "";
    $a21 = "";
    $a22 = "";
    $a23 = "";
    $a24 = "";
    $a25 = "";
    $a26 = "";
    $a27 = "";
    $a28 = "";
    $a29 = "";
    $a30 = "";
    $a31 = "";
    $a32 = "";
    $a33 = "";
    $a34 = "";
    $a35 = "";

    $a36 = "";
    $a37 = "";
    $a38 = "";
    $a39 = "";
    $a40 = "";
    $a41 = "";
    $a42 = "";
    $a43 = "";
    $a44 = "";
    $a45 = "";
    $a46 = "";
    $a47 = "";
    $a48 = "";
    $a49 = "";
    $a50 = "";
    $a51 = "";
    $a52 = "";
    $a53 = "";
    $a54 = "";
    $a55 = "";
    $a56 = "";
    $a57 = "";
    $a58 = "";
    $a59 = "";
    $a60 = "";
    $a61 = "";
    $a62 = "";
    $a63 = "";
    $a64 = "";
    $a65 = "";
    $a66 = "";
    $a67 = "";
    $a68 = "";
    $a69 = "";
    $a70 = "";

if ($_SESSION['aluno']) {
    $sql = "SELECT abreviatura, tipo, dia_semana, hora_inicio, hora_fim, bloco, sala
    FROM turma, uc
    WHERE EXISTS (
        SELECT *
        FROM inscritos AS i 
        WHERE turma.id=i.turma_id AND '$numero' = i.aluno_id
    ) AND uc.id = turma.uc_id AND uc.semestre = '1'";
    $connect = $conn->query($sql);
    if ($connect == TRUE) {
    while($row = mysqli_fetch_array($connect,MYSQLI_ASSOC)){
        if ($row['dia_semana'] == 'Segunda' && $row['bloco'] == '1.1.1') {
            $a1 .= $row['abreviatura'] . "-" . $row['tipo'] . "-" . $row['sala'] . '<br>';
        }elseif ($row['dia_semana'] == 'Segunda' && $row['bloco'] == '1.2.1') {
            $a2 .= $row['abreviatura'] . "-" . $row['tipo'] . "-" . $row['sala'] . '<br>';
        }elseif ($row['dia_semana'] == 'Segunda' && $row['bloco'] == '1.3.1') {
            $a3 .= $row['abreviatura'] . "-" . $row['tipo'] . "-" . $row['sala'] . '<br>';
        }elseif ($row['dia_semana'] == 'Segunda' && $row['bloco'] == '1.4.1') {
            $a4 .= $row['abreviatura'] . "-" . $row['tipo'] . "-" . $row['sala'] . '<br>';
        }elseif ($row['dia_semana'] == 'Segunda' && $row['bloco'] == '1.5.1') {
            $a5 .= $row['abreviatura'] . "-" . $row['tipo'] . "-" . $row['sala'] . '<br>';
        }elseif ($row['dia_semana'] == 'Segunda' && $row['bloco'] == '1.6.1') {
            $a6 .= $row['abreviatura'] . "-" . $row['tipo'] . "-" . $row['sala'] . '<br>';
        }elseif ($row['dia_semana'] == 'Segunda' && $row['bloco'] == '1.7.1') {
            $a7 .= $row['abreviatura'] . "-" . $row['tipo'] . "-" . $row['sala'] . '<br>';
        }
        if ($row['dia_semana'] == 'Terça' && $row['bloco'] == '2.1.1') {
            $a8 .= $row['abreviatura'] . "-" . $row['tipo'] . "-" . $row['sala'] . '<br>';
        }elseif ($row['dia_semana'] == 'Terça' && $row['bloco'] == '2.2.1') {
            $a9 .= $row['abreviatura'] . "-" . $row['tipo'] . "-" . $row['sala'] . '<br>';
        }elseif ($row['dia_semana'] == 'Terça' && $row['bloco'] == '2.3.1') {
            $a10 .= $row['abreviatura'] . "-" . $row['tipo'] . "-" . $row['sala'] . '<br>';
        }elseif ($row['dia_semana'] == 'Terça' && $row['bloco'] == '2.4.1') {
            $a11 .= $row['abreviatura'] . "-" . $row['tipo'] . "-" . $row['sala'] . '<br>';
        }elseif ($row['dia_semana'] == 'Terça' && $row['bloco'] == '2.5.1') {
            $a12 .= $row['abreviatura'] . "-" . $row['tipo'] . "-" . $row['sala'] . '<br>';
        }elseif ($row['dia_semana'] == 'Terça' && $row['bloco'] == '2.6.1') {
            $a13 .= $row['abreviatura'] . "-" . $row['tipo'] . "-" . $row['sala'] . '<br>';
        }elseif ($row['dia_semana'] == 'Terça' && $row['bloco'] == '2.7.1') {
            $a14 .= $row['abreviatura'] . "-" . $row['tipo'] . "-" . $row['sala'] . '<br>';
        }

        if ($row['dia_semana'] == 'Quarta' && $row['bloco'] == '3.1.1') {
            $a15 .= $row['abreviatura'] . ", " . $row['tipo'] . ", " . $row['sala'] . '<br>';
        }elseif ($row['dia_semana'] == 'Quarta' && $row['bloco'] == '3.2.1') {
            $a16 .= $row['abreviatura'] . "-" . $row['tipo'] . "-" . $row['sala'] . '<br>';
        }elseif ($row['dia_semana'] == 'Quarta' && $row['bloco'] == '3.3.1') {
            $a17 .= $row['abreviatura'] . "-" . $row['tipo'] . "-" . $row['sala'] . '<br>';
        }elseif ($row['dia_semana'] == 'Quarta' && $row['bloco'] == '3.4.1') {
            $a18 .= $row['abreviatura'] . "-" . $row['tipo'] . "-" . $row['sala'] . '<br>';
        }elseif ($row['dia_semana'] == 'Quarta' && $row['bloco'] == '3.5.1') {
            $a19 .= $row['abreviatura'] . "-" . $row['tipo'] . "-" . $row['sala'] . '<br>';
        }elseif ($row['dia_semana'] == 'Quarta' && $row['bloco'] == '3.6.1') {
            $a20 .= $row['abreviatura'] . "-" . $row['tipo'] . "-" . $row['sala'] . '<br>';
        }elseif ($row['dia_semana'] == 'Quarta' && $row['bloco'] == '3.7.1') {
            $a21 .= $row['abreviatura'] . "-" . $row['tipo'] . "-" . $row['sala'] . '<br>';
        }

        if ($row['dia_semana'] == 'Quinta' && $row['bloco'] == '4.1.1') {
            $a22 .= $row['abreviatura'] . ", " . $row['tipo'] . ", " . $row['sala'] . '<br>';
        }elseif ($row['dia_semana'] == 'Quinta' && $row['bloco'] == '4.2.1') {
            $a23 .= $row['abreviatura'] . "-" . $row['tipo'] . "-" . $row['sala'] . '<br>';
        }elseif ($row['dia_semana'] == 'Quinta' && $row['bloco'] == '4.3.1') {
            $a24 .= $row['abreviatura'] . "-" . $row['tipo'] . "-" . $row['sala'] . '<br>';
        }elseif ($row['dia_semana'] == 'Quinta' && $row['bloco'] == '4.4.1') {
            $a25 .= $row['abreviatura'] . "-" . $row['tipo'] . "-" . $row['sala'] . '<br>';
        }elseif ($row['dia_semana'] == 'Quinta' && $row['bloco'] == '4.5.1') {
            $a26 .= $row['abreviatura'] . "-" . $row['tipo'] . "-" . $row['sala'] . '<br>';
        }elseif ($row['dia_semana'] == 'Quinta' && $row['bloco'] == '4.6.1') {
            $a27 .= $row['abreviatura'] . "-" . $row['tipo'] . "-" . $row['sala'] . '<br>';
        }elseif ($row['dia_semana'] == 'Quinta' && $row['bloco'] == '4.7.1') {
            $a28 .= $row['abreviatura'] . "-" . $row['tipo'] . "-" . $row['sala'] . '<br>';
        }

        if ($row['dia_semana'] == 'Sexta' && $row['bloco'] == '5.1.1') {
            $a29 .= $row['abreviatura'] . ", " . $row['tipo'] . ", " . $row['sala'] . '<br>';
        }elseif ($row['dia_semana'] == 'Sexta' && $row['bloco'] == '5.2.1') {
            $a30 .= $row['abreviatura'] . "-" . $row['tipo'] . "-" . $row['sala'] . '<br>';
        }elseif ($row['dia_semana'] == 'Sexta' && $row['bloco'] == '5.3.1') {
            $a31 .= $row['abreviatura'] . "-" . $row['tipo'] . "-" . $row['sala'] . '<br>';
        }elseif ($row['dia_semana'] == 'Sexta' && $row['bloco'] == '5.4.1') {
            $a32 .= $row['abreviatura'] . "-" . $row['tipo'] . "-" . $row['sala'] . '<br>';
        }elseif ($row['dia_semana'] == 'Sexta' && $row['bloco'] == '5.5.1') {
            $a33 .= $row['abreviatura'] . "-" . $row['tipo'] . "-" . $row['sala'] . '<br>';
        }elseif ($row['dia_semana'] == 'Sexta' && $row['bloco'] == '5.6.1') {
            $a34 .= $row['abreviatura'] . "-" . $row['tipo'] . "-" . $row['sala'] . '<br>';
        }elseif ($row['dia_semana'] == 'Sexta' && $row['bloco'] == '5.7.1') {
            $a35 .= $row['abreviatura'] . "-" . $row['tipo'] . "-" . $row['sala'] . '<br>';
        }
    }
}else {
    echo "Error creating table: " . $conn->error;
}

    $sql = "SELECT abreviatura, tipo, dia_semana, hora_inicio, hora_fim, bloco, sala
    FROM turma, uc
    WHERE EXISTS (
        SELECT *
        FROM inscritos AS i 
        WHERE turma.id=i.turma_id AND '$numero' = i.aluno_id
    ) AND uc.id = turma.uc_id AND uc.semestre = '2'";
    $connect = $conn->query($sql);
    if ($connect == TRUE) {
        while($row = mysqli_fetch_array($connect,MYSQLI_ASSOC)){
            if ($row['dia_semana'] == 'Segunda' && $row['bloco'] == '1.1.2') {
                $a36 .= $row['abreviatura'] . "-" . $row['tipo'] . "-" . $row['sala'] . '<br>';
            }elseif ($row['dia_semana'] == 'Segunda' && $row['bloco'] == '1.2.2') {
                $a37 .= $row['abreviatura'] . "-" . $row['tipo'] . "-" . $row['sala'] . '<br>';
            }elseif ($row['dia_semana'] == 'Segunda' && $row['bloco'] == '1.3.2') {
                $a38 .= $row['abreviatura'] . "-" . $row['tipo'] . "-" . $row['sala'] . '<br>';
            }elseif ($row['dia_semana'] == 'Segunda' && $row['bloco'] == '1.4.2') {
                $a39 .= $row['abreviatura'] . "-" . $row['tipo'] . "-" . $row['sala'] . '<br>';
            }elseif ($row['dia_semana'] == 'Segunda' && $row['bloco'] == '1.5.2') {
                $a40 .= $row['abreviatura'] . "-" . $row['tipo'] . "-" . $row['sala'] . '<br>';
            }elseif ($row['dia_semana'] == 'Segunda' && $row['bloco'] == '1.6.2') {
                $a41 .= $row['abreviatura'] . "-" . $row['tipo'] . "-" . $row['sala'] . '<br>';
            }elseif ($row['dia_semana'] == 'Segunda' && $row['bloco'] == '1.7.2') {
                $a42 .= $row['abreviatura'] . "-" . $row['tipo'] . "-" . $row['sala'] . '<br>';
            }
            if ($row['dia_semana'] == 'Terça' && $row['bloco'] == '2.1.2') {
                $a43 .= $row['abreviatura'] . "-" . $row['tipo'] . "-" . $row['sala'] . '<br>';
            }elseif ($row['dia_semana'] == 'Terça' && $row['bloco'] == '2.2.2') {
                $a44 .= $row['abreviatura'] . "-" . $row['tipo'] . "-" . $row['sala'] . '<br>';
            }elseif ($row['dia_semana'] == 'Terça' && $row['bloco'] == '2.3.2') {
                $a45 .= $row['abreviatura'] . "-" . $row['tipo'] . "-" . $row['sala'] . '<br>';
            }elseif ($row['dia_semana'] == 'Terça' && $row['bloco'] == '2.4.2') {
                $a46 .= $row['abreviatura'] . "-" . $row['tipo'] . "-" . $row['sala'] . '<br>';
            }elseif ($row['dia_semana'] == 'Terça' && $row['bloco'] == '2.5.2') {
                $a47 .= $row['abreviatura'] . "-" . $row['tipo'] . "-" . $row['sala'] . '<br>';
            }elseif ($row['dia_semana'] == 'Terça' && $row['bloco'] == '2.6.2') {
                $a48 .= $row['abreviatura'] . "-" . $row['tipo'] . "-" . $row['sala'] . '<br>';
            }elseif ($row['dia_semana'] == 'Terça' && $row['bloco'] == '2.7.2') {
                $a49 .= $row['abreviatura'] . "-" . $row['tipo'] . "-" . $row['sala'] . '<br>';
            }

            if ($row['dia_semana'] == 'Quarta' && $row['bloco'] == '3.1.2') {
                $a50 .= $row['abreviatura'] . ", " . $row['tipo'] . ", " . $row['sala'] . '<br>';
            }elseif ($row['dia_semana'] == 'Quarta' && $row['bloco'] == '3.2.2') {
                $a51 .= $row['abreviatura'] . "-" . $row['tipo'] . "-" . $row['sala'] . '<br>';
            }elseif ($row['dia_semana'] == 'Quarta' && $row['bloco'] == '3.3.2') {
                $a52 .= $row['abreviatura'] . "-" . $row['tipo'] . "-" . $row['sala'] . '<br>';
            }elseif ($row['dia_semana'] == 'Quarta' && $row['bloco'] == '3.4.2') {
                $a53 .= $row['abreviatura'] . "-" . $row['tipo'] . "-" . $row['sala'] . '<br>';
            }elseif ($row['dia_semana'] == 'Quarta' && $row['bloco'] == '3.5.2') {
                $a54 .= $row['abreviatura'] . "-" . $row['tipo'] . "-" . $row['sala'] . '<br>';
            }elseif ($row['dia_semana'] == 'Quarta' && $row['bloco'] == '3.6.2') {
                $a55 .= $row['abreviatura'] . "-" . $row['tipo'] . "-" . $row['sala'] . '<br>';
            }elseif ($row['dia_semana'] == 'Quarta' && $row['bloco'] == '3.7.2') {
                $a56 .= $row['abreviatura'] . "-" . $row['tipo'] . "-" . $row['sala'] . '<br>';
            }

            if ($row['dia_semana'] == 'Quinta' && $row['bloco'] == '4.1.2') {
                $a57 .= $row['abreviatura'] . ", " . $row['tipo'] . ", " . $row['sala'] . '<br>';
            }elseif ($row['dia_semana'] == 'Quinta' && $row['bloco'] == '4.2.2') {
                $a58 .= $row['abreviatura'] . "-" . $row['tipo'] . "-" . $row['sala'] . '<br>';
            }elseif ($row['dia_semana'] == 'Quinta' && $row['bloco'] == '4.3.2') {
                $a59 .= $row['abreviatura'] . "-" . $row['tipo'] . "-" . $row['sala'] . '<br>';
            }elseif ($row['dia_semana'] == 'Quinta' && $row['bloco'] == '4.4.2') {
                $a60 .= $row['abreviatura'] . "-" . $row['tipo'] . "-" . $row['sala'] . '<br>';
            }elseif ($row['dia_semana'] == 'Quinta' && $row['bloco'] == '4.5.2') {
                $a61 .= $row['abreviatura'] . "-" . $row['tipo'] . "-" . $row['sala'] . '<br>';
            }elseif ($row['dia_semana'] == 'Quinta' && $row['bloco'] == '4.6.2') {
                $a62 .= $row['abreviatura'] . "-" . $row['tipo'] . "-" . $row['sala'] . '<br>';
            }elseif ($row['dia_semana'] == 'Quinta' && $row['bloco'] == '4.7.2') {
                $a63 .= $row['abreviatura'] . "-" . $row['tipo'] . "-" . $row['sala'] . '<br>';
            }

            if ($row['dia_semana'] == 'Sexta' && $row['bloco'] == '5.1.2') {
                $a64 .= $row['abreviatura'] . ", " . $row['tipo'] . ", " . $row['sala'] . '<br>';
            }elseif ($row['dia_semana'] == 'Sexta' && $row['bloco'] == '5.2.2') {
                $a65 .= $row['abreviatura'] . "-" . $row['tipo'] . "-" . $row['sala'] . '<br>';
            }elseif ($row['dia_semana'] == 'Sexta' && $row['bloco'] == '5.3.2') {
                $a66 .= $row['abreviatura'] . "-" . $row['tipo'] . "-" . $row['sala'] . '<br>';
            }elseif ($row['dia_semana'] == 'Sexta' && $row['bloco'] == '5.4.2') {
                $a67 .= $row['abreviatura'] . "-" . $row['tipo'] . "-" . $row['sala'] . '<br>';
            }elseif ($row['dia_semana'] == 'Sexta' && $row['bloco'] == '5.5.2') {
                $a68 .= $row['abreviatura'] . "-" . $row['tipo'] . "-" . $row['sala'] . '<br>';
            }elseif ($row['dia_semana'] == 'Sexta' && $row['bloco'] == '5.6.2') {
                $a69 .= $row['abreviatura'] . "-" . $row['tipo'] . "-" . $row['sala'] . '<br>';
            }elseif ($row['dia_semana'] == 'Sexta' && $row['bloco'] == '5.7.2') {
                $a70 .= $row['abreviatura'] . "-" . $row['tipo'] . "-" . $row['sala'] . '<br>';
            }
        }
    } else {
                echo "Error creating table: " . $conn->error;
    }

    echo "<script type='text/javascript'>",
                "window.onload = function () {",
                    "document.getElementById('1.1.1').innerHTML='$a1';",
                    "document.getElementById('1.2.1').innerHTML='$a2';",
                    "document.getElementById('1.3.1').innerHTML='$a3';",
                    "document.getElementById('1.4.1').innerHTML='$a4';",
                    "document.getElementById('1.5.1').innerHTML='$a5';",
                    "document.getElementById('1.6.1').innerHTML='$a6';",
                    "document.getElementById('1.7.1').innerHTML='$a7';",
                    "document.getElementById('2.1.1').innerHTML='$a8';",
                    "document.getElementById('2.2.1').innerHTML='$a9';",
                    "document.getElementById('2.3.1').innerHTML='$a10';",
                    "document.getElementById('2.4.1').innerHTML='$a11';",
                    "document.getElementById('2.5.1').innerHTML='$a12';",
                    "document.getElementById('2.6.1').innerHTML='$a13';",
                    "document.getElementById('2.7.1').innerHTML='$a14';",
                    "document.getElementById('3.1.1').innerHTML='$a15';",
                    "document.getElementById('3.2.1').innerHTML='$a16';",
                    "document.getElementById('3.3.1').innerHTML='$a17';",
                    "document.getElementById('3.4.1').innerHTML='$a18';",
                    "document.getElementById('3.5.1').innerHTML='$a19';",
                    "document.getElementById('3.6.1').innerHTML='$a20';",
                    "document.getElementById('3.7.1').innerHTML='$a21';",
                    "document.getElementById('4.1.1').innerHTML='$a22';",
                    "document.getElementById('4.2.1').innerHTML='$a23';",
                    "document.getElementById('4.3.1').innerHTML='$a24';",
                    "document.getElementById('4.4.1').innerHTML='$a25';",
                    "document.getElementById('4.5.1').innerHTML='$a26';",
                    "document.getElementById('4.6.1').innerHTML='$a27';",
                    "document.getElementById('4.7.1').innerHTML='$a28';",
                    "document.getElementById('5.1.1').innerHTML='$a29';",
                    "document.getElementById('5.2.1').innerHTML='$a30';",
                    "document.getElementById('5.3.1').innerHTML='$a31';",
                    "document.getElementById('5.4.1').innerHTML='$a32';",
                    "document.getElementById('5.5.1').innerHTML='$a33';",
                    "document.getElementById('5.6.1').innerHTML='$a34';",
                    "document.getElementById('5.7.1').innerHTML='$a35';",
                    "document.getElementById('1.1.2').innerHTML='$a36';",
                    "document.getElementById('1.2.2').innerHTML='$a37';",
                    "document.getElementById('1.3.2').innerHTML='$a38';",
                    "document.getElementById('1.4.2').innerHTML='$a39';",
                    "document.getElementById('1.5.2').innerHTML='$a40';",
                    "document.getElementById('1.6.2').innerHTML='$a41';",
                    "document.getElementById('1.7.2').innerHTML='$a42';",
                    "document.getElementById('2.1.2').innerHTML='$a43';",
                    "document.getElementById('2.2.2').innerHTML='$a44';",
                    "document.getElementById('2.3.2').innerHTML='$a45';",
                    "document.getElementById('2.4.2').innerHTML='$a46';",
                    "document.getElementById('2.5.2').innerHTML='$a47';",
                    "document.getElementById('2.6.2').innerHTML='$a48';",
                    "document.getElementById('2.7.2').innerHTML='$a49';",
                    "document.getElementById('3.1.2').innerHTML='$a50';",
                    "document.getElementById('3.2.2').innerHTML='$a51';",
                    "document.getElementById('3.3.2').innerHTML='$a52';",
                    "document.getElementById('3.4.2').innerHTML='$a53';",
                    "document.getElementById('3.5.2').innerHTML='$a54';",
                    "document.getElementById('3.6.2').innerHTML='$a55';",
                    "document.getElementById('3.7.2').innerHTML='$a56';",
                    "document.getElementById('4.1.2').innerHTML='$a57';",
                    "document.getElementById('4.2.2').innerHTML='$a58';",
                    "document.getElementById('4.3.2').innerHTML='$a59';",
                    "document.getElementById('4.4.2').innerHTML='$a60';",
                    "document.getElementById('4.5.2').innerHTML='$a61';",
                    "document.getElementById('4.6.2').innerHTML='$a62';",
                    "document.getElementById('4.7.2').innerHTML='$a63';",
                    "document.getElementById('5.1.2').innerHTML='$a64';",
                    "document.getElementById('5.2.2').innerHTML='$a65';",
                    "document.getElementById('5.3.2').innerHTML='$a66';",
                    "document.getElementById('5.4.2').innerHTML='$a67';",
                    "document.getElementById('5.5.2').innerHTML='$a68';",
                    "document.getElementById('5.6.2').innerHTML='$a69';",
                    "document.getElementById('5.7.2').innerHTML='$a70';",
                    "document.getElementById('menu-aluno').style.display='block';",
                    "document.getElementById('menu-prof').style.display='none';",
                    "document.getElementById('user').innerHTML='Aluno: $nome';",
                    "document.getElementById('login').style.display='none';",
                    "document.getElementById('divlogoff').style.display='block';",
                    "document.getElementById('logoff').innerHTML='Log Off';",
                    "document.getElementById('logoff').href = '".base_url()."home?off=true';",
                "};",
                "</script>";
}

if ($_SESSION['professor']) {
    $sql = "SELECT abreviatura, tipo, dia_semana, hora_inicio, hora_fim, bloco, sala
    FROM turma, uc
    WHERE turma.professor = $numero AND uc.semestre = '1'  AND uc.id = turma.uc_id";
    $connect = $conn->query($sql);
    if ($connect == TRUE) {
    while($row = mysqli_fetch_array($connect,MYSQLI_ASSOC)){
        if ($row['dia_semana'] == 'Segunda' && $row['bloco'] == '1.1.1') {
            $a1 .= $row['abreviatura'] . "-" . $row['tipo'] . "-" . $row['sala'] . '<br>';
        }elseif ($row['dia_semana'] == 'Segunda' && $row['bloco'] == '1.2.1') {
            $a2 .= $row['abreviatura'] . "-" . $row['tipo'] . "-" . $row['sala'] . '<br>';
        }elseif ($row['dia_semana'] == 'Segunda' && $row['bloco'] == '1.3.1') {
            $a3 .= $row['abreviatura'] . "-" . $row['tipo'] . "-" . $row['sala'] . '<br>';
        }elseif ($row['dia_semana'] == 'Segunda' && $row['bloco'] == '1.4.1') {
            $a4 .= $row['abreviatura'] . "-" . $row['tipo'] . "-" . $row['sala'] . '<br>';
        }elseif ($row['dia_semana'] == 'Segunda' && $row['bloco'] == '1.5.1') {
            $a5 .= $row['abreviatura'] . "-" . $row['tipo'] . "-" . $row['sala'] . '<br>';
        }elseif ($row['dia_semana'] == 'Segunda' && $row['bloco'] == '1.6.1') {
            $a6 .= $row['abreviatura'] . "-" . $row['tipo'] . "-" . $row['sala'] . '<br>';
        }elseif ($row['dia_semana'] == 'Segunda' && $row['bloco'] == '1.7.1') {
            $a7 .= $row['abreviatura'] . "-" . $row['tipo'] . "-" . $row['sala'] . '<br>';
        }
        if ($row['dia_semana'] == 'Terça' && $row['bloco'] == '2.1.1') {
            $a8 .= $row['abreviatura'] . "-" . $row['tipo'] . "-" . $row['sala'] . '<br>';
        }elseif ($row['dia_semana'] == 'Terça' && $row['bloco'] == '2.2.1') {
            $a9 .= $row['abreviatura'] . "-" . $row['tipo'] . "-" . $row['sala'] . '<br>';
        }elseif ($row['dia_semana'] == 'Terça' && $row['bloco'] == '2.3.1') {
            $a10 .= $row['abreviatura'] . "-" . $row['tipo'] . "-" . $row['sala'] . '<br>';
        }elseif ($row['dia_semana'] == 'Terça' && $row['bloco'] == '2.4.1') {
            $a11 .= $row['abreviatura'] . "-" . $row['tipo'] . "-" . $row['sala'] . '<br>';
        }elseif ($row['dia_semana'] == 'Terça' && $row['bloco'] == '2.5.1') {
            $a12 .= $row['abreviatura'] . "-" . $row['tipo'] . "-" . $row['sala'] . '<br>';
        }elseif ($row['dia_semana'] == 'Terça' && $row['bloco'] == '2.6.1') {
            $a13 .= $row['abreviatura'] . "-" . $row['tipo'] . "-" . $row['sala'] . '<br>';
        }elseif ($row['dia_semana'] == 'Terça' && $row['bloco'] == '2.7.1') {
            $a14 .= $row['abreviatura'] . "-" . $row['tipo'] . "-" . $row['sala'] . '<br>';
        }

        if ($row['dia_semana'] == 'Quarta' && $row['bloco'] == '3.1.1') {
            $a15 .= $row['abreviatura'] . ", " . $row['tipo'] . ", " . $row['sala'] . '<br>';
        }elseif ($row['dia_semana'] == 'Quarta' && $row['bloco'] == '3.2.1') {
            $a16 .= $row['abreviatura'] . "-" . $row['tipo'] . "-" . $row['sala'] . '<br>';
        }elseif ($row['dia_semana'] == 'Quarta' && $row['bloco'] == '3.3.1') {
            $a17 .= $row['abreviatura'] . "-" . $row['tipo'] . "-" . $row['sala'] . '<br>';
        }elseif ($row['dia_semana'] == 'Quarta' && $row['bloco'] == '3.4.1') {
            $a18 .= $row['abreviatura'] . "-" . $row['tipo'] . "-" . $row['sala'] . '<br>';
        }elseif ($row['dia_semana'] == 'Quarta' && $row['bloco'] == '3.5.1') {
            $a19 .= $row['abreviatura'] . "-" . $row['tipo'] . "-" . $row['sala'] . '<br>';
        }elseif ($row['dia_semana'] == 'Quarta' && $row['bloco'] == '3.6.1') {
            $a20 .= $row['abreviatura'] . "-" . $row['tipo'] . "-" . $row['sala'] . '<br>';
        }elseif ($row['dia_semana'] == 'Quarta' && $row['bloco'] == '3.7.1') {
            $a21 .= $row['abreviatura'] . "-" . $row['tipo'] . "-" . $row['sala'] . '<br>';
        }

        if ($row['dia_semana'] == 'Quinta' && $row['bloco'] == '4.1.1') {
            $a22 .= $row['abreviatura'] . ", " . $row['tipo'] . ", " . $row['sala'] . '<br>';
        }elseif ($row['dia_semana'] == 'Quinta' && $row['bloco'] == '4.2.1') {
            $a23 .= $row['abreviatura'] . "-" . $row['tipo'] . "-" . $row['sala'] . '<br>';
        }elseif ($row['dia_semana'] == 'Quinta' && $row['bloco'] == '4.3.1') {
            $a24 .= $row['abreviatura'] . "-" . $row['tipo'] . "-" . $row['sala'] . '<br>';
        }elseif ($row['dia_semana'] == 'Quinta' && $row['bloco'] == '4.4.1') {
            $a25 .= $row['abreviatura'] . "-" . $row['tipo'] . "-" . $row['sala'] . '<br>';
        }elseif ($row['dia_semana'] == 'Quinta' && $row['bloco'] == '4.5.1') {
            $a26 .= $row['abreviatura'] . "-" . $row['tipo'] . "-" . $row['sala'] . '<br>';
        }elseif ($row['dia_semana'] == 'Quinta' && $row['bloco'] == '4.6.1') {
            $a27 .= $row['abreviatura'] . "-" . $row['tipo'] . "-" . $row['sala'] . '<br>';
        }elseif ($row['dia_semana'] == 'Quinta' && $row['bloco'] == '4.7.1') {
            $a28 .= $row['abreviatura'] . "-" . $row['tipo'] . "-" . $row['sala'] . '<br>';
        }

        if ($row['dia_semana'] == 'Sexta' && $row['bloco'] == '5.1.1') {
            $a29 .= $row['abreviatura'] . ", " . $row['tipo'] . ", " . $row['sala'] . '<br>';
        }elseif ($row['dia_semana'] == 'Sexta' && $row['bloco'] == '5.2.1') {
            $a30 .= $row['abreviatura'] . "-" . $row['tipo'] . "-" . $row['sala'] . '<br>';
        }elseif ($row['dia_semana'] == 'Sexta' && $row['bloco'] == '5.3.1') {
            $a31 .= $row['abreviatura'] . "-" . $row['tipo'] . "-" . $row['sala'] . '<br>';
        }elseif ($row['dia_semana'] == 'Sexta' && $row['bloco'] == '5.4.1') {
            $a32 .= $row['abreviatura'] . "-" . $row['tipo'] . "-" . $row['sala'] . '<br>';
        }elseif ($row['dia_semana'] == 'Sexta' && $row['bloco'] == '5.5.1') {
            $a33 .= $row['abreviatura'] . "-" . $row['tipo'] . "-" . $row['sala'] . '<br>';
        }elseif ($row['dia_semana'] == 'Sexta' && $row['bloco'] == '5.6.1') {
            $a34 .= $row['abreviatura'] . "-" . $row['tipo'] . "-" . $row['sala'] . '<br>';
        }elseif ($row['dia_semana'] == 'Sexta' && $row['bloco'] == '5.7.1') {
            $a35 .= $row['abreviatura'] . "-" . $row['tipo'] . "-" . $row['sala'] . '<br>';
        }
    }
}else {
    echo "Error creating table: " . $conn->error;
}

    $sql = "SELECT abreviatura, tipo, dia_semana, hora_inicio, hora_fim, bloco, sala
    FROM turma, uc
    WHERE turma.professor = $numero AND uc.semestre = '2'  AND uc.id = turma.uc_id";
    $connect = $conn->query($sql);
    if ($connect == TRUE) {
        while($row = mysqli_fetch_array($connect,MYSQLI_ASSOC)){
            if ($row['dia_semana'] == 'Segunda' && $row['bloco'] == '1.1.2') {
                $a36 .= $row['abreviatura'] . "-" . $row['tipo'] . "-" . $row['sala'] . '<br>';
            }elseif ($row['dia_semana'] == 'Segunda' && $row['bloco'] == '1.2.2') {
                $a37 .= $row['abreviatura'] . "-" . $row['tipo'] . "-" . $row['sala'] . '<br>';
            }elseif ($row['dia_semana'] == 'Segunda' && $row['bloco'] == '1.3.2') {
                $a38 .= $row['abreviatura'] . "-" . $row['tipo'] . "-" . $row['sala'] . '<br>';
            }elseif ($row['dia_semana'] == 'Segunda' && $row['bloco'] == '1.4.2') {
                $a39 .= $row['abreviatura'] . "-" . $row['tipo'] . "-" . $row['sala'] . '<br>';
            }elseif ($row['dia_semana'] == 'Segunda' && $row['bloco'] == '1.5.2') {
                $a40 .= $row['abreviatura'] . "-" . $row['tipo'] . "-" . $row['sala'] . '<br>';
            }elseif ($row['dia_semana'] == 'Segunda' && $row['bloco'] == '1.6.2') {
                $a41 .= $row['abreviatura'] . "-" . $row['tipo'] . "-" . $row['sala'] . '<br>';
            }elseif ($row['dia_semana'] == 'Segunda' && $row['bloco'] == '1.7.2') {
                $a42 .= $row['abreviatura'] . "-" . $row['tipo'] . "-" . $row['sala'] . '<br>';
            }
            if ($row['dia_semana'] == 'Terça' && $row['bloco'] == '2.1.2') {
                $a43 .= $row['abreviatura'] . "-" . $row['tipo'] . "-" . $row['sala'] . '<br>';
            }elseif ($row['dia_semana'] == 'Terça' && $row['bloco'] == '2.2.2') {
                $a44 .= $row['abreviatura'] . "-" . $row['tipo'] . "-" . $row['sala'] . '<br>';
            }elseif ($row['dia_semana'] == 'Terça' && $row['bloco'] == '2.3.2') {
                $a45 .= $row['abreviatura'] . "-" . $row['tipo'] . "-" . $row['sala'] . '<br>';
            }elseif ($row['dia_semana'] == 'Terça' && $row['bloco'] == '2.4.2') {
                $a46 .= $row['abreviatura'] . "-" . $row['tipo'] . "-" . $row['sala'] . '<br>';
            }elseif ($row['dia_semana'] == 'Terça' && $row['bloco'] == '2.5.2') {
                $a47 .= $row['abreviatura'] . "-" . $row['tipo'] . "-" . $row['sala'] . '<br>';
            }elseif ($row['dia_semana'] == 'Terça' && $row['bloco'] == '2.6.2') {
                $a48 .= $row['abreviatura'] . "-" . $row['tipo'] . "-" . $row['sala'] . '<br>';
            }elseif ($row['dia_semana'] == 'Terça' && $row['bloco'] == '2.7.2') {
                $a49 .= $row['abreviatura'] . "-" . $row['tipo'] . "-" . $row['sala'] . '<br>';
            }

            if ($row['dia_semana'] == 'Quarta' && $row['bloco'] == '3.1.2') {
                $a50 .= $row['abreviatura'] . "-" . $row['tipo'] . "-" . $row['sala'] . '<br>';
            }elseif ($row['dia_semana'] == 'Quarta' && $row['bloco'] == '3.2.2') {
                $a51 .= $row['abreviatura'] . "-" . $row['tipo'] . "-" . $row['sala'] . '<br>';
            }elseif ($row['dia_semana'] == 'Quarta' && $row['bloco'] == '3.3.2') {
                $a52 .= $row['abreviatura'] . "-" . $row['tipo'] . "-" . $row['sala'] . '<br>';
            }elseif ($row['dia_semana'] == 'Quarta' && $row['bloco'] == '3.4.2') {
                $a53 .= $row['abreviatura'] . "-" . $row['tipo'] . "-" . $row['sala'] . '<br>';
            }elseif ($row['dia_semana'] == 'Quarta' && $row['bloco'] == '3.5.2') {
                $a54 .= $row['abreviatura'] . "-" . $row['tipo'] . "-" . $row['sala'] . '<br>';
            }elseif ($row['dia_semana'] == 'Quarta' && $row['bloco'] == '3.6.2') {
                $a55 .= $row['abreviatura'] . "-" . $row['tipo'] . "-" . $row['sala'] . '<br>';
            }elseif ($row['dia_semana'] == 'Quarta' && $row['bloco'] == '3.7.2') {
                $a56 .= $row['abreviatura'] . "-" . $row['tipo'] . "-" . $row['sala'] . '<br>';
            }

            if ($row['dia_semana'] == 'Quinta' && $row['bloco'] == '4.1.2') {
                $a57 .= $row['abreviatura'] . "-" . $row['tipo'] . "-" . $row['sala'] . '<br>';
            }elseif ($row['dia_semana'] == 'Quinta' && $row['bloco'] == '4.2.2') {
                $a58 .= $row['abreviatura'] . "-" . $row['tipo'] . "-" . $row['sala'] . '<br>';
            }elseif ($row['dia_semana'] == 'Quinta' && $row['bloco'] == '4.3.2') {
                $a59 .= $row['abreviatura'] . "-" . $row['tipo'] . "-" . $row['sala'] . '<br>';
            }elseif ($row['dia_semana'] == 'Quinta' && $row['bloco'] == '4.4.2') {
                $a60 .= $row['abreviatura'] . "-" . $row['tipo'] . "-" . $row['sala'] . '<br>';
            }elseif ($row['dia_semana'] == 'Quinta' && $row['bloco'] == '4.5.2') {
                $a61 .= $row['abreviatura'] . "-" . $row['tipo'] . "-" . $row['sala'] . '<br>';
            }elseif ($row['dia_semana'] == 'Quinta' && $row['bloco'] == '4.6.2') {
                $a62 .= $row['abreviatura'] . "-" . $row['tipo'] . "-" . $row['sala'] . '<br>';
            }elseif ($row['dia_semana'] == 'Quinta' && $row['bloco'] == '4.7.2') {
                $a63 .= $row['abreviatura'] . "-" . $row['tipo'] . "-" . $row['sala'] . '<br>';
            }

            if ($row['dia_semana'] == 'Sexta' && $row['bloco'] == '5.1.2') {
                $a64 .= $row['abreviatura'] . "-" . $row['tipo'] . "-" . $row['sala'] . '<br>';
            }elseif ($row['dia_semana'] == 'Sexta' && $row['bloco'] == '5.2.2') {
                $a65 .= $row['abreviatura'] . "-" . $row['tipo'] . "-" . $row['sala'] . '<br>';
            }elseif ($row['dia_semana'] == 'Sexta' && $row['bloco'] == '5.3.2') {
                $a66 .= $row['abreviatura'] . "-" . $row['tipo'] . "-" . $row['sala'] . '<br>';
            }elseif ($row['dia_semana'] == 'Sexta' && $row['bloco'] == '5.4.2') {
                $a67 .= $row['abreviatura'] . "-" . $row['tipo'] . "-" . $row['sala'] . '<br>';
            }elseif ($row['dia_semana'] == 'Sexta' && $row['bloco'] == '5.5.2') {
                $a68 .= $row['abreviatura'] . "-" . $row['tipo'] . "-" . $row['sala'] . '<br>';
            }elseif ($row['dia_semana'] == 'Sexta' && $row['bloco'] == '5.6.2') {
                $a69 .= $row['abreviatura'] . "-" . $row['tipo'] . "-" . $row['sala'] . '<br>';
            }elseif ($row['dia_semana'] == 'Sexta' && $row['bloco'] == '5.7.2') {
                $a70 .= $row['abreviatura'] . "-" . $row['tipo'] . "-" . $row['sala'] . '<br>';
            }
        }
    } else {
                echo "Error creating table: " . $conn->error;
    }

    echo "<script type='text/javascript'>",
                "window.onload = function () {",
                    "document.getElementById('1.1.1').innerHTML='$a1';",
                    "document.getElementById('1.2.1').innerHTML='$a2';",
                    "document.getElementById('1.3.1').innerHTML='$a3';",
                    "document.getElementById('1.4.1').innerHTML='$a4';",
                    "document.getElementById('1.5.1').innerHTML='$a5';",
                    "document.getElementById('1.6.1').innerHTML='$a6';",
                    "document.getElementById('1.7.1').innerHTML='$a7';",
                    "document.getElementById('2.1.1').innerHTML='$a8';",
                    "document.getElementById('2.2.1').innerHTML='$a9';",
                    "document.getElementById('2.3.1').innerHTML='$a10';",
                    "document.getElementById('2.4.1').innerHTML='$a11';",
                    "document.getElementById('2.5.1').innerHTML='$a12';",
                    "document.getElementById('2.6.1').innerHTML='$a13';",
                    "document.getElementById('2.7.1').innerHTML='$a14';",
                    "document.getElementById('3.1.1').innerHTML='$a15';",
                    "document.getElementById('3.2.1').innerHTML='$a16';",
                    "document.getElementById('3.3.1').innerHTML='$a17';",
                    "document.getElementById('3.4.1').innerHTML='$a18';",
                    "document.getElementById('3.5.1').innerHTML='$a19';",
                    "document.getElementById('3.6.1').innerHTML='$a20';",
                    "document.getElementById('3.7.1').innerHTML='$a21';",
                    "document.getElementById('4.1.1').innerHTML='$a22';",
                    "document.getElementById('4.2.1').innerHTML='$a23';",
                    "document.getElementById('4.3.1').innerHTML='$a24';",
                    "document.getElementById('4.4.1').innerHTML='$a25';",
                    "document.getElementById('4.5.1').innerHTML='$a26';",
                    "document.getElementById('4.6.1').innerHTML='$a27';",
                    "document.getElementById('4.7.1').innerHTML='$a28';",
                    "document.getElementById('5.1.1').innerHTML='$a29';",
                    "document.getElementById('5.2.1').innerHTML='$a30';",
                    "document.getElementById('5.3.1').innerHTML='$a31';",
                    "document.getElementById('5.4.1').innerHTML='$a32';",
                    "document.getElementById('5.5.1').innerHTML='$a33';",
                    "document.getElementById('5.6.1').innerHTML='$a34';",
                    "document.getElementById('5.7.1').innerHTML='$a35';",
                    "document.getElementById('1.1.2').innerHTML='$a36';",
                    "document.getElementById('1.2.2').innerHTML='$a37';",
                    "document.getElementById('1.3.2').innerHTML='$a38';",
                    "document.getElementById('1.4.2').innerHTML='$a39';",
                    "document.getElementById('1.5.2').innerHTML='$a40';",
                    "document.getElementById('1.6.2').innerHTML='$a41';",
                    "document.getElementById('1.7.2').innerHTML='$a42';",
                    "document.getElementById('2.1.2').innerHTML='$a43';",
                    "document.getElementById('2.2.2').innerHTML='$a44';",
                    "document.getElementById('2.3.2').innerHTML='$a45';",
                    "document.getElementById('2.4.2').innerHTML='$a46';",
                    "document.getElementById('2.5.2').innerHTML='$a47';",
                    "document.getElementById('2.6.2').innerHTML='$a48';",
                    "document.getElementById('2.7.2').innerHTML='$a49';",
                    "document.getElementById('3.1.2').innerHTML='$a50';",
                    "document.getElementById('3.2.2').innerHTML='$a51';",
                    "document.getElementById('3.3.2').innerHTML='$a52';",
                    "document.getElementById('3.4.2').innerHTML='$a53';",
                    "document.getElementById('3.5.2').innerHTML='$a54';",
                    "document.getElementById('3.6.2').innerHTML='$a55';",
                    "document.getElementById('3.7.2').innerHTML='$a56';",
                    "document.getElementById('4.1.2').innerHTML='$a57';",
                    "document.getElementById('4.2.2').innerHTML='$a58';",
                    "document.getElementById('4.3.2').innerHTML='$a59';",
                    "document.getElementById('4.4.2').innerHTML='$a60';",
                    "document.getElementById('4.5.2').innerHTML='$a61';",
                    "document.getElementById('4.6.2').innerHTML='$a62';",
                    "document.getElementById('4.7.2').innerHTML='$a63';",
                    "document.getElementById('5.1.2').innerHTML='$a64';",
                    "document.getElementById('5.2.2').innerHTML='$a65';",
                    "document.getElementById('5.3.2').innerHTML='$a66';",
                    "document.getElementById('5.4.2').innerHTML='$a67';",
                    "document.getElementById('5.5.2').innerHTML='$a68';",
                    "document.getElementById('5.6.2').innerHTML='$a69';",
                    "document.getElementById('5.7.2').innerHTML='$a70';",
                    "document.getElementById('menu-aluno').style.display='none';",
                    "document.getElementById('menu-prof').style.display='block';",
                    "document.getElementById('user').innerHTML='Professor: $nome';",
                    "document.getElementById('login').style.display='none';",
                    "document.getElementById('divlogoff').style.display='block';",
                    "document.getElementById('logoff').innerHTML='Log Off';",
                    "document.getElementById('logoff').href = '".base_url()."home?off=true';",
                "};",
                "</script>";
}
?>