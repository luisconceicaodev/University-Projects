<?php
    echo "<div class='w3-container mainbox' id='CIE'>
    <h1 id='MC'>Consultar Inscritos nos Exames</h1>
    <br>";
    echo "<p id='pconsultar' style='display:none'>Selecione a disciplina à qual pretende consultar os alunos inscritos nos exames:</p>";
    $sql = "SELECT id, nome
    FROM uc
    WHERE coordenador = $numero";
    $connect = $conn->query($sql);
    if ($connect == TRUE) {
        if($connect->num_rows > 0) {
            echo "<table class='w3-table-all table-responsive table' id='consultar'>
            <tr class='w3-indigo'>
            <th>" . "Disciplina" . "</th>";
            while($row = mysqli_fetch_array($connect,MYSQLI_ASSOC)){
                echo "<tr>";
            foreach ($row as $chave => $valor){
                if ($chave !== 'id'){
                    echo "<td>" . $valor . "</td>";
                }
            }
            echo "<td><form action='verinscritosexames' method='POST'>
                <input type='submit' class='btn btn-primary' name='consultarprof' value='Consultar'/>
                <input type='hidden' name='ucprof' href='' id='join' value='$row[id]'>
                <input type='hidden' name='ucnomeprof' href='' id='join' value='$row[nome]'>
                </form></td>";
            echo "</tr>";
            }   
            echo "</table>";
            echo "</div>";
        }else{
            echo "</div>";
            echo "<script type='text/javascript'>",
                        "document.getElementById('CIE').style.display='none';",
                    "</script>";
                    echo "<div class='w3-container mainbox'><h1>Você não tem permissões de coordenador nas unidades curriculares.</h1></div>";
        }
    } else {
        echo "Error creating table: " . $conn->error;
    }

    if(isset($_POST['consultarprof'])){
        echo "<script type='text/javascript'>",
        "document.getElementById('CIE').style.display='none';",
        "</script>";
        $id_uc = $_POST ['ucprof'];
        $nome_uc = $_POST ['ucnomeprof'];
        echo "<div class='w3-container mainbox'>
        <h1 id='MC'>$nome_uc:</h1>
        <h2>Consulta de Alunos Inscritos nos Exames</h2>
        <br>
        ";
        $sql = "SELECT aluno_id, fase
        FROM inscritos_exame
        WHERE uc_id = $id_uc";
        $connect = $conn->query($sql);
        if ($connect == TRUE) {
            echo "<table class='w3-table-all table-responsive table' id=''>
            <tr class='w3-indigo'>
            <th>" . "Nº Aluno" . "</th>
            <th>" . "Fase" . "</th>";
            while($row = mysqli_fetch_array($connect,MYSQLI_ASSOC)){
                echo "<tr>";
                foreach ($row as $chave => $valor){
                    echo "<td>" . $valor . "</td>";
                }
            }
            echo "</table>";
            echo "</div>";
        }else{
            echo '<script language="javascript">',
            "alert('Ocorreu um erro na pesquisa da base de dados.')",
            '</script>';
            echo "<h1>".$conn->error."</h1>";
        }
    }
?>