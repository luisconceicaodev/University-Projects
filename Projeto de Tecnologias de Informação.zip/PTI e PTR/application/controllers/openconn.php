<?php

    $dbhost = "34.76.112.55";
  	$dbuser = "root";
  	$dbpass = "123";
  	$dbname = "ptiptr";
  	$dbport = 3306;
  	$dbsocket = "/cloudsql/ptiptr:europe-west1:ptiptr";

	$conn = mysqli_connect(null, $dbuser, $dbpass, $dbname, null,$dbsocket);
	if (!$conn) {
		die("Connection failed: " . mysqli_connect_error());
	}
	mysqli_set_charset($conn,"utf8");

    function login_handler($email, $numero, $nome, $curso, $disciplinas, $gabinete, $conn) {
        $url = $_SERVER['REQUEST_URI'];
        if ($url === '/infoPessoa') {
            if ($_SESSION['professor']) {
                $notificacoes = "";
                $sql= "SELECT * FROM notificacao WHERE para = $numero";
                $result = mysqli_query($conn, $sql);
                while ($rows = mysqli_fetch_array($result, MYSQLI_ASSOC)) {
                    $notificacoes .= '<br>' . $rows['mensagem'] . ' <br>';
                }
                if ($notificacoes !== "") {
                    echo "<script type='text/javascript'>",
                    "window.onload = function () {",
                    "document.getElementById('informacao').style.display='block';",
                    "document.getElementById('nome').innerHTML='<strong>Nome:</strong> $nome';",
                    "document.getElementById('user').innerHTML='Professor: $nome';",
                    "document.getElementById('curso').innerHTML='<strong>Departamento:</strong> $curso';",
                    "document.getElementById('disciplinas').innerHTML='<strong>Disciplinas:</strong> $disciplinas';",
                    "document.getElementById('notificacoes').innerHTML='<strong>Notificações:</strong> $notificacoes';",
                    "document.getElementById('gabinete').innerHTML='<strong>Gabinete:</strong> $gabinete';",
                    "document.getElementById('login').style.display='none';",
                    "document.getElementById('logoff').innerHTML='Log Off';",
                    "document.getElementById('divlogoff').style.display='block';",
                    "document.getElementById('logoff').href = '".base_url()."home?off=true';",
                    "document.getElementById('numero').innerHTML='<strong>Nº de Professor:</strong> $numero';",
                    "document.getElementById('email').innerHTML='<strong>Email:</strong> $email';",
                    "document.getElementById('menu-prof').style.display='block';",
                    "document.getElementById('menu-aluno').style.display='none';",
                    "document.getElementById('elimina').style.display='block';",
                "};",
                "</script>";
                }else{
                    echo "<script type='text/javascript'>",
                    "window.onload = function () {",
                    "document.getElementById('informacao').style.display='block';",
                    "document.getElementById('nome').innerHTML='<strong>Nome:</strong> $nome';",
                    "document.getElementById('user').innerHTML='Professor: $nome';",
                    "document.getElementById('curso').innerHTML='<strong>Departamento:</strong> $curso';",
                    "document.getElementById('disciplinas').innerHTML='<strong>Disciplinas:</strong> $disciplinas';",
                    "document.getElementById('notificacoes').innerHTML='De momento você não tem notificações.';",
                    "document.getElementById('gabinete').innerHTML='<strong>Gabinete:</strong> $gabinete';",
                    "document.getElementById('login').style.display='none';",
                    "document.getElementById('logoff').innerHTML='Log Off';",
                    "document.getElementById('divlogoff').style.display='block';",
                    "document.getElementById('logoff').href = '".base_url()."home?off=true';",
                    "document.getElementById('numero').innerHTML='<strong>Nº de Professor:</strong> $numero';",
                    "document.getElementById('email').innerHTML='<strong>Email:</strong> $email';",
                    "document.getElementById('menu-prof').style.display='block';",
                    "document.getElementById('menu-aluno').style.display='none';",
                "};",
                "</script>";
                }
            }elseif ($_SESSION['aluno']) {
                $notificacoes = "";
                $sql= "SELECT * FROM notificacao WHERE para = $numero";
                $result = mysqli_query($conn, $sql);
                while ($rows = mysqli_fetch_array($result, MYSQLI_ASSOC)) {
                    $notificacoes .= '<br>' . $rows['de'] . ' : ' . $rows['mensagem'] . ' <br>';
                }
                if ($notificacoes !== "") {
                    echo "<script type='text/javascript'>",
                    "window.onload = function () {",
                    "document.getElementById('informacao').style.display='block';",
                    "document.getElementById('nome').innerHTML='<strong>Nome:</strong> $nome';",
                    "document.getElementById('user').innerHTML='Aluno: $nome';",
                    "document.getElementById('curso').innerHTML='<strong>Curso:</strong> $curso';",
                    "document.getElementById('disciplinas').innerHTML='<strong>Disciplinas:</strong> $disciplinas';",
                    "document.getElementById('notificacoes').innerHTML='<strong>Notificações:</strong> $notificacoes';",
                    "document.getElementById('login').style.display='none';",
                    "document.getElementById('logoff').innerHTML='Log Off';",
                    "document.getElementById('divlogoff').style.display='block';",
                    "document.getElementById('logoff').href = '".base_url()."home?off=true';",
                    "document.getElementById('numero').innerHTML='<strong>Nº de Aluno:</strong> $numero';",
                    "document.getElementById('email').innerHTML='<strong>Email:</strong> $email';",
                    "document.getElementById('menu-aluno').style.display='block';",
                    "document.getElementById('menu-prof').style.display='none';",
                    "document.getElementById('elimina').style.display='block';",
                "};",
                "</script>";
                }else{
                    echo "<script type='text/javascript'>",
                    "window.onload = function () {",
                    "document.getElementById('informacao').style.display='block';",
                    "document.getElementById('nome').innerHTML='<strong>Nome:</strong> $nome';",
                    "document.getElementById('user').innerHTML='Aluno: $nome';",
                    "document.getElementById('curso').innerHTML='<strong>Curso:</strong> $curso';",
                    "document.getElementById('disciplinas').innerHTML='<strong>Disciplinas:</strong> $disciplinas';",
                    "document.getElementById('notificacoes').innerHTML='De momento você não tem notificações.';",
                    "document.getElementById('login').style.display='none';",
                    "document.getElementById('logoff').innerHTML='Log Off';",
                    "document.getElementById('divlogoff').style.display='block';",
                    "document.getElementById('logoff').href = '".base_url()."home?off=true';",
                    "document.getElementById('numero').innerHTML='<strong>Nº de Aluno:</strong> $numero';",
                    "document.getElementById('email').innerHTML='<strong>Email:</strong> $email';",
                    "document.getElementById('menu-aluno').style.display='block';",
                    "document.getElementById('menu-prof').style.display='none';",
                "};",
                "</script>";
                }
            }
        } elseif ($url === '/horario') {
		}else {
            if ($_SESSION['professor']) {
                echo "<script type='text/javascript'>",
                "window.onload = function () {",
                    "document.getElementById('menu-aluno').style.display='none';",
                    "document.getElementById('menu-prof').style.display='block';",
                    "document.getElementById('user').innerHTML='Professor: $nome';",
                    "document.getElementById('login').style.display='none';",
                    "document.getElementById('divlogoff').style.display='block';",
                    "document.getElementById('logoff').innerHTML='Log Off';",
                    "document.getElementById('logoff').href = '".base_url()."home?off=true';",
                "};",
                "</script>";
            }elseif ($_SESSION['aluno']) {
                echo "<script type='text/javascript'>",
                "window.onload = function () {",
                    "document.getElementById('menu-aluno').style.display='block';",
                    "document.getElementById('menu-prof').style.display='none';",
                    "document.getElementById('user').innerHTML='Aluno: $nome';",
                    "document.getElementById('login').style.display='none';",
                    "document.getElementById('divlogoff').style.display='block';",
                    "document.getElementById('logoff').innerHTML='Log Off';",
                    "document.getElementById('logoff').href = '".base_url()."home?off=true';",
                "};",
                "</script>";
            }elseif ($_SESSION['admin']) {
                echo "<script type='text/javascript'>",
                "window.onload = function () {",
                    "document.getElementById('sub-menu-admin').style.display='block';",
                    "document.getElementById('user').innerHTML='Administrador';",
                    "document.getElementById('login').style.display='none';",
                    "document.getElementById('divlogoff').style.display='block';",
                    "document.getElementById('logoff').innerHTML='Log Off';",
                    "document.getElementById('logoff').href = '".base_url()."admin?off=true';",
                "};",
                "</script>";
            }
        }
    }

    session_start();
    if (isset($_GET['off'])) {
        $_SESSION['loggedin'] = false;
		$_SESSION['email'] = null;
        $_SESSION['numero'] = null;
        $_SESSION['aluno'] = null;
        $_SESSION['professor'] = null;
        $_SESSION['curso'] = null;
        $_SESSION['nome'] = null;
        $_SESSION['disciplinas'] = null;
        $_SESSION['email'] = null;
        $_SESSION['gabinete'] = null;
        echo "<div class='toast__container'>
        <div class='toast__cell mainbox'>
            <div class='toast toast--green'>
                <div class='toast__icon'>
                </div>
                <div class='toast__content'>
                    <p class='toast__type'>Sucesso</p>
                    <p class='toast__message'>Sessão terminada.</p>
                </div>
                <div class='toast__close'>
                    X
                </div>
            </div>
        </div>
    </div>";
    }
    
     if (isset($_SESSION['loggedin']) && $_SESSION['loggedin'] == true) {
        $email = $_SESSION['email'];
        $numero = $_SESSION['numero'];
        $nome = $_SESSION['nome'];
        $curso = null;
        $disciplinas = null;
        $gabinete = null;

        if ($_SESSION['aluno']) {
            $curso = $_SESSION['curso'];
            $disciplinas = $_SESSION['disciplinas'];
        }

        if ($_SESSION['professor']) {
            $curso = $_SESSION['departamento'];
            $disciplinas = $_SESSION['disciplinas'];
            $gabinete = $_SESSION['gabinete'];
        }
        login_handler($email, $numero, $nome, $curso, $disciplinas, $gabinete, $conn);
    }
    
    if(isset($_POST ['Login'])) {
        $email = mysqli_real_escape_string($conn,$_POST['email']);
        $pass = mysqli_real_escape_string($conn,$_POST['pass']);

        $sql = "SELECT nome FROM pessoa WHERE email = '$email' AND pass = '$pass'";
        $result = mysqli_query($conn,$sql);
        $row = mysqli_fetch_array($result,MYSQLI_ASSOC);
        $count = mysqli_num_rows($result);
        
        $sql = "SELECT * FROM pessoa WHERE '$email' = email";
            $result = mysqli_query($conn, $sql);
            while ($rows = mysqli_fetch_array($result, MYSQLI_ASSOC)) {
                $numero = $rows['numero'];
                $nome = $rows['nome'];
            }
		if(isset($nome)) {
            $_SESSION['nome'] = $nome;
		}
		
		if (isset($numero)) {
			$sql = "SELECT prof_id FROM professor WHERE prof_id = '$numero'";
			$result = mysqli_query($conn,$sql);
			$row = mysqli_fetch_array($result,MYSQLI_ASSOC);
			$countprof = mysqli_num_rows($result);

			$sql = "SELECT aluno_id FROM aluno WHERE aluno_id = '$numero'";
			$result = mysqli_query($conn,$sql);
			$row = mysqli_fetch_array($result,MYSQLI_ASSOC);
			$countaluno = mysqli_num_rows($result);
		}

        if($count == 1) {
            $_SESSION['loggedin'] = true;
            $_SESSION['email'] = $email;
            $_SESSION['numero'] = $numero;
            $_SESSION['professor'] = false;
            $_SESSION['aluno'] = false;
            $_SESSION['curso'] = null;
            $_SESSION['disciplinas'] = null;
            $_SESSION['gabinete'] = null;
            echo "<div class='toast__container'>
        <div class='toast__cell mainbox'>
            <div class='toast toast--green'>
                <div class='toast__icon'>
                </div>
                <div class='toast__content'>
                    <p class='toast__type'>Sucesso</p>
                    <p class='toast__message'>Sessão iniciada.</p>
                </div>
                <div class='toast__close'>
                    X
                </div>
            </div>
        </div>
    </div>";
            if ($countprof == 1) {
                $_SESSION['professor'] = true;
                $sql = "SELECT * FROM professor WHERE '$numero' = prof_id";
                $result = mysqli_query($conn, $sql);
                while ($rows = mysqli_fetch_array($result, MYSQLI_ASSOC)) {
                    $curso = $rows['departamento'];
                    $gabinete = $rows['gabinete'];
                }
                $_SESSION['gabinete'] = $gabinete;
                $_SESSION['departamento'] = $curso;
                $disciplinas = "";
                $sql = "SELECT id,nome
                FROM uc
                WHERE coordenador = $numero";
                $result = mysqli_query($conn, $sql);
                while ($rows = mysqli_fetch_array($result, MYSQLI_ASSOC)) {
                    $disciplinas .= $rows['nome'] . "; ";
                }
                $_SESSION['disciplinas'] = $disciplinas;
            }elseif ($countaluno == 1) {
                $_SESSION['aluno'] = true;
                $sql = "SELECT * FROM aluno WHERE '$numero' = aluno_id";
                $result = mysqli_query($conn, $sql);
                while ($rows = mysqli_fetch_array($result, MYSQLI_ASSOC)) {
                    $curso = $rows['curso'];
                }
                $_SESSION['curso'] = $curso;
                $disciplinas = "";
                $sql = "SELECT id,nome
                FROM uc
                WHERE EXISTS (
                    SELECT *
                    FROM inscritos AS i 
                    WHERE uc.id=i.uc_id AND '$numero' = i.aluno_id)";
                $result = mysqli_query($conn, $sql);
                while ($rows = mysqli_fetch_array($result, MYSQLI_ASSOC)) {
                    $disciplinas .= $rows['nome'] . "; ";
                }
                $_SESSION['disciplinas'] = $disciplinas;
            }
            login_handler($email, $numero, $_SESSION['nome'], $_SESSION['curso'], $_SESSION['disciplinas'],$_SESSION['gabinete'], $conn);
        }else {
            echo "<div class='toast__container'>
        <div class='toast__cell mainbox'>
        <div class='toast toast--yellow'>
          <div class='toast__icon'>
          </div>
          <div class='toast__content'>
            <p class='toast__type'>Erro</p>
            <p class='toast__message'>O email ou password inseridos não estão associados a uma conta. Verifique que os inseriu corretamente e tente novamente.</p>
          </div>
          <div class='toast__close'>
            X
          </div>
        </div>
        </div>
        </div>";
        }
    }

    if(isset($_POST ['Login_Admin'])) {
        $count = 0;
        $email = mysqli_real_escape_string($conn,$_POST['email']);
        $pass = mysqli_real_escape_string($conn,$_POST['pass']);

        if ($email == 'admin@admin.com' && $pass == '0987') {
            $count = 1;
        }

        if($count == 1) {
            $_SESSION['loggedin'] = true;
            $_SESSION['email'] = $email;
            $_SESSION['numero'] = null;
            $_SESSION['professor'] = false;
            $_SESSION['aluno'] = false;
            $_SESSION['admin'] = true;
            $_SESSION['curso'] = null;
            $_SESSION['nome'] = null;
            $_SESSION['gabinete'] = null;
            $_SESSION['disciplinas'] = null;
            login_handler($email, null, null, null, null, null, null);
            echo "<div class='toast__container'>
        <div class='toast__cell mainbox'>
            <div class='toast toast--green'>
                <div class='toast__icon'>
                </div>
                <div class='toast__content'>
                    <p class='toast__type'>Sucesso</p>
                    <p class='toast__message'>Sessão iniciada.</p>
                </div>
                <div class='toast__close'>
                    X
                </div>
            </div>
        </div>
    </div>";
        }else {
            echo "<div class='toast__container'>
        <div class='toast__cell mainbox'>
        <div class='toast toast--yellow'>
          <div class='toast__icon'>
          </div>
          <div class='toast__content'>
            <p class='toast__type'>Erro</p>
            <p class='toast__message'>O email ou password inseridos não estão associados conta. Verifique que os inseriu corretamente e tente novamente.</p>
          </div>
          <div class='toast__close'>
            X
          </div>
        </div>
        </div>
        </div>";
        }
    }
?>