<?php
echo "<div class='w3-container mainbox' id='GRU'>
<h1 id='MC'>Gerir Turmas</h1>
<br>";
echo "<p id='pconsultar'>Selecione a disciplina à qual pretende abrir/fechar as inscrições/pedidos de mudança de turma.</p>";
$sql = "SELECT id, nome
FROM uc
WHERE coordenador = $numero";
$connect = $conn->query($sql);
if ($connect == TRUE) {
    if($connect->num_rows > 0) {
        echo "<table class='w3-table-all table-responsive table' id='consultar'>
        <tr class='w3-indigo'>
        <th>" . "Disciplina" . "</th>";
        while($row = mysqli_fetch_array($connect,MYSQLI_ASSOC)){
            echo "<tr>";
        foreach ($row as $chave => $valor){
            if ($chave !== 'id'){
                echo "<td>" . $valor . "</td>";
            }
        }
        echo "<td><form action='gerirturmas' method='POST'>
            <input type='submit' class='btn btn-primary' name='ucturma' value='Selecionar'/>
            <input type='hidden' name='ucprof' href='' value='$row[id]'>
            <input type='hidden' name='ucnomeprof' href='' value='$row[nome]'>
            </form></td>";
        echo "</tr>";
        }   
        echo "</table>";
        echo "</div>";
    }else{ # se professor não for coordenador de nenhuma UC 
        echo "</div>";
        echo "<script type='text/javascript'>",
                "document.getElementById('GRU').style.display='none';",
            "</script>";
            echo "<div class='w3-container mainbox'><h1>Não foram encontradas unidades curriculares cujo o professor fosse coordenador.</h1></div>";
    }
}else {
    echo "Error creating table: " . $conn->error;
}

if(isset($_POST['ucturma'])){
    echo "<script type='text/javascript'>",
    "document.getElementById('GRU').style.display='none';",
    "</script>";
    $id_uc = $_POST ['ucprof'];
    $nome_uc = $_POST ['ucnomeprof'];
    $sql = "SELECT t.id,t.uc_id,tipo,dia_semana,hora_inicio,hora_fim,sala,ano_letivo,max_alunos,status,NULL
        FROM turma as t, uc as u
        WHERE u.coordenador = '$numero' AND u.id = $id_uc AND t.uc_id = u.id";
$connect = $conn->query($sql);
if ($connect == TRUE) {
    $turmaidArray = array();
    $count = 0;
    $count2 = 10;
    $aberta=True;
    echo "<div class='w3-container mainbox' id='bigtable'>
    <h1>Gestão de turmas</h1>
    <p>Nesta página você pode decidir se uma turma deve permanecer aberta ou fechada a inscrições/mudanças de turma.</p>
    <br>";
    echo "<table class='w3-table-all table-responsive table' class='jogo'>
            <tr class='w3-indigo'>
            <th>" . "Tipo" . "</th>" .
            "<th>" . "Dia da semana" . "</th>" .
            "<th>" . "Hora inicio" . "</th>" .
            "<th>" . "Hora fim" . "</th>" .
            "<th>" . "Sala" . "</th>" .
            "<th>" . "Ano Letivo" . "</th>" .
            "<th>" . "Nº Máximo de Alunos" . "</th>" .
            "<th>" . "Estado da UC" . "</th>" .
            "<th>" . "Nº Alunos Inscritos" . "</th>" .
            "<th>" . "Decisão" . "</th>" ;
    while($row = mysqli_fetch_array($connect,MYSQLI_ASSOC)){
        array_push($turmaidArray,$row['id']);
        $turmaid = $row['id'];
        echo "<tr>";
        
        foreach ($row as $chave => $valor){
            if ($chave !== 'id' && $chave !== 'uc_id' && $chave !== 'NULL'){
                echo "<td>" . $valor . "</td>";
            }
            if ($row['status']=='Aberta') {
                $aberta = True;
            }else {
                $aberta = False;
            }
            if ($chave == 'NULL') {
                echo "<td id='". $count ."'></td>";
                $count+=1;
                if ($aberta == True) {
                    echo "<td><form action='gerirturmas' method='POST'>
                            <input type='submit' class='btn btn-primary' name='fechar' href='' value='Fechar'>
                            <input type='hidden' name='id_turma' href='' value='$turmaid'>
                            </form></td>";
                }else{
                    echo "<td><form action='gerirturmas' method='POST'>
                    <input type='submit' class='btn btn-primary' name='abrir' href='' value='Abrir'>
                    <input type='hidden' name='id_turma' href='' value='$turmaid'>
                    </form></td>";
                }
            }
            
        }
        echo "</tr>";
    }
    if (isset($turmaidArray)) {
        $count = 0;
        $count2 = 10;
        foreach($turmaidArray as $id) {
            $sql = "SELECT COUNT(turma_id) FROM inscritos WHERE turma_id='$id'";
            $connect = $conn->query($sql);
            if ($connect == TRUE) {
                while($row = mysqli_fetch_array($connect,MYSQLI_ASSOC)){
                    foreach ($row as $chave => $valor){
                            echo "<script type='text/javascript'>",
                            "document.getElementById('".$count."').innerHTML='$valor';",
                            "</script>";
                            $count +=1;
                    }
                    
                }
            }
        }
    }
    echo "</table>";
    echo "</div>";
}else{
    echo "<div class='w3-container mainbox'>
    <h1>Não foram encontradas turmas para a presente disciplina.</h1>
    </div>";
}
}

if(isset($_POST['fechar'])){
    $id_turma = $_POST ['id_turma'];

    $sql = "UPDATE turma SET status='Fechada' WHERE id='$id_turma'";
    if ($conn->query($sql) == TRUE) {
        echo "<div class='toast__container'>
        <div class='toast__cell mainbox'>
            <div class='toast toast--green'>
                <div class='toast__icon'>
                </div>
                <div class='toast__content'>
                    <p class='toast__type'>Sucesso</p>
                    <p class='toast__message'>Turma fechada com sucesso.</p>
                </div>
                <div class='toast__close'>
                    X
                </div>
            </div>
        </div>
    </div>";
    }else{
        echo "<div class='toast__container'>
        <div class='toast__cell mainbox'>
        <div class='toast toast--yellow'>
          <div class='toast__icon'>
          </div>
          <div class='toast__content'>
            <p class='toast__type'>Erro</p>
            <p class='toast__message'>O pedido de fechar a turma falhou.</p>
          </div>
          <div class='toast__close'>
            X
          </div>
        </div>
        </div>
        </div>";
    }
}
if(isset($_POST['abrir'])) {
    echo "<script type='text/javascript'>",
    "window.onload = function () {",
        "document.getElementById('menu-prof').style.display='block';",
        "document.getElementById('user').innerHTML='Utilizador: $numero';",
        "document.getElementById('login').style.visibility='hidden';",
        "document.getElementById('logoff').innerHTML='Log Off';",
        "document.getElementById('logoff').href = '".base_url()."home?off=true';",
    "};",
    "</script>";
    $id_turma = $_POST ['id_turma'];

    $sql = "UPDATE turma SET status='Aberta' WHERE id='$id_turma'";
    if ($conn->query($sql) == TRUE) {
        echo "<div class='toast__container'>
        <div class='toast__cell mainbox'>
            <div class='toast toast--green'>
                <div class='toast__icon'>
                </div>
                <div class='toast__content'>
                    <p class='toast__type'>Sucesso</p>
                    <p class='toast__message'>Turma aberta com sucesso.</p>
                </div>
                <div class='toast__close'>
                    X
                </div>
            </div>
        </div>
    </div>";
    }else{
        echo "<div class='toast__container'>
        <div class='toast__cell mainbox'>
        <div class='toast toast--yellow'>
          <div class='toast__icon'>
          </div>
          <div class='toast__content'>
            <p class='toast__type'>Erro</p>
            <p class='toast__message'>O pedido de fechar a turma falhou.</p>
          </div>
          <div class='toast__close'>
            X
          </div>
        </div>
        </div>
        </div>";
    }
}
?>