<?php
    $url = $_SERVER['REQUEST_URI'];
    if ($url === '/inscricaoUC') {
        echo "<div class='w3-container mainbox'>
        <h1 id='seme'>Selecione uma Disciplina: 1º Semestre</h1>
    <div class='w3-bar w3-border w3-light-grey'>
        <button onclick='showsem1()' class='w3-bar-item w3-button w3-indigo' style='margin-right:1em'>1º Semestre</button>
        <button onclick='showsem2()' class='w3-bar-item w3-button w3-indigo'>2º Semestre</button>
    </div>
    <br>";
        $sql = "SELECT id, nome, ects, semestre, professores
            FROM uc
            WHERE semestre = '1'";
        $connect = $conn->query($sql);
        if ($connect == TRUE) {
        echo "<table class='w3-table-all table-responsive table' id='um'>
        <tr class='w3-indigo'>
        <th>" . "Nº" . "</th>
        <th>" . "Disciplina" . "</th>" .
        "<th>" . "ECTS" . "</th>" .
        "<th>" . "Semestre" . "</th>" .
        "<th>" . "Professores" . "</th>";
        while($row = mysqli_fetch_array($connect,MYSQLI_ASSOC)){
            echo "<tr>";
        foreach ($row as $chave => $valor){
            echo "<td>" . $valor . "</td>";
        }
            echo "<td><form action='inscricaoHorario' method='POST'>
                <input type='submit' name='join' class='btn btn-primary' value='Selecionar'/>
                <input type='hidden' name='id1' href='' value='$row[id]'>
                <input type='hidden' name='ucnome1' href='' value='$row[nome]'>
                </form></td>";
            echo "</tr>";
        }

    } else {
                echo "Error creating table: " . $conn->error;
    }
    echo "</table>";

        $sql = "SELECT id, nome, ects, semestre, professores
            FROM uc
            WHERE semestre = '2'";
        $connect = $conn->query($sql);
        if ($connect == TRUE) {
        echo "<table class='w3-table-all table-responsive table' id='dois' style='display:none'>
        <tr class='w3-indigo'>
        <th>" . "Nº" . "</th>
        <th>" . "Disciplina" . "</th>" .
        "<th>" . "ECTS" . "</th>" .
        "<th>" . "Semestre" . "</th>" .
        "<th>" . "Professores" . "</th>";
        while($row = mysqli_fetch_array($connect,MYSQLI_ASSOC)){
            echo "<tr>";
        foreach ($row as $chave => $valor){
            echo "<td>" . $valor . "</td>";
        }
            echo "<td><form action='inscricaoHorario' method='POST'>
                <input type='submit' name='join' class='btn btn-primary' value='Selecionar'/>
                <input type='hidden' name='id1' href='' value='$row[id]'>
                <input type='hidden' name='ucnome1' href='' value='$row[nome]'>
                </form></td>";
            echo "</tr>";
        }

    } else {
                echo "Error creating table: " . $conn->error;
    }
    echo "</table>";

    echo "</div>";
}

    if ($url === '/inscricaoHorario') {
        if(isset($_POST['join']) && isset($_POST['id1']) && isset($_POST['ucnome1']) ) {
            $_SESSION['join'] =  $_POST['id1'];
            $_SESSION['ucnome1'] =  $_POST['ucnome1'];
        }
        if(isset($_SESSION['join']) && isset($_SESSION['ucnome1'])) {
            $classid = $_SESSION['join'];
            $classname = $_SESSION['ucnome1'];
            echo "<div class='w3-container mainbox' id='hor'>
            <h1>Selecione os horários a que se quer inscrever.</h1>
            <h3>$classname</h3>
            <p><a href='/inscricaoUC'>Inscrever noutra disciplina.</a></p><br>";
            $sql = "SELECT id, tipo, dia_semana, hora_inicio, hora_fim, sala, bloco, status
            FROM turma AS t
            WHERE NOT EXISTS (
            SELECT *
            FROM inscritos AS i 
            WHERE t.id=i.turma_id AND '$numero' = i.aluno_id
            ) AND t.status = 'Aberta' AND t.uc_id = '$classid'";
            $connect = $conn->query($sql);
            if ($connect == TRUE) {
                if($connect->num_rows > 0) {
                echo "<table class='w3-table-all table-responsive table' class='jogo'>
                <tr class='w3-indigo'>
                <th>" . "Tipo de aula" . "</th>" .
                "<th>" . "Dia da semana" . "</th>" .
                "<th>" . "Hora de início" . "</th>" .
                "<th>" . "Hora de término" . "</th>" .
                "<th>" . "Sala" ."</th>" .
                "<th>" . "Estado" ."</th>";
                while($row = mysqli_fetch_array($connect,MYSQLI_ASSOC)){
                    echo "<tr id='$row[id]'>";
                foreach ($row as $chave => $valor){
                    if ($chave !== 'id' && $chave !== 'bloco'){
                        echo "<td>" . $valor . "</td>";
                    }
                }
                    echo "<td><form action='inscricaoHorario' method='POST'>
                            <input type='submit' class='btn btn-primary' name='inscrito' href='inscricaoHorario' id='$row[id]' value='Inscrever'>
                            <input type='hidden' name='inscrito' href='inscricaoHorario' id='join' value='$row[id]'>
                            <input type='hidden' name='bloco' href='inscricaoHorario' id='join' value='$row[bloco]'>
                        </form></td>";
                    echo "</tr>";
                }
            }else{
                echo "</table>";
                    echo "</div>";
                    echo "<script type='text/javascript'>",
                        "document.getElementById('hor').style.display='none';",
                        "document.getElementById('consultbox').style.visibility='hidden';",
                    "</script>";
                    echo "<div class='w3-container mainbox'><h1>De momento não há mais turmas disponíveis para inscrição.</h1></div>";
            }

        } else {
                    echo "Error creating table: " . $conn->error;
        }
        echo "</table>";
        echo "</div>";
    }
    }

    if(isset($_POST['inscrito'])){
        $turma_id = $_POST ['inscrito'];
        $bloco = $_POST ['bloco'];
        $sql = "SELECT turma.uc_id FROM turma WHERE turma.id = '$turma_id'";
        $result = mysqli_query($conn, $sql);
        while ($rows = mysqli_fetch_array($result, MYSQLI_ASSOC)) {
            $uc_id = $rows['uc_id'];
        }
        $sql = "INSERT INTO inscritos (aluno_id,turma_id,uc_id, bloco_inscrito) VALUES('$numero','$turma_id','$uc_id','$bloco')";
            if ($conn->query($sql) == TRUE) {
                echo "<div class='toast__container'>
        <div class='toast__cell mainbox'>
            <div class='toast toast--green'>
                <div class='toast__icon'>
                </div>
                <div class='toast__content'>
                    <p class='toast__type'>Sucesso</p>
                    <p class='toast__message'>Inscrição ocorreu com sucesso.</p>
                </div>
                <div class='toast__close'>
                    X
                </div>
            </div>
        </div>
    </div>";
    echo "<script type='text/javascript'>",
        "document.getElementById('$turma_id').style.display='none';",
        "</script>";
                }else {
                    echo "<div class='toast__container'>
        <div class='toast__cell mainbox'>
        <div class='toast toast--yellow'>
          <div class='toast__icon'>
          </div>
          <div class='toast__content'>
            <p class='toast__type'>Erro</p>
            <p class='toast__message'>A inscrição falhou.</p>
          </div>
          <div class='toast__close'>
            X
          </div>
        </div>
        </div>
        </div>";
            }
    }


?>