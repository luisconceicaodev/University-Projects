<?php
echo "<div class='w3-container mainbox' id='GRU'>
<h1 id='MC'>Grupos de Trabalho</h1>
<br>";
echo "<p id='pconsultar'>Selecione a disciplina à qual pretende criar uma área de registo de grupos de 
trabalho. Se a área já estiver aberta, poderá consultar os grupos formados e os alunos que ainda não formaram grupo.</p>";
$sql = "SELECT id, nome
FROM uc
WHERE coordenador = $numero";
$connect = $conn->query($sql);
if ($connect == TRUE) {
    if($connect->num_rows > 0) {
        echo "<table class='w3-table-all table-responsive table' id='consultar'>
        <tr class='w3-indigo'>
        <th>" . "Disciplina" . "</th>";
        while($row = mysqli_fetch_array($connect,MYSQLI_ASSOC)){
            echo "<tr>";
        foreach ($row as $chave => $valor){
            if ($chave !== 'id'){
                echo "<td>" . $valor . "</td>";
            }
        }
        echo "<td><form action='gruposProfessor' method='POST'>
            <input type='submit' class='btn btn-primary' name='consultarprof' value='Selecionar'/>
            <input type='hidden' name='ucprof' href='' id='join' value='$row[id]'>
            <input type='hidden' name='ucnomeprof' href='' id='join' value='$row[nome]'>
            </form></td>";
        echo "</tr>";
        }   
        echo "</table>";
        echo "</div>";
    }else{ # se professor não for coordenador de nenhuma UC 
        echo "</div>";
        echo "<script type='text/javascript'>",
                "document.getElementById('GRU').style.display='none';",
            "</script>";
            echo "<div class='w3-container mainbox'><h1>Você não tem permissões de coordenador nas unidades curriculares.</h1></div>";
    }
}else {
    echo "Error creating table: " . $conn->error;
}

if(isset($_POST['consultarprof'])){
    echo "<script type='text/javascript'>",
    "document.getElementById('GRU').style.display='none';",
    "</script>";
    $id_uc = $_POST ['ucprof'];
    $nome_uc = $_POST ['ucnomeprof'];
    echo "<div class='w3-container mainbox'>
    <h1 id='MC'>Grupos de Trabalho</h1>
    <br>";
    $sql = "SELECT *
    FROM grupo
    WHERE uc_id = $id_uc";
    $connect = $conn->query($sql);
    if ($connect == TRUE) {
        if($connect->num_rows > 0) {
            echo "<table class='w3-table-all table-responsive table'>
            <tr class='w3-indigo'>
            <th>Nº do grupo</th>
            <th>Alunos inscritos</th>
            <th>Nº máximo de alunos</th>
            <th>Disponibilidade</th>";
            while($row = mysqli_fetch_array($connect,MYSQLI_ASSOC)){
                echo "<tr>";
            foreach ($row as $chave => $valor){
                if ($chave !== 'uc_id' && $chave !== 'num_inscritos'){
                    echo "<td>" . $valor . "</td>";
                } elseif ($chave == 'num_inscritos') {
                    $sql2 = "SELECT uc_id, grupo_id, aluno_id
                    FROM inscritos_grupo
                    WHERE uc_id = $id_uc AND grupo_id = $row[id]";
                    $connect2 = $conn->query($sql2);
                    if ($connect2 == TRUE) {
                        if($connect2->num_rows > 0) {
                        echo "<td>";
                        while($row2 = mysqli_fetch_array($connect2,MYSQLI_ASSOC)){
                            foreach ($row2 as $chave2 => $valor2){
                                if ($chave2 == 'aluno_id') {
                                    echo $valor2 . "; ";
                                }
                            }
                        }
                        echo "</td>";
                        }else{
                            echo "<td>Sem alunos inscritos.</td>";
                        }
                    }
                }
            }
        }
        echo "</table>";
        echo "</div>";
        
        }else{ # se não existem grupos para esta disciplina 
            echo "<script type='text/javascript'>",
                        "document.getElementById('GRU').style.display='none';",
                    "</script>";
            echo "<h3>Esta disciplina não tem grupos de trabalho.</h3>";
            echo "<h3>Deseja criar uma área de registo de grupos?</h3>";
            echo "<div  class='' style='margin-top: 2em !important';border-style: groove;>";
            echo "<form class='animate' style='padding: 2% 2% 2% 2%'' action='gruposProfessor' method='POST'>
                <label for='num_maxG' class='light'><b>Número total de grupos de trabalho:</b></label>
                <br>
                <input type='number' name='num_maxG' min='2' max='30'>
                <br>
                <br>
                <label for='num_maxA' class='light'><b>Número máximo de alunos por grupo:</b></label>
                <br>
                <input type='number' name='num_maxA' min='2' max='10'>
                <br>
                <br>
                <input type='submit' class='btn btn-primary' name='criargrupos' value='Criar'/>
                <input type='hidden' name='id_pedido' href='' id='' value='$id_uc'>
                <input type='hidden' name='ucnome' href='' id='' value='$nome_uc'>
                </form></div></div>";
        }
    }else {
        echo "Error creating table: " . $conn->error;
    }   
}

if(isset($_POST['criargrupos'])){
    $id_uc = $_POST ['id_pedido'];
    $ucnome = $_POST ['ucnome'];
    $maxG = $_POST ['num_maxG'];
    $maxA = $_POST ['num_maxA'];

    $sql = "INSERT INTO grupo (uc_id, num_inscritos, max_alunos, status)
                VALUES ($id_uc, 0, $maxA, 'Aberto')";
    for ($i = 1; $i <= $maxG; $i++) {
        $connect = $conn->query($sql);
        if ($connect !== TRUE) {
            echo "<div class='toast__container'>
        <div class='toast__cell mainbox'>
        <div class='toast toast--yellow'>
          <div class='toast__icon'>
          </div>
          <div class='toast__content'>
            <p class='toast__type'>Erro</p>
            <p class='toast__message'>Erro de inserção de dados para a abertura de área de criação de grupos de trabalho.</p>
          </div>
          <div class='toast__close'>
            X
          </div>
        </div>
        </div>
        </div>";
        }
    }
    $sql = "SELECT DISTINCT uc_id, aluno_id
    FROM inscritos
    WHERE uc_id = $id_uc";
    $connect = $conn->query($sql);
    if ($connect == TRUE) {
        $alunosArray = array();
        if($connect->num_rows > 0) {
            while($row = mysqli_fetch_array($connect,MYSQLI_ASSOC)){
                array_push($alunosArray,$row['aluno_id']);
            }
            if (isset($alunosArray)) {
                foreach($alunosArray as $aluno) {
                    $sql = "INSERT INTO notificacao (para,de,mensagem) VALUES('$aluno','$nome','Área de criação de grupos de trabalho aberta para a disciplina de $ucnome. Crie o seu grupo na opção Gerir Disciplinas->Formação de grupos do menu.')";
                    $result = mysqli_query($conn, $sql);
                }
            }
        }
    }
    echo "<div class='toast__container'>
        <div class='toast__cell mainbox'>
            <div class='toast toast--green'>
                <div class='toast__icon'>
                </div>
                <div class='toast__content'>
                    <p class='toast__type'>Sucesso</p>
                    <p class='toast__message'>Área de criação de grupos aberta com sucesso.</p>
                </div>
                <div class='toast__close'>
                    X
                </div>
            </div>
        </div>
    </div>";
}

?>