<?php
$url = $_SERVER['REQUEST_URI'];
if ($url === '/mudancasTurma') {
    echo "<div class='w3-container mainbox' id='ucs_inscrito'>
    <h1>Pedidos de mudança de turma</h1>
    <p>Selecione a unidade curricular que deseja pedir uma mudança de turma:</p>
    <br>";
    $sql = "SELECT id, nome
        FROM uc AS u
        WHERE EXISTS (
           SELECT uc_id, aluno_id
           FROM inscritos AS i 
           WHERE u.id=i.uc_id AND '$numero' = i.aluno_id
        )";
    $connect = $conn->query($sql);
    if ($connect == TRUE) {
        if($connect->num_rows > 0) {
        echo "<table class='w3-table-all table-responsive table' class='jogo'>
        <tr class='w3-indigo'>
        <th>" . "Disciplina" . "</th>" ;
        while($row = mysqli_fetch_array($connect,MYSQLI_ASSOC)){
            echo "<tr>";
        foreach ($row as $chave => $valor){
            if ($chave !== 'id') {
                echo "<td>" . $valor . "</td>";
            }
        }
            echo "<td><form action='mudancasTurma' method='POST'>
                    <input type='submit' class='btn btn-primary' name='uc' href='' id='$row[id]' value='Selecionar'>
                    <input type='hidden' name='uc' href='' id='join' value='$row[id]'>
                </form></td>";
            echo "</tr>";
        }
            }else{
                echo "</div></table>";
        echo "<script type='text/javascript'>",
                    "document.getElementById('ucs_inscrito').style.display='none';",
                    "</script>";
                echo "<div class='toast__container'>
        <div class='toast__cell mainbox'>
        <div class='toast toast--yellow'>
          <div class='toast__icon'>
          </div>
          <div class='toast__content'>
            <p class='toast__type'>Erro</p>
            <p class='toast__message'>Você não está inscrito a unidades curriculares.</p>
          </div>
          <div class='toast__close'>
            X
          </div>
        </div>
        </div>
        </div>";
            }
    } else {
            echo "Error creating table: " . $conn->error;
    }
echo "</table>";
echo "</div>";
}elseif ($url === '/pedidosProfessor') {
        echo "<div class='w3-container mainbox' id='mudancas'>
        <h1>Pedidos de mudança de turma:</h1>
        <br>";
        $sql = "SELECT i.id as iid, p.id as pid, u.nome,p.aluno_id, p.turma_antiga, tipo, dia_semana, hora_inicio, hora_fim
        FROM turma as t, pedido AS p, uc as u, inscritos as i
        WHERE u.id=p.uc_id AND u.coordenador='$numero' AND t.id= p.turma_antiga AND i.turma_id = p.turma_antiga AND p.status IS NULL";
        $connect = $conn->query($sql);
        if ($connect == TRUE) {
            if($connect->num_rows > 0) {
                echo "<table class='w3-table-all table-responsive table' class='jogo'>
                <tr class='w3-indigo'>
                <th>" . "Unidade Curricular" . "</th>" .
                "<th>" . "Nº Aluno" . "</th>" .
                "<th>" . "Turma inscrito" . "</th>" .
                "<th>" . "Turma desejada" . "</th>" ,
                "<th>" . "Decisão" . "</th>" ;
                while($row = mysqli_fetch_array($connect,MYSQLI_ASSOC)){
                    $id_pedido = $row['pid'];
                    $id_inscrito = $row['iid'];
                    $aluno = $row['aluno_id'];
                    $uc_nome = $row['nome'];
                    $turma1 = $row['tipo'] . " " . $row['dia_semana'] ." " . $row['hora_inicio'] . "-" . $row['hora_fim'];
                    echo "<tr id='$aluno'>";
                    foreach ($row as $chave => $valor){
                        $oldturmaid = $row['turma_antiga'];
                        if ($chave !== 'iid' && $chave !== 'pid' && $chave !== 'tipo' && $chave !== 'hora_inicio' && $chave !== 'hora_fim' && $chave !== 'turma_antiga' && $chave !== 'dia_semana'){
                            echo "<td>" . $valor . "</td>";
                        }
                    }
                    echo "<td>" . $turma1 . "</td>";
                }
                if (isset($aluno) && isset($id_pedido) && isset($id_inscrito)) {
                    $sql = "SELECT u.nome,p.aluno_id, p.turma_nova, tipo, dia_semana, hora_inicio, hora_fim, bloco
                    FROM turma as t, pedido AS p, uc as u
                    WHERE u.id=p.uc_id AND u.coordenador='$numero' AND (t.id= p.turma_nova) AND p.aluno_id = $aluno AND p.status IS NULL";
                    $connect = $conn->query($sql);
                    if ($connect == TRUE) {
                        while($row = mysqli_fetch_array($connect,MYSQLI_ASSOC)){
                            $newturmaid = $row['turma_nova'];
                            $bloco = $row['bloco'];
                            $turma2 = $row['tipo'] . " " . $row['dia_semana'] ." " . $row['hora_inicio'] . "-" . $row['hora_fim'];
                            echo "<td>" . $turma2 . "</td>";
                            echo "<td><form action='pedidosProfessor' method='POST'>
                            <input type='submit' class='btn btn-primary' name='aceitar' href='' value='Aceitar'>
                            <input type='hidden' name='new_turma' href='' value='$newturmaid'>
                            <input type='hidden' name='id_inscrito' href='' value='$id_inscrito'>
                            <input type='hidden' name='id_pedido' href='' value='$id_pedido'>
                            <input type='hidden' name='aluno_id1' href='' value='$aluno'>
                            <input type='hidden' name='ucnome_1' href='' value='$uc_nome'>
                            <input type='hidden' name='bloco' href='' value='$bloco'>
                            <input type='submit' class='btn btn-danger' name='rejeitar' href='' value='Rejeitar'>
                            <input type='hidden' name='id_pedido' href='' value='$id_pedido'>
                            <input type='hidden' name='aluno_id2' href='' value='$aluno'>
                            <input type='hidden' name='ucnome_2' href='' value='$uc_nome'>
                            </form></td>";
                            echo "</tr>";
                        }
                        echo "</table>";
                        echo "</div>";
                    }else {
                        echo "Error creating table: " . $conn->error;
                    }
                } else {
                    echo "</table>";
                    echo "</div>";
                    echo "<h1>De momento não existem pedidos de mudança de turma.</h1>";
                }
            }else{
                    echo "<h1>De momento não existem pedidos de mudança de turma.</h1>";
            }
        } else {
                echo "Error creating table: " . $conn->error;
        }
}

if(isset($_POST['uc'])){
    echo "<script type='text/javascript'>",
    "document.getElementById('ucs_inscrito').style.display='none';",
"</script>";
    echo "<div class='w3-container mainbox' id='ucs_inscrito'>
    <h1>Turmas a que está inscrito:</h1>
    <br>";
    $class_id = $_POST ['uc'];
    $sql = "SELECT id, uc_id, tipo, dia_semana, hora_inicio, hora_fim, sala
    FROM turma AS t
    WHERE EXISTS (
       SELECT *
       FROM inscritos AS i 
       WHERE t.id=i.turma_id AND '$numero' = i.aluno_id AND $class_id = i.uc_id
    )";
        $connect = $conn->query($sql);
        if ($connect == TRUE) {
        echo "<table class='w3-table-all table-responsive table' class='jogo'>
        <tr class='w3-indigo'>
        <th>" . "Tipo de aula" . "</th>" .
        "<th>" . "Dia da semana" . "</th>" .
        "<th>" . "Hora de início" . "</th>" .
        "<th>" . "Hora de término" . "</th>" .
        "<th>" . "Sala" ."</th>" ;
        while($row = mysqli_fetch_array($connect,MYSQLI_ASSOC)){
            echo "<tr>";
        foreach ($row as $chave => $valor){
            if ($chave !== 'id' && $chave !== 'uc_id') {
                echo "<td>" . $valor . "</td>";
            }
        }
            echo "</tr>";
        }
    
        } else {
                echo "Error creating table: " . $conn->error;
        }
    echo "</table>";

    echo "<h1>Turmas disponíveis:</h1>
    <p>Selecione a turma à qual se deseja mudar</p><br>";
        $sql = "SELECT id, uc_id, tipo, dia_semana, hora_inicio, hora_fim, sala, status
        FROM turma AS t
        WHERE NOT EXISTS (
          SELECT *
          FROM inscritos AS i 
          WHERE t.id=i.turma_id AND '$numero' = i.aluno_id
        ) AND t.uc_id = $class_id AND t.status = 'Aberta'";
        $connect = $conn->query($sql);
        if ($connect == TRUE) {
            if($connect->num_rows > 0) {
            echo "<table class='w3-table-all table-responsive table' class='jogo'>
            <tr class='w3-indigo'>
            <th>" . "Tipo de aula" . "</th>" .
            "<th>" . "Dia da semana" . "</th>" .
            "<th>" . "Hora de início" . "</th>" .
            "<th>" . "Hora de término" . "</th>" .
            "<th>" . "Sala" ."</th>" ;
            while($row = mysqli_fetch_array($connect,MYSQLI_ASSOC)){
                echo "<tr>";
            foreach ($row as $chave => $valor){
                if ($chave !== 'id' && $chave !== 'uc_id' && $chave !== 'status'){
                    echo "<td>" . $valor . "</td>";
                }
            }
                echo "<td><form action='mudancasTurma' method='POST'>
                        <input type='submit' class='btn btn-primary' name='pedido' href='' id='$row[id]' value='Solicitar troca'>
                        <input type='hidden' name='pedido' href='' id='join' value='$row[id]'>
                    </form></td>";
                echo "</tr>";
            }
            echo "</table>";
            echo "</div>";
            }else{
                echo "</table>";
                echo "</div>";
                echo "<script type='text/javascript'>",
                    "document.getElementById('marcar').style.display='none';",
                    "document.getElementById('consultar').style.display='none';",
                    "document.getElementById('firstbox').style.display='none';",
                    "document.getElementById('consultbox').style.visibility='hidden';",
                "</script>";
                echo "<div class='w3-container mainbox'><h1>De momento não tem existem turmas disponíveis para fazer a troca.</h1></div>";
            }
    }else {
        echo "Error creating table: " . $conn->error;
    }
}

if(isset($_POST['pedido'])){
    $turma_nova = $_POST ['pedido'];
    $sql = "SELECT turma.uc_id, professor FROM turma WHERE turma.id = '$turma_nova'";
        $result = mysqli_query($conn, $sql);
        while ($rows = mysqli_fetch_array($result, MYSQLI_ASSOC)) {
            $uc_id = $rows['uc_id'];
            $prof = $rows['professor'];
        }
    $sql = "SELECT turma_id FROM inscritos WHERE aluno_id = '$numero' AND uc_id = '$uc_id'";
        $result = mysqli_query($conn, $sql);
        while ($rows = mysqli_fetch_array($result, MYSQLI_ASSOC)) {
            $turma_antiga = $rows['turma_id'];
        }
    $sql = "INSERT INTO pedido (aluno_id,uc_id,turma_antiga,turma_nova) VALUES('$numero','$uc_id','$turma_antiga', '$turma_nova')";
            if ($conn->query($sql) == TRUE) {
                $sql = "INSERT INTO notificacao (para,de,mensagem) VALUES('$prof','$nome','O aluno $nome nº $numero enviou lhe um pedido de mudança de turma. Poderá consultar e responder ao pedido na opção Gerir Disciplinas->Gerir pedidos do menu.')";
            $result = mysqli_query($conn, $sql);
                echo "<div class='toast__container'>
    <div class='toast__cell mainbox'>
        <div class='toast toast--green'>
            <div class='toast__icon'>
            </div>
            <div class='toast__content'>
                <p class='toast__type'>Sucesso</p>
                <p class='toast__message'>Pedido foi enviado ao coordenador da unidade curricular.</p>
            </div>
            <div class='toast__close'>
                X
            </div>
        </div>
        </div>
    </div>";
                }else {
                    echo "<div class='toast__container'>
            <div class='toast__cell mainbox'>
            <div class='toast toast--yellow'>
            <div class='toast__icon'>
            </div>
            <div class='toast__content'>
                <p class='toast__type'>Erro</p>
                <p class='toast__message'>Pedido de mudança de turma falhou.</p>
            </div>
            <div class='toast__close'>
                X
            </div>
            </div>
            </div>
            </div>";
            }
}

if(isset($_POST['aceitar'])){
    $id_pedido = $_POST ['id_pedido'];
    $id_inscrito = $_POST ['id_inscrito'];
    $new_turma = $_POST ['new_turma'];
    $aluno = $_POST ['aluno_id1'];
    $ucnome = $_POST ['ucnome_1'];
    $bloco = $_POST ['bloco'];

    $sql = "UPDATE pedido SET status='Aceite' WHERE id='$id_pedido'";
    if ($conn->query($sql) == TRUE) {
        $sql = "UPDATE inscritos SET turma_id='$new_turma', bloco_inscrito='$bloco' WHERE id='$id_inscrito'";
        if ($conn->query($sql) == TRUE) {
            $sql = "INSERT INTO notificacao (para,de,mensagem) VALUES('$aluno','$nome','O seu pedido de mudança de turma na disciplina $ucnome foi aceite.')";
            $result = mysqli_query($conn, $sql);
            echo "<script type='text/javascript'>",
    "document.getElementById('$aluno').style.display='none';",
"</script>";
            echo "<div class='toast__container'>
    <div class='toast__cell mainbox'>
        <div class='toast toast--green'>
            <div class='toast__icon'>
            </div>
            <div class='toast__content'>
                <p class='toast__type'>Sucesso</p>
                <p class='toast__message'>O pedido de mudança de turma foi aceite.</p>
            </div>
            <div class='toast__close'>
                X
            </div>
        </div>
        </div>
    </div>";
        }else{
            echo "<div class='toast__container'>
        <div class='toast__cell mainbox'>
        <div class='toast toast--yellow'>
          <div class='toast__icon'>
          </div>
          <div class='toast__content'>
            <p class='toast__type'>Erro</p>
            <p class='toast__message'>Update dos inscritos falhou.</p>
          </div>
          <div class='toast__close'>
            X
          </div>
        </div>
        </div>
        </div>";
        }
    }else{
        echo "<div class='toast__container'>
        <div class='toast__cell mainbox'>
        <div class='toast toast--yellow'>
          <div class='toast__icon'>
          </div>
          <div class='toast__content'>
            <p class='toast__type'>Erro</p>
            <p class='toast__message'>Update do status do pedido falhou.</p>
          </div>
          <div class='toast__close'>
            X
          </div>
        </div>
        </div>
        </div>";
    }
}

if(isset($_POST['rejeitar'])){
    $id_pedido = $_POST ['id_pedido'];
    $aluno = $_POST ['aluno_id2'];
    $ucnome = $_POST ['ucnome_2'];
    $sql = "UPDATE pedido SET status='Rejeitado' WHERE id='$id_pedido'";
    if ($conn->query($sql) == TRUE) {
        $sql = "INSERT INTO notificacao (para,de,mensagem) VALUES('$aluno','$nome','O seu pedido de mudança de turma na disciplina $ucnome foi rejeitado.')";
        $result = mysqli_query($conn, $sql);
        echo "<script type='text/javascript'>",
    "document.getElementById('$aluno').style.display='none';",
"</script>";
        echo "<div class='toast__container'>
    <div class='toast__cell mainbox'>
        <div class='toast toast--green'>
            <div class='toast__icon'>
            </div>
            <div class='toast__content'>
                <p class='toast__type'>Sucesso</p>
                <p class='toast__message'>O pedido de mudança de turma foi rejeitado.</p>
            </div>
            <div class='toast__close'>
                X
            </div>
        </div>
        </div>
    </div>";
    }else{
        echo "<div class='toast__container'>
        <div class='toast__cell mainbox'>
        <div class='toast toast--yellow'>
          <div class='toast__icon'>
          </div>
          <div class='toast__content'>
            <p class='toast__type'>Erro</p>
            <p class='toast__message'>Rejeição do pedido de mudança de turma falhou.</p>
          </div>
          <div class='toast__close'>
            X
          </div>
        </div>
        </div>
        </div>";
    }
}
?>