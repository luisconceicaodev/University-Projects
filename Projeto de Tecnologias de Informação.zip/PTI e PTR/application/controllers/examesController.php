<?php
header('Content-Type: text/html; charset=utf-8');
    echo "<div class='w3-container mainbox' id='abcdef'>
    <h1 id='MC'>Inscrição Exames 1ª Fase</h1>
    <br>
    <div class='w3-bar w3-border w3-light-grey'>
        <button onclick='showexame1()' class='w3-bar-item w3-button w3-indigo' style='margin-right:1em'>1ª Fase</button>
        <button onclick='showexame2()' class='w3-bar-item w3-button w3-indigo'>2ª Fase</button>
    </div>
    <br>
    ";
    $sql = "SELECT exame.id as eid, uc.id as ucid, nome, data, hora_inicio, hora_fim, duracao, fase
    FROM exame, uc
    WHERE EXISTS (
        SELECT *
        FROM inscritos AS i 
        WHERE uc.id=i.uc_id AND '$numero' = i.aluno_id
    ) AND uc.id = exame.uc AND exame.fase = '1'";
    $connect = $conn->query($sql);
    if ($connect == TRUE) {
        if($connect->num_rows > 0) {
        echo "<table class='w3-table-all table-responsive table' id='ex1'>
        <tr class='w3-indigo'>
        <th>" . "Unidade Curricular" . "</th>
        <th>" . "Data" . "</th>
        <th>" . "Hora inicio" . "</th>
        <th>" . "Hora fim" . "</th>
        <th>" . "Duração" . "</th>
        <th>" . "Inscrição" . "</th>";
        while($row = mysqli_fetch_array($connect,MYSQLI_ASSOC)){
            echo "<tr>";
        foreach ($row as $chave => $valor){
            if ($chave !== 'fase' && $chave !== 'eid' && $chave !== 'ucid'){
                echo "<td>" . $valor . "</td>";
            }
        }
        $exame = $row['eid'];
        $uc = $row['ucid'];
        $fase = $row['fase'];
        $sql2 = "SELECT *
            FROM inscritos_exame
            WHERE aluno_id = $numero AND $uc = uc_id AND fase = '1'";
            $result = mysqli_query($conn, $sql2);
            if (mysqli_num_rows($result)==0) {
                echo "<td id='$row[eid]'><form action='inscricaoExames' method='POST'>
        <input type='submit' class='btn btn-primary' name='inscrever' value='Inscrever'/>
        <input type='hidden' name='exame' href='' id='' value='$exame'>
        <input type='hidden' name='uc' href='' id='' value='$uc'>
        <input type='hidden' name='fase' href='' id='' value='$fase'>
        </form></td>";
        echo "</tr>";
            }else{
                echo "<td><p>Já está inscrito</p></td></tr>";
            }
        }
    }else{
        echo "</div></table>";
        echo "<script type='text/javascript'>",
                    "document.getElementById('abcdef').style.display='none';",
                    "</script>";
        echo "<div class='toast__container'>
        <div class='toast__cell mainbox'>
        <div class='toast toast--yellow'>
          <div class='toast__icon'>
          </div>
          <div class='toast__content'>
            <p class='toast__type'>Erro</p>
            <p class='toast__message'>Você não está inscrito a unidades curriculares.</p>
          </div>
          <div class='toast__close'>
            X
          </div>
        </div>
        </div>
        </div>";
    }
} else {
            echo "Error creating table: " . $conn->error;
}
echo "</table>";

$sql = "SELECT exame.id as eid, uc.id as ucid, nome, data, hora_inicio, hora_fim, duracao, fase
FROM exame, uc
WHERE EXISTS (
    SELECT *
    FROM inscritos AS i 
    WHERE uc.id=i.uc_id AND '$numero' = i.aluno_id
) AND uc.id = exame.uc AND exame.fase = '2'";
$connect = $conn->query($sql);
if ($connect == TRUE) {
    echo "<table class='w3-table-all table-responsive table' id='ex2' style='display:none'>
    <tr class='w3-indigo'>
    <th>" . "Unidade Curricular" . "</th>
    <th>" . "Data" . "</th>
    <th>" . "Hora inicio" . "</th>
    <th>" . "Hora fim" . "</th>
    <th>" . "Duração" . "</th>
    <th>" . "Inscrição" . "</th>";
    while($row = mysqli_fetch_array($connect,MYSQLI_ASSOC)){
        echo "<tr>";
    foreach ($row as $chave => $valor){
        if ($chave !== 'fase' && $chave !== 'eid' && $chave !== 'ucid'){
            echo "<td>" . $valor . "</td>";
        }
    }
    $exame = $row['eid'];
    $uc = $row['ucid'];
    $fase = $row['fase'];
    $sql2 = "SELECT *
        FROM inscritos_exame
        WHERE aluno_id = $numero AND $uc = uc_id AND fase = '2'";
        $result = mysqli_query($conn, $sql2);
        if (mysqli_num_rows($result)==0) {
            echo "<td><form action='inscricaoExames' method='POST'>
    <input type='submit' class='btn btn-primary' name='inscrever' value='Inscrever'/>
    <input type='hidden' name='exame' href='' id='' value='$exame'>
    <input type='hidden' name='uc' href='' id='' value='$uc'>
    <input type='hidden' name='fase' href='' id='' value='$fase'>
    </form></td>";
    echo "</tr>";
        }else{
            echo "<td><p>Já está inscrito</p></td></tr>";
        }
    }

} else {
            echo "Error creating table: " . $conn->error;
}
echo "</table>";
echo "</div>";

if(isset($_POST['inscrever'])){
    $exame = $_POST ['exame'];
    $uc = $_POST['uc'];
    $fase = $_POST['fase'];
    $sql = "INSERT INTO inscritos_exame (exame_id, uc_id, aluno_id, fase) VALUES ($exame, $uc, $numero, $fase)";
    if ($conn->query($sql) == TRUE) {
        echo "<script type='text/javascript'>",
        "document.getElementById('$exame').innerHTML='Já está inscrito';",
        "</script>";
        echo "<div class='toast__container'>
    <div class='toast__cell mainbox'>
        <div class='toast toast--green'>
            <div class='toast__icon'>
            </div>
            <div class='toast__content'>
                <p class='toast__type'>Sucesso</p>
                <p class='toast__message'>Inscrição efetuada com sucesso.</p>
            </div>
            <div class='toast__close'>
                X
            </div>
        </div>
        </div>
    </div>";
    }else{
        echo "<div class='toast__container'>
        <div class='toast__cell mainbox'>
        <div class='toast toast--yellow'>
          <div class='toast__icon'>
          </div>
          <div class='toast__content'>
            <p class='toast__type'>Erro</p>
            <p class='toast__message'>Ocorreu um erro na inscrição do exame.</p>
          </div>
          <div class='toast__close'>
            X
          </div>
        </div>
        </div>
        </div>";
    }
}
?>