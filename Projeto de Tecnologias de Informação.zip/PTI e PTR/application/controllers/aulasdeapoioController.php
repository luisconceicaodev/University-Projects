<?php
echo "<div class='w3-container mainbox' id='MAA'>
<h1>Marcar Aula de Apoio</h1>
<br>";
echo "<p>Selecione a disciplina à qual pretende marcar uma aula de apoio.</p>";
$sql = "SELECT id, nome
FROM uc
WHERE coordenador = $numero";
$connect = $conn->query($sql);
if ($connect == TRUE) {
    if($connect->num_rows > 0) {
        echo "<table class='w3-table-all table-responsive table' id='consultar'>
        <tr class='w3-indigo'>
        <th>" . "Disciplina" . "</th>";
        while($row = mysqli_fetch_array($connect,MYSQLI_ASSOC)){
            echo "<tr>";
        foreach ($row as $chave => $valor){
            if ($chave !== 'id'){
                echo "<td>" . $valor . "</td>";
            }
        }
        echo "<td><form action='auladeapoio' method='POST'>
            <input type='submit' class='btn btn-primary' name='ucapoio' value='Selecionar'/>
            <input type='hidden' name='ucid' href='' id='join' value='$row[id]'>
            <input type='hidden' name='ucname' href='' id='join' value='$row[nome]'>
            </form></td>";
        echo "</tr>";
        }   
        echo "</table>";
        echo "</div>";
    }else{ # se professor não for coordenador de nenhuma UC
        echo "</div>"; 
        echo "<script type='text/javascript'>",
                "document.getElementById('MAA').style.display='none';",
            "</script>";
            echo "<div class='w3-container mainbox'><h1>Você não tem permissões de coordenador nas unidades curriculares.</h1></div>";
    }
}else {
    echo "Error creating table: " . $conn->error;
}

if(isset($_POST['ucapoio'])){
    echo "<script type='text/javascript'>",
    "document.getElementById('MAA').style.display='none';",
    "</script>";
    $id_uc = $_POST ['ucid'];
    $nome_uc = $_POST ['ucname'];
    echo "<div class='w3-container mainbox'>
    <h1 id='MC'>Marcar Aula de Apoio</h1>
    <br>";
    $sql = "SELECT *
    FROM aulaapoio WHERE status = 'Aberto'";
    $connect = $conn->query($sql);
    if ($connect == TRUE) {
        if($connect->num_rows > 0) {
            echo "<table class='w3-table-all table-responsive table'>
            <tr class='w3-indigo'>
            <th>Dia da semana</th>
            <th>Hora disponível</th>
            <th>Sala</th>
            <th>Status</th>";
            while($row = mysqli_fetch_array($connect,MYSQLI_ASSOC)){
                echo "<tr>";
            foreach ($row as $chave => $valor){
                if ($chave !== 'id'){
                    echo "<td>" . $valor . "</td>";
                } 
            }
            echo "<td><form action='auladeapoio' method='POST'>
            <input type='submit' class='btn btn-primary' name='selectaula' value='Marcar'/>
            <input type='hidden' name='ucid' href='' value='$id_uc'>
            <input type='hidden' name='ucname' href='' id='join' value='$nome_uc'>
            <input type='hidden' name='idapoio' href='' value='$row[id]'>
            <input type='hidden' name='diasemana' href='' value='$row[dia_semana]'>
            <input type='hidden' name='horadisp' href='' value='$row[hora_disponivel]'>
            <input type='hidden' name='saladisp' href='' value='$row[sala]'>
            </form></td>";
            echo "</tr>";
        }   
        echo "</table>";
        echo "</div>";
        }else{
            echo "<h3>Não existem mais espaços disponíveis para marcação de aulas de apoio.</h3>";
        }
        echo "</table>";
        echo "</div>";
        
        }else{
            echo "<h3>Não existem mais espaços disponíveis para marcação de aulas de apoio.</h3>";
        }
    }

if(isset($_POST['selectaula'])){
    $id_uc = $_POST ['ucid'];
    $nome_uc = $_POST ['ucname'];
    $idapoio = $_POST ['idapoio'];
    $diasemana = $_POST ['diasemana'];
    $horadisp = $_POST['horadisp'];
    $saladisp = $_POST['saladisp'];

    $sql = "SELECT DISTINCT uc_id, aluno_id
    FROM inscritos
    WHERE uc_id = $id_uc";
    $connect = $conn->query($sql);
    if ($connect == TRUE) {
        $alunosArray = array();
        if($connect->num_rows > 0) {
            while($row = mysqli_fetch_array($connect,MYSQLI_ASSOC)){
                array_push($alunosArray,$row['aluno_id']);
            }
            if (isset($alunosArray)) {
                foreach($alunosArray as $aluno) {
                    $sql = "INSERT INTO notificacao (para,de,mensagem) VALUES('$aluno','$nome','Aula de apoio marcada para a disciplina $nome_uc na $diasemana ás $horadisp na sala $saladisp.')";
                    $result = mysqli_query($conn, $sql);
                }
            }
        }
    }

    $sql = "INSERT INTO apoio_marcado (aulaapoioid,prof_id,uc_id) VALUES('$idapoio','$numero','$id_uc')";
    if ($conn->query($sql) == TRUE) {
            $sql = "UPDATE aulaapoio SET status='Fechado' WHERE id='$idapoio'";
            $result = mysqli_query($conn, $sql);
            echo "<div class='toast__container'>
    <div class='toast__cell mainbox'>
        <div class='toast toast--green'>
            <div class='toast__icon'>
            </div>
            <div class='toast__content'>
                <p class='toast__type'>Sucesso</p>
                <p class='toast__message'>Marcação da aula de apoio na $diasemana ás $horadisp na sala $saladisp ocorreu com sucesso.</p>
            </div>
            <div class='toast__close'>
                X
            </div>
        </div>
    </div>
</div>";
            }else {
                echo "<div class='toast__container'>
    <div class='toast__cell mainbox'>
    <div class='toast toast--yellow'>
      <div class='toast__icon'>
      </div>
      <div class='toast__content'>
        <p class='toast__type'>Erro</p>
        <p class='toast__message'>A marcação da aula de apoio falhou.</p>
      </div>
      <div class='toast__close'>
        X
      </div>
    </div>
    </div>
    </div>";
        }
}
?>