<?php
echo "<div class='w3-container mainbox' id='KJK'>
<h1 id='MC'>Grupos de Trabalho</h1>
<br>";
echo "<p id='pconsultar'>Selecione a disciplina à qual pretende se inscrever a um grupo de trabalho.</p>";
$sql = "SELECT id,nome
    FROM uc
    WHERE EXISTS (
        SELECT *
        FROM inscritos AS i 
        WHERE uc.id=i.uc_id AND '$numero' = i.aluno_id
    )";
$connect = $conn->query($sql);
if ($connect == TRUE) {
    if($connect->num_rows > 0) {
        echo "<table class='w3-table-all table-responsive table'>
        <tr class='w3-indigo'>
        <th>" . "Disciplina" . "</th>";
        while($row = mysqli_fetch_array($connect,MYSQLI_ASSOC)){
            echo "<tr>";
        foreach ($row as $chave => $valor){
            if ($chave !== 'id'){
                echo "<td>" . $valor . "</td>";
            }
        }
        echo "<td><form action='grupos' method='POST'>
            <input type='submit' class='btn btn-primary' name='selectuc' value='Selecionar'/>
            <input type='hidden' name='uc' href='' id='join' value='$row[id]'>
            <input type='hidden' name='ucnome' href='' id='join' value='$row[nome]'>
            </form></td>";
        echo "</tr>";
        }   
        echo "</table>";
        echo "</div>";
    }else{ # se aluno não estiver inscrito a disciplinas
        echo "</div>";
        echo "<script type='text/javascript'>",
                "document.getElementById('KJK').style.display='none';",
            "</script>";
            echo "<div class='toast__container'>
        <div class='toast__cell mainbox'>
        <div class='toast toast--yellow'>
          <div class='toast__icon'>
          </div>
          <div class='toast__content'>
            <p class='toast__type'>Erro</p>
            <p class='toast__message'>Você não está inscrito a unidades curriculares.</p>
          </div>
          <div class='toast__close'>
            X
          </div>
        </div>
        </div>
        </div>";
    }
}else {
    echo "Error accessing table: " . $conn->error;
}

if(isset($_POST['selectuc'])){
    echo "<script type='text/javascript'>",
    "document.getElementById('KJK').style.display='none';",
    "</script>";
    $id_uc = $_POST ['uc'];
    $nome_uc = $_POST ['ucnome'];
    $jainsc = 0;
    $jainscgrupo = 0;
    echo "<div class='w3-container mainbox'>
    <h1 id='MC'>Grupos de Trabalho</h1>
    <h3>$nome_uc</h3>
    <br>";
    $sql = "SELECT *
    FROM grupo
    WHERE uc_id = $id_uc";
    $connect = $conn->query($sql);
    if ($connect == TRUE) {
        if($connect->num_rows > 0) {
            echo "<table class='w3-table-all table-responsive table'>
            <tr class='w3-indigo'>
            <th>Nº do grupo</th>
            <th>Alunos inscritos</th>
            <th>Nº máximo de alunos</th>
            <th>Disponibilidade</th>";
            while($row = mysqli_fetch_array($connect,MYSQLI_ASSOC)){
                echo "<tr>";
            foreach ($row as $chave => $valor){
                if ($chave !== 'uc_id'  && $chave !== 'num_inscritos' ){
                    echo "<td>" . $valor . "</td>";
                } elseif ($chave == 'num_inscritos') {
                    $sql2 = "SELECT uc_id, grupo_id, aluno_id
                    FROM inscritos_grupo
                    WHERE uc_id = $id_uc AND grupo_id = $row[id]";
                    $connect2 = $conn->query($sql2);
                    if ($connect2 == TRUE) {
                        if($connect2->num_rows > 0) {
                        echo "<td>";
                        while($row2 = mysqli_fetch_array($connect2,MYSQLI_ASSOC)){
                            foreach ($row2 as $chave2 => $valor2){
                                if ($chave2 == 'aluno_id') {
                                    echo $valor2 . "; ";
                                    if ($valor2 == $numero) {
                                        $jainsc += 1;
                                        $jainscgrupo = $row2['grupo_id'];
                                    }
                                }
                            }
                        }
                        echo "</td>";
                        }else{
                            echo "<td>Sem alunos inscritos.</td>";
                        }
                    }
                }
                if ($chave == 'status') {
                    if ($jainsc == 1 && $jainscgrupo == $row['id']) {
                        echo "<td><form action='grupos' method='POST'>
                        <input type='submit' class='btn btn-primary' name='desinscrever' value='Sair'>
                        <input type='hidden' name='uc' href='' value='$id_uc'>
                        <input type='hidden' name='grupoid' href='' value='$row[id]'>
                        <input type='hidden' name='inscri' href='' value='$row[num_inscritos]'>
                        <input type='hidden' name='max' href='' value='$row[max_alunos]'>
                        </form></td>";
                    }elseif ($jainsc == 1 && $jainscgrupo != $row['id']){
                        echo "<td>Já está inscrito noutro grupo.</td>";
                    }else{
                        if ($row['num_inscritos'] !== $row['max_alunos']) {
                            echo "<td><form action='grupos' method='POST'>
                        <input type='submit' class='btn btn-primary' name='inscgrupos' value='Aderir'>
                        <input type='hidden' name='uc' href='' value='$id_uc'>
                        <input type='hidden' name='grupoid' href='' value='$row[id]'>
                        <input type='hidden' name='inscri' href='' value='$row[num_inscritos]'>
                        <input type='hidden' name='max' href='' value='$row[max_alunos]'>
                        </form></td>";
                        }else{
                            echo "<td>Grupo cheio.</td>";
                        }
                    }
                }
            }

            echo "</tr>";
            }
            echo "</table>";
            echo "</div>";
        }else{
            echo "<p>O coordenador desta disciplina não abriu uma área para inscrição em grupos de trabalho.</p>";
        }
    }else {
        echo "Error accessing table: " . $conn->error;
    }
}

if(isset($_POST['inscgrupos'])){
    $id_uc = $_POST ['uc'];
    $grupo_id = $_POST ['grupoid'];
    $inscritos = $_POST ['inscri'];
    $maxalunos = $_POST ['max'];
    
    $inscritos += 1;

    if ($inscritos == $maxalunos) {
        $sql = "UPDATE grupo SET num_inscritos='$inscritos', status = 'Fechado' WHERE id='$grupo_id'";
        if ($conn->query($sql) == TRUE) {
            $sql = "INSERT INTO inscritos_grupo (uc_id, grupo_id, aluno_id) 
        VALUES ($id_uc,$grupo_id,$numero)";
        $connect = $conn->query($sql);
        if ($connect == TRUE) {
            echo "<div class='toast__container'>
            <div class='toast__cell mainbox'>
                <div class='toast toast--green'>
                    <div class='toast__icon'>
                    </div>
                    <div class='toast__content'>
                        <p class='toast__type'>Sucesso</p>
                        <p class='toast__message'>Você aderiu ao grupo nº ".$grupo_id.".</p>
                    </div>
                    <div class='toast__close'>
                        X
                    </div>
                </div>
            </div>
            </div>";
            }else{
                echo "<div class='toast__container'>
                <div class='toast__cell mainbox'>
                <div class='toast toast--yellow'>
                <div class='toast__icon'>
                </div>
                <div class='toast__content'>
                    <p class='toast__type'>Erro</p>
                    <p class='toast__message'>Adesão ao grupo falhou.</p>
                </div>
                <div class='toast__close'>
                    X
                </div>
                </div>
                </div>
                </div>";
            }   
        }else{
            echo "<div class='toast__container'>
                <div class='toast__cell mainbox'>
                <div class='toast toast--yellow'>
                <div class='toast__icon'>
                </div>
                <div class='toast__content'>
                    <p class='toast__type'>Erro</p>
                    <p class='toast__message'>Adesão ao grupo falhou.</p>
                </div>
                <div class='toast__close'>
                    X
                </div>
                </div>
                </div>
                </div>";
        }
    }else{
        $sql = "UPDATE grupo SET num_inscritos='$inscritos' WHERE id='$grupo_id'";
        if ($conn->query($sql) == TRUE) {
            $sql = "INSERT INTO inscritos_grupo (uc_id, grupo_id, aluno_id) 
        VALUES ($id_uc,$grupo_id,$numero)";
        $connect = $conn->query($sql);
        if ($connect == TRUE) {
            echo "<div class='toast__container'>
            <div class='toast__cell mainbox'>
                <div class='toast toast--green'>
                    <div class='toast__icon'>
                    </div>
                    <div class='toast__content'>
                        <p class='toast__type'>Sucesso</p>
                        <p class='toast__message'>Você aderiu ao grupo nº ".$grupo_id.".</p>
                    </div>
                    <div class='toast__close'>
                        X
                    </div>
                </div>
            </div>
            </div>";
            }else{
                echo "<div class='toast__container'>
                <div class='toast__cell mainbox'>
                <div class='toast toast--yellow'>
                <div class='toast__icon'>
                </div>
                <div class='toast__content'>
                    <p class='toast__type'>Erro</p>
                    <p class='toast__message'>Adesão ao grupo falhou.</p>
                </div>
                <div class='toast__close'>
                    X
                </div>
                </div>
                </div>
                </div>";
            }   
        }else{
            echo "<div class='toast__container'>
                <div class='toast__cell mainbox'>
                <div class='toast toast--yellow'>
                <div class='toast__icon'>
                </div>
                <div class='toast__content'>
                    <p class='toast__type'>Erro</p>
                    <p class='toast__message'>Adesão ao grupo falhou.</p>
                </div>
                <div class='toast__close'>
                    X
                </div>
                </div>
                </div>
                </div>";
    }
}
}

if(isset($_POST['desinscrever'])){
    $id_uc = $_POST ['uc'];
    $grupo_id = $_POST ['grupoid'];
    $inscritos = $_POST ['inscri'];
    $maxalunos = $_POST ['max'];
    $inscritos -= 1;
    $maxtest = $maxalunos - 1;
    
    if ($inscritos == $maxtest) {
        $sql = "UPDATE grupo SET num_inscritos='$inscritos', status='Aberto' WHERE id='$grupo_id'";
        if ($conn->query($sql) == TRUE) {
            $sql = "DELETE from inscritos_grupo 
        where aluno_id = $numero";
        $connect = $conn->query($sql);
        if ($connect == TRUE) {
            echo "<div class='toast__container'>
        <div class='toast__cell mainbox'>
            <div class='toast toast--green'>
                <div class='toast__icon'>
                </div>
                <div class='toast__content'>
                    <p class='toast__type'>Sucesso</p>
                    <p class='toast__message'>Você saiu do grupo nº ".$grupo_id.".</p>
                </div>
                <div class='toast__close'>
                    X
                </div>
            </div>
            </div>
        </div>";
            }else{
                echo "<div class='toast__container'>
            <div class='toast__cell mainbox'>
            <div class='toast toast--yellow'>
            <div class='toast__icon'>
            </div>
            <div class='toast__content'>
                <p class='toast__type'>Erro</p>
                <p class='toast__message'>Sair do grupo falhou.</p>
            </div>
            <div class='toast__close'>
                X
            </div>
            </div>
            </div>
            </div>";
            } 
        }else{
            echo "<div class='toast__container'>
                <div class='toast__cell mainbox'>
                <div class='toast toast--yellow'>
                <div class='toast__icon'>
                </div>
                <div class='toast__content'>
                    <p class='toast__type'>Erro</p>
                    <p class='toast__message'>Sair do grupo falhou.</p>
                </div>
                <div class='toast__close'>
                    X
                </div>
                </div>
                </div>
                </div>";
        }
    }else{
        $sql = "UPDATE grupo SET num_inscritos='$inscritos' WHERE id='$grupo_id'";
        if ($conn->query($sql) == TRUE) {
            $sql = "DELETE from inscritos_grupo 
        where aluno_id = $numero";
        $connect = $conn->query($sql);
        if ($connect == TRUE) {
            echo "<div class='toast__container'>
        <div class='toast__cell mainbox'>
            <div class='toast toast--green'>
                <div class='toast__icon'>
                </div>
                <div class='toast__content'>
                    <p class='toast__type'>Sucesso</p>
                    <p class='toast__message'>Você saiu do grupo nº ".$grupo_id.".</p>
                </div>
                <div class='toast__close'>
                    X
                </div>
            </div>
            </div>
        </div>";
            }else{
                echo "<div class='toast__container'>
            <div class='toast__cell mainbox'>
            <div class='toast toast--yellow'>
            <div class='toast__icon'>
            </div>
            <div class='toast__content'>
                <p class='toast__type'>Erro</p>
                <p class='toast__message'>Sair do grupo falhou.</p>
            </div>
            <div class='toast__close'>
                X
            </div>
            </div>
            </div>
            </div>";
            } 
        }else{
            echo "<div class='toast__container'>
                <div class='toast__cell mainbox'>
                <div class='toast toast--yellow'>
                <div class='toast__icon'>
                </div>
                <div class='toast__content'>
                    <p class='toast__type'>Erro</p>
                    <p class='toast__message'>Sair do grupo falhou.</p>
                </div>
                <div class='toast__close'>
                    X
                </div>
                </div>
                </div>
                </div>";
        }
    }
}
?>