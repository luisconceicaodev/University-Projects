<?php
$url = $_SERVER['REQUEST_URI'];
if ($url === '/verDados') {
    echo "<div class='w3-container mainbox' style='margin-top: 5em !important' id='ucs_inscrito'>
    <h1>Pessoas:</h1>
    <br>";
    $sql = "SELECT *
        FROM pessoa";
    $connect = $conn->query($sql);
    if ($connect == TRUE) {
    echo "<table class='w3-table-all table-responsive table' class='jogo'>
    <tr class='w3-indigo'>
    <th>" . "Nº" . "</th>
    <th>" . "Email" . "</th>
    <th>" . "Nome" . "</th>";
    while($row = mysqli_fetch_array($connect,MYSQLI_ASSOC)){
        echo "<tr>";
    foreach ($row as $chave => $valor){
        if ($chave !== 'pass') {
            echo "<td>" . $valor . "</td>";
        }
    }
        echo "</tr>";
    }

    } else {
            echo "Error creating table: " . $conn->error;
    }
echo "</table>";

echo "<h1>Alunos:</h1>
    <br>";
    $sql = "SELECT *
        FROM aluno";
    $connect = $conn->query($sql);
    if ($connect == TRUE) {
    echo "<table class='w3-table-all table-responsive table' class='jogo'>
    <tr class='w3-indigo'>
    <th>" . "Nº" . "</th>
    <th>" . "Curso" . "</th>";
    while($row = mysqli_fetch_array($connect,MYSQLI_ASSOC)){
        echo "<tr>";
    foreach ($row as $chave => $valor){
        echo "<td>" . $valor . "</td>";
        
    }
        echo "</tr>";
    }

    } else {
            echo "Error creating table: " . $conn->error;
    }
echo "</table>";

echo "<h1>Unidades Curriculares:</h1>
    <br>";
    $sql = "SELECT *
        FROM uc";
    $connect = $conn->query($sql);
    if ($connect == TRUE) {
    echo "<table class='w3-table-all table-responsive table' class='jogo'>
    <tr class='w3-indigo'>
    <th>" . "Id" . "</th>
    <th>" . "Nome" . "</th>
    <th>" . "Abreviação" . "</th>
    <th>" . "ECTS" . "</th>
    <th>" . "Semestre" . "</th>
    <th>" . "Professores" . "</th>
    <th>" . "Nº do Coordenador" . "</th>";
    while($row = mysqli_fetch_array($connect,MYSQLI_ASSOC)){
        echo "<tr>";
    foreach ($row as $chave => $valor){
            echo "<td>" . $valor . "</td>";
        
    }
        echo "</tr>";
    }

    } else {
            echo "Error creating table: " . $conn->error;
    }
echo "</table>";

echo "<h1>Aulas de apoio e o seu status:</h1>
    <br>";
    $sql = "SELECT *
        FROM aulaapoio";
    $connect = $conn->query($sql);
    if ($connect == TRUE) {
    echo "<table class='w3-table-all table-responsive table' class='jogo'>
    <tr class='w3-indigo'>
    <th>" . "Dia da semana" . "</th>
    <th>" . "Hora disponivel" . "</th>
    <th>" . "Sala" . "</th>
    <th>" . "Status" . "</th>";
    while($row = mysqli_fetch_array($connect,MYSQLI_ASSOC)){
        echo "<tr>";
    foreach ($row as $chave => $valor){
        if($chave !== 'id') {
            echo "<td>" . $valor . "</td>";
        }
    }
        echo "</tr>";
    }

    } else {
            echo "Error creating table: " . $conn->error;
    }
echo "</table>";

echo "<h1>Aulas de apoio marcadas:</h1>
    <br>";
    $sql = "SELECT *
        FROM apoio_marcado";
    $connect = $conn->query($sql);
    if ($connect == TRUE) {
    echo "<table class='w3-table-all table-responsive table' class='jogo'>
    <tr class='w3-indigo'>
    <th>" . "Id da aula de apoio" . "</th>
    <th>" . "Nº do professor" . "</th>
    <th>" . "Nº da disciplina" . "</th>";
    while($row = mysqli_fetch_array($connect,MYSQLI_ASSOC)){
        echo "<tr>";
    foreach ($row as $chave => $valor){
        if($chave !== 'id') {
            echo "<td>" . $valor . "</td>";
        }
    }
        echo "</tr>";
    }

    } else {
            echo "Error creating table: " . $conn->error;
    }
echo "</table>";

echo "<h1>Exames:</h1>
    <br>";
    $sql = "SELECT *
        FROM exame";
    $connect = $conn->query($sql);
    if ($connect == TRUE) {
    echo "<table class='w3-table-all table-responsive table' class='jogo'>
    <tr class='w3-indigo'>
    <th>" . "Id" . "</th>
    <th>" . "Uc Id" . "</th>
    <th>" . "Data" . "</th>
    <th>" . "Hora Inicio" . "</th>
    <th>" . "Hora Fim" . "</th>
    <th>" . "Duração" . "</th>
    <th>" . "Fase" . "</th>";
    while($row = mysqli_fetch_array($connect,MYSQLI_ASSOC)){
        echo "<tr>";
    foreach ($row as $chave => $valor){
        if ($chave !== 'ano_letivo') {
            echo "<td>" . $valor . "</td>";
        }
    }
        echo "</tr>";
    }

    } else {
            echo "Error creating table: " . $conn->error;
    }
echo "</table>";

echo "<h1>Inscritos em Turmas:</h1>
    <br>";
    $sql = "SELECT *
        FROM inscritos";
    $connect = $conn->query($sql);
    if ($connect == TRUE) {
    echo "<table class='w3-table-all table-responsive table' class='jogo'>
    <tr class='w3-indigo'>
    <th>" . "Id" . "</th>
    <th>" . "Nº Aluno" . "</th>
    <th>" . "Nº Turma" . "</th>
    <th>" . "Nº da Disciplina" . "</th>
    <th>" . "Bloco" . "</th>";
    while($row = mysqli_fetch_array($connect,MYSQLI_ASSOC)){
        echo "<tr>";
    foreach ($row as $chave => $valor){
            echo "<td>" . $valor . "</td>";
    }
        echo "</tr>";
    }

    } else {
            echo "Error creating table: " . $conn->error;
    }
echo "</table>";

echo "<h1>Inscritos em Exames:</h1>
    <br>";
    $sql = "SELECT *
        FROM inscritos_exame";
    $connect = $conn->query($sql);
    if ($connect == TRUE) {
    echo "<table class='w3-table-all table-responsive table' class='jogo'>
    <tr class='w3-indigo'>
    <th>" . "Id" . "</th>
    <th>" . "Nº Exame" . "</th>
    <th>" . "Nº Aluno" . "</th>
    <th>" . "Nº da Disciplina" . "</th>
    <th>" . "Fase" . "</th>";
    while($row = mysqli_fetch_array($connect,MYSQLI_ASSOC)){
        echo "<tr>";
    foreach ($row as $chave => $valor){
            echo "<td>" . $valor . "</td>";
    }
        echo "</tr>";
    }

    } else {
            echo "Error creating table: " . $conn->error;
    }
echo "</table>";

echo "<h1>Grupos de tabalho criados:</h1>
    <br>";
    $sql = "SELECT *
        FROM grupo";
    $connect = $conn->query($sql);
    if ($connect == TRUE) {
    echo "<table class='w3-table-all table-responsive table' class='jogo'>
    <tr class='w3-indigo'>
    <th>" . "Nº Grupo" . "</th>
    <th>" . "Nº da Disciplina" . "</th>
    <th>" . "Nº de inscritos" . "</th>
    <th>" . "Nº maximo de inscritos" . "</th>
    <th>" . "Status" . "</th>";
    while($row = mysqli_fetch_array($connect,MYSQLI_ASSOC)){
        echo "<tr>";
    foreach ($row as $chave => $valor){
            echo "<td>" . $valor . "</td>";
    }
        echo "</tr>";
    }

    } else {
            echo "Error creating table: " . $conn->error;
    }
echo "</table>";

echo "<h1>Alunos inscritos em grupos de trabalho:</h1>
    <br>";
    $sql = "SELECT *
        FROM inscritos_grupo";
    $connect = $conn->query($sql);
    if ($connect == TRUE) {
    echo "<table class='w3-table-all table-responsive table' class='jogo'>
    <tr class='w3-indigo'>
    <th>" . "Id" . "</th>
    <th>" . "Nº da Disciplina" . "</th>
    <th>" . "Nº Grupo" . "</th>
    <th>" . "Nº de Aluno" . "</th>";
    while($row = mysqli_fetch_array($connect,MYSQLI_ASSOC)){
        echo "<tr>";
    foreach ($row as $chave => $valor){
            echo "<td>" . $valor . "</td>";
    }
        echo "</tr>";
    }

    } else {
            echo "Error creating table: " . $conn->error;
    }
echo "</table>";

echo "<h1>Pedidos de Turma:</h1>
    <br>";
    $sql = "SELECT *
        FROM pedido";
    $connect = $conn->query($sql);
    if ($connect == TRUE) {
    echo "<table class='w3-table-all table-responsive table' class='jogo'>
    <tr class='w3-indigo'>
    <th>" . "Id" . "</th>
    <th>" . "Nº Aluno" . "</th>
    <th>" . "Nº da Disciplina" . "</th>
    <th>" . "Turma antiga" . "</th>
    <th>" . "Turma nova" . "</th>
    <th>" . "Status" . "</th>";
    while($row = mysqli_fetch_array($connect,MYSQLI_ASSOC)){
        echo "<tr>";
    foreach ($row as $chave => $valor){
            echo "<td>" . $valor . "</td>";
    }
        echo "</tr>";
    }

    } else {
            echo "Error creating table: " . $conn->error;
    }
echo "</table>";

echo "<h1>Presenças:</h1>
    <br>";
    $sql = "SELECT *
        FROM presenca";
    $connect = $conn->query($sql);
    if ($connect == TRUE) {
    echo "<table class='w3-table-all table-responsive table' class='jogo'>
    <tr class='w3-indigo'>
    <th>" . "Id" . "</th>
    <th>" . "Nº da Disciplina" . "</th>
    <th>" . "Nº Aluno" . "</th>
    <th>" . "Turma" . "</th>
    <th>" . "Data e hora" . "</th>";
    while($row = mysqli_fetch_array($connect,MYSQLI_ASSOC)){
        echo "<tr>";
    foreach ($row as $chave => $valor){
        echo "<td>" . $valor . "</td>";
        
    }
        echo "</tr>";
    }

    } else {
            echo "Error creating table: " . $conn->error;
    }
echo "</table>";

echo "<h1>Professor:</h1>
    <br>";
    $sql = "SELECT *
        FROM professor";
    $connect = $conn->query($sql);
    if ($connect == TRUE) {
    echo "<table class='w3-table-all table-responsive table' class='jogo'>
    <tr class='w3-indigo'>
    <th>" . "Nº de Professor" . "</th>
    <th>" . "Departamento" . "</th>
    <th>" . "Gabinete" . "</th>";
    while($row = mysqli_fetch_array($connect,MYSQLI_ASSOC)){
        echo "<tr>";
    foreach ($row as $chave => $valor){
        echo "<td>" . $valor . "</td>";
    }
        echo "</tr>";
    }

    } else {
            echo "Error creating table: " . $conn->error;
    }
echo "</table>";

echo "<h1>Mensagens:</h1>
    <br>";
    $sql = "SELECT *
        FROM notificacao";
    $connect = $conn->query($sql);
    if ($connect == TRUE) {
    echo "<table class='w3-table-all table-responsive table' class='jogo'>
    <tr class='w3-indigo'>
    <th>" . "Id" . "</th>
    <th>" . "Quem enviou" . "</th>
    <th>" . "Quem recebeu" . "</th>
    <th>" . "Mensagem" . "</th>";
    while($row = mysqli_fetch_array($connect,MYSQLI_ASSOC)){
        echo "<tr>";
    foreach ($row as $chave => $valor){
        echo "<td>" . $valor . "</td>";
    }
        echo "</tr>";
    }

    } else {
            echo "Error creating table: " . $conn->error;
    }
echo "</table>";

echo "<h1>Classificações:</h1>
    <br>";
    $sql = "SELECT *
        FROM classificacoes";
    $connect = $conn->query($sql);
    if ($connect == TRUE) {
    echo "<table class='w3-table-all table-responsive table' class='jogo'>
    <tr class='w3-indigo'>
    <th>" . "Nº Disc." . "</th>
    <th>" . "Aluno" . "</th>
    <th>" . "Contínua" . "</th>
    <th>" . "Períodica" . "</th>
    <th>" . "Exame Freq.1" . "</th>
    <th>" . "Exame Freq.2" . "</th>
    <th>" . "Exame 1ª Fase" . "</th>
    <th>" . "Exame 2ª Fase" . "</th>
    <th>" . "Final" . "</th>";
    while($row = mysqli_fetch_array($connect,MYSQLI_ASSOC)){
        echo "<tr>";
    foreach ($row as $chave => $valor){
        if ($chave !== 'id') {
            echo "<td>" . $valor . "</td>";
        }
    }
        echo "</tr>";
    }

    } else {
            echo "Error creating table: " . $conn->error;
    }
echo "</table>";

echo "<h1>Turmas:</h1>
    <br>";
    $sql = "SELECT *
        FROM turma";
    $connect = $conn->query($sql);
    if ($connect == TRUE) {
    echo "<table class='w3-table-all table-responsive table' class='jogo'>
    <tr class='w3-indigo'>
    <th>" . "Nº" . "</th>
    <th>" . "Tipo" . "</th>
    <th>" . "Dia da Semana" . "</th>
    <th>" . "Hora Inicio" . "</th>
    <th>" . "Hora Fim" . "</th>
    <th>" . "Sala" . "</th>
    <th>" . "Max Alunos" . "</th>
    <th>" . "Coordenador" . "</th>
    <th>" . "Status" . "</th>";
    while($row = mysqli_fetch_array($connect,MYSQLI_ASSOC)){
        echo "<tr>";
    foreach ($row as $chave => $valor){
        if ($chave !== 'id' && $chave !== 'ano_letivo' && $chave !== 'bloco') {
            echo "<td>" . $valor . "</td>";
        }
    }
        echo "</tr>";
    }

    } else {
            echo "Error creating table: " . $conn->error;
    }
echo "</table>";
echo "</div>";
}

if(isset($_POST ['Registo_Aluno'])) {
    $num = $_POST ["numero"];
    $nome = $_POST ["nome"];
    $curso = $_POST ["curso"];
    $mail = $_POST ["email"];
    $pass = $_POST ["pass"];
    $sql = "INSERT INTO pessoa (numero, email, nome, pass) VALUES ('$num', '$mail', '$nome', '$pass')";
    if ($conn->query($sql) == TRUE) {
        $sql = "INSERT INTO aluno (aluno_id, curso) VALUES ('$num', '$curso')";
        if ($conn->query($sql) == TRUE) {
            echo "<div class='toast__container'>
        <div class='toast__cell mainbox'>
            <div class='toast toast--green'>
                <div class='toast__icon'>
                </div>
                <div class='toast__content'>
                    <p class='toast__type'>Sucesso</p>
                    <p class='toast__message'>Registo do aluno efetuado com sucesso.</p>
                </div>
                <div class='toast__close'>
                    X
                </div>
            </div>
        </div>
    </div>";
        }else{
            echo "<div class='toast__container'>
        <div class='toast__cell mainbox'>
        <div class='toast toast--yellow'>
          <div class='toast__icon'>
          </div>
          <div class='toast__content'>
            <p class='toast__type'>Erro</p>
            <p class='toast__message'>Ocorreu um erro no registo do aluno.</p>
          </div>
          <div class='toast__close'>
            X
          </div>
        </div>
        </div>
        </div>";
            echo "<h1>".$conn->error."</h1>";
        }
    }else{
        echo "<div class='toast__container'>
        <div class='toast__cell mainbox'>
        <div class='toast toast--yellow'>
          <div class='toast__icon'>
          </div>
          <div class='toast__content'>
            <p class='toast__type'>Erro</p>
            <p class='toast__message'>Ocorreu um erro no registo da pessoa.</p>
          </div>
          <div class='toast__close'>
            X
          </div>
        </div>
        </div>
        </div>";
        echo "<h1>".$conn->error."</h1>";
    }
}

if(isset($_POST ['Registo_Professor'])) {
    $num = $_POST ["numero"];
    $nome = $_POST ["nome"];
    $departamento = $_POST ["departamento"];
    $mail = $_POST ["email"];
    $gabinete = $_POST ["gabinete"];
    $pass = $_POST ["pass"];
    $sql = "INSERT INTO pessoa (numero, email, nome, pass) VALUES ('$num', '$mail', '$nome', '$pass')";
    if ($conn->query($sql) == TRUE) {
        $sql = "INSERT INTO professor (prof_id, departamento, gabinete) VALUES ('$num', '$departamento', '$gabinete')";
        if ($conn->query($sql) == TRUE) {
            echo "<div class='toast__container'>
        <div class='toast__cell mainbox'>
            <div class='toast toast--green'>
                <div class='toast__icon'>
                </div>
                <div class='toast__content'>
                    <p class='toast__type'>Sucesso</p>
                    <p class='toast__message'>Registo do professor efetuado com sucesso.</p>
                </div>
                <div class='toast__close'>
                    X
                </div>
            </div>
        </div>
    </div>";
        }else{
            echo "<div class='toast__container'>
        <div class='toast__cell mainbox'>
        <div class='toast toast--yellow'>
          <div class='toast__icon'>
          </div>
          <div class='toast__content'>
            <p class='toast__type'>Erro</p>
            <p class='toast__message'>Ocorreu um erro no registo do professor.</p>
          </div>
          <div class='toast__close'>
            X
          </div>
        </div>
        </div>
        </div>";
            echo "<h1>".$conn->error."</h1>";
        }
    }else{
        echo "<div class='toast__container'>
        <div class='toast__cell mainbox'>
        <div class='toast toast--yellow'>
          <div class='toast__icon'>
          </div>
          <div class='toast__content'>
            <p class='toast__type'>Erro</p>
            <p class='toast__message'>Ocorreu um erro no registo da pessoa.</p>
          </div>
          <div class='toast__close'>
            X
          </div>
        </div>
        </div>
        </div>";
        echo "<h1>".$conn->error."</h1>";
    }
}
?>