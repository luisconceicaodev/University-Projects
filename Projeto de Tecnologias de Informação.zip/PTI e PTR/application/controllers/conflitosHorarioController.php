<?php
echo "<div class='w3-container mainbox' id='IH'>
<h1 id='MC'>Incompatibilidade de Horário</h1>
<br>";
echo "<p id='pconsultar'>Selecione a disciplina à qual pretende verificar se existe alunos com incompatibilidade de horário.</p>";
$sql = "SELECT id, nome
FROM uc
WHERE coordenador = $numero";
$connect = $conn->query($sql);
if ($connect == TRUE) {
    if($connect->num_rows > 0) {
        echo "<table class='w3-table-all table-responsive table' id='consultar'>
        <tr class='w3-indigo'>
        <th>" . "Disciplina" . "</th>";
        while($row = mysqli_fetch_array($connect,MYSQLI_ASSOC)){
            echo "<tr>";
        foreach ($row as $chave => $valor){
            if ($chave !== 'id'){
                echo "<td>" . $valor . "</td>";
            }
        }
        echo "<td><form action='conflitohorario' method='POST'>
            <input type='submit' class='btn btn-primary' name='ucselecionada' value='Selecionar'/>
            <input type='hidden' name='ucprof' href='' value='$row[id]'>
            <input type='hidden' name='ucnomeprof' href='' value='$row[nome]'>
            </form></td>";
        echo "</tr>";
        }   
        echo "</table>";
        echo "</div>";
    }else{ # se professor não for coordenador de nenhuma UC 
        echo "</div>";
        echo "<script type='text/javascript'>",
                "document.getElementById('IH').style.display='none';",
            "</script>";
            echo "<div class='w3-container mainbox'><h1>Você não tem permissões de coordenador nas unidades curriculares.</h1></div>";
    }
}else {
    echo "Error creating table: " . $conn->error;
}

if(isset($_POST['ucselecionada'])){
    echo "<script type='text/javascript'>",
    "document.getElementById('IH').style.display='none';",
    "</script>";
    $id_uc = $_POST ['ucprof'];
    $nome_uc = $_POST ['ucnomeprof'];
    $sql = "SELECT DISTINCT uc_id, aluno_id
    FROM inscritos
    WHERE uc_id = $id_uc";
    $connect = $conn->query($sql);
    if ($connect == TRUE) {
        $alunosArray = array();
        if($connect->num_rows > 0) {
            while($row = mysqli_fetch_array($connect,MYSQLI_ASSOC)){
                array_push($alunosArray,$row['aluno_id']);
            }
            if (isset($alunosArray)) {
                foreach($alunosArray as $aluno) {
                    $sql = "SELECT bloco_inscrito, COUNT(*) c FROM inscritos WHERE aluno_id = '$aluno' GROUP BY bloco_inscrito HAVING c > 1";
                    $alunoscomconflitoArray = array();
                    $connect = $conn->query($sql);
                    if ($connect == TRUE) {
                        while($row = mysqli_fetch_array($connect,MYSQLI_ASSOC)){
                            $alunoscomconflitoArray[$aluno] = $row['bloco_inscrito'];
                        }
                    }
                }
                if (isset($alunoscomconflitoArray)) {
                    echo "<div class='w3-container mainbox' id='incomp'>
                        <h1>Incompatibilidade de Horário</h1>
                        <br>";
                    foreach($alunoscomconflitoArray as $aluno => $bloco) {
                        $sql = "SELECT abreviatura, tipo, dia_semana, hora_inicio, hora_fim, bloco, sala
                        FROM turma, uc
                        WHERE EXISTS (
                            SELECT *
                            FROM inscritos AS i 
                            WHERE aluno_id = '$aluno' AND bloco = '$bloco' AND i.uc_id = '$id_uc'
                        ) AND turma.bloco = '$bloco' AND turma.uc_id = uc.id";
                        echo "O aluno $aluno possui a seguinte incompatibilidade de horários na sua disciplina de $nome_uc: <br>";
                        $connect = $conn->query($sql);
                        if ($connect == TRUE) {
                            if($connect->num_rows > 0) {
                                echo "<table class='w3-table-all table-responsive table' id='consultar'>
                                <tr class='w3-indigo'>
                                <th>" . "Disciplina" . "</th>
                                <th>" . "Tipo" . "</th>
                                <th>" . "Dia da semana" . "</th>
                                <th>" . "Hora de início" . "</th>
                                <th>" . "Hora de término" . "</th>
                                <th>" . "Sala" . "</th>";
                                while($row = mysqli_fetch_array($connect,MYSQLI_ASSOC)){
                                    echo "<tr>";
                                foreach ($row as $chave => $valor){
                                    if ($chave !== 'bloco') {
                                    echo "<td>" . $valor . "</td>";
                                    }
                                }
                            }
                            echo "<td><form action='conflitohorario' method='POST'>
                                    <input type='submit' class='btn btn-primary' name='sugerir' value='Sugerir solução'/>
                                    <input type='hidden' name='aluno' href='' value='$aluno'>
                                    <input type='hidden' name='uc' href='' value='$id_uc'>
                                    <input type='hidden' name='ucnome' href='' value='$nome_uc'>
                                    </form></td>";
                                echo "</tr>";
                        }
                    }else{
                        echo "<div class='toast__container'>
        <div class='toast__cell mainbox'>
        <div class='toast toast--yellow'>
          <div class='toast__icon'>
          </div>
          <div class='toast__content'>
            <p class='toast__type'>Erro</p>
            <p class='toast__message'>Ocorreu um erro ao procurar por sobreposições.</p>
          </div>
          <div class='toast__close'>
            X
          </div>
        </div>
        </div>
        </div>";
                    }
                    echo "</table>";
                    echo "</div>";
                    }
                }
            }else{
                echo "<div class='toast__container'>
        <div class='toast__cell mainbox'>
        <div class='toast toast--yellow'>
          <div class='toast__icon'>
          </div>
          <div class='toast__content'>
            <p class='toast__type'>Erro</p>
            <p class='toast__message'>Ocorreu um erro ao procurar por sobreposições.</p>
          </div>
          <div class='toast__close'>
            X
          </div>
        </div>
        </div>
        </div>";
            }
        }else{ 
            echo "</div>";
            echo "<script type='text/javascript'>",
                    "document.getElementById('IH').style.display='none';",
                "</script>";
                echo "<div class='w3-container mainbox'><h1>Não há alunos inscritos nesta disciplina.</h1></div>";
        }
    }else {
        echo "Error creating table: " . $conn->error;
    }
}

if(isset($_POST['sugerir'])){
    $id_uc = $_POST ['uc'];
    $nome_uc = $_POST ['ucnome'];
    $aluno = $_POST ['aluno'];
    echo "<script type='text/javascript'>",
    "document.getElementById('IH').style.display='none';",
    "document.getElementById('incomp').style.display='none';",
    "</script>";
    echo "<div class='w3-container mainbox' id='notificaraluno'>
        <h1>Incompatibilidade de Horário</h1>
        <h3>Disciplina: $nome_uc</h3>
        <h3>Aluno: $aluno</h1>
        <p>Envie uma notificação ao aluno, a sua mensagem terá de ter no máximo 250 caracteres.</p>
        <br>";
    echo "<form action='conflitohorario' method='POST'>
    <input type='text' maxlength='250' placeholder='Sugira outras turmas a que o aluno se possa inscrever.' name='mensagem'>
    <input type='submit' class='btn btn-primary' name='notificacao' value='Enviar'/>
    <input type='hidden' name='aluno' value='$aluno'>
    <input type='hidden' name='uc' value='$id_uc'>
    <input type='hidden' name='ucnome' value='$nome_uc'>
    </form></div>";
}

if(isset($_POST['notificacao'])){
    $id_uc = $_POST ['uc'];
    $nome_uc = $_POST ['ucnome'];
    $aluno = $_POST ['aluno'];
    $mensagem = $_POST ['mensagem'];
    echo "<script type='text/javascript'>",
    "document.getElementById('incomp').style.display='none';",
    "document.getElementById('notificaraluno').style.display='none';",
    "</script>";
    $sql = "INSERT INTO notificacao (para,de,mensagem) VALUES('$aluno','$nome','$mensagem')";
    if ($conn->query($sql) == TRUE) {
        echo "<div class='toast__container'>
<div class='toast__cell mainbox'>
<div class='toast toast--green'>
    <div class='toast__icon'>
    </div>
    <div class='toast__content'>
        <p class='toast__type'>Sucesso</p>
        <p class='toast__message'>A sua mensagem foi enviada.</p>
    </div>
    <div class='toast__close'>
        X
    </div>
</div>
</div>
</div>";
        }else {
            echo "<div class='toast__container'>
    <div class='toast__cell mainbox'>
    <div class='toast toast--yellow'>
    <div class='toast__icon'>
    </div>
    <div class='toast__content'>
        <p class='toast__type'>Erro</p>
        <p class='toast__message'>Ocorreu um erro ao enviar a sua mensagem.</p>
    </div>
    <div class='toast__close'>
        X
    </div>
    </div>
    </div>
    </div>";
    }
    
}

?>