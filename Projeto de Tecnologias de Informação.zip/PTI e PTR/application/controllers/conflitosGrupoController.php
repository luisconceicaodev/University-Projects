<?php
echo "<div class='w3-container mainbox' id='GASG'>
<h1 id='MC'>Gestão de Alunos Sem Grupo</h1>
<br>";
echo "<p id='pconsultar'>Selecione a disciplina à qual pretende verificar se existe alunos sem grupo de trabalho.</p>";
$sql = "SELECT id, nome
FROM uc
WHERE coordenador = $numero";
$connect = $conn->query($sql);
if ($connect == TRUE) {
    if($connect->num_rows > 0) {
        echo "<table class='w3-table-all table-responsive table' id='consultar'>
        <tr class='w3-indigo'>
        <th>" . "Disciplina" . "</th>";
        while($row = mysqli_fetch_array($connect,MYSQLI_ASSOC)){
            echo "<tr>";
        foreach ($row as $chave => $valor){
            if ($chave !== 'id'){
                echo "<td>" . $valor . "</td>";
            }
        }
        echo "<td><form action='conflitogrupo' method='POST'>
            <input type='submit' class='btn btn-primary' name='ucgrupo' value='Selecionar'/>
            <input type='hidden' name='ucprof' href='' value='$row[id]'>
            <input type='hidden' name='ucnomeprof' href='' value='$row[nome]'>
            </form></td>";
        echo "</tr>";
        }   
        echo "</table>";
        echo "</div>";
    }else{ # se professor não for coordenador de nenhuma UC 
        echo "</div>";
        echo "<script type='text/javascript'>",
                "document.getElementById('GASG').style.display='none';",
            "</script>";
            echo "<div class='w3-container mainbox'><h1>Você não tem permissões de coordenador nas unidades curriculares.</h1></div>";
    }
}else {
    echo "Error creating table: " . $conn->error;
}

if(isset($_POST['ucgrupo'])){
    $id_uc = $_POST ['ucprof'];
    $nome_uc = $_POST ['ucnomeprof'];
    echo "<script type='text/javascript'>",
    "document.getElementById('GASG').style.display='none';",
    "</script>";
    echo "<div class='w3-container mainbox' id='notificaraluno2'>
        <h1>Alunos Sem Grupo</h1>
        <h3>Disciplina: $nome_uc</h3>
        <p>Envie uma notificação ao aluno, a sua mensagem terá de ter no máximo 250 caracteres.</p>
        <br>";
    $id_uc = $_POST ['ucprof'];
    $nome_uc = $_POST ['ucnomeprof'];
    $sql = "SELECT DISTINCT aluno_id
    FROM inscritos as i
    WHERE NOT EXISTS (
        SELECT *
        FROM inscritos_grupo AS ig 
        WHERE ig.aluno_id = i.aluno_id AND ig.uc_id = '$id_uc'
    ) AND i.uc_id = '$id_uc'";
    $connect = $conn->query($sql);
    if ($connect == TRUE) {
        if($connect->num_rows > 0) {
            echo "<table class='w3-table-all table-responsive table'>
            <tr class='w3-indigo'>
            <th>" . "Alunos Sem Grupo" . "</th>";
            while($row = mysqli_fetch_array($connect,MYSQLI_ASSOC)){
                echo "<tr>";
            foreach ($row as $chave => $valor){
                echo "<td>" . $valor . "</td>";
                
            }
            echo "<td><form action='conflitogrupo' method='POST'>
                <input type='submit' class='btn btn-primary' name='sugerir2' value='Sugerir solução'/>
                <input type='hidden' name='aluno' href='' value='$row[aluno_id]'>
                <input type='hidden' name='uc' href='' value='$id_uc'>
                <input type='hidden' name='ucnome' href='' value='$nome_uc'>
                </form></td>";
            echo "</tr>";
            echo "</tr>";
            }   
            echo "</table>";
            echo "</div>";
        }else{ # se aluno não estiver inscrito a disciplinas
                echo "<div class='toast__container'>
            <div class='toast__cell mainbox'>
            <div class='toast toast--yellow'>
              <div class='toast__icon'>
              </div>
              <div class='toast__content'>
                <p class='toast__type'>Erro</p>
                <p class='toast__message'>Você não está inscrito a unidades curriculares.</p>
              </div>
              <div class='toast__close'>
                X
              </div>
            </div>
            </div>
            </div>";
        }
    }else {
        echo "Error accessing table: " . $conn->error;
    }
}

if(isset($_POST['sugerir2'])){
    $id_uc = $_POST ['uc'];
    $nome_uc = $_POST ['ucnome'];
    $aluno = $_POST ['aluno'];
    echo "<script type='text/javascript'>",
    "document.getElementById('GASG').style.display='none';",
    "document.getElementById('notificaraluno2').style.display='none';",
    "</script>";
    echo "<div class='w3-container mainbox' id='notificaraluno'>
        <h1>Alunos Sem Grupo</h1>
        <h3>Disciplina: $nome_uc</h3>
        <h3>Aluno: $aluno</h1>
        <p>Envie uma notificação ao aluno, a sua mensagem terá de ter no máximo 250 caracteres.</p>
        <br>";
    echo "<form action='conflitogrupo' method='POST'>
    <input type='text' maxlength='250' placeholder='Sugira outro aluno que não tenha grupo ou avise da data final de formação de grupos.' name='mensagem'>
    <input type='submit' class='btn btn-primary' name='notificacao' value='Enviar'/>
    <input type='hidden' name='aluno' value='$aluno'>
    <input type='hidden' name='uc' value='$id_uc'>
    <input type='hidden' name='ucnome' value='$nome_uc'>
    </form>";
}

if(isset($_POST['notificacao'])){
    $id_uc = $_POST ['uc'];
    $nome_uc = $_POST ['ucnome'];
    $aluno = $_POST ['aluno'];
    $mensagem = $_POST ['mensagem'];
    echo "<script type='text/javascript'>",
    "document.getElementById('GASG').style.display='none';",
    "document.getElementById('notificaraluno2').style.display='none';",
    "</script>";
    $sql = "INSERT INTO notificacao (para,de,mensagem) VALUES('$aluno','$nome','$mensagem')";
    if ($conn->query($sql) == TRUE) {
        echo "<div class='toast__container'>
<div class='toast__cell mainbox'>
<div class='toast toast--green'>
    <div class='toast__icon'>
    </div>
    <div class='toast__content'>
        <p class='toast__type'>Sucesso</p>
        <p class='toast__message'>A sua mensagem foi enviada.</p>
    </div>
    <div class='toast__close'>
        X
    </div>
</div>
</div>
</div>";
        }else {
            echo "<div class='toast__container'>
    <div class='toast__cell mainbox'>
    <div class='toast toast--yellow'>
    <div class='toast__icon'>
    </div>
    <div class='toast__content'>
        <p class='toast__type'>Erro</p>
        <p class='toast__message'>Ocorreu um erro ao enviar a sua mensagem.</p>
    </div>
    <div class='toast__close'>
        X
    </div>
    </div>
    </div>
    </div>";
    }
    
}

?>