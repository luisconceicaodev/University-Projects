<?php
echo "<div class='w3-container mainbox' id='GRU'>
<h1 id='MC'>Alunos inscritos nas suas disciplinas</h1>
<br>";
echo "<p id='pconsultar'>Selecione a disciplina à qual pretende consultar os alunos inscritos.</p>";
$sql = "SELECT id, nome
FROM uc
WHERE coordenador = $numero";
$connect = $conn->query($sql);
if ($connect == TRUE) {
    if($connect->num_rows > 0) {
        echo "<table class='w3-table-all table-responsive table' id='consultar'>
        <tr class='w3-indigo'>
        <th>" . "Disciplina" . "</th>";
        while($row = mysqli_fetch_array($connect,MYSQLI_ASSOC)){
            echo "<tr>";
        foreach ($row as $chave => $valor){
            if ($chave !== 'id'){
                echo "<td>" . $valor . "</td>";
            }
        }
        echo "<td><form action='inscritosProfessor' method='POST'>
            <input type='submit' class='btn btn-primary' name='consultarinscritos' value='Selecionar'/>
            <input type='hidden' name='ucprof' href='' id='join' value='$row[id]'>
            <input type='hidden' name='ucnomeprof' href='' id='join' value='$row[nome]'>
            </form></td>";
        echo "</tr>";
        }   
        echo "</table>";
        echo "</div>";
    }else{ # se professor não for coordenador de nenhuma UC 
        echo "</div>";
        echo "<script type='text/javascript'>",
                "document.getElementById('GRU').style.display='none';",
            "</script>";
            echo "<div class='w3-container mainbox'><h1>Você não tem permissões de coordenador nas unidades curriculares.</h1></div>";
    }
}else {
    echo "Error creating table: " . $conn->error;
}

if(isset($_POST['consultarinscritos'])){
    echo "<script type='text/javascript'>",
    "document.getElementById('GRU').style.display='none';",
    "</script>";
    $id_uc = $_POST ['ucprof'];
    $nome_uc = $_POST ['ucnomeprof'];
    echo "<div class='w3-container mainbox'>
    <h1 id='MC'>Alunos inscritos a ".$nome_uc."</h1>
    <br>";
    $sql = "SELECT DISTINCT aluno_id, uc_id FROM inscritos WHERE uc_id = $id_uc";
    $connect = $conn->query($sql);
    if ($connect == TRUE) {
        if($connect->num_rows > 0) {
            echo "<table class='w3-table-all table-responsive table'>
            <tr class='w3-indigo'>
            <th>Nº de Aluno</th>";
            while($row = mysqli_fetch_array($connect,MYSQLI_ASSOC)){
                echo "<tr>";
            foreach ($row as $chave => $valor){
                if ($chave !== 'uc_id'){
                    echo "<td>" . $valor . "</td>";
                }
            }
        }
        echo "</table>";
        echo "</div>";
        
        }else{ # se não existem alunos inscritos nesta disciplina
            echo "</div>";
            echo "<script type='text/javascript'>",
                        "document.getElementById('GRU').style.display='none';",
                    "</script>";
            echo "<h3>De momento, ainda nenhum aluno se inscreveu nesta disciplina.</h3>";
            echo "<p>Consulte outra vez mais tarde.</p>";
    }  
    }else {
        echo "Error creating table: " . $conn->error;
    } 
}
?>