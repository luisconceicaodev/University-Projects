<?php
    if(isset($_POST['delete'])){
        $sql = "DELETE from notificacao 
                where para = $numero";
        $connect = $conn->query($sql);
        if ($connect == TRUE) {
            echo "<div class='toast__container'>
        <div class='toast__cell mainbox'>
            <div class='toast toast--green'>
                <div class='toast__icon'>
                </div>
                <div class='toast__content'>
                    <p class='toast__type'>Sucesso</p>
                    <p class='toast__message'>Notificações eliminadas com sucesso</p>
                </div>
                <div class='toast__close'>
                    X
                </div>
            </div>
            </div>
        </div>";
            header('Location: '.$_SERVER['REQUEST_URI']);
        }else{
            echo "<div class='toast__container'>
        <div class='toast__cell mainbox'>
        <div class='toast toast--yellow'>
        <div class='toast__icon'>
        </div>
        <div class='toast__content'>
            <p class='toast__type'>Erro</p>
            <p class='toast__message'>Erro ao eliminar as notificações.</p>
        </div>
        <div class='toast__close'>
            X
        </div>
        </div>
        </div>
        </div>";
    } 
}
?>