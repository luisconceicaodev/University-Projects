<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Home extends CI_Controller {
	public function index() {
		$this->load->view('pages/home');
	}

	public function InfoPessoa()
	{
		$this->load->view('pages/infoPessoa');
	}

	public function Admin()
	{
		$this->load->view('pages/admin');
	}
	
	public function Classificacoes()
	{
		$this->load->view('pages/classificacoes');
	}

	public function Curriculo()
	{
		$this->load->view('pages/curriculo');
	}

	public function DetalhesConta()
	{
		$this->load->view('pages/detalhesConta');
	}

	public function DivulgacaoResultados()
	{
		$this->load->view('pages/divulgacaoResultados');
	}

	public function EntregaTrabalhos()
	{
		$this->load->view('pages/entregaTrabalhos');
	}

	public function GerirTurmas()
	{
		$this->load->view('pages/gerirTurmas');
	}

	public function Horario()
	{
		$this->load->view('pages/horario');
	}

	public function InscricaoExames()
	{
		$this->load->view('pages/inscricaoExames');
	}

	public function InscricaoGrupos()
	{
		$this->load->view('pages/inscricaoGrupos');
	}

	public function InscricaoHorario()
	{
		$this->load->view('pages/inscricaoHorario');
	}

	public function InscricaoUC()
	{
		$this->load->view('pages/inscricaoUC');
	}

	public function MudancasTurma()
	{
		$this->load->view('pages/mudancasTurma');
	}

	public function PedidosProfessor()
	{
		$this->load->view('pages/pedidosProfessor');
	}

	public function RegistoAlunos()
	{
		$this->load->view('pages/registoAlunos');
	}

	public function RegistoProfessores()
	{
		$this->load->view('pages/registoProfessores');
	}

	public function UnidadesCurricularesAluno()
	{
		$this->load->view('pages/unidadesCurricularesAluno');
	}

	public function UnidadesCurricularesProfessor()
	{
		$this->load->view('pages/unidadesCurricularesProfessor');
	}

	public function VerDados()
	{
		$this->load->view('pages/verDados');
	}

	public function Verinscritosexames()
	{
		$this->load->view('pages/verinscritosexames');
	}
}
