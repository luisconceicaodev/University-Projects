<?php
defined('BASEPATH') OR exit('No direct script access allowed');

$route['default_controller'] = 'pages/view';
$route['(:any)'] = 'pages/view/$1'; // para nao ter de meter /view no url
$route['404_override'] = '';
$route['translate_uri_dashes'] = FALSE;
$route['Home'] = 'Home';
$route['InfoPessoa'] = 'home/InfoPessoa';
$route['Admin'] = 'home/Admin';
$route['Classificacoes'] = 'home/Classificacoes';
$route['Curriculo'] = 'home/Curriculo';
$route['DetalhesConta'] = 'home/DetalhesConta';
$route['DivulgacaoResultados'] = 'home/DivulgacaoResultados';
$route['EntregaTrabalhos'] = 'home/EntregaTrabalhos';
$route['GerirTurmas'] = 'home/GerirTurmas';
$route['Horario'] = 'home/Horario';
$route['InscricaoExames'] = 'home/InscricaoExames';
$route['InscricaoGrupos'] = 'home/InscricaoGrupos';
$route['InscricaoHorario'] = 'home/InscricaoHorario';
$route['InscricaoUC'] = 'home/InscricaoUC';
$route['MudancasTurma'] = 'home/MudancasTurma';
$route['PedidosProfessor'] = 'home/PedidosProfessor';
$route['RegistoAlunos'] = 'home/RegistoAlunos';
$route['RegistoProfessores'] = 'home/RegistoProfessores';
$route['UnidadesCurricularesAluno'] = 'home/UnidadesCurricularesAluno';
$route['UnidadesCurricularesProfessor'] = 'home/UnidadesCurricularesProfessor';
$route['VerDados'] = 'home/VerDados';
$route['Verinscritosexames'] = 'home/Verinscritosexames';
$route['public/(:any)'] = 'public/$1';