from SOAPpy import SOAPProxy

url = 'http://appserver-01.alunos.di.fc.ul.pt/~asw010/Poker/infopartida.php'
namespace = 'uri:cumpwsdl'
server = SOAPProxy(url, namespace)
server.infopartida('52')
