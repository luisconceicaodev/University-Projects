<!DOCTYPE html>
<html>

<head>
    <meta charset="UTF-8">
    <title>Página dos Administradores</title>
    <link rel="stylesheet" type="text/css" href="/~asw010/Poker/estilo.css">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
    <link href="https://fonts.googleapis.com/css?family=Sansita" rel="stylesheet">
    <link href="https://fonts.googleapis.com/css?family=Lobster" rel="stylesheet">
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.2.1/jquery.min.js"></script>
    <script src="/~asw010/Poker/javascript.js?2"></script>
</head>

<body>
    <header>
        <img id="logotipo" src="/~asw010/Poker/logotipo.png">
        <form id="login" action="admin.php" method="POST">
            <ul class="menu cf">
                <li><a href="/~asw010/Poker/Inicial.php"><i class="fa fa-home fa-lg"></i></a></li>
                <li><a id="util" onclick="show_form()" href="#">Entrar</a>
                    <ul id='sub'>
                        <li id="1">
                            <p>Email/Username:</p>
                            <input class="input_log" type="text" name="user"></li>
                        <li id="2">
                            <p>Password:</p>
                            <input class="input_log" type="password" name="pass"></li>
                        <li id="4"><input type="submit" name="login" value="Login" id="log"></li>
                        <li><a id="3" href="/~asw010/Poker/registar.php">Registar</a></li>
                    </ul>
                </li>
                <li><a href="/~asw010/Poker/regras.html">Regras</a></li>
                <li> <a href="/~asw010/Poker/jogar.php">Jogar</a></li>
                <li><a href="/~asw010/Poker/ranking.php">Ranking</a></li>
                <li><a href="#">Créditos</a>
                    <ul class="submenu">
                        <li>
                            <p>Chandani Tushar nº48340</p>
                        </li>
                        <li>
                            <p>Ines Lino nº48311</p>
                        </li>
                        <li>
                            <p>Luís Conceição nº48303</p>
                        </li>
                        <li>
                            <p>Aplicações e Serviços na Web</p>
                        </li>
                    </ul>
                </li>
            </ul>
        </form>
    </header>

    <form class="search" action="admin.php" method="POST" id="procurar">
        <input type="text" name="user_search" id="myInput" placeholder="Pesquise nick/email ou local">
        <input type="submit" class="float_l" name="search" value="Procurar">
    </form>
    
    
    
    <form class="search" action="admin.php" method="POST" id="procurarJogos">
        <input type="text" name="game_search" id="myInput" placeholder="Pesquise nome/descrição/dono">
        <input type="submit" class="float_l" name="submitSearch" value="Procurar">
    </form>
    
    <div id='buts'>
        <input type='button' value='Tabela de Utilizadores' id='butAdmin' onclick='butAdmin(1);'>
        <input type='button' value='Tabela de Jogos' id='butAdmin2' onclick='butAdmin(2);'>
    </div>
    
    <input type="button" id='go_back' value='Voltar atrás' onclick='location.href = location.href';>
    
    
    
    <?php
        include("openconn.php");
        session_start();

        if (isset($_GET['off'])) {
            $_SESSION['loggedin'] = false;
            $_SESSION['username'] = null;
        }

        if (isset($_SESSION['loggedin']) && $_SESSION['loggedin'] == true) {
        $nome = $_SESSION['username'];
        echo "<script type='text/javascript'>",
            "document.getElementById('util').innerHTML = '$nome';",
            "document.getElementById('3').innerHTML = 'log off';",
            "document.getElementById('3').href = 'admin.php?off=true';",
            "var elem1 = document.getElementById('1');",
            " elem2 = document.getElementById('2');",
            " elem3 = document.getElementById('3');",
            " elem4 = document.getElementById('4');",
            "elem1.parentNode.removeChild(elem1);",
            "elem2.parentNode.removeChild(elem2);",
            "elem4.parentNode.removeChild(elem4);",
            "</script>";
        }

        if(isset($_POST ['login'])) {
            $user = mysqli_real_escape_string($conn,$_POST['user']);
            $pass = mysqli_real_escape_string($conn,$_POST['pass']);

            $sql = "SELECT nick FROM user WHERE (nick = '$user' or email = '$user') AND password = '$pass'";
            $result = mysqli_query($conn,$sql);
            $row = mysqli_fetch_array($result,MYSQLI_ASSOC);
            $active = $row['active'];
            $count = mysqli_num_rows($result);

            if($count == 1) {
                $_SESSION['loggedin'] = true;
                $_SESSION['username'] = $user;
                echo "<script type='text/javascript'>",
                "document.getElementById('util').innerHTML = '$user';",
                "document.getElementById('3').innerHTML = 'log off';",
                "document.getElementById('3').href = 'admin.php';",
                "var elem1 = document.getElementById('1');",
                " elem2 = document.getElementById('2');",
                " elem3 = document.getElementById('3');",
                " elem4 = document.getElementById('4');",
                "elem1.parentNode.removeChild(elem1);",
                "elem2.parentNode.removeChild(elem2);",
                "elem4.parentNode.removeChild(elem4);",
                "</script>";

            }else {
                echo "<p style=color:white;text-align:center;font-family:Sansita;>O teu nick/email ou password é invalida</p>";
            }
        }
    
        echo "<div id='notifications'></div>";
    
        if (isset($_POST['game_search'])) {
            $search = $_POST['game_search'];
            $sql = "SELECT game_request.id,player_id,player_cards,username,game_request.name,description,started_at,ended_at,table_cards,current_player,current_bet 
            FROM game_request,game_status,game_players,users 
            WHERE ((game_request.name = '$search' AND game_players.player_id = users.id AND game_status.id = game_request.id AND game_players.id = game_request.id) OR (description = '$search' AND game_players.player_id = users.id AND game_status.id = game_request.id AND game_players.id = game_request.id
            ) OR (username = '$search' AND game_request.id = game_players.id AND game_request.owner = users.id AND game_status.id = game_request.id))";
            $connect = $conn->query($sql);
            if ($connect == TRUE) {
                echo "<script>document.getElementById('buts').style.display = 'none';
                document.getElementById('go_back').style.display='block';</script>";
                echo "<p class = table-title>Resultado da pesquisa</p>
                <br>
                <div id =aparecer style='display:block'>
                <table class = jogo>";
                echo "<tr><th class = tabela, id = minha>" . "Id do jogo" . "</th>
              <th>" . "Id do jogador" . "</th>" .
              "<th>" . "Cartas do jogador" . "</th>" .
              "<th>" . "Dono do jogo" ."</th>" .
              "<th>" . "Nome do jogo" . "</th>" .
              "<th>" . "Descrição do jogo" . "</th>" .
              "<th>" . "Começou as" . "</th>" .
              "<th>" . "Acabou as" . "</th>" .
              "<th>" . "Cartas na mesa" . "</th>" .
              "<th>" . "Jogador a jogar" . "</th>" .
              "<th>" . "Aposta atual" . "</th></tr>";
                while($row = mysqli_fetch_array($connect,MYSQLI_ASSOC)){
                    echo "<tr>";
                    foreach ($row as $chave => $valor){
                         echo "<td>" . $valor . "</td>";
                    }
              echo "</tr>";
                }
                echo "</table></div>";

            } else {
                    echo "Error creating table: " . $conn->error;
            }

        }

        if (isset($_POST ['search'])) {
            $user = $_POST ['user_search'];
            $sql = "SELECT * FROM users WHERE (username = '$user' OR email = '$user' OR country = '$user' OR district = '$user' OR county = '$user')";
            $connect = $conn->query($sql);
            if ($connect == TRUE) {
                echo "<script>document.getElementById('buts').style.display = 'none';
                document.getElementById('go_back').style.display='block';</script>";
                echo " <div id =aparecer style='display:block'><p class = table-title>Resultado da pesquisa</p>
                <table class = tabela>";
                echo "<tr><th class = tabela, id = minha>" . "Id" . "</th>
              <th>" . "Username" . "</th>" .
              "<th>" . "Password" . "</th>" .
              "<th>" . "Email" ."</th>" .
              "<th>" . "Nome" . "</th>" .
              "<th>" . "Apelido" . "</th>" .
              "<th>" . "Sexo" . "</th>" .
              "<th>" . "Data de nascimento" . "</th>" .
              "<th>" . "País" . "</th>" .
              "<th>" . "Distrito" . "</th>" .
              "<th>" . "Concelho" . "</th>" .
              "<th>" . "Créditos" . "</th>" .
              "<th>" . "Vitórias" . "</th>" .
              "<th>" . "Derrotas" . "</th></tr>";
                while($row = mysqli_fetch_array($connect,MYSQLI_ASSOC)){
                    echo "<tr>";
                    foreach ($row as $chave => $valor){
                         echo "<td>" . $valor . "</td>";
                    }
              echo "</tr>";
                }

            } else {
                    echo "Error creating table: " . $conn->error;
            }

    	echo "</table></div>";
        }else{


    	$sql = "SELECT * FROM users";
    	$connect = $conn->query($sql);
    	if ($connect == TRUE) {
            echo " <div id =aparecer><p class = table-title>Tabela de Utilizadores</p>
            <table class = tabela>";
            echo "<tr><th class = tabela, id = minha>" . "Id" . "</th>
          <th>" . "Username" . "</th>" .
          "<th>" . "Password" . "</th>" .
          "<th>" . "Email" ."</th>" .
          "<th>" . "Nome" . "</th>" .
          "<th>" . "Apelido" . "</th>" .
          "<th>" . "Sexo" . "</th>" .
          "<th>" . "Data de nascimento" . "</th>" .
          "<th>" . "Pais" . "</th>" .
          "<th>" . "Distrito" . "</th>" .
          "<th>" . "Concelho" . "</th>" .
          "<th>" . "Créditos" . "</th>" .
          "<th>" . "Vitórias" . "</th>" .
          "<th>" . "Derrotas" . "</th></tr>";
    		while($row = mysqli_fetch_array($connect,MYSQLI_ASSOC)){
          echo "<tr>";
          foreach ($row as $chave => $valor){
    			     echo "<td>" . $valor . "</td>";
          }
          echo "</tr>";
    		}

    	} else {
        		echo "Error creating table: " . $conn->error;
    	}

    	echo "</table></div>";
        }
    
        $sql = "SELECT id,name,description,max_players,first_bet FROM game_request";
        $connect = $conn->query($sql);
        if ($connect == TRUE) {
        echo "<div id='jogos_admin'>
        <p id='titulo'>Tabela de todos os jogos propostos</p>";
        echo "<table class='jogo'>
        <tr>
        <th>" . "Id" . "</th>
        <th>" . "Nome" . "</th>" .
        "<th>" . "Descrição" . "</th>" .
        "<th>" . "Limite de jogadores" . "</th>" .
        "<th>" . "Primeira aposta" . "</th>";
        while($row = mysqli_fetch_array($connect,MYSQLI_ASSOC)){
            echo "<tr>";
        foreach ($row as $chave => $valor){
            echo "<td>" . $valor . "</td>";
        }
            echo "</tr>";
        }

    	} else {
        		echo "Error creating table: " . $conn->error;
    	}
    	echo "</table></div><br>";
        
    $sql = "SELECT id,started_at,ended_at,table_cards,current_player,current_bet,current_pot,row,last_to_raise FROM game_status";
    $connect = $conn->query($sql);
    if ($connect == TRUE) {
        echo "<div id='jogos_admin2'>
        <p id='titulo'>Tabela de jogos a decorrer e terminados</p>
        <table class='jogo'>
        <tr>
        <th>" . "Id do Jogo" . "</th>
          <th>" . "Início do jogo" . "</th>" .
          "<th>" . "Fim do jogo" . "</th>" .
          "<th>" . "Cartas na mesa" . "</th>" .
          "<th>" . "Jogador atual" ."</th>" .
          "<th>" . "Aposta atual" . "</th>" .
          "<th>" . "Pote total" . "</th>" .
          "<th>" . "Ronda" . "</th>" .
          "<th>" . "Id do ultimo a jogar" . "</th>";
        while($row = mysqli_fetch_array($connect,MYSQLI_ASSOC)){
            echo "<tr>";
            foreach ($row as $chave => $valor){
                echo "<td>" . $valor . "</td>";
            }
        }

    	} else {
        		echo "Error creating table: " . $conn->error;
    	}
    	echo "</table></div><br>";
    
    $sql = "SELECT id,player_id,player_cards,player_bet FROM game_players";
    $connect = $conn->query($sql);
    if ($connect == TRUE) {
        echo "<div id='jogos_admin3'>
        <p id='titulo'>Tabela de jogadores (jogos a decorrer e jogos terminados)</p>
        <table class='jogo'>
        <tr>
        <th>" . "Id do jogo" . "</th>
          <th>" . "Id do jogador" . "</th>" .
          "<th>" . "Cartas do jogador" . "</th>" .
          "<th>" . "Ultima aposta do jogador" . "</th>";
        while($row = mysqli_fetch_array($connect,MYSQLI_ASSOC)){
            echo "<tr>";
            foreach ($row as $chave => $valor){
                echo "<td>" . $valor . "</td>";
            }
        }

    	} else {
        		echo "Error creating table: " . $conn->error;
    	}
    	echo "</table><br></div>";
    
    	$conn->close();

  ?>
    



</body>

</html>
