<?php
    $dbhost = "appserver-01.alunos.di.fc.ul.pt";
  	$dbuser = "asw010";
  	$dbpass = "grupoCIL10";
  	$dbname = "asw010";

  	$conn = mysqli_connect($dbhost, $dbuser, $dbpass, $dbname);
  	if ($conn->connect_error) {
  		die("Database connection FAILED:". $conn->connect_error);
  	}
?>