<?php
    $dbhost = "appserver-01.alunos.di.fc.ul.pt";
  	$dbuser = "asw010";
  	$dbpass = "grupoCIL10";
  	$dbname = "asw010";

  	$conn = mysqli_connect($dbhost, $dbuser, $dbpass, $dbname);
  	if ($conn->connect_error) {
  		die("Database connection FAILED:". $conn->connect_error);
    }
    
    echo "<p id='titulo'>Tabela de todos os jogos propostos</p>";
    $sql = "SELECT id,name,description,max_players,first_bet FROM game_request";
    $connect = $conn->query($sql);
    if ($connect == TRUE) {
        echo "<div id='jogos_admin' style='display: block;'>";
        echo "<table class='jogo'>
        <tr>
        <th>" . "Id" . "</th>
        <th>" . "Nome" . "</th>" .
        "<th>" . "Descrição" . "</th>" .
        "<th>" . "Limite de jogadores" . "</th>" .
        "<th>" . "Primeira aposta" . "</th>";
        while($row = mysqli_fetch_array($connect,MYSQLI_ASSOC)){
            echo "<tr>";
        foreach ($row as $chave => $valor){
            echo "<td>" . $valor . "</td>";
        }
            $join_id = $row['id'];
            echo "</tr>";
        }

    } else {
        echo "Error creating table: " . $conn->error;
    	}
    echo "</table></div><br>";
?>