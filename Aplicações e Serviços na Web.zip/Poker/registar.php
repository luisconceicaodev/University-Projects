<!DOCTYPE html>
<html>

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Registar</title>
    <link rel="stylesheet" type="text/css" href="estilo.css">
    <link href="https://fonts.googleapis.com/css?family=Sansita" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.2.1/jquery.min.js"></script>
    <script src="javascript.js?v=1"></script>
</head>

<body>

    <header>
        <img id="logotipo" src="logotipo.png">
        <form id="login" action="registar.php" method="POST">
        <ul class="menu cf">
            <li><a href="Inicial.php"><i class="fa fa-home fa-lg"></i></a></li>
            <li><a id="util" onclick="show_form()" href="#">Entrar</a>
            <ul id='sub'>
                    <li id="1"><p>Email/Username:</p>
                <input class="input_log" type="text" name="user"></li>
                    <li id="2"><p>Password:</p>
                <input class="input_log" type="password" name="pass"></li>
                    <li id="4"><input type="submit" name="Login" name="Login" value="Login" id="log"></li>
                    <li><a id="3" href="registar.php">Registar</a></li>
                </ul>
            </li>
            <li><a href="regras.php">Regras</a></li>
            <li> <a href="jogar.php">Jogar</a></li>
            <li><a href="ranking.php">Ranking</a></li>
            <li><a href="#">Créditos</a>
            <ul class="submenu">
                    <li><p>Chandani Tushar nº48340</p></li>
                    <li><p>Ines Lino nº48311</p></li>
                    <li><p>Luís Conceição nº48303</p></li>
                    <li><p>Aplicações e Serviços na Web</p></li>
                </ul>
            </li>
        </ul>
      </form>
    </header>

    <?php
    include("openconn.php");
    
    if (isset($_POST ['input'])) {
        $nome = $_POST ["user_name"];
        $apelido = $_POST ["user_surname"];
        $email = $_POST ["user_email"];
        $nick = $_POST ["user_nick"];
        $sexo = $_POST ["user_sexo"];
        $data_nascimento = date($_POST ["user_year"] . '-' . $_POST ["user_month"] . '-' . $_POST ["user_day"]);
        $password = $_POST ["user_password"];
        $pais = $_POST ["user_country"];
        $distrito = $_POST ["user_distrito"];
        $concelho = $_POST ["user_concelho"];
        
        $sql = "INSERT INTO users (username, password, email, name, surname, gender, birthdate, country, district, county, credits, wins, losses) VALUES('$nick','$password','$email','$nome','$apelido','$sexo','$data_nascimento','$pais', '$distrito', '$concelho',20000,0,0)";

        if ($conn->query($sql) == TRUE) {
                echo "<p style=color:white;text-align:center;font-family:Sansita;>Conta criada com sucesso</p>";
        }else {
                echo "<p style=color:white;text-align:center;font-family:Sansita;>Já existe um utilizador com esse nick</p>";
                echo $nick,$password,$email,$nome,$apelido,$sexo,$data_nascimento,$pais,$distrito,$concelho;
        }
    }
  	$conn->close();

    

    ?>

    <form id="form_resgisto" action="registar.php" method="POST">

        <h1 id="registar">Registar</h1>

            <label for="name">Nome Próprio:</label>
            <input type="text" id="nome" name="user_name" pattern='[a-zA-Z0-9áéíóúãõÁÉÍÓÚÃÕ]+' required>


            <label for="surname">Apelido:</label>
            <input type="text" id="apelido" name="user_surname" pattern='[a-zA-Z0-9áéíóúãõÁÉÍÓÚÃÕ]+' required>

            <label for="nickname">Nome de utilizador/Nick:</label>
            <input maxlength="" type="text" id="nick" name="user_nick" pattern='[a-zA-Z0-9áéíóúãõÁÉÍÓÚÃÕ]+' required>

            <label for="gender">Sexo:</label>
                <input type="radio" id="fem" value="female" name="user_sexo" required>
            <label for="female" class="light">Feminino</label>
            <br>
                <input type="radio" value="male" name="user_sexo" required>
            <label for="male" id="masc" class="light">Masculino</label>
            <br>
            <input type="radio" value="other" name="user_sexo" required>
            <label for="other" class="light">Outro</label>
            <br>
            <br>

            <label for="birthday">Data de Nascimento:</label>
            <br>
        <div id="nascimento">
            <label for="day" class="light">Dia:</label>
            <select required id="dia" name="user_day">
                    <option value="" selected>Selecione um dia</option>
                    <option type="day" value="01">1</option>
                    <option type="day" value="02">2</option>
                    <option type="day" value="03">3</option>
                    <option type="day" value="04">4</option>
                    <option type="day" value="05">5</option>
                    <option type="day" value="06">6</option>
                    <option type="day" value="07">7</option>
                    <option type="day" value="08">8</option>
                    <option type="day" value="09">9</option>
                    <option type="day" value="10">10</option>
                    <option type="day" value="11">11</option>
                    <option type="day" value="12">12</option>
                    <option type="day" value="13">13</option>
                    <option type="day" value="14">14</option>
                    <option type="day" value="15">15</option>
                    <option type="day" value="16">16</option>
                    <option type="day" value="17">17</option>
                    <option type="day" value="18">18</option>
                    <option type="day" value="19">19</option>
                    <option type="day" value="20">20</option>
                    <option type="day" value="21">21</option>
                    <option type="day" value="22">22</option>
                    <option type="day" value="23">23</option>
                    <option type="day" value="24">24</option>
                    <option type="day" value="25">25</option>
                    <option type="day" value="26">26</option>
                    <option type="day" value="27">27</option>
                    <option type="day" value="28">28</option>
                    <option type="day" value="29">29</option>
                    <option type="day" value="30">30</option>
                    <option type="day" value="31">31</option>
            </select>

            <label for="month" class="light">Mês:</label>
            <select required id="mes" name="user_month">
                        <option value="" selected>Selecione um mês</option>
                        <option type="month" value="01">Janeiro</option>
                        <option type="month" value="02">Fevereiro</option>
                        <option type="month" value="03">Março</option>
                        <option type="month" value="04">Abril</option>
                        <option type="month" value="05">Maio</option>
                        <option type="month" value="06">Junho</option>
                        <option type="month" value="07">Julho</option>
                        <option type="month" value="08">Agosto</option>
                        <option type="month" value="09">Setembro</option>
                        <option type="month" value="10">Outubro</option>
                        <option type="month" value="11">Novembro</option>
                        <option type="month" value="12">Dezembro</option>
            </select>

            <label for="year" class="light">Ano:</label>
            <select required id="ano" name="user_year">
                <option value="" selected>Selecione um ano</option>
                <option type="year" value="1999">1999</option>
                <option type="year" value="1998">1998</option>
                <option type="year" value="1997">1997</option>
                <option type="year" value="1996">1996</option>
                <option type="year" value="1995">1995</option>
                <option type="year" value="1994">1994</option>
                <option type="year" value="1993">1993</option>
                <option type="year" value="1992">1992</option>
                <option type="year" value="1991">1991</option>
                <option type="year" value="1990">1990</option>
                <option type="year" value="1989">1989</option>
                <option type="year" value="1988">1988</option>
                <option type="year" value="1987">1987</option>
                <option type="year" value="1986">1986</option>
                <option type="year" value="1985">1985</option>
                <option type="year" value="1984">1984</option>
                <option type="year" value="1983">1983</option>
                <option type="year" value="1982">1982</option>
                <option type="year" value="1981">1981</option>
                <option type="year" value="1980">1980</option>
                <option type="year" value="1979">1979</option>
                <option type="year" value="1978">1978</option>
                <option type="year" value="1977">1977</option>
                <option type="year" value="1976">1976</option>
                <option type="year" value="1975">1975</option>
                <option type="year" value="1974">1974</option>
                <option type="year" value="1973">1973</option>
                <option type="year" value="1972">1972</option>
                <option type="year" value="1971">1971</option>
                <option type="year" value="1970">1970</option>
                <option type="year" value="1969">1969</option>
                <option type="year" value="1968">1968</option>
                <option type="year" value="1967">1967</option>
                <option type="year" value="1966">1966</option>
                <option type="year" value="1965">1965</option>
                <option type="year" value="1964">1964</option>
                <option type="year" value="1963">1963</option>
                <option type="year" value="1962">1962</option>
                <option type="year" value="1961">1961</option>
                <option type="year" value="1960">1960</option>
                <option type="year" value="1959">1959</option>
                <option type="year" value="1958">1958</option>
                <option type="year" value="1957">1957</option>
                <option type="year" value="1956">1956</option>
                <option type="year" value="1955">1955</option>
                <option type="year" value="1954">1954</option>
                <option type="year" value="1953">1953</option>
                <option type="year" value="1952">1952</option>
                <option type="year" value="1951">1951</option>
                <option type="year" value="1950">1950</option>
                <option type="year" value="1949">1949</option>
                <option type="year" value="1948">1948</option>
                <option type="year" value="1947">1947</option>
                <option type="year" value="1946">1946</option>
                <option type="year" value="1945">1945</option>
                <option type="year" value="1944">1944</option>
                <option type="year" value="1943">1943</option>
                <option type="year" value="1942">1942</option>
                <option type="year" value="1941">1941</option>
                <option type="year" value="1940">1940</option>
                <option type="year" value="1939">1939</option>
                <option type="year" value="1938">1938</option>
                <option type="year" value="1937">1937</option>
                <option type="year" value="1936">1936</option>
                <option type="year" value="1935">1935</option>
                <option type="year" value="1934">1934</option>
                <option type="year" value="1933">1933</option>
                <option type="year" value="1932">1932</option>
                <option type="year" value="1931">1931</option>
                <option type="year" value="1930">1930</option>
                <option type="year" value="1929">1929</option>
                <option type="year" value="1928">1928</option>
                <option type="year" value="1927">1927</option>
            </select>
        </div>
            <br>
            <br>

            <label for="mail">Email:</label>
            <input type="email" id="mail" name="user_email" pattern='[a-z0-9._%+-]+@[a-z0-9.-]+\.[a-z]{2,4}$' required>


            <label for="password">Password:</label>
            <input type="password" id="password" name="user_password" pattern=".{5,15}" required title="5 a 15 caracteres" required>

            <label for="Pais" class="light">País:</label>
            <select required id="pais" onchange="show()" name="user_country">
                <option value="" selected>Selecione um país</option>
                <option value="Alemanha">Alemanha</option>
                <option value="Argentina">Argentina</option>
                <option value="Austrália">Austrália</option>
                <option value="Austria">Austria</option>
                <option value="Bahamas">Bahamas</option>
                <option value="Bélgica">Bélgica</option>
                <option value="Brasil">Brasil</option>
                <option value="Bulgária">Bulgária</option>
                <option value="Canada">Canada</option>
                <option value="Chile">Chile</option>
                <option value="China">China</option>
                <option value="Dinamarca">Dinamarca</option>
                <option value="Egipto">Egipto</option>
                <option value="Espanha">Espanha</option>
                <option value="Estados Unidos">Estados Unidos</option>
                <option value="Estonia">Estonia</option>
                <option value="Fiji">Fiji</option>
                <option value="Finlândia">Finlândia</option>
                <option value="França">França</option>
                <option value="Grécia">Grécia</option>
                <option value="Índia">Índia</option>
                <option value="Inglaterra">Inglaterra</option>
                <option value="Iraque">Iraque</option>
                <option value="Irlanda">Irlanda</option>
                <option value="Israel">Israel</option>
                <option value="Itália">Itália</option>
                <option value="Japão">Japão</option>
                <option value="Luxemburgo">Luxemburgo</option>
                <option value="México">México</option>
                <option value="Nova Zelândia">Nova Zelândia</option>
                <option value="Noruega">Noruega</option>
                <option value="Paquistão">Paquistão</option>
                <option value="Portugal">Portugal</option>
                <option value="Russia">Russia</option>
                <option value="Venezuela">Venezuela</option>
        </select>
        <div id="hide2">
            <br>
        <label class="light" for="Distrito">Distrito:</label>
            <select name="user_distrito" onchange="concelho()" id="distrito">
                <option value="" id="must1" selected>Selecione um distrito</option>
                <option value="Açores">Açores</option>
                <option value="Aveiro">Aveiro</option>
                <option value="Beja">Beja</option>
                <option value="Braga">Braga</option>
                <option value="Bragança">Bragança</option>
                <option value="Castelo Branco">Castelo Branco</option>
                <option value="Coimbra">Coimbra</option>
                <option value="Évora">Évora</option>
                <option value="Faro">Faro</option>
                <option value="Guarda">Guarda</option>
                <option value="Leiria">Leiria</option>
                <option value="Lisboa">Lisboa</option>
                <option value="Madeira">Madeira</option>
                <option value="Portalegre">Portalegre</option>
                <option value="Porto">Porto</option>
                <option value="Santarém">Santarém</option>
                <option value="Setúbal">Setúbal</option>
                <option value="Viana do Castelo">Viana do Castelo</option>
                <option value="Vila Real">Vila Real</option>
                <option value="Viseu">Viseu</option>
            </select>
        <br><br>
        </div>

        <div id="concelho">
            <label class="light" for="Concelho">Concelho:</label>
            <select name="user_concelho" id="concelho_select">
                <option value="" id="must2" selected>Selecione um concelho</option>
            </select>
        </div>


        <p id="maiores"><strong>Nota:</strong> Jogo indicado para maiores de 18 anos, caso seja menor deverá ter o consentimento de um maior de idade.</p>
        <br>

        <input type="submit" id="user_res" name="input" value="Submeter">
    </form>

</body>

</html>
