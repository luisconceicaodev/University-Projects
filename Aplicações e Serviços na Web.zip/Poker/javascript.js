//var user_array = sessionStorage.getItem("user").split(",");
var path = window.location.pathname,
    page = path.split("/").pop();

window.addEventListener("load", function(){
    if (page === "Inicial.php") {
        var myIndex = 0;
        carousel();
    }

    function carousel() {
        var i;
        var x = document.getElementsByClassName("mySlides");
        for (i = 0; i < x.length; i++) {
           x[i].style.display = "none";
        }
        myIndex++;
        if (myIndex > x.length) {
            myIndex = 1;
        }
        x[myIndex-1].style.display = "block";
        setTimeout(carousel, 2000); // Change image every 2 seconds
    }
});

$(document).mouseup(function (e)
{
    var container = $("#sub");

    if (!container.is(e.target) // if the target of the click isn't the container...
        && container.has(e.target).length === 0) // ... nor a descendant of the container
    {
        container.hide();
    }
});


function showGetResult(url) {
    var win = "";
    jQuery.ajax({
        url: 'http://appserver-01.alunos.di.fc.ul.pt/~asw000/cgi-bin/findwinners.py?hands='+url+'&group=asw010',
        type: 'GET',
        method:"GET",
        dataType: 'xml',
        success:function(xml) {
            $(xml).find('winners').each(function(){
                $(this).find("index").each(function(){
                    var index_win = $(this).text();
                    win += index_win;
                });
                $(this).find("winning-rank").each(function(){
                    var rank = $(this).text();
                    if (window.location.href == 'http://appserver-01.alunos.di.fc.ul.pt/~asw010/Poker/jogo.php') {
                        window.location.href='jogo.php?winner='+win+"&rank="+rank;
                    }
                });
            });
        }
    });
}

//showGetResult('AS+9C+2C+QD+9H+JD+QC,AS+9C+2C+QD+9H+8H+QH,AS+9C+2C+QD+9H+6D+7H');

//showGetResult('5C 5S QD 8D JD,5C 5S QD AC 5H');

setInterval('AJAX()', 1000)
setInterval('AJAX_slow()', 1000)

function AJAX(){
    if (page === "jogar.php") {
         $.ajax({
             async: true,
             type: "GET",
             url: "http://appserver-01.alunos.di.fc.ul.pt/~asw010/Poker/view_table.php",
             dataType: "html",
             success: function (html) {
                 $("#tab_jogos").html(html);
             }  
        });
    }else if (page === "jogo.php") {
        $.ajax({
             async: true,
             type: "GET",
             url: "http://appserver-01.alunos.di.fc.ul.pt/~asw010/Poker/view_game.php",
             dataType: "html",
             success: function (html) {
                 $("#tabjogo").html(html);
             }  
        });
    }else if (page === 'admin.php') {
        $.ajax({
             async: true,
             type: "GET",
             url: "http://appserver-01.alunos.di.fc.ul.pt/~asw010/Poker/view_admin_notifications.php",
             dataType: "html",
             success: function (html) {
                 $("#notifications").html(html);
             }  
        });
    }

}

function alter_css_ajax() {
    $.ajax({
         async: true,
         type: "GET",
         url: "http://appserver-01.alunos.di.fc.ul.pt/~asw010/Poker/view_admin_requests.php",
         dataType: "html",
         success: function (html) {
             $("#jogos_admin").html(html);
         }  
    });
    $.ajax({
         async: true,
         type: "GET",
         url: "http://appserver-01.alunos.di.fc.ul.pt/~asw010/Poker/view_admin_status.php",
         dataType: "html",
         success: function (html) {
             $("#jogos_admin2").html(html);
         }  
    });
    $.ajax({
         async: true,
         type: "GET",
         url: "http://appserver-01.alunos.di.fc.ul.pt/~asw010/Poker/view_admin_players.php",
         dataType: "html",
         success: function (html) {
             $("#jogos_admin3").html(html);
         }  
    });
}

function AJAX_slow() {
    if (page === "jogo.php" && $("#nova_aposta").length == 0) {
         $.ajax({
             async: true,
             type: "GET",
             url: "http://appserver-01.alunos.di.fc.ul.pt/~asw010/Poker/view_status.php",
             dataType: "html",
             success: function (html) {
                 $("#info").html(html);
             }  
        });
    }
}

function hide_notifications() {
    document.getElementById('notifications').style.display = 'none';
}


function concelho() {
    document.getElementById("concelho").style.display = "block";
    var concelhos;
    if (document.getElementById("distrito").value === "Açores") {
        concelhos = ["Selecione um concelho","Angra do Heroísmo","Calheta","Corvo","Horta","Lagoa","Lajes das Flores","Lajes do Pico","Madalena","Nordeste","Ponta Delgada","Povoação","Praia da Vitória","Ribeira Grande","Santa Cruz da Graciosa","Santa Cruz das Flores","São Roque do Pico","Velas","Vila do Porto","Vila Franca do Campo"];
        mostrar_concelhos(concelhos);
        
    }else if (document.getElementById("distrito").value === "Aveiro") {
        concelhos = ["Selecione um concelho","Águeda","Albergaria-a-Velha","Anadia","Arouca","Aveiro","Castelo de Paiva","Espinho","Estarreja","Ílhavo","Mealhada","Murtosa","Oliveira de Azeméis","Oliveira do Bairro","Ovar","Santa Maria da Feira","São João da Madeira","Sever do Vouga","Vagos","Vale de Cambra"];
        mostrar_concelhos(concelhos);
        
    }else if (document.getElementById("distrito").value === "Beja") {
        concelhos = ["Selecione um concelho","Aljustrel","Almodôvar","Alvito","Barrancos","Beja","Castro Verde","Cuba","Ferreira do Alentejo","Mértola","Moura","Odemira","Ourique","Serpa","Vidigueira"];
        mostrar_concelhos(concelhos);
        
    }else if (document.getElementById("distrito").value === "Braga") {
        concelhos = ["Selecione um concelho","Amares","Barcelos","Braga","Cabeceiras de Basto","Celorico de Basto","Esposende","Fafe","Guimarães","Póvoa de Lanhoso","Terras de Bouro","Vieira do Minho","Vila Nova de Famalicão","Vila Verde","Vizela"];
        mostrar_concelhos(concelhos);
        
    }else if (document.getElementById("distrito").value === "Bragança") {
        concelhos = ["Selecione um concelho","Alfândega da Fé","Bragança","Carrazeda de Ansiães","Freixo de Espada à Cinta","Macedo de Cavaleiros","Miranda do Douro","Mirandela","Mogadouro","Torre de Moncorvo","Vila Flor","Vimioso","Vinhais"];
        mostrar_concelhos(concelhos);
        
    }else if (document.getElementById("distrito").value === "Castelo Branco") {
        concelhos = ["Selecione um concelho","Belmonte","Castelo Branco","Covilhã","Fundão","Idanha-a-Nova","Oleiros","Penamacor","Proença-a-Nova","Sertã","Vila de Rei","Vila Velha de Ródão"];
        mostrar_concelhos(concelhos);
        
    }else if (document.getElementById("distrito").value === "Coimbra") {
        concelhos = ["Selecione um concelho","Arganil","Cantanhede","Coimbra","Condeixa-a-Nova","Figueira da Foz","Góis","Lousã","Mira","Miranda do Corvo","Montemor-o-Velho","Oliveira do Hospital","Pampilhosa da Serra","Penacova","Penela","Soure","Tábua","Vila Nova de Poiares"];
        mostrar_concelhos(concelhos);
        
    }else if (document.getElementById("distrito").value === "Évora") {
        concelhos = ["Selecione um concelho","Alandroal","Arraiolos","Borba","Estremoz","Évora","Montemor-o-Novo","Mora","Mourão","Olivença","Portel","Redondo","Reguengos de Monsaraz","Vendas Novas","Viana do Alentejo","Vila Viçosa"];
        mostrar_concelhos(concelhos);
        
    }else if (document.getElementById("distrito").value === "Faro") {
        concelhos = ["Selecione um concelho","Albufeira","Alcoutim","Aljezur","Castro Marim","Faro","Lagoa","Lagos","Loulé","Monchique","Olhão","Portimão","São Brás de Alportel","Silves","Tavira","Vila do Bispo","Vila Real de Santo António"];
        mostrar_concelhos(concelhos);
        
    }else if (document.getElementById("distrito").value === "Guardar") {
        concelhos = ["Selecione um concelho","Aguiar da Beira","Almeida","Celorico da Beira","Figueira de Castelo Rodrigo","Fornos de Algodres","Gouveia","Guarda","Manteigas","Mêda","Pinhel","Sabugal","Seia","Trancoso","Vila Nova de Foz Côa"];
        mostrar_concelhos(concelhos);
        
    }else if (document.getElementById("distrito").value === "Leiria") {
        concelhos = ["Selecione um concelho", "Alcobaça","Alvaiázere","Ansião","Batalha","Bombarral","Caldas da Rainha","Castanheira de Pera","Figueiró dos Vinhos","Leiria","Marinha Grande","Nazaré","Óbidos","Pedrógão Grande","Peniche","Pombal","Porto de Mós"];
        mostrar_concelhos(concelhos);
        
    }else if (document.getElementById("distrito").value === "Lisboa") {
        concelhos = ["Selecione um concelho", "Alenquer","Amadora","Arruda dos Vinhos","Azambuja","Cadaval","Cascais","Lisboa","Loures","Lourinhã","Mafra","Odivelas","Oeiras","Sintra","Sobral de Monte Agraço","Torres Vedras","Vila Franca de Xira"];
        mostrar_concelhos(concelhos);
        
    }else if (document.getElementById("distrito").value === "Madeira") {
        concelhos = ["Selecione um concelho", "Calheta","Câmara de Lobos","Funchal","Machico","Ponta do Sol","Porto Moniz","Porto Santo","Ribeira Brava","Santa Cruz","Santana","São Vicente"];
        mostrar_concelhos(concelhos);
        
    }else if (document.getElementById("distrito").value === "Portalegre") {
        concelhos = ["Selecione um concelho","Alter do Chão","Arronches","Avis","Campo Maior","Castelo de Vide","Crato","Elvas","Fronteira","Gavião","Marvão","Monforte","Nisa","Ponte de Sor","Portalegre","Sousel"];
        mostrar_concelhos(concelhos);
        
    }else if (document.getElementById("distrito").value === "Porto") {
        concelhos = ["Selecione um concelho","Amarante","Baião","Felgueiras","Gondomar","Lousada","Maia","Marco de Canaveses","Matosinhos","Paços de Ferreira","Paredes","Penafiel","Porto","Póvoa de Varzim","Santo Tirso","Trofa","Valongo","Vila do Conde","Vila Nova de Gaia"];
        mostrar_concelhos(concelhos);
        
    }else if (document.getElementById("distrito").value === "Santarém") {
        concelhos = ["Selecione um concelho","Abrantes","Alcanena","Almeirim","Alpiarça","Benavente","Cartaxo","Chamusca","Constância","Coruche","Entroncamento","Ferreira do Zêzere","Golegã","Mação","Ourém","Rio Maior","Salvaterra de Magos","Santarém","Sardoal","Tomar","Torres Novas","Vila Nova da Barquinha"];
        mostrar_concelhos(concelhos);
        
    }else if (document.getElementById("distrito").value === "Setúbal") {
        concelhos = ["Selecione um concelho","Alcácer do Sal","Alcochete","Almada","Barreiro","Grândola","Moita","Montijo","Palmela","Santiago do Cacém","Seixal","Sesimbra","Setúbal","Sines"];
        mostrar_concelhos(concelhos);
        
    }else if (document.getElementById("distrito").value === "Viana do Castelo") {
        concelhos = ["Selecione um concelho","Arcos de Valdevez","Caminha","Melgaço","Monção","Paredes de Coura","Ponte da Barca","Ponte de Lima","Valença","Viana do Castelo","Vila Nova de Cerveira"];
        mostrar_concelhos(concelhos);
        
    }else if (document.getElementById("distrito").value === "Vila Real") {
        concelhos = ["Selecione um concelho","Alijó","Boticas","Chaves","Mesão Frio","Mondim de Basto","Montalegre","Murça","Peso da Régua","Ribeira de Pena","Sabrosa","Santa Marta de Penaguião","Valpaços","Vila Pouca de Aguiar","Vila Real"];
        mostrar_concelhos(concelhos);
        
    }else if (document.getElementById("distrito").value === "Viseu") {
        concelhos = ["Selecione um concelho","Armamar","Carregal do Sal","Castro Daire","Cinfães","Lamego","Mangualde","Moimenta da Beira","Mortágua","Nelas","Oliveira de Frades","Penalva do Castelo","Penedono","Resende","Santa Comba Dão","São João da Pesqueira","São Pedro do Sul","Sátão","Sernancelhe","Tabuaço","Tarouca","Tondela","Vila Nova de Paiva","Viseu","Vouzela"];
        mostrar_concelhos(concelhos);
    }
}
        
function mostrar_concelhos(concelhos) {
    document.getElementById("distrito").required = "true";
    var myDiv = document.getElementById("concelho");
    var element =  document.getElementById('concelho_select');
    if(element.options.length) {
            element.options.length = 0;

            for (var i = 0; i < concelhos.length; i++) {
                var option = document.createElement("option");
                if (concelhos[i] === "Selecione um concelho") {
                    option.value = "";    
                    option.selected = true;
                    option.id = "must2";
                }else{
                    option.value = concelhos[i];
                }
                option.text = concelhos[i];
                element.appendChild(option);
            }
        } else {
            for (var i = 0; i < concelhos.length; i++) {
                var option = document.createElement("option");
                option.value = concelhos[i];
                option.text = concelhos[i];
                element.appendChild(option);
            }
        }
}

function show() {
    "use strict";
    var must1 = document.getElementById("must1");
    var must2 = document.getElementById("must2");
    if (document.getElementById("pais").value === "Portugal") {
        document.getElementById("hide2").style.display = "block";
        document.getElementById("distrito").required = true;
        document.getElementById("concelho_select").required = true;
        must1.value = "";
        must2.value = "";
    }else{
        document.getElementById("concelho").style.display = "none";
        document.getElementById("hide2").style.display = "none";
        document.getElementById("concelho_select").required = false;
        document.getElementById("distrito").required = false;
        must1.selected = true;
        must2.selected = true;
        must1.value = "null";
        must2.value = "null";
    }
}

function registo() {
    var name = document.getElementById("nome").value;
    var surname = document.getElementById("apelido").value;
    var nick =  document.getElementById("nick").value;
    if (document.getElementById('fem').checked) {
        var gender = document.getElementById('fem').value;
    }
    if (document.getElementById('masc').checked) {
        var gender = document.getElementById('masc').value;
    }
    var dia = document.getElementById("dia").value;
    var mes = document.getElementById("mes").value;
    var ano = document.getElementById("ano").value;
    var email = document.getElementById("mail").value;
    var password = document.getElementById("password").value;
    var pais = document.getElementById("pais").value;

    var user = [name,surname,nick,gender,email,password,pais];
    sessionStorage.setItem("user",user);
    console.log(user);
}

function criar_jogo() {
    document.getElementById("hide").style.display = "block";
    document.getElementById("novoJogo").style.display = "none";
}

function hide() {
    document.getElementById("hide").style.display = "none";
    document.getElementById("novoJogo").style.display = "inherit";
}

function butAdmin(num) {
    if(num == 1){
        document.getElementById("aparecer").style.display="block";
        document.getElementById("buts").style.display="none";
        document.getElementById("procurar").style.display="block";
        document.getElementById("go_back").style.display="block";
    }
    else{
        document.getElementById("buts").style.display="none";
        document.getElementById("go_back").style.display="block";
        document.getElementById("jogos_admin").style.display="block";
        document.getElementById("jogos_admin2").style.display="block";
        document.getElementById("jogos_admin3").style.display="block";
        document.getElementById("procurarJogos").style.display="block";
        setInterval('alter_css_ajax()', 1000)
    }
}

function show_form() {
    document.getElementById('sub').style.display= "block";
}


function goAway(){
    document.getElementById("tab_jogos").style.display = "none";
    document.getElementById("titulo").style.display = "none";
    document.getElementById("filtrar").style.display = "none";
}

function come(){
    document.getElementById("tab_jogos").style.display = "table";
    document.getElementById("titulo").style.display = "block";
    document.getElementById("filtrar").style.display = "block";
}