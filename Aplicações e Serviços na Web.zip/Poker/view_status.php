<?php
    $dbhost = "appserver-01.alunos.di.fc.ul.pt";
  	$dbuser = "asw010";
  	$dbpass = "grupoCIL10";
  	$dbname = "asw010";

  	$conn = mysqli_connect($dbhost, $dbuser, $dbpass, $dbname);
  	if ($conn->connect_error) {
  		die("Database connection FAILED:". $conn->connect_error);
    }
    session_start();

    if (isset($_SESSION['loggedin']) && $_SESSION['loggedin'] == true) {
        $nome = $_SESSION['username'];
        $id = $_SESSION['user_id'];
    }

    $sql = "SELECT credits FROM users WHERE id = '$id'";
    $result = mysqli_query($conn, $sql);
        while ($rows = mysqli_fetch_array($result, MYSQLI_ASSOC)) {
            $credits = $rows['credits'];
    }

    $sql = "SELECT game_status.id,started_at,player_cards,table_cards,current_player,current_bet,current_pot,row,last_to_raise,max_players FROM game_request,game_status,game_players WHERE game_request.id = game_status.id AND game_players.player_id = '$id' AND game_players.id = game_status.id ORDER BY id DESC LIMIT 1";
    $connect = $conn->query($sql);
    if ($connect == TRUE) {
        while($row = mysqli_fetch_array($connect,MYSQLI_ASSOC)){
            $game_id = $row['id'];
            $current_p = $row['current_player'];
            $current_bet = $row['current_bet'];
            $current_pot = $row['current_pot'];
            $current_table_cards = $row['table_cards'];
            $ronda = $row['row'];
            $last = $row['last_to_raise'];
            $max_players = $row['max_players'];
            $started_at = $row['started_at'];
        }

    } else {
        echo $conn->error;
    }

    $sql = "SELECT player_id 
            FROM game_players 
            WHERE id = '$game_id' AND played = 'N' AND gave_up = 'N' 
            GROUP BY player_id LIMIT 1";
        $result = mysqli_query($conn, $sql);
        while ($rows = mysqli_fetch_array($result, MYSQLI_ASSOC)) {
            $next_player = $rows['player_id'];
        }

    $sql = "SELECT username FROM users,game_status WHERE game_status.id = '$game_id' AND game_status.current_player = '$next_player' AND '$next_player' = users.id";
    $result = mysqli_query($conn, $sql);
        while ($rows = mysqli_fetch_array($result, MYSQLI_ASSOC)) {
            $jogador_atual = $rows['username'];
    }

    $sql = "SELECT COUNT(player_id) FROM game_players WHERE id = '$game_id'";
    $result = mysqli_query($conn, $sql);
    while ($rows = mysqli_fetch_array($result, MYSQLI_ASSOC)) {
        $players = $rows['COUNT(player_id)'];
    }

    $sql = "SELECT COUNT(played) FROM game_players WHERE id = '$game_id' AND played = 'Y'";
    $result = mysqli_query($conn, $sql);
    while ($rows = mysqli_fetch_array($result, MYSQLI_ASSOC)) {
        $played = $rows['COUNT(played)'];
    }

    $sql = "SELECT player_id,player_bet,username FROM game_players,users WHERE game_players.id = '$game_id' AND users.id = game_players.player_id";
    $result = mysqli_query($conn, $sql);
    echo "<div id='creditos_pote'>";
    while ($rows = mysqli_fetch_array($result, MYSQLI_ASSOC)) {
        echo "<p style=color:white;font-family:Sansita;>Aposta do jogador " . $rows['username'] . ": " . $rows['player_bet'] . " €</p>";
    }
    echo "<p style=color:white;font-family:Sansita;>Valor na mesa: " . $current_pot. " €</p>";
    echo "<p style=color:white;font-family:Sansita;>Você tem " .$credits. " €.</p>";
    echo "</div>";
    
    // Pesquisar na BD o nome do jogador atual

    $sql = "SELECT owner 
            FROM game_request 
            WHERE id = '$game_id'";
        $result = mysqli_query($conn, $sql);
        while ($rows = mysqli_fetch_array($result, MYSQLI_ASSOC)) {
            $owner = $rows['owner'];
        }
    if ($ronda == 0) {
        $next_player = $owner;
    }
    
    $next_value = $current_bet + 1;
    if ($next_player == $id && $players == $max_players) {
        $sql = "UPDATE game_status SET current_player='$next_player' WHERE id='$game_id'";
            $connect = $conn->query($sql);
        echo "<p id='estado'>É a sua vez de jogar.</p>
        <div id='info'></div>
            <div id='opcoes'>
            <form action='jogo.php' method='POST'>
                <input type='submit' name='desistir' value='Desistir' id=''>
                <input type='submit' name='cobrir' value='Cobrir a aposta - " . $current_bet . " créditos' id=''> 
                <br>
                <br>
                Aumentar para:
                <input type='number' name='novaAposta' min='$next_value' max='$credits' id='nova_aposta'>
                <input type='submit' name='aumentar' value='Aumentar aposta' id=''>
                <br>
            </form>
            </div>";
    }elseif ($next_player == $id && $players < $max_players) {
        echo "<p id='estado' style=color:white;text-align:center;font-family:Sansita;>Esperando por mais jogadores...</p>";
    }elseif ($next_player != $id && $players == $max_players) {
        echo "<p id='estado'>É a vez do jogador ".$jogador_atual." </p>
        <div id='info'></div>";
    }elseif ($next_player != $id && $players < $max_players) {
        echo "<p id='estado' style=color:white;text-align:center;font-family:Sansita;>Esperando por mais jogadores...</p>";
    }

    if ($players == 2) {
        if ($played == $players && $ronda == $players+6) {
            $sql = "SELECT player_id,player_cards FROM game_players WHERE id='$game_id'";
            $result = mysqli_query($conn, $sql);
            while ($rows = mysqli_fetch_array($result, MYSQLI_ASSOC)) {
                echo "<script>document.getElementById('opcoes').style.display='none';document.getElementById('info').style.display='none';</script>";
            }
            echo "<script>document.getElementById('estado').style.display = 'none';document.getElementById('time').style.display='none'</script>";
            echo "<p style=color:white;text-align:center;font-family:Sansita;></p>";
            $end = date("Y-m-d H:i:s");
            $sql = "UPDATE game_status SET ended_at='$end' WHERE id='$game_id'";
            $connect = $conn->query($sql);
        }
    }elseif ($players == 3) {
        if ($played == $players && $ronda == $players+9) {
            $sql = "SELECT player_id,player_cards FROM game_players WHERE id='$game_id'";
            $result = mysqli_query($conn, $sql);
            while ($rows = mysqli_fetch_array($result, MYSQLI_ASSOC)) {
                echo "<script>document.getElementById('opcoes').style.display='none';document.getElementById('info').style.display='none';</script>";
            }
            echo "<script>document.getElementById('estado').style.display = 'none';document.getElementById('time').style.display='none'</script>";
            echo "<p style=color:white;text-align:center;font-family:Sansita;></p>";
            $end = date("Y-m-d H:i:s");
            $sql = "UPDATE game_status SET ended_at='$end' WHERE id='$game_id'";
            $connect = $conn->query($sql);
        }
    }
?>