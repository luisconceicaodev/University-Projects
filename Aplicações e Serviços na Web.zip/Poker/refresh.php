<?php
    include('openconn.php');
    $sql = "SELECT game_request.id, name, description, max_players, first_bet
            FROM game_request, game_players
            WHERE game_request.id = game_players.id
            GROUP BY game_request.id, name, description, first_bet
            HAVING COUNT(game_players.id) < game_request.max_players";
    $result = mysqli_query($conn, $sql);
    if ($result == TRUE) {
        echo "<input type='button' onclick='criar_jogo()' value='Criar novo jogo' id='novoJogo'>";
        echo "<p id='titulo'>Lista de jogos</p>";
        echo "<table class='jogo'>
            <tr>
            <th>" . "Id" . "</th>
            <th>" . "Nome" . "</th>" .
            "<th>" . "Descrição" . "</th>" .
            "<th>" . "Max players" . "</th>" .
            "<th>" . "Primeira aposta" . "</th>" .
            "<th>" . "Entrar" ."</th>";
        while($row=mysql_fetch_array($result)){
            echo "<tr>";
            foreach ($row as $chave => $valor){
                echo "<td>" . $valor . "</td>";
            }
                $join_id = $row['id'];
                echo "<td><form action='jogar.php' method='POST'><input type='submit' name='join' href='jogo.php' id='join' value='$join_id'></form></td>";
                echo "</tr>";
            }

        } else {
                    echo "Error creating table: " . $conn->error;
        }
        echo "</table><br>";
?>