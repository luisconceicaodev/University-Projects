<?php
    require_once "lib/nusoap.php";
    
    function infopartida($id) {
        require("openconn.php");
        $sql = "SELECT started_at, current_player, table_cards, current_bet
        FROM game_status
        WHERE game_status.id = '$id'";
        $result = mysqli_query($conn, $sql);
        while ($rows = mysqli_fetch_array($result, MYSQLI_ASSOC)) {
            $inicio = $rows['started_at'];
            $current_player = $rows['current_player'];
            $table_cards = $rows['table_cards'];
            $current_bet = $rows['current_bet'];
        }
        
        $sql = "SELECT username, player_cards, player_bet
                FROM game_players, users
                WHERE game_players.id = '$id' AND game_players.player_id = users.id";
        $result = mysqli_query($conn, $sql);
        while ($rows = mysqli_fetch_array($result, MYSQLI_ASSOC)) {
            $username[] = $rows['username'];
            $player_cards[] = $rows['player_cards'];
            $player_bet[] = $rows['table_cards'];
        }
        
        
        echo $id;
        $resultado = "Inicio: ". $inicio . "\n" . "Jogador atual: " . $current_player . "\n" . "Cartas na mesa: " . $table_cards . "\n" . "Aposta atual: " . $current_bet . "\n" . "Cartas de cada jogador: " . $username[0] . " : " . $player_cards[0] . "\n" . $username[1] . " : " . $player_cards[1] . "Aposta de cada jogador: " . $username[0] . " : " . $player_cards[0] . "\n" . $username[1] . " : " . $player_cards[1];
        echo $resultado;
        return $resultado;
    }

    $server = new soap_server();
    $server->register("infopartida", // nome metodo
     array('id' => 'xsd:string'), // input
     array('return' => 'xsd:string'), // output
     'uri:cumpwsdl', // namespace
     'urn:cumpwsdl#infopartida', // SOAPAction
     'rpc', // estilo
     'encoded' // uso
     );

    $HTTP_RAW_POST_DATA = isset($HTTP_RAW_POST_DATA) ? $HTTP_RAW_POST_DATA : '';
    $server->service($HTTP_RAW_POST_DATA); 

?>