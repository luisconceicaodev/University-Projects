<!DOCTYPE html>
<html>

<head>
    <meta charset="UTF-8">
    <title>Página Inicial</title>
    <link rel="stylesheet" type="text/css" href="estilo.css">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link href="https://fonts.googleapis.com/css?family=Lobster" rel="stylesheet">
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.2.1/jquery.min.js"></script>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
    <script src="javascript.js"></script>
</head>

<body>
    <header>
        <img id="logotipo" src="logotipo.png">
        <form id="login" action="Inicial.php" method="POST">
        <ul class="menu cf">
            <li><a href="Inicial.php"><i class="fa fa-home fa-lg"></i></a></li>
            <li><a id="util" onclick="show_form()" href="#">Entrar</a>
            <ul id='sub'>
                    <li id="1"><p>Email/Username:</p>
                <input class="input_log" type="text" name="user"></li>
                    <li id="2"><p>Password:</p>
                <input class="input_log" type="password" name="pass"></li>
                    <li id="4"><input type="submit" name="Login" value="Login" id="log"></li>
                    <li><a id="3" href="registar.php">Registar</a></li>
                </ul>
            </li>
            <li><a href="regras.php">Regras</a></li>
            <li> <a href="jogar.php">Jogar</a></li>
            <li><a href="ranking.php">Ranking</a></li>
            <li><a href="#">Créditos</a>
            <ul class="submenu">
                    <li><p>Chandani Tushar nº48340</p></li>
                    <li><p>Ines Lino nº48311</p></li>
                    <li><p>Luís Conceição nº48303</p></li>
                    <li><p>Aplicações e Serviços na Web</p></li>
                </ul>
            </li>
        </ul>
      </form>
    </header>

    <?php
    include("openconn.php");
    
    ?>

    <div id="Slides" class="w3-content w3-section">
        <img class="mySlides" src="slide1.jpg">
        <img class="mySlides" src="slide2.jpg">
        <img class="mySlides" src="slide3.jpg">
        <p id="quote">"If you can't beat them Bluff them." - N.R. Kudelis</p>
    </div>


    </body>

</html>
