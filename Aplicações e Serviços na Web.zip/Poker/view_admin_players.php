<?php
    $dbhost = "appserver-01.alunos.di.fc.ul.pt";
  	$dbuser = "asw010";
  	$dbpass = "grupoCIL10";
  	$dbname = "asw010";

  	$conn = mysqli_connect($dbhost, $dbuser, $dbpass, $dbname);
  	if ($conn->connect_error) {
  		die("Database connection FAILED:". $conn->connect_error);
    }
    echo "<p id='titulo'>Tabela de jogadores (jogos a decorrer e jogos terminados)</p>";
    $sql = "SELECT id,player_id,player_cards,player_bet FROM game_players";
    $connect = $conn->query($sql);
    if ($connect == TRUE) {
        echo "<div id='jogos_admin3' style='display: block;'><table class='jogo'>
        <tr>
        <th>" . "Id do jogo" . "</th>
          <th>" . "Id do jogador" . "</th>" .
          "<th>" . "Cartas do jogador" . "</th>" .
          "<th>" . "Ultima aposta do jogador" . "</th>";
        while($row = mysqli_fetch_array($connect,MYSQLI_ASSOC)){
            echo "<tr>";
            foreach ($row as $chave => $valor){
                echo "<td>" . $valor . "</td>";
            }
        }

    	} else {
        		echo "Error creating table: " . $conn->error;
    	}
    	echo "</table><br></div>";
?>