<?php
    $dbhost = "appserver-01.alunos.di.fc.ul.pt";
  	$dbuser = "asw010";
  	$dbpass = "grupoCIL10";
  	$dbname = "asw010";

  	$conn = mysqli_connect($dbhost, $dbuser, $dbpass, $dbname);
  	if ($conn->connect_error) {
  		die("Database connection FAILED:". $conn->connect_error);
    }
    echo "<p id='titulo'>Tabela de jogos a decorrer e terminados</p>";
    $sql = "SELECT id,started_at,ended_at,table_cards,current_player,current_bet,current_pot,row,last_to_raise FROM game_status";
    $connect = $conn->query($sql);
    if ($connect == TRUE) {
        echo "<div id='jogos_admin2' style='display: block;'><table class='jogo'>
        <tr>
        <th>" . "Id do Jogo" . "</th>
          <th>" . "Início do jogo" . "</th>" .
          "<th>" . "Fim do jogo" . "</th>" .
          "<th>" . "Cartas na mesa" . "</th>" .
          "<th>" . "Jogador atual" ."</th>" .
          "<th>" . "Aposta atual" . "</th>" .
          "<th>" . "Pote total" . "</th>" .
          "<th>" . "Ronda" . "</th>" .
          "<th>" . "Id do ultimo a jogar" . "</th>";
        while($row = mysqli_fetch_array($connect,MYSQLI_ASSOC)){
            echo "<tr>";
            foreach ($row as $chave => $valor){
                echo "<td>" . $valor . "</td>";
            }
        }

    	} else {
        		echo "Error creating table: " . $conn->error;
    	}
    	echo "</table></div><br>";
?>