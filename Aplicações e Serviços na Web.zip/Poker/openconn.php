<?php
    $dbhost = "appserver-01.alunos.di.fc.ul.pt";
  	$dbuser = "asw010";
  	$dbpass = "grupoCIL10";
  	$dbname = "asw010";

  	$conn = mysqli_connect($dbhost, $dbuser, $dbpass, $dbname);
  	if ($conn->connect_error) {
  		die("Database connection FAILED:". $conn->connect_error);
    }
    session_start();
    if (isset($_GET['off'])) {
        $_SESSION['loggedin'] = false;
        $_SESSION['username'] = null;
        $_SESSION['user_id'] = null;
    }
    
    if (isset($_SESSION['loggedin']) && $_SESSION['loggedin'] == true) {
        $nome = $_SESSION['username'];
        $id = $_SESSION['user_id'];
        echo "<script type='text/javascript'>",
            "document.getElementById('util').innerHTML = '$nome';",
            "document.getElementById('2').innerHTML = '<a href=".'historico.php'.">Histórico</a>';",
            "document.getElementById('3').innerHTML = 'log off';",
            "document.getElementById('3').href = 'Inicial.php?off=true';",
            "var elem1 = document.getElementById('1');",
            " elem2 = document.getElementById('2');",
            " elem3 = document.getElementById('3');",
            " elem4 = document.getElementById('4');",
            "elem1.parentNode.removeChild(elem1);",
            "elem4.parentNode.removeChild(elem4);",
            "</script>";
    }
    
    if(isset($_POST ['Login'])) {
        $user = mysqli_real_escape_string($conn,$_POST['user']);
        $pass = mysqli_real_escape_string($conn,$_POST['pass']);

        $sql = "SELECT username FROM users WHERE (username = '$user' OR email = '$user') AND password = '$pass'";
        $result = mysqli_query($conn,$sql);
        $row = mysqli_fetch_array($result,MYSQLI_ASSOC);
        $active = $row['active'];
        $count = mysqli_num_rows($result);
        
        $sql = "SELECT id FROM users WHERE '$user' = username";
                $result = mysqli_query($conn, $sql);
                while ($rows = mysqli_fetch_array($result, MYSQLI_ASSOC)) {
                    $id = $rows['id'];
                }

        if($count == 1) {
            $_SESSION['loggedin'] = true;
            $_SESSION['username'] = $user;
            $_SESSION['user_id'] = $id;
            echo "<script type='text/javascript'>",
            "document.getElementById('util').innerHTML = '$user';",
            "document.getElementById('2').innerHTML = '<a href=".'historico.php'.">Histórico</a>';",
            "document.getElementById('3').innerHTML = 'log off';",
            "document.getElementById('3').href = 'Inicial.php?off=true';",
            "var elem1 = document.getElementById('1');",
            " elem2 = document.getElementById('2');",
            " elem3 = document.getElementById('3');",
            " elem4 = document.getElementById('4');",
            "elem1.parentNode.removeChild(elem1);",
            "elem4.parentNode.removeChild(elem4);",
            "</script>";
            
        }else {
            echo "<p style=color:white;text-align:center;font-family:Sansita;>O teu nick/email ou password é invalida</p>";
        }
    }
?>