<?php
    $dbhost = "appserver-01.alunos.di.fc.ul.pt";
  	$dbuser = "asw010";
  	$dbpass = "grupoCIL10";
  	$dbname = "asw010";

  	$conn = mysqli_connect($dbhost, $dbuser, $dbpass, $dbname);
  	if ($conn->connect_error) {
  		die("Database connection FAILED:". $conn->connect_error);
    }

    $sql = "SELECT current_pot FROM game_status";
    $connect = $conn->query($sql);
    if ($connect == TRUE) {

        while($row = mysqli_fetch_array($connect,MYSQLI_ASSOC)){
            foreach ($row as $chave => $valor){
                if ($valor >= 10000) {
                    echo "<p>Notificação: O valor de apostas num jogo chegou a 10000€!</p>";
                    echo "<input type='button' onclick='hide_notifications()' value='Esconder notificação'>";
                }
            }
        }

    	} else {
        		echo "Error showing notification: " . $conn->error;
    	}
    	echo "<br>";
?>