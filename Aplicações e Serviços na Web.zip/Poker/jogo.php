<!DOCTYPE html>
<html>

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Jogar</title>
    <link rel="stylesheet" type="text/css" href="estilo.css">
    <link href="https://fonts.googleapis.com/css?family=Sansita" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.2.1/jquery.min.js"></script>
    <script src="javascript.js?v=1"></script>
</head>

<body>

    <header>
        <img id="logotipo" src="logotipo.png">
        <form id="login" action="jogo.php" method="POST">
        <ul class="menu cf">
            <li><a href="Inicial.php"><i class="fa fa-home fa-lg"></i></a></li>
            <li><a id="util" onclick="show_form()" href="#">Entrar</a>
            <ul id="sub">
                    <li id="1"><p>Email/Username:</p>
                <input class="input_log" type="text" name="user"></li>
                    <li id="2"><p>Password:</p>
                <input class="input_log" type="password" name="pass"></li>
                    <li id="4"><input type="submit" name="Login" value="Login" id="log"></li>
                    <li><a id="3" href="registar.php">Registar</a></li>
                </ul>
            </li>
            <li><a href="regras.php">Regras</a></li>
            <li> <a href="jogar.php">Jogar</a></li>
            <li><a href="ranking.php">Ranking</a></li>
            <li><a href="#">Créditos</a>
            <ul class="submenu">
                    <li><p>Chandani Tushar nº48340</p></li>
                    <li><p>Ines Lino nº48311</p></li>
                    <li><p>Luís Conceição nº48303</p></li>
                    <li><p>Aplicações e Serviços na Web</p></li>
                </ul>
            </li>
        </ul>
      </form>
    </header>
    <?php
    include("openconn.php");
    $nome = $_SESSION['username'];
    $id = $_SESSION['user_id'];
    
    $sql = "SELECT credits FROM users WHERE id = '$id'";
    $result = mysqli_query($conn, $sql);
        while ($rows = mysqli_fetch_array($result, MYSQLI_ASSOC)) {
            $credits = $rows['credits'];
    }

    $sql = "SELECT row FROM game_status,game_request WHERE game_status.id = game_request.id"; // definir jogadores
    $result = mysqli_query($conn, $sql);
        while ($rows = mysqli_fetch_array($result, MYSQLI_ASSOC)) {
            $ronda = $rows['row'];
    }
    
    $sql = "SELECT game_status.id,started_at,player_cards,table_cards,current_player,current_bet,current_pot,row,last_to_raise FROM game_request,game_status,game_players WHERE game_request.id = game_status.id AND game_players.player_id = '$id' AND game_players.id = game_status.id ORDER BY id DESC LIMIT 1";
    $connect = $conn->query($sql);
    if ($connect == TRUE) {
        echo "<div id='tabjogo'>
        <img id='table_img' src='mesa.png'>
        <table id='viewgame' class='jogo'>
        <tr>
        <th>" . "Id do Jogo" . "</th>
          <th>" . "Início" . "</th>" .
          "<th>" . "Suas cartas" . "</th>" .
          "<th>" . "Cartas na mesa" . "</th>" .
          "<th>" . "Jogador atual" ."</th>" .
          "<th>" . "Aposta atual" . "</th>" .
          "<th>" . "Current pot" . "</th>" .
          "<th>" . "Ronda" . "</th>" .
          "<th>" . "Ultimo a jogar" . "</th>";
        while($row = mysqli_fetch_array($connect,MYSQLI_ASSOC)){
            echo "<tr>";
        foreach ($row as $chave => $valor){
            if ($chave != 'table_cards') {
                echo "<td>" . $valor . "</td>";
            }else {
                $current_table_cards = $row['table_cards'];
                if ($current_table_cards != '-') {
                    $each_card = explode(' ', $current_table_cards);
                    echo "<td>";
                    foreach($each_card as $key=>$card) {
                        echo "<img class='cartas' src='http://appserver-01.alunos.di.fc.ul.pt/~asw010/Poker/cartas/" . $card . ".png'>" . "</img>";
                    }
                    echo "</td>";
                }
            }
        }
            $game_id = $row['id'];
            $current_p = $row['current_player'];
            $current_bet = $row['current_bet'];
            $current_pot = $row['current_pot'];
            $current_table_cards = $row['table_cards'];
            $ronda = $row['row'];
            $last = $row['last_to_raise'];
            echo "</tr>";
        }

    	} else {
        		echo "Error creating table: " . $conn->error;
    	}
    	echo "</table><br></div>";
    
    $sql = "SELECT player_id 
            FROM game_players 
            WHERE id = '$game_id' AND played = 'N' 
            GROUP BY player_id LIMIT 1";
        $result = mysqli_query($conn, $sql);
        while ($rows = mysqli_fetch_array($result, MYSQLI_ASSOC)) {
            $next_player = $rows['player_id'];
        }
    
    $sql = "SELECT owner FROM game_request WHERE id = '$game_id'";
    $result = mysqli_query($conn, $sql);
    while ($rows = mysqli_fetch_array($result, MYSQLI_ASSOC)) {
        $dono = $rows['owner'];
    }
    
    $lista_cartas = array ('AC', '2C', '3C', '4C', '5C', '6C', '7C', '8C', '9C', 'JC', 'QC', 'KC', 'AD', '2D', '3D', '4D', '5D', '6D', '7D', '8D', '9D', 'JD', 'QD', 'KD','AH', '2H', '3H', '4H', '5H', '6H', '7H', '8H', '9H', 'JH', 'QH', 'KH', 'AS', '2S', '3S', '4S', '5S', '6S', '7S', '8S', '9S', 'JS', 'QS', 'KS');
    $cartas_alea = array_rand($lista_cartas, 6);
    $carta1 = $lista_cartas[$cartas_alea[0]];
    $carta2 = $lista_cartas[$cartas_alea[1]];
    $carta3 = $lista_cartas[$cartas_alea[2]];
    $carta4 = $lista_cartas[$cartas_alea[3]];
    $carta5 = $lista_cartas[$cartas_alea[4]];
    $carta6 = $lista_cartas[$cartas_alea[5]];
    $resultado =  $carta1 . " " .  $carta2 . " " .  $carta3;
    $conjunto1 = $carta1 . " " . $carta2;
    $conjunto2 = $carta3 . " " . $carta4;
    $conjunto2 = $carta5 . " " . $carta6;
    
    $sql = "SELECT COUNT(played) FROM game_players WHERE played = 'Y' WHERE id = '$game_id'";
    $result = mysqli_query($conn, $sql);
    while ($rows = mysqli_fetch_array($result, MYSQLI_ASSOC)) {
        $played = $rows['COUNT(played)'];
    }
    
    $sql = "SELECT COUNT(player_id) FROM game_players WHERE id = '$game_id'";
    $result = mysqli_query($conn, $sql);
    while ($rows = mysqli_fetch_array($result, MYSQLI_ASSOC)) {
        $players = $rows['COUNT(player_id)'];
    }
    
    $sql = "SELECT game_status.id,started_at,player_cards,table_cards,current_player,current_bet,current_pot,row,last_to_raise,max_players FROM game_request,game_status,game_players WHERE game_request.id = game_status.id AND game_players.player_id = '$id' AND game_players.id = game_status.id ORDER BY id DESC LIMIT 1";
    $connect = $conn->query($sql);
    if ($connect == TRUE) {
        while($row = mysqli_fetch_array($connect,MYSQLI_ASSOC)){
            $max_players = $row['max_players'];
        }

    } else {
        echo $conn->error;
    }
    
    echo "<div id='info'></div>";
    
    if ($players == 2 && $players == $max_players) {
        if ($played == $players && $ronda >= $players && $ronda !=$players+6){
            if ($current_table_cards == '-') {
                $sql = "UPDATE game_status SET table_cards='$resultado' WHERE table_cards='$current_table_cards' AND id='$game_id'";
                $connect = $conn->query($sql);
                $sql = "UPDATE game_players SET played='N' WHERE played='Y'";
                $connect = $conn->query($sql);
            }else {
                $somar_cartas = $current_table_cards . " " .  $carta2;
                $sql = "UPDATE game_status SET table_cards='$somar_cartas' WHERE table_cards='$current_table_cards' AND id='$game_id'";
                $connect = $conn->query($sql);
                $sql = "UPDATE game_players SET played='N' WHERE played='Y'";
                $connect = $conn->query($sql);
            }
        }
    }elseif ($players == 3 && $players == $max_players) {
        if ($played == $players && $ronda >= $players && $ronda !=$players+9){
            if ($current_table_cards == '-') {
                $sql = "UPDATE game_status SET table_cards='$resultado' WHERE table_cards='$current_table_cards' AND id='$game_id'";
                $connect = $conn->query($sql);
                $sql = "UPDATE game_players SET played='N' WHERE played='Y'";
                $connect = $conn->query($sql);
            }else {
                $somar_cartas = $current_table_cards . " " .  $carta2;
                $sql = "UPDATE game_status SET table_cards='$somar_cartas' WHERE table_cards='$current_table_cards' AND id='$game_id'";
                $connect = $conn->query($sql);
                $sql = "UPDATE game_players SET played='N' WHERE played='Y'";
                $connect = $conn->query($sql);
            }
        }
    }

    if ($players == 2 && $players == $max_players) {
        if ($played == $players && $ronda == $players+6) {
            $sql = "SELECT player_id,player_cards FROM game_players WHERE id='$game_id'";
            $result = mysqli_query($conn, $sql);
            while ($rows = mysqli_fetch_array($result, MYSQLI_ASSOC)) {
                echo "<p style=color:white;text-align:center;font-family:Sansita;>";
                echo "Cartas do jogador " . $rows['player_id'] . ": " . $rows['player_cards'] . "<br>";
                echo "</p>";
                echo "<script>document.getElementById('opcoes').style.display='none';document.getElementById('info').style.display='none';</script>";
            }
        }
    }elseif ($players == 3 && $players == $max_players) {
        if ($played == $players && $ronda == $players+9) {
            $sql = "SELECT player_id,player_cards FROM game_players WHERE id='$game_id'";
            $result = mysqli_query($conn, $sql);
            while ($rows = mysqli_fetch_array($result, MYSQLI_ASSOC)) {
                echo "<p style=color:white;text-align:center;font-family:Sansita;>";
                echo "Cartas do jogador " . $rows['player_id'] . ": " . $rows['player_cards'] . "<br>";
                echo "</p>";
                echo "<script>document.getElementById('opcoes').style.display='none';document.getElementById('info').style.display='none';</script>";
            }
            $end = date("Y-m-d H:i:s");
            $sql = "UPDATE game_status SET ended_at='$end' WHERE id='$game_id'";
            $connect = $conn->query($sql);
        }
    }
    
    //buscar id de cada jogador que entrou no jogo, ainda não está em uso       [Não apagar]
    $sql = "SELECT player_id FROM game_players WHERE id = '$game_id'";
    $each_player_id = array();    
    $result = mysqli_query($conn, $sql);
    while ($rows = mysqli_fetch_array($result, MYSQLI_ASSOC)) {
        array_push($each_player_id, $rows['player_id']);
    }
    
    if (isset($_POST ['desistir'])) {
        
        // marcar que user desistiu
        $sql = "UPDATE game_players SET gave_up='Y',played='Y' WHERE player_id='$id' AND id='$game_id'";
        $connect = $conn->query($sql);
        
        $sql = "SELECT first_bet FROM game_request WHERE id = '$game_id'";
        $result = mysqli_query($conn, $sql);
        while ($rows = mysqli_fetch_array($result, MYSQLI_ASSOC)) {
            $aposta_minima = $rows['first_bet'];
        }
        
        if ($players == 2 && $players == $max_players) {
            $sql = "SELECT player_id 
                    FROM game_players,game_status
                    WHERE game_players.id = '$game_id' AND game_status.id = game_players.id";
            $result = mysqli_query($conn, $sql);
            while ($rows = mysqli_fetch_array($result, MYSQLI_ASSOC)) {
                $players_ids = $rows['player_id'];
                $array_ids[] = $players_ids;
            }
            $player1 = $array_ids[0];
            $player2 = $array_ids[1];

            // buscar username dos jogadores
            $sql = "SELECT username FROM users WHERE id='$player1'";
            $result = mysqli_query($conn, $sql);
            while ($rows = mysqli_fetch_array($result, MYSQLI_ASSOC)) {
                $player1_name = $rows['username'];
            }

            $sql = "SELECT username FROM users WHERE id='$player2'";
            $result = mysqli_query($conn, $sql);
            while ($rows = mysqli_fetch_array($result, MYSQLI_ASSOC)) {
                $player2_name = $rows['username'];
            }
                // buscar cartas dos jogadores
            $sql = "SELECT player_cards 
                            FROM game_players, game_status
                            WHERE game_players.id = game_status.id AND game_status.id = '$game_id' AND game_players.player_id = '$player1'";
            $result = mysqli_query($conn, $sql);
            while ($rows = mysqli_fetch_array($result, MYSQLI_ASSOC)) {
                $cartas_jogador1 = $rows['player_cards'];
            }

            $sql = "SELECT player_cards 
                            FROM game_players, game_status
                            WHERE game_players.id = game_status.id AND game_status.id = '$game_id' AND game_players.player_id = '$player2'";
            $result = mysqli_query($conn, $sql);
            while ($rows = mysqli_fetch_array($result, MYSQLI_ASSOC)) {
                $cartas_jogador2 = $rows['player_cards'];
            }

            $sql = "SELECT player_id,COUNT(gave_up) FROM game_players WHERE id = '$game_id' AND gave_up = 'N'";
            $result = mysqli_query($conn, $sql);
            while ($rows = mysqli_fetch_array($result, MYSQLI_ASSOC)) {
                $num_still_play = $rows['COUNT(gave_up)'];
                $gets_prize = $rows['player_id'];
            }

            $sql = "SELECT username,credits FROM game_players,users WHERE player_id = '$gets_prize' AND game_players.id = '$game_id' AND users.id = '$gets_prize'";
            $result = mysqli_query($conn, $sql);
            while ($rows = mysqli_fetch_array($result, MYSQLI_ASSOC)) {
                $winner_name = $rows['username'];
                $winner_credits = $rows['credits'];
            }

            $sql = "SELECT wins,losses FROM users WHERE id='$player1'";
            $result = mysqli_query($conn, $sql);
            while ($rows = mysqli_fetch_array($result, MYSQLI_ASSOC)) {
                $player1_wins = $rows['wins'];
                $player1_losses = $rows['losses'];
            }

            $sql = "SELECT wins,losses FROM users WHERE id='$player2'";
            $result = mysqli_query($conn, $sql);
            while ($rows = mysqli_fetch_array($result, MYSQLI_ASSOC)) {
                $player2_wins = $rows['wins'];
                $player2_losses = $rows['losses'];
            }

            // caso só um jogador ainda não desistiu, recebe premio e começa nova ronda
            if ($num_still_play == 1 && $max_players == $players) {
                $total = $winner_credits + $current_pot;
                $alerta = "Fim da ronda\\n\\nCartas do jogador $player1_name : $cartas_jogador1\\nCartas do jogador $player2_name : $cartas_jogador2\\nCartas na mesa: $current_table_cards\\n\\nVencedor: $winner_name\\nPrémio: $current_pot €";

                echo '<script type="text/javascript">
                    alert("'.$alerta.'");</script>';

                sleep(1);

                if ($id == $player1) {
                    $player1_losses++;
                    $player2_wins++;
                    $sql = "UPDATE users SET losses='$player1_losses' WHERE id='$player1'";
                    $connect = $conn->query($sql);
                    $sql = "UPDATE users SET wins='$player2_wins' WHERE id='$player2'";
                    $connect = $conn->query($sql);
                }else if ($id == $player2) {
                    $player1_wins++;
                    $player2_losses++;
                    $sql = "UPDATE users SET wins='$player1_wins' WHERE id='$player1'";
                    $connect = $conn->query($sql);
                    $sql = "UPDATE users SET losses='$player2_losses' WHERE id='$player2'";
                    $connect = $conn->query($sql);
                }

                $sql = "UPDATE users SET credits='$total' WHERE id='$gets_prize'";
                $connect = $conn->query($sql);

                $sql = "UPDATE game_players SET played='N',gave_up= 'N' WHERE id='$game_id'";
                $connect = $conn->query($sql);

                $sql = "UPDATE game_players SET player_cards='$conjunto1',played='N',player_bet='0' WHERE id='$game_id' and player_id='$player1'";
                $connect = $conn->query($sql);

                $sql = "UPDATE game_players SET player_cards='$conjunto2',played='N',player_bet='0' WHERE id='$game_id' and player_id='$player2'";
                $connect = $conn->query($sql);

                $sql = "UPDATE game_status SET row='0',table_cards='-',current_bet='$aposta_minima',current_player='$dono',current_pot='0' WHERE id='$game_id'";
                $connect = $conn->query($sql);
            }
            
        }if ($players == 3 && $players == $max_players) {
            $sql = "SELECT player_id 
                    FROM game_players,game_status
                    WHERE game_players.id = '$game_id' AND game_status.id = game_players.id";
            $result = mysqli_query($conn, $sql);
            while ($rows = mysqli_fetch_array($result, MYSQLI_ASSOC)) {
                $players_ids = $rows['player_id'];
                $array_ids[] = $players_ids;
            }
            $player1 = $array_ids[0];
            $player2 = $array_ids[1];
            $player3 = $array_ids[2];

            // buscar username dos jogadores
            $sql = "SELECT username FROM users WHERE id='$player1'";
            $result = mysqli_query($conn, $sql);
            while ($rows = mysqli_fetch_array($result, MYSQLI_ASSOC)) {
                $player1_name = $rows['username'];
            }

            $sql = "SELECT username FROM users WHERE id='$player2'";
            $result = mysqli_query($conn, $sql);
            while ($rows = mysqli_fetch_array($result, MYSQLI_ASSOC)) {
                $player2_name = $rows['username'];
            }
            
            $sql = "SELECT username FROM users WHERE id='$player3'";
            $result = mysqli_query($conn, $sql);
            while ($rows = mysqli_fetch_array($result, MYSQLI_ASSOC)) {
                $player3_name = $rows['username'];
            }
                // buscar cartas dos jogadores
            $sql = "SELECT player_cards 
                            FROM game_players, game_status
                            WHERE game_players.id = game_status.id AND game_status.id = '$game_id' AND game_players.player_id = '$player1'";
            $result = mysqli_query($conn, $sql);
            while ($rows = mysqli_fetch_array($result, MYSQLI_ASSOC)) {
                $cartas_jogador1 = $rows['player_cards'];
            }

            $sql = "SELECT player_cards 
                            FROM game_players, game_status
                            WHERE game_players.id = game_status.id AND game_status.id = '$game_id' AND game_players.player_id = '$player2'";
            $result = mysqli_query($conn, $sql);
            while ($rows = mysqli_fetch_array($result, MYSQLI_ASSOC)) {
                $cartas_jogador2 = $rows['player_cards'];
            }
            
            $sql = "SELECT player_cards 
                            FROM game_players, game_status
                            WHERE game_players.id = game_status.id AND game_status.id = '$game_id' AND game_players.player_id = '$player3'";
            $result = mysqli_query($conn, $sql);
            while ($rows = mysqli_fetch_array($result, MYSQLI_ASSOC)) {
                $cartas_jogador3 = $rows['player_cards'];
            }

            // marcar que user desistiu
            $sql = "UPDATE game_players SET gave_up='Y' WHERE player_id='$id' AND id='$game_id'";
            $connect = $conn->query($sql);

            $sql = "SELECT player_id,COUNT(gave_up) FROM game_players WHERE id = '$game_id' AND gave_up = 'N'";
            $result = mysqli_query($conn, $sql);
            while ($rows = mysqli_fetch_array($result, MYSQLI_ASSOC)) {
                $num_still_play = $rows['COUNT(gave_up)'];
                $gets_prize = $rows['player_id'];
            }

            $sql = "SELECT username,credits FROM game_players,users WHERE player_id = '$gets_prize' AND game_players.id = '$game_id' AND users.id = '$gets_prize'";
            $result = mysqli_query($conn, $sql);
            while ($rows = mysqli_fetch_array($result, MYSQLI_ASSOC)) {
                $winner_name = $rows['username'];
                $winner_credits = $rows['credits'];
            }

            $sql = "SELECT wins,losses FROM users WHERE id='$player1'";
            $result = mysqli_query($conn, $sql);
            while ($rows = mysqli_fetch_array($result, MYSQLI_ASSOC)) {
                $player1_wins = $rows['wins'];
                $player1_losses = $rows['losses'];
            }

            $sql = "SELECT wins,losses FROM users WHERE id='$player2'";
            $result = mysqli_query($conn, $sql);
            while ($rows = mysqli_fetch_array($result, MYSQLI_ASSOC)) {
                $player2_wins = $rows['wins'];
                $player2_losses = $rows['losses'];
            }
            
            $sql = "SELECT wins,losses FROM users WHERE id='$player3'";
            $result = mysqli_query($conn, $sql);
            while ($rows = mysqli_fetch_array($result, MYSQLI_ASSOC)) {
                $player3_wins = $rows['wins'];
                $player3_losses = $rows['losses'];
            }

            // caso só um jogador ainda não desistiu, recebe premio e começa nova ronda
            if ($num_still_play == 1 && $max_players == $players) {
                $total = $winner_credits + $current_pot;
                $alerta = "Fim da ronda\\n\\nCartas do jogador $player1_name : $cartas_jogador1\\nCartas do jogador $player2_name : $cartas_jogador2\\nCartas do jogador $player3_name : $cartas_jogador3\\nCartas na mesa: $current_table_cards\\n\\nVencedor: $winner_name\\nPrémio: $current_pot €";

                echo '<script type="text/javascript">
                    alert("'.$alerta.'");</script>';

                sleep(1);

                if ($id == $player1) {
                    $player1_losses++;
                    $sql = "UPDATE users SET losses='$player1_losses' WHERE id='$player1'";
                    $connect = $conn->query($sql);
                    if ($gets_prize == $player2) {
                        $sql = "UPDATE users SET wins='$player2_wins' WHERE id='$player2'";
                        $connect = $conn->query($sql);
                        $player3_losses++;
                        $sql = "UPDATE users SET losses='$player3_losses' WHERE id='$player3'";
                        $connect = $conn->query($sql);
                    }else if ($gets_prize == $player3) {
                        $sql = "UPDATE users SET losses='$player2_losses' WHERE id='$player2'";
                        $connect = $conn->query($sql);
                        $player3_wins++;
                        $sql = "UPDATE users SET wins='$player3_wins' WHERE id='$player3'";
                        $connect = $conn->query($sql);
                    }
                }else if ($id == $player2) {
                    $player2_losses++;
                    $sql = "UPDATE users SET losses='$player2_losses' WHERE id='$player2'";
                    $connect = $conn->query($sql);
                    if ($gets_prize = $player1) {
                        $sql = "UPDATE users SET wins='$player1_wins' WHERE id='$player1'";
                        $connect = $conn->query($sql);
                        $sql = "UPDATE users SET losses='$player3_losses' WHERE id='$player3'";
                        $connect = $conn->query($sql);
                    }else if ($gets_prize == $player3) {
                        $sql = "UPDATE users SET losses='$player1_losses' WHERE id='$player1'";
                        $connect = $conn->query($sql);
                        $sql = "UPDATE users SET wins='$player3_wins' WHERE id='$player3'";
                        $connect = $conn->query($sql);
                    }
                }else if ($id == $player3) {
                    $player3_losses++;
                    $sql = "UPDATE users SET losses='$player3_losses' WHERE id='$player3'";
                    $connect = $conn->query($sql);
                    if ($gets_prize = $player1) {
                        $sql = "UPDATE users SET wins='$player1_wins' WHERE id='$player1'";
                        $connect = $conn->query($sql);
                        $sql = "UPDATE users SET losses='$player2_losses' WHERE id='$player2'";
                        $connect = $conn->query($sql);
                    }else if ($gets_prize == $player2) {
                        $sql = "UPDATE users SET losses='$player1_losses' WHERE id='$player1'";
                        $connect = $conn->query($sql);
                        $sql = "UPDATE users SET wins='$player2_wins' WHERE id='$player2'";
                        $connect = $conn->query($sql);
                    }
                }

                $sql = "UPDATE users SET credits='$total' WHERE id='$gets_prize'";
                $connect = $conn->query($sql);

                $sql = "UPDATE game_players SET played='N',gave_up= 'N' WHERE id='$game_id'";
                $connect = $conn->query($sql);

                $sql = "UPDATE game_players SET player_cards='$conjunto1',played='N',player_bet='0' WHERE id='$game_id' and player_id='$player1'";
                $connect = $conn->query($sql);

                $sql = "UPDATE game_players SET player_cards='$conjunto2',played='N',player_bet='0' WHERE id='$game_id' and player_id='$player2'";
                $connect = $conn->query($sql);
                
                $sql = "UPDATE game_players SET player_cards='$conjunto3',played='N',player_bet='0' WHERE id='$game_id' and player_id='$player3'";
                $connect = $conn->query($sql);

                $sql = "UPDATE game_status SET row='0',table_cards='-',current_bet='$aposta_minima',current_player='$dono',current_pot='0' WHERE id='$game_id'";
                $connect = $conn->query($sql);
            }
        }
    }
    
    if (isset($_POST ['cobrir'])) {
        $sql = "UPDATE game_players SET played='Y',player_bet=player_bet+'$current_bet' WHERE played='N' AND player_id='$id'";
        $connect = $conn->query($sql);
        $sql = "UPDATE game_status SET current_pot='$current_bet' + '$current_pot', row='$ronda'+1, last_to_raise='$id' WHERE current_pot='$current_pot' AND row='$ronda' AND id='$game_id'";
        $connect = $conn->query($sql);
        if ($connect == TRUE) {
            $sql = "SELECT player_id 
            FROM game_players 
            WHERE id = '$game_id' AND played = 'N' 
            GROUP BY player_id LIMIT 1";
        $result = mysqli_query($conn, $sql);
        while ($rows = mysqli_fetch_array($result, MYSQLI_ASSOC)) {
            $next_player = $rows['player_id'];
        }
            $sql = "UPDATE game_status SET current_player='$next_player' WHERE id='$game_id'";
            $connect = $conn->query($sql);
            $sql = "UPDATE users SET credits='$credits' - '$current_bet' WHERE credits='$credits' AND id='$id'";
            $connect = $conn->query($sql);
            if ($connect == TRUE) {
            }else{
                echo "Fazer update dos creditos deu erro";
            }
        }else{
            echo "Determinar proximo jogador deu erro";
        }
    }
    
    if (isset($_POST ['aumentar'])) {
        $valor = $_POST ['novaAposta'];
        $sql = "UPDATE game_status SET current_pot='$valor' + '$current_pot', row='$ronda'+1, last_to_raise='$id' WHERE current_pot='$current_pot' AND row='$ronda' AND id='$game_id'";
        $connect = $conn->query($sql);
        $sql = "UPDATE game_players SET played='Y',player_bet=player_bet+'$valor' WHERE played='N' AND player_id='$id'";
        $connect = $conn->query($sql);
        $sql = "UPDATE game_status SET current_bet='$valor',last_to_raise='$id' WHERE current_bet='$current_bet' AND id='$game_id'";
        $connect = $conn->query($sql);
        if ($connect == TRUE) {
            $sql = "SELECT player_id 
            FROM game_players 
            WHERE id = '$game_id' AND played = 'N' 
            GROUP BY player_id LIMIT 1";
        $result = mysqli_query($conn, $sql);
        while ($rows = mysqli_fetch_array($result, MYSQLI_ASSOC)) {
            $next_player = $rows['player_id'];
        }
            $sql = "UPDATE game_status SET current_player='$next_player' WHERE id='$game_id'";
            $connect = $conn->query($sql);
            $sql = "UPDATE users SET credits='$credits' - '$valor' WHERE credits='$credits' AND id='$id'";
            $connect = $conn->query($sql);
            if ($connect == TRUE) {
            }else{
                echo "Fazer update do proximo jogador deu erro";
            }
        }else{
            echo "<p style=color:white;text-align:center;font-family:Sansita;>Erro ao aumentar aposta</p>";
        }
    }
    

    $_SESSION['winner'] = $_GET["winner"];
    $_SESSION['rank'] = $_GET["rank"];;
    
    $conn->close();
    ?>
    



</body>

</html>