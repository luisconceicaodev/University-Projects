<?php
    $dbhost = "appserver-01.alunos.di.fc.ul.pt";
  	$dbuser = "asw010";
  	$dbpass = "grupoCIL10";
  	$dbname = "asw010";

  	$conn = mysqli_connect($dbhost, $dbuser, $dbpass, $dbname);
  	if ($conn->connect_error) {
  		die("Database connection FAILED:". $conn->connect_error);
    }
    session_start();
    if (isset($_SESSION['loggedin']) && $_SESSION['loggedin'] == true) {
        $nome = $_SESSION['username'];
        $id = $_SESSION['user_id'];
    }

    $sql = "SELECT credits FROM users WHERE id = '$id'";
    $result = mysqli_query($conn, $sql);
        while ($rows = mysqli_fetch_array($result, MYSQLI_ASSOC)) {
            $credits = $rows['credits'];
    }

    $sql = "SELECT row FROM game_status,game_request WHERE game_status.id = game_request.id"; // definir jogadores
    $result = mysqli_query($conn, $sql);
        while ($rows = mysqli_fetch_array($result, MYSQLI_ASSOC)) {
            $ronda = $rows['row'];
    }
    
    $sql = "SELECT game_status.id,started_at,player_cards,table_cards,current_player,current_bet,current_pot,row,last_to_raise FROM game_request,game_status,game_players WHERE game_request.id = game_status.id AND game_players.player_id = '$id' AND game_players.id = game_status.id ORDER BY id DESC LIMIT 1";
    $connect = $conn->query($sql);
    if ($connect == TRUE) {
        echo "<div id='tabjogo'>
        <img id='table_img' src='mesa.png'>
        <table id='viewgame' class='jogo'>
        <tr>
        <th>" . "Id do Jogo" . "</th>
          <th>" . "Início" . "</th>" .
          "<th>" . "Jogador atual" ."</th>" .
          "<th>" . "Aposta atual" . "</th>" .
          "<th>" . "Current pot" . "</th>" .
          "<th>" . "Ronda" . "</th>" .
          "<th>" . "Ultimo a jogar" . "</th>";
        while($row = mysqli_fetch_array($connect,MYSQLI_ASSOC)){
            echo "<tr>";
        foreach ($row as $chave => $valor){
            if ($chave != 'table_cards' && $chave != 'player_cards') {
                echo "<td>" . $valor . "</td>";
            }elseif ($chave == 'table_cards') {
                $current_table_cards = $row['table_cards'];
                if ($current_table_cards != '-') {
                    $each_card = explode(' ', $current_table_cards);
                    echo "<div class='div_m_cartas'>";
                    echo "<p style=color:white;font-family:Sansita;>Cartas na mesa</p>";
                    foreach($each_card as $key=>$card) {
                        echo "<img class='cartas' src='http://appserver-01.alunos.di.fc.ul.pt/~asw010/Entrega_2/cartas/" . $card . ".png'>";
                    }
                }
                echo "</div>";
            }else if ($chave == 'player_cards') {
                $current_cards = $row['player_cards'];
                $each_player_card = explode(' ', $current_cards);
                echo "<div class='div_j_cartas'>";
                echo "<p style=color:white;text-align:left;font-family:Sansita;>As suas cartas</p>";
                foreach($each_player_card as $key=>$player_card) {
                    echo "<img id='j_cartas' src='http://appserver-01.alunos.di.fc.ul.pt/~asw010/Entrega_2/cartas/" . $player_card . ".png'>";
                    echo "<br>";
                }
                echo "</div>";
            }
        }
            $game_id = $row['id'];
            $current_p = $row['current_player'];
            $current_bet = $row['current_bet'];
            $current_pot = $row['current_pot'];
            $current_table_cards = $row['table_cards'];
            $ronda = $row['row'];
            $last = $row['last_to_raise'];
            $max_players = $row['max_players'];
            $started_at = $row['started_at'];
            echo "</tr>";
        }

    	} else {
        		echo "Error creating table: " . $conn->error;
    	}
    	echo "</table></div>";

    $sql = "SELECT player_id,COUNT(gave_up) FROM game_players WHERE id = '$game_id' AND gave_up = 'N'";
    $result = mysqli_query($conn, $sql);
    while ($rows = mysqli_fetch_array($result, MYSQLI_ASSOC)) {
            $num_still_play = $rows['COUNT(gave_up)'];
            $gets_prize = $rows['player_id'];
    }

    // buscar id de cada jogador
    $sql = "SELECT player_id 
                FROM game_players,game_status
                WHERE game_players.id = '$game_id' AND game_status.id = game_players.id";
    $result = mysqli_query($conn, $sql);
    while ($rows = mysqli_fetch_array($result, MYSQLI_ASSOC)) {
        $players_ids = $rows['player_id'];
        $array_ids[] = $players_ids;
    }
    $player1 = $array_ids[0];
    $player2 = $array_ids[1];

    // buscar username dos jogadores
    $sql = "SELECT username FROM users WHERE id='$player1'";
    $result = mysqli_query($conn, $sql);
    while ($rows = mysqli_fetch_array($result, MYSQLI_ASSOC)) {
        $player1_name = $rows['username'];
    }

    $sql = "SELECT username FROM users WHERE id='$player2'";
    $result = mysqli_query($conn, $sql);
    while ($rows = mysqli_fetch_array($result, MYSQLI_ASSOC)) {
        $player2_name = $rows['username'];
    }

    // buscar apostas de cada jogador
    $sql = "SELECT player_bet FROM game_players WHERE player_id='$player1'";
    $result = mysqli_query($conn, $sql);
    while ($rows = mysqli_fetch_array($result, MYSQLI_ASSOC)) {
        $player1_bet = $rows['player_bet'];
    }

    $sql = "SELECT player_bet FROM game_players WHERE player_id='$player2'";
    $result = mysqli_query($conn, $sql);
    while ($rows = mysqli_fetch_array($result, MYSQLI_ASSOC)) {
        $player2_bet = $rows['player_bet'];
    }

    $sql = "SELECT credits FROM users WHERE id = '$player1'";
        $result = mysqli_query($conn, $sql);
        while ($rows = mysqli_fetch_array($result, MYSQLI_ASSOC)) {
            $player1_credits = $rows['credits'];
    }
                
    $sql = "SELECT credits FROM users WHERE id = '$player2'";
        $result = mysqli_query($conn, $sql);
        while ($rows = mysqli_fetch_array($result, MYSQLI_ASSOC)) {
            $player2_credits = $rows['credits'];
    }

    $sql = "SELECT game_status.id,started_at,player_cards,table_cards,current_player,current_bet,current_pot,row,last_to_raise,max_players FROM game_request,game_status,game_players WHERE game_request.id = game_status.id AND game_players.player_id = '$id' AND game_players.id = game_status.id ORDER BY id DESC LIMIT 1";
    $connect = $conn->query($sql);
    if ($connect == TRUE) {
        while($row = mysqli_fetch_array($connect,MYSQLI_ASSOC)){
            $max_players = $row['max_players'];
        }

    } else {
        echo $conn->error;
    }

    $sql = "SELECT owner FROM game_request WHERE id = '$game_id'";
    $result = mysqli_query($conn, $sql);
    while ($rows = mysqli_fetch_array($result, MYSQLI_ASSOC)) {
        $dono = $rows['owner'];
    }

    $sql = "SELECT first_bet FROM game_request WHERE id = '$game_id'";
    $result = mysqli_query($conn, $sql);
    while ($rows = mysqli_fetch_array($result, MYSQLI_ASSOC)) {
        $aposta_minima = $rows['first_bet'];
    }

    $sql = "SELECT COUNT(played) FROM game_players WHERE id = '$game_id' AND played = 'Y'";
    $result = mysqli_query($conn, $sql);
    while ($rows = mysqli_fetch_array($result, MYSQLI_ASSOC)) {
        $played = $rows['COUNT(played)'];
    }
    
    $sql = "SELECT COUNT(player_id) FROM game_players WHERE id = '$game_id'";
    $result = mysqli_query($conn, $sql);
    while ($rows = mysqli_fetch_array($result, MYSQLI_ASSOC)) {
        $players = $rows['COUNT(player_id)'];
    }

    if ($num_still_play == 1 && $gets_prize == $id && $players == $max_players) {
        echo "<script>alert('Os outros jogadores desistiram resultando na sua vitória nesta ronda!\\nPrémio: $current_pot €' );</script>";
    }

    date_default_timezone_set('Europe/London');
    $current_time = date('Y-m-d H:i:s', time());

    $start_date = new DateTime($started_at);
    $since_start = $start_date->diff(new DateTime($current_time));

    if ($players == $max_players) {
        echo "<div id='time'>";
        echo "Tempo de jogo: <br>";
        echo $since_start->h.' hora(s)<br>';
        echo $since_start->i.' minuto(s)<br>';
        echo $since_start->s.' segundo(s)<br>';
        echo "</div>";
    }elseif ($players < $max_players) {
        echo "<div id='time'>";
        echo "Tempo de espera: <br>";
        echo $since_start->h.' hora(s)<br>';
        echo $since_start->i.' minuto(s)<br>';
        echo $since_start->s.' segundo(s)<br>';
        echo "</div>";
    }

    $var_horas = $since_start->h.' hora(s)<br>';

    $sql = "SELECT username FROM users,game_status WHERE game_status.id = '$game_id' AND game_status.current_player = '$current_p' AND '$current_p' = users.id";
    $result = mysqli_query($conn, $sql);
        while ($rows = mysqli_fetch_array($result, MYSQLI_ASSOC)) {
            $jogador_atual = $rows['username'];
    }

    $sql = "SELECT player_id 
            FROM game_players,game_status
            WHERE game_players.id = '$game_id' AND player_id != game_status.current_player AND game_status.id=game_players.id AND game_players.gave_up = 'N'
            GROUP BY player_id LIMIT 1
            ";
        $result = mysqli_query($conn, $sql);
        while ($rows = mysqli_fetch_array($result, MYSQLI_ASSOC)) {
            $next_player = $rows['player_id'];
        }
    echo "<p id='titulo' style=display:none;>".$next_player."</p>";

    $sql = "SELECT username FROM users,game_status,game_players WHERE game_status.id = '$game_id' AND game_players.id = game_status.id AND game_players.player_id = '$next_player' AND users.id = game_players.player_id";
    $result = mysqli_query($conn, $sql);
        while ($rows = mysqli_fetch_array($result, MYSQLI_ASSOC)) {
            $jogador_adversario = $rows['username'];
    }

    // se um jogador perder todos os creditos
    if ($player1_credits <= 0 || $player2_credits <= 0 && $max_players = $players && players == 2) {
        echo "<script>alert('Um dos jogadores ficou sem créditos.\\nGAME OVER');
        window.location.replace('Inicial.php');</script>;";
        
        $end = date("Y-m-d H:i:s");
        $sql = "UPDATE game_status SET ended_at='$end' WHERE id='$game_id'";
        $connect = $conn->query($sql);
    }

    

    if ($current_p != $id) {
        echo "<img src='user_n.png' id='gamer'></img>";
        echo "<img src='user_p.png' id='non_gamer'></img>";
        echo "<div class='adversario'>";
        echo "<p style=color:white;text-align:left;font-family:Sansita;>Jogador: ".$jogador_atual."</p>";
        echo "<img id='cartas_ad' src='adversario.png'>";
        echo "</div>";
    }elseif ($current_p == $id && $players == $max_players) {
        echo "<img src='user_p.png' id='gamer'></img>";
        echo "<img src='user_n.png' id='non_gamer'></img>";
        echo "<div class='adversario'>";
        echo "<p style=color:white;text-align:left;font-family:Sansita;>Jogador: ".$jogador_adversario."</p>";
        echo "<img id='cartas_ad' src='adversario.png'>";
        echo "</div>";
    }

    $lista_cartas = array ('AC', '2C', '3C', '4C', '5C', '6C', '7C', '8C', '9C', 'JC', 'QC', 'KC', 'AD', '2D', '3D', '4D', '5D', '6D', '7D', '8D', '9D', 'JD', 'QD', 'KD','AH', '2H', '3H', '4H', '5H', '6H', '7H', '8H', '9H', 'JH', 'QH', 'KH', 'AS', '2S', '3S', '4S', '5S', '6S', '7S', '8S', '9S', 'JS', 'QS', 'KS');

    $users_cards = "";
    
    // eliminar cartas que já foram dadas aos jogadores e já postas na mesa à array lista_cartas
    $sql = "SELECT player_cards 
                    FROM game_players, game_status
                    WHERE game_players.id = game_status.id AND game_status.id = '$game_id'";
    $result = mysqli_query($conn, $sql);
    while ($rows = mysqli_fetch_array($result, MYSQLI_ASSOC)) {
        $cartas_usadas = $rows['player_cards'];
        $users_cards .= " " . $cartas_usadas;
        $array_cards = explode(" ",$users_cards);
    }

    $sql = "SELECT table_cards 
                    FROM game_status
                    WHERE game_status.id = '$game_id'";
    $result = mysqli_query($conn, $sql);
    while ($rows = mysqli_fetch_array($result, MYSQLI_ASSOC)) {
        $cartas_usadas2 = $rows['table_cards'];
        $tb_cards .= " " . $cartas_usadas2;
        $array_cards_tb = explode(" ",$tb_cards);
    }
    
    foreach ($array_cards as &$value) {
        if(($key = array_search($value, $lista_cartas)) !== false) {
            unset($lista_cartas[$key]);
        }  
    }

    if ($cartas_usadas2 != "-") {
        foreach ($array_cards_tb as &$value) {
            if(($key = array_search($value, $lista_cartas)) !== false) {
                unset($lista_cartas[$key]);
            }  
        }
    }


    $cartas_alea = array_rand($lista_cartas, 6);
    $carta1 = $lista_cartas[$cartas_alea[0]];
    $carta2 = $lista_cartas[$cartas_alea[1]];
    $carta3 = $lista_cartas[$cartas_alea[2]];
    $carta4 = $lista_cartas[$cartas_alea[3]];
    $carta5 = $lista_cartas[$cartas_alea[4]];
    $carta6 = $lista_cartas[$cartas_alea[5]];
    $resultado =  $carta1 . " " .  $carta2 . " " .  $carta3;
    $conjunto1 = $carta1 . " " . $carta2;
    $conjunto2 = $carta3 . " " . $carta4;
    $conjunto3 = $carta5 . " " . $carta6;

    if ($players == 2 && $players == $max_players) {
        if ($played == $players && $ronda >= $players && $ronda !=$players+6){
            if ($current_table_cards == '-') {
                $sql = "UPDATE game_status SET table_cards='$resultado' WHERE table_cards='$current_table_cards' AND id='$game_id'";
                $connect = $conn->query($sql);
                $sql = "UPDATE game_players SET played='N' WHERE played='Y'";
                $connect = $conn->query($sql);
            }else {
                $somar_cartas = $current_table_cards . " " .  $carta2;
                $sql = "UPDATE game_status SET table_cards='$somar_cartas' WHERE table_cards='$current_table_cards' AND id='$game_id'";
                $connect = $conn->query($sql);
                $sql = "UPDATE game_players SET played='N' WHERE played='Y'";
                $connect = $conn->query($sql);
            }
        }
    }elseif ($players == 3 && $players == $max_players) {
        if ($played == $players && $ronda >= $players && $ronda !=$players+9){
            if ($current_table_cards == '-') {
                $sql = "UPDATE game_status SET table_cards='$resultado' WHERE table_cards='$current_table_cards' AND id='$game_id'";
                $connect = $conn->query($sql);
                $sql = "UPDATE game_players SET played='N' WHERE played='Y' AND gave_up != 'Y'";
                $connect = $conn->query($sql);
            }else {
                $somar_cartas = $current_table_cards . " " .  $carta2;
                $sql = "UPDATE game_status SET table_cards='$somar_cartas' WHERE table_cards='$current_table_cards' AND id='$game_id'";
                $connect = $conn->query($sql);
                $sql = "UPDATE game_players SET played='N' WHERE played='Y' AND gave_up != 'Y'";
                $connect = $conn->query($sql);
            }
        }
    }
    

    if ($players == 2) {
        
        if ($played == $players && $ronda == $players+6) {
            // buscar cartas do jogador 1
            $sql = "SELECT player_cards 
                        FROM game_players, game_status
                        WHERE game_players.id = game_status.id AND game_status.id = '$game_id' AND game_players.player_id = '$player1'";
            $result = mysqli_query($conn, $sql);
            while ($rows = mysqli_fetch_array($result, MYSQLI_ASSOC)) {
                $cartas_jogador1 = $rows['player_cards'];
            }

            // buscar cartas do jogador 2
            $sql = "SELECT player_cards 
                        FROM game_players, game_status
                        WHERE game_players.id = game_status.id AND game_status.id = '$game_id' AND game_players.player_id = '$player2'";
            $result = mysqli_query($conn, $sql);
            while ($rows = mysqli_fetch_array($result, MYSQLI_ASSOC)) {
                $cartas_jogador2 = $rows['player_cards'];
            }
            
            // determinar vitorias e perdas passadas de cada jogador
            $sql = "SELECT wins,losses FROM users WHERE id='$player1'";
            $result = mysqli_query($conn, $sql);
            while ($rows = mysqli_fetch_array($result, MYSQLI_ASSOC)) {
                $player1_wins = $rows['wins'];
                $player1_losses = $rows['losses'];
            }
                
            $sql = "SELECT wins,losses FROM users WHERE id='$player2'";
            $result = mysqli_query($conn, $sql);
            while ($rows = mysqli_fetch_array($result, MYSQLI_ASSOC)) {
                $player2_wins = $rows['wins'];
                $player2_losses = $rows['losses'];
            }
            
            // criar parte do url
            $url = $current_table_cards . " " . $cartas_jogador1 . "," . $current_table_cards . " " . $cartas_jogador2;
                     
            echo "<script>
            document.getElementById('estado').style.display = 'none';
            document.getElementById('time').style.display='none';
            </script>";
            
            $winner = $_SESSION['winner'];
            $rank = $_SESSION['rank'];
            
            // casos de um user ganhar
            if ($winner == '0' && $winner != null && strlen($winner) == 1) {
                $premio = $credits + $current_pot;
                $alerta = "Fim da ronda\\n\\nCartas do jogador $player1_name : $cartas_jogador1\\nCartas do jogador $player2_name : $cartas_jogador2\\nCartas na mesa: $current_table_cards\\n\\nVencedor: $player1_name\\nRank:$rank\\nPrémio: $current_pot €";
                
                echo '<script type="text/javascript">
                alert("'.$alerta.'");</script>';
                
                sleep(2);
                
                $player1_wins++;
                $player2_losses++;
                
                $sql = "UPDATE game_players SET player_cards='$conjunto1',played='N',player_bet='0',gave_up ='N' WHERE id='$game_id' and player_id='$player1'";
                $connect = $conn->query($sql);
                
                $sql = "UPDATE game_players SET player_cards='$conjunto2',played='N',player_bet='0',gave_up ='N' WHERE id='$game_id' and player_id='$player2'";
                $connect = $conn->query($sql);
                
                $sql = "UPDATE users SET credits='$premio',wins='$player1_wins' WHERE id='$player1'";
                $connect = $conn->query($sql);
                
                $sql = "UPDATE users SET losses='$player2_losses' WHERE id='$player2'";
                $connect = $conn->query($sql);
                
                $sql = "UPDATE game_status SET row='0',table_cards='-',current_bet='$aposta_minima',current_player='$dono',current_pot='0' WHERE id='$game_id'";
                $connect = $conn->query($sql);
            }else if ($winner == '1' && strlen($winner) == 1) {
                $premio = $credits + $current_pot;
                $alerta = "Fim da ronda\\n\\nCartas do jogador $player1_name : $cartas_jogador1\\nCartas do jogador $player2_name : $cartas_jogador2\\nCartas na mesa: $current_table_cards\\n\\nVencedor: $player2_name\\nRank:$rank\\nPrémio: $current_pot €";
                
                echo '<script type="text/javascript">
                alert("'.$alerta.'");</script>';
                
                sleep(2);
                
                $player1_losses++;
                $player2_wins++;
                
                $sql = "UPDATE game_players SET player_cards='$conjunto1',played='N',player_bet='0',gave_up ='N' WHERE id='$game_id' and player_id='$player1'";
                $connect = $conn->query($sql);
                
                $sql = "UPDATE game_players SET player_cards='$conjunto2',played='N',player_bet='0',gave_up ='N' WHERE id='$game_id' and player_id='$player2'";
                $connect = $conn->query($sql);
                
                $sql = "UPDATE users SET losses='$player1_losses' WHERE id='$player1'";
                $connect = $conn->query($sql);
                
                $sql = "UPDATE users SET wins='$player2_wins',credits='$premio' WHERE id='$player2'";
                $connect = $conn->query($sql);
                
                $sql = "UPDATE game_status SET row='0',table_cards='-',current_bet='$aposta_minima',current_player='$dono',current_pot='0' WHERE id='$game_id'";
                $connect = $conn->query($sql);
            }else if ($winner == '01' && strlen($winner) == 2) {
                $alerta = "Fim da ronda\\n\\nCartas do jogador $player1_name : $cartas_jogador1\\nCartas do jogador $player2_name : $cartas_jogador2\\nCartas na mesa: $current_table_cards\\n\\nOcorreu empate\\nRank:$rank\\n";
                
                echo '<script type="text/javascript">
                alert("'.$alerta.'");</script>';
                
                sleep(2);
                    
                $pot_div = $current_pot / 2;
                
                $player_total = $credits + $pot_div;
                
                $sql = "UPDATE game_players SET player_cards='$conjunto1',played='N',player_bet='0' WHERE id='$game_id' and player_id='$player1'";
                $connect = $conn->query($sql);
                
                $sql = "UPDATE game_players SET player_cards='$conjunto2',played='N',player_bet='0' WHERE id='$game_id' and player_id='$player2'";
                $connect = $conn->query($sql);
                
                $sql = "UPDATE users SET credits='$player_total' WHERE id='$id'";
                $connect = $conn->query($sql);
                
                $sql = "UPDATE game_status SET row='0',table_cards='-',current_bet='$aposta_minima',current_player='$dono',current_pot='0' WHERE id='$game_id'";
                $connect = $conn->query($sql);
            }
        }
        
    }elseif ($players == 3) {
        
        $sql = "SELECT player_id FROM game_players WHERE game_players.gave_up = 'N' AND id ='$game_id'";
            $result = mysqli_query($conn, $sql);
            while ($rows = mysqli_fetch_array($result, MYSQLI_ASSOC)) {
                $still_playing[] = $rows['player_id'];
            }
            $still1 = $still_playing[0];
            $still2 = $still_playing[1];
        
        $sql = "SELECT COUNT(player_id) FROM game_players WHERE game_players.gave_up = 'N' AND id ='$game_id'";
            $result = mysqli_query($conn, $sql);
            while ($rows = mysqli_fetch_array($result, MYSQLI_ASSOC)) {
                $notgiveup = $rows['COUNT(player_id)'];
            }
        
        
        if($notgiveup == '2') {
            if (($still1 == $player1 && $still2 == $player2) || ($still1 == $player2 && $still2 == $player1)) {
                $url = $current_table_cards . " " . $cartas_jogador1 . "," . $current_table_cards .  " " . $cartas_jogador2;
                $winner = $_SESSION['winner'];
                $rank = $_SESSION['rank'];
            }else if (($still1 == $player2 && $still2 == $player3) || ($still1 == $player3 && $still2 == $player2)) {
                $url = $current_table_cards . " " . $cartas_jogador2 . "," . $current_table_cards .  " " . $cartas_jogador3;
                $winner = $_SESSION['winner'];
                $rank = $_SESSION['rank'];
            }else if (($still1 == $player1 && $still2 == $player3) || ($still1 == $player3 && $still2 == $player1)) {
                $url = $current_table_cards . " " . $cartas_jogador1 . "," . $current_table_cards .  " " . $cartas_jogador3;
                $winner = $_SESSION['winner'];
                $rank = $_SESSION['rank'];
            }
        }
            
        
        $sql = "SELECT player_id,COUNT(gave_up) FROM game_players WHERE id = '$game_id' AND gave_up = 'N'";
            $result = mysqli_query($conn, $sql);
            while ($rows = mysqli_fetch_array($result, MYSQLI_ASSOC)) {
                    $num_still_play = $rows['COUNT(gave_up)'];
                    $gets_prize = $rows['player_id'];
            }

            // buscar id de cada jogador
            $sql = "SELECT player_id 
                        FROM game_players,game_status
                        WHERE game_players.id = '$game_id' AND game_status.id = game_players.id";
            $result = mysqli_query($conn, $sql);
            while ($rows = mysqli_fetch_array($result, MYSQLI_ASSOC)) {
                $players_ids = $rows['player_id'];
                $array_ids[] = $players_ids;
            }
            $player1 = $array_ids[0];
            $player2 = $array_ids[1];
            $player3 = $array_ids[2];

            // buscar username dos jogadores
            $sql = "SELECT username FROM users WHERE id='$player1'";
            $result = mysqli_query($conn, $sql);
            while ($rows = mysqli_fetch_array($result, MYSQLI_ASSOC)) {
                $player1_name = $rows['username'];
            }

            $sql = "SELECT username FROM users WHERE id='$player2'";
            $result = mysqli_query($conn, $sql);
            while ($rows = mysqli_fetch_array($result, MYSQLI_ASSOC)) {
                $player2_name = $rows['username'];
            }
            
            $sql = "SELECT username FROM users WHERE id='$player3'";
            $result = mysqli_query($conn, $sql);
            while ($rows = mysqli_fetch_array($result, MYSQLI_ASSOC)) {
                $player3_name = $rows['username'];
            }

            // buscar apostas de cada jogador
            $sql = "SELECT player_bet FROM game_players WHERE player_id='$player1'";
            $result = mysqli_query($conn, $sql);
            while ($rows = mysqli_fetch_array($result, MYSQLI_ASSOC)) {
                $player1_bet = $rows['player_bet'];
            }

            $sql = "SELECT player_bet FROM game_players WHERE player_id='$player2'";
            $result = mysqli_query($conn, $sql);
            while ($rows = mysqli_fetch_array($result, MYSQLI_ASSOC)) {
                $player2_bet = $rows['player_bet'];
            }
            
            $sql = "SELECT player_bet FROM game_players WHERE player_id='$player3'";
            $result = mysqli_query($conn, $sql);
            while ($rows = mysqli_fetch_array($result, MYSQLI_ASSOC)) {
                $player3_bet = $rows['player_bet'];
            }

            $sql = "SELECT credits FROM users WHERE id = '$player1'";
                $result = mysqli_query($conn, $sql);
                while ($rows = mysqli_fetch_array($result, MYSQLI_ASSOC)) {
                    $player1_credits = $rows['credits'];
            }

            $sql = "SELECT credits FROM users WHERE id = '$player2'";
                $result = mysqli_query($conn, $sql);
                while ($rows = mysqli_fetch_array($result, MYSQLI_ASSOC)) {
                    $player2_credits = $rows['credits'];
            }
            
            $sql = "SELECT credits FROM users WHERE id = '$player3'";
                $result = mysqli_query($conn, $sql);
                while ($rows = mysqli_fetch_array($result, MYSQLI_ASSOC)) {
                    $player3_credits = $rows['credits'];
            }
        
        // buscar cartas do jogador 1
            $sql = "SELECT player_cards 
                        FROM game_players, game_status
                        WHERE game_players.id = game_status.id AND game_status.id = '$game_id' AND game_players.player_id = '$player1'";
            $result = mysqli_query($conn, $sql);
            while ($rows = mysqli_fetch_array($result, MYSQLI_ASSOC)) {
                $cartas_jogador1 = $rows['player_cards'];
            }

            // buscar cartas do jogador 2
            $sql = "SELECT player_cards 
                        FROM game_players, game_status
                        WHERE game_players.id = game_status.id AND game_status.id = '$game_id' AND game_players.player_id = '$player2'";
            $result = mysqli_query($conn, $sql);
            while ($rows = mysqli_fetch_array($result, MYSQLI_ASSOC)) {
                $cartas_jogador2 = $rows['player_cards'];
            }
            
            $sql = "SELECT player_cards 
                        FROM game_players, game_status
                        WHERE game_players.id = game_status.id AND game_status.id = '$game_id' AND game_players.player_id = '$player3'";
            $result = mysqli_query($conn, $sql);
            while ($rows = mysqli_fetch_array($result, MYSQLI_ASSOC)) {
                $cartas_jogador3 = $rows['player_cards'];
            }
            
            // determinar vitorias e perdas passadas de cada jogador
            $sql = "SELECT wins,losses FROM users WHERE id='$player1'";
            $result = mysqli_query($conn, $sql);
            while ($rows = mysqli_fetch_array($result, MYSQLI_ASSOC)) {
                $player1_wins = $rows['wins'];
                $player1_losses = $rows['losses'];
            }
                
            $sql = "SELECT wins,losses FROM users WHERE id='$player2'";
            $result = mysqli_query($conn, $sql);
            while ($rows = mysqli_fetch_array($result, MYSQLI_ASSOC)) {
                $player2_wins = $rows['wins'];
                $player2_losses = $rows['losses'];
            }
            
            $sql = "SELECT wins,losses FROM users WHERE id='$player3'";
            $result = mysqli_query($conn, $sql);
            while ($rows = mysqli_fetch_array($result, MYSQLI_ASSOC)) {
                $player3_wins = $rows['wins'];
                $player3_losses = $rows['losses'];
            }
        
        if ($played == $players && $ronda == $players+9) {
            
            // criar parte do url
            $url = $current_table_cards . " " . $cartas_jogador1 . "," . $current_table_cards .  " " . $cartas_jogador2 . "," . $current_table_cards . " " . $cartas_jogador3;
            
            $winner = $_SESSION['winner'];
            $rank = $_SESSION['rank'];
            
            // casos de um user ganhar
            if ($winner == '0' && $winner != null && strlen($winner) == 1) {
                $premio = $credits + $current_pot;
                $alerta = "Fim da ronda\\n\\nCartas do jogador $player1_name : $cartas_jogador1\\nCartas do jogador $player2_name : $cartas_jogador2\\nCartas do jogador $player3_name : $cartas_jogador3\\nCartas na mesa: $current_table_cards\\n\\nVencedor: $player1_name\\nRank:$rank\\nPrémio: $current_pot €";
                
                echo '<script type="text/javascript">
                alert("'.$alerta.'");</script>';
                
                sleep(2);
                
                $player1_wins++;
                $player2_losses++;
                $player3_losses++;
                
                $sql = "UPDATE game_players SET player_cards='$conjunto1',played='N',player_bet='0',gave_up ='N' WHERE id='$game_id' and player_id='$player1'";
                $connect = $conn->query($sql);
                
                $sql = "UPDATE game_players SET player_cards='$conjunto2',played='N',player_bet='0',gave_up ='N' WHERE id='$game_id' and player_id='$player2'";
                $connect = $conn->query($sql);
                
                $sql = "UPDATE game_players SET player_cards='$conjunto3',played='N',player_bet='0',gave_up ='N' WHERE id='$game_id' and player_id='$player3'";
                $connect = $conn->query($sql);
                
                $sql = "UPDATE users SET credits='$premio',wins='$player1_wins' WHERE id='$player1'";
                $connect = $conn->query($sql);
                
                $sql = "UPDATE users SET losses='$player2_losses' WHERE id='$player2'";
                $connect = $conn->query($sql);
                
                $sql = "UPDATE users SET losses='$player3_losses' WHERE id='$player3'";
                $connect = $conn->query($sql);
                
                $sql = "UPDATE game_status SET row='0',table_cards='-',current_bet='$aposta_minima',current_player='$dono',current_pot='0' WHERE id='$game_id'";
                $connect = $conn->query($sql);
            }else if ($winner == '1' && strlen($winner) == 1) {
                $premio = $credits + $current_pot;
                $alerta = "Fim da ronda\\n\\nCartas do jogador $player1_name : $cartas_jogador1\\nCartas do jogador $player2_name : $cartas_jogador2\\nCartas do jogador $player3_name : $cartas_jogador3 \\nCartas na mesa: $current_table_cards\\n\\nVencedor: $player2_name\\nRank:$rank\\nPrémio: $current_pot €";
                
                echo '<script type="text/javascript">
                alert("'.$alerta.'");</script>';
                
                sleep(2);
                
                $player1_losses++;
                $player2_wins++;
                $player3_losses++;
                
                $sql = "UPDATE game_players SET player_cards='$conjunto1',played='N',player_bet='0',gave_up ='N' WHERE id='$game_id' and player_id='$player1'";
                $connect = $conn->query($sql);
                
                $sql = "UPDATE game_players SET player_cards='$conjunto2',played='N',player_bet='0',gave_up ='N' WHERE id='$game_id' and player_id='$player2'";
                $connect = $conn->query($sql);
                
                $sql = "UPDATE game_players SET player_cards='$conjunto3',played='N',player_bet='0',gave_up ='N' WHERE id='$game_id' and player_id='$player3'";
                $connect = $conn->query($sql);
                
                $sql = "UPDATE users SET losses='$player1_losses' WHERE id='$player1'";
                $connect = $conn->query($sql);
                
                $sql = "UPDATE users SET credits='$premio',wins='$player2_wins' WHERE id='$player2'";
                $connect = $conn->query($sql);
                
                $sql = "UPDATE users SET losses='$player3_losses' WHERE id='$player3'";
                $connect = $conn->query($sql);
                
                $sql = "UPDATE game_status SET row='0',table_cards='-',current_bet='$aposta_minima',current_player='$dono',current_pot='0' WHERE id='$game_id'";
                $connect = $conn->query($sql);
            }else if ($winner == '2' && strlen($winner) == 1) {
                $premio = $credits + $current_pot;
                $alerta = "Fim da ronda\\n\\nCartas do jogador $player1_name : $cartas_jogador1\\nCartas do jogador $player2_name : $cartas_jogador2\\nCartas do jogador $player3_name : $cartas_jogador3 \\nCartas na mesa: $current_table_cards\\n\\nVencedor: $player2_name\\nRank:$rank\\nPrémio: $current_pot €";
                
                echo '<script type="text/javascript">
                alert("'.$alerta.'");</script>';
                
                sleep(2);
                
                $player1_losses++;
                $player2_losses++;
                $player3_wins++;
                
                $sql = "UPDATE game_players SET player_cards='$conjunto1',played='N',player_bet='0',gave_up ='N' WHERE id='$game_id' and player_id='$player1'";
                $connect = $conn->query($sql);
                
                $sql = "UPDATE game_players SET player_cards='$conjunto2',played='N',player_bet='0',gave_up ='N' WHERE id='$game_id' and player_id='$player2'";
                $connect = $conn->query($sql);
                
                $sql = "UPDATE game_players SET player_cards='$conjunto3',played='N',player_bet='0',gave_up ='N' WHERE id='$game_id' and player_id='$player3'";
                $connect = $conn->query($sql);
                
                $sql = "UPDATE users SET losses='$player1_losses' WHERE id='$player1'";
                $connect = $conn->query($sql);
                
                $sql = "UPDATE users SET losses='$player2_losses' WHERE id='$player2'";
                $connect = $conn->query($sql);
                
                $sql = "UPDATE users SET credits='$premio',wins='$player3_wins' WHERE id='$player3'";
                $connect = $conn->query($sql);
                
                $sql = "UPDATE game_status SET row='0',table_cards='-',current_bet='$aposta_minima',current_player='$dono',current_pot='0' WHERE id='$game_id'";
                $connect = $conn->query($sql);
            }else if ($winner == '01' && strlen($winner) == 2) {
                $alerta = "Fim da ronda\\n\\nCartas do jogador $player1_name : $cartas_jogador1\\nCartas do jogador $player2_name : $cartas_jogador2\\nCartas do jogador $player3_name : $cartas_jogador3\\nCartas na mesa: $current_table_cards\\n\\nOcorreu empate\\nRank:$rank\\n";
                
                echo '<script type="text/javascript">
                alert("'.$alerta.'");</script>';
                
                sleep(2);
                    
                $pot_div = $current_pot / 2;
                
                $player_total = $credits + $pot_div;
                
                $sql = "UPDATE game_players SET player_cards='$conjunto1',played='N',player_bet='0',gave_up ='N' WHERE id='$game_id' and player_id='$player1'";
                $connect = $conn->query($sql);
                
                $sql = "UPDATE game_players SET player_cards='$conjunto2',played='N',player_bet='0',gave_up ='N' WHERE id='$game_id' and player_id='$player2'";
                $connect = $conn->query($sql);
                
                $sql = "UPDATE game_players SET player_cards='$conjunto3',played='N',player_bet='0',gave_up ='N' WHERE id='$game_id' and player_id='$player3'";
                $connect = $conn->query($sql);
                
                $sql = "UPDATE users SET credits='$player_total' WHERE id='$id'";
                $connect = $conn->query($sql);
                
                $sql = "UPDATE game_status SET row='0',table_cards='-',current_bet='$aposta_minima',current_player='$dono',current_pot='0' WHERE id='$game_id'";
                $connect = $conn->query($sql);
            }else if ($winner == '12' && strlen($winner) == 2) {
                $alerta = "Fim da ronda\\n\\nCartas do jogador $player1_name : $cartas_jogador1\\nCartas do jogador $player2_name : $cartas_jogador2\\nCartas do jogador $player3_name : $cartas_jogador3\\nCartas na mesa: $current_table_cards\\n\\nOcorreu empate\\nRank:$rank\\n";
                
                echo '<script type="text/javascript">
                alert("'.$alerta.'");</script>';
                
                sleep(2);
                    
                $pot_div = $current_pot / 2;
                
                $player_total = $credits + $pot_div;
                
                $sql = "UPDATE game_players SET player_cards='$conjunto1',played='N',player_bet='0',gave_up ='N' WHERE id='$game_id' and player_id='$player1'";
                $connect = $conn->query($sql);
                
                $sql = "UPDATE game_players SET player_cards='$conjunto2',played='N',player_bet='0',gave_up ='N' WHERE id='$game_id' and player_id='$player2'";
                $connect = $conn->query($sql);
                
                $sql = "UPDATE game_players SET player_cards='$conjunto3',played='N',player_bet='0',gave_up ='N' WHERE id='$game_id' and player_id='$player3'";
                $connect = $conn->query($sql);
                
                $sql = "UPDATE users SET credits='$player_total' WHERE id='$id'";
                $connect = $conn->query($sql);
                
                $sql = "UPDATE game_status SET row='0',table_cards='-',current_bet='$aposta_minima',current_player='$dono',current_pot='0' WHERE id='$game_id'";
                $connect = $conn->query($sql);
            }
            
        }
        if (($ronda == 9 || $ronda == 10 || $ronda == 11 || $ronda == 12) && $num_still_play == 2 && strlen($current_table_cards) == 14 && $played == $players) {            
            $premio = $credits + $current_pot;
            
            $alerta = "Fim da ronda\\n\\nCartas do jogador $player1_name : $cartas_jogador1\\nCartas do jogador $player2_name : $cartas_jogador2\\nCartas do jogador $player3_name : $cartas_jogador3\\nCartas na mesa: $current_table_cards\\n\\Vencedor : Não definido em caso de desistir um dos 3\\nRank:$rank\\n";
                
            echo '<script type="text/javascript">
                alert("'.$alerta.'");</script>';
            
            if ($winner == '0' && strlen($winner) != null) {
                $player1_wins++;
                $player2_losses++;
                $player3_losses++;
                
                $sql = "UPDATE users SET wins='$player1_wins',credits='$premio' WHERE id='$player1'";
                $connect = $conn->query($sql);
                
                $sql = "UPDATE users SET losses='$player2_losses' WHERE id='$player2'";
                $connect = $conn->query($sql);
                
                $sql = "UPDATE users SET losses='$player3_losses' WHERE id='$player3'";
                $connect = $conn->query($sql);
                
                $alerta = "Fim da ronda\\n\\nCartas do jogador $player1_name : $cartas_jogador1\\nCartas do jogador $player2_name : $cartas_jogador2\\nCartas do jogador $player3_name : $cartas_jogador3\\nCartas na mesa: $current_table_cards\\n\\Vencedor : $player1_name \\nRank:$rank\\n";
                
                echo '<script type="text/javascript">
                alert("'.$alerta.'");</script>';
                
                sleep(2);
                
            }else if ($winner == '1') {
                $player1_losses++;
                $player2_wins++;
                $player3_losses++;
                
                $sql = "UPDATE users SET losses='$player1_losses' WHERE id='$player1'";
                $connect = $conn->query($sql);
                
                $sql = "UPDATE users SET wins='$player2_wins',credits='$premio' WHERE id='$player2'";
                $connect = $conn->query($sql);
                
                $sql = "UPDATE users SET losses='$player3_losses' WHERE id='$player3'";
                $connect = $conn->query($sql);
                
                $alerta = "Fim da ronda\\n\\nCartas do jogador $player1_name : $cartas_jogador1\\nCartas do jogador $player2_name : $cartas_jogador2\\nCartas do jogador $player3_name : $cartas_jogador3\\nCartas na mesa: $current_table_cards\\n\\Vencedor : $player2_name \\nRank:$rank\\n";
                
                echo '<script type="text/javascript">
                alert("'.$alerta.'");</script>';
                
                sleep(2);
            }else if ($winner == '2') {
                $player1_losses++;
                $player2_losses++;
                $player3_wins++;
                
                $sql = "UPDATE users SET losses='$player1_losses' WHERE id='$player1'";
                $connect = $conn->query($sql);
                
                $sql = "UPDATE users SET losses='$player2_lossws' WHERE id='$player2'";
                $connect = $conn->query($sql);
                
                $sql = "UPDATE users SET wins='$player3_wins',credits='$premio' WHERE id='$player3'";
                $connect = $conn->query($sql);
                
                $alerta = "Fim da ronda\\n\\nCartas do jogador $player1_name : $cartas_jogador1\\nCartas do jogador $player2_name : $cartas_jogador2\\nCartas do jogador $player3_name : $cartas_jogador3\\nCartas na mesa: $current_table_cards\\n\\Vencedor : $player3_name \\nRank:$rank\\n";
                
                echo '<script type="text/javascript">
                alert("'.$alerta.'");</script>';
                
                sleep(2);
            }
                
            $sql = "UPDATE game_players SET player_cards='$conjunto1',played='N',player_bet='0',gave_up ='N' WHERE id='$game_id' and player_id='$player1'";
            $connect = $conn->query($sql);
                
            $sql = "UPDATE game_players SET player_cards='$conjunto2',played='N',player_bet='0',gave_up ='N' WHERE id='$game_id' and player_id='$player2'";
            $connect = $conn->query($sql);
                
            $sql = "UPDATE game_players SET player_cards='$conjunto3',played='N',player_bet='0',gave_up ='N' WHERE id='$game_id' and player_id='$player3'";
            $connect = $conn->query($sql);
                
            $sql = "UPDATE game_status SET row='0',table_cards='-',current_bet='$aposta_minima',current_player='$dono',current_pot='0' WHERE id='$game_id'";
            $connect = $conn->query($sql);
        }
    }
?>


<script type="text/javascript">
    var javaScriptVar = "<?php echo $url; ?>";
    showGetResult(javaScriptVar);
</script>