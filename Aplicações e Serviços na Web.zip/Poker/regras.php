<!DOCTYPE html>
<html>

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Regras Poker All Starts</title>
    <link rel="stylesheet" type="text/css" href="estilo.css">
    <link href="https://fonts.googleapis.com/css?family=Sansita" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.2.1/jquery.min.js"></script>
    <script src="javascript.js"></script>
</head>

<body>

    <header>
        <img id="logotipo" src="logotipo.png">
        <form id="login" action="jogar.php" method="POST">
        <ul class="menu cf">
            <li><a href="Inicial.php"><i class="fa fa-home fa-lg"></i></a></li>
            <li><a id="util" onclick="show_form()" href="#">Entrar</a>
            <ul id="sub">
                    <li id="1"><p>Email/Username:</p>
                <input class="input_log" type="text" name="user"></li>
                    <li id="2"><p>Password:</p>
                <input class="input_log" type="password" name="pass"></li>
                    <li id="4"><input type="submit" name="Login" value="Login" id="log"></li>
                    <li><a id="3" href="registar.php">Registar</a></li>
                </ul>
            </li>
            <li><a href="regras.php">Regras</a></li>
            <li> <a href="jogar.php">Jogar</a></li>
            <li><a href="ranking.php">Ranking</a></li>
            <li><a href="#">Créditos</a>
            <ul class="submenu">
                    <li><p>Chandani Tushar nº48340</p></li>
                    <li><p>Ines Lino nº48311</p></li>
                    <li><p>Luís Conceição nº48303</p></li>
                    <li><p>Aplicações e Serviços na Web</p></li>
                </ul>
            </li>
        </ul>
      </form>
    </header>
    <?php
        include("openconn.php");
    ?>

    <div class="intro">
        <p id="titulo">Objetivo</p>
        <p style="padding: 0px 10em 0px 10em;text-align: center;">O objetivo do Texas hold 'em é ganhar o pote, ou seja, ganhar a soma em dinheiro de aposta apostada pelos outros jogadores da mesa.
            Um pote é ganho tanto pela descida do melhor jogo de cinco cartas das sete possíveis, ou pela desistência de todos 
            os outros jogadores por apostas não acompanhadas.</p>
        <p id="titulo">Regras e Ranking de mãos</p>
        <p>Para começar a jogar, aconselhamos a saber as regras e as noções básicas dos
            rankings de mãos disponíveis no site <a href="https://www.pokerstars.pt/poker/games/texas-holdem/">pokerStars</a>.</p>
        <br>
        <p id="titulo">Mãos de Poker</p>
        <br>
    </div>
    
    
    <div class="texto">

        
        <p id="titulo">Straight flush</p>
        <img src="stright.gif">
        <p>Cinco cartas em ordem numérica, todas do mesmo naipe. O melhor straight flush possível é conhecido como royal flush,
            consistindo num ás, rei, dama, valete e dez, todos do mesmo naipe. Um royal flush é uma mão imbatível.</p>
        
        <p id="titulo">Four of a kind</p>
        <img src="four.gif">
        <p>Quatro cartas do mesmo valor, e uma carta de desempate ou ‘kicker’. Nos jogos com cartas comunitárias em que os jogadores têm o mesmo four of a kind,
            a quinta carta lateral mais alta ('kicker') ganha.</p>
        
        <p id="titulo">Full House</p>
        <img src="house.gif">
        <p>Três cartas do mesmo valor (trio), e outras duas cartas do mesmo valor (par). Nos jogos com cartas comunitárias em que os jogadores têm os mesmos trios, 
            ganha o full house do par com o valor mais alto.</p>
        
        <br>
        
        <p id="titulo">Flush</p>
        <img src="flush.gif">
        <p>Cinco cartas do mesmo naipe.</p>
        <p>Ganha o jogador com a carta mais alta do ranking.</p>
        
        <p id="titulo">Straight</p>
        <img src="straight.gif">
        <p>Cinco cartas em sequência. Ganha a carta mais alta da sequência. O ás pode ser utilizado tanto no topo como na base 
            da sequência, sendo a única carta que pode funcionar desta forma. A,K,Q,J,T é o straight mais alto (ás como carta alta)</p>
        
        <p id="titulo">Trio</p>
        <img src="trio.gif">
        <p>Três cartas do mesmo valor e duas cartas laterais não relacionadas. Ganha o trio mais alto. Nos jogos com cartas comunitárias em que os jogadores têm o mesmo 
            trio, a carta lateral mais alta ou, se for preciso, a segunda carta mais alta, decidem o vencedor.</p>
        
        <p id="titulo">Dois pares</p>
        <img src="pares.gif">
        <p>Duas cartas do mesmo valor, outras duas cartas de valor idêntico entre si, e uma carta não relacionada. Ganha o par mais alto. Se os jogadores tiverem o mesmo par mais alto, ganha o segundo par mais alto. 
            Se ambos os jogadores tiverem dois pares idênticos, ganha a carta lateral mais alta.</p>
        
        <p id="titulo">Um par</p>
        <img src="par.gif">
        <p>Duas cartas do mesmo valor, outras duas cartas de valor idêntico entre si, e uma carta não relacionada. Ganha o par mais alto. Se os jogadores tiverem o mesmo par, ganha a
            carta lateral mais alta e, se for preciso, podem ser usadas a segunda e terceira cartas laterais mais altas para desempatar.</p>
        
        <p id="titulo">Carta Alta</p>
        <img src="alta.gif">
        <p>Qualquer mão que não esteja nas categorias acima. Ganha a carta mais alta, e caso seja necessário, serão utilizadas a 
            segunda, a terceira, a quarta e a quinta carta mais alta para desempatar.</p>
        
    </div>


</body>

</html>