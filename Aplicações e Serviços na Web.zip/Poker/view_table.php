<?php
    $dbhost = "appserver-01.alunos.di.fc.ul.pt";
  	$dbuser = "asw010";
  	$dbpass = "grupoCIL10";
  	$dbname = "asw010";

  	$conn = mysqli_connect($dbhost, $dbuser, $dbpass, $dbname);
  	if ($conn->connect_error) {
  		die("Database connection FAILED:". $conn->connect_error);
    }
    $sql = "SELECT game_request.id, name, description, max_players, first_bet
            FROM game_request, game_players
            WHERE game_request.id = game_players.id
            GROUP BY game_request.id, name, description, first_bet
            HAVING COUNT(game_players.id) < game_request.max_players";
    $connect = $conn->query($sql);
    if ($connect == TRUE) {
        echo "<table id='tab_jogos' class='jogo'>
        <tr>
        <th>" . "Id" . "</th>
        <th>" . "Nome" . "</th>" .
        "<th>" . "Descrição" . "</th>" .
        "<th>" . "Limite de jogadores" . "</th>" .
        "<th>" . "Primeira aposta" . "</th>" .
        "<th>" . "Entrar" ."</th>";
        while($row = mysqli_fetch_array($connect,MYSQLI_ASSOC)){
            echo "<tr>";
        foreach ($row as $chave => $valor){
            echo "<td>" . $valor . "</td>";
        }
            $join_id = $row['id'];
            echo "<td><form action='jogar.php' method='POST'><input type='submit' name='join' href='jogo.php' id='join' value='$join_id'></form></td>";
            echo "</tr>";
        }

    	} else {
        		echo "Error creating table: " . $conn->error;
    	}
    	echo "</table>";
?>