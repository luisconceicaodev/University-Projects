<!DOCTYPE html>
<html>

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Lista de jogos</title>
    <link rel="stylesheet" type="text/css" href="estilo.css">
    <link href="https://fonts.googleapis.com/css?family=Sansita" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.2.1/jquery.min.js"></script>
    <link rel="stylesheet" href="//code.jquery.com/ui/1.12.1/themes/base/jquery-ui.css">
    <script src="https://code.jquery.com/jquery-1.12.4.js"></script>
    <script src="https://code.jquery.com/ui/1.12.1/jquery-ui.js"></script>
    <script src="javascript.js?2"></script>
</head>

<body>

    <header>
        <img id="logotipo" src="logotipo.png">
        <form id="login" action="jogar.php" method="POST">
        <ul class="menu cf">
            <li><a href="Inicial.php"><i class="fa fa-home fa-lg"></i></a></li>
            <li><a id="util" onclick="show_form()" href="#">Entrar</a>
            <ul id='sub'>
                    <li id="1"><p>Email/Username:</p>
                <input class="input_log" type="text" name="user"></li>
                    <li id="2"><p>Password:</p>
                <input class="input_log" type="password" name="pass"></li>
                    <li id="4"><input type="submit" name="Login" value="Login" id="log"></li>
                    <li><a id="3" href="registar.php">Registar</a></li>
                </ul>
            </li>
            <li><a href="regras.php">Regras</a></li>
            <li> <a href="jogar.php">Jogar</a></li>
            <li><a href="ranking.php">Ranking</a></li>
            <li><a href="#">Créditos</a>
            <ul class="submenu">
                    <li><p>Chandani Tushar nº48340</p></li>
                    <li><p>Ines Lino nº48311</p></li>
                    <li><p>Luís Conceição nº48303</p></li>
                    <li><p>Aplicações e Serviços na Web</p></li>
                </ul>
            </li>
        </ul>
      </form>
    </header>

    <?php
    include("openconn.php");
    $user = $_SESSION['username'];
    $deck = "AC 2C 3C 4C 5C 6C 7C 8C 9C 10C JC QC KC
            AD 2D 3D 4D 5D 6D 7D 8D 9D 10D JD QD KD
            AH 2H 3H 4H 5H 6H 7H 8H 9H 10H JH QH KH
            AS 2S 3S 4S 5S 6S 7S 8S 9S 10S JS QS KS";

    $sql = "SELECT id FROM users WHERE username = '$user'";

    $result = mysqli_query($conn, $sql);
    while ($rows = mysqli_fetch_array($result, MYSQLI_ASSOC)) {
        $user_id = $rows['id'];
    }
    
    function cartas() {
        $lista_cartas = array ('AC', '2C', '3C', '4C', '5C', '6C', '7C', '8C', '9C', 'JC', 'QC', 'KC', 'AD', '2D', '3D', '4D', '5D', '6D', '7D', '8D', '9D', 'JD', 'QD', 'KD','AH', '2H', '3H', '4H', '5H', '6H', '7H', '8H', '9H', 'JH', 'QH', 'KH', 'AS', '2S', '3S', '4S', '5S', '6S', '7S', '8S', '9S', 'JS', 'QS', 'KS');
        $cartas_alea = array_rand($lista_cartas, 3);
        $carta1 = $lista_cartas[$cartas_alea[0]];
        $carta2 = $lista_cartas[$cartas_alea[1]];
        $carta3 = $lista_cartas[$cartas_alea[2]];
        $resultado =  $carta1 . " " .  $carta2;
        return $resultado;
    }
     
    if (isset($_POST ['novojogo'])) {
        $nome = $_POST ["Nome"];
        $valor= $_POST ["Valor"];
        $descri = $_POST ["Descricao"];
        $jogadores = $_POST ["Jogadores"];
        
        $sql = "INSERT INTO game_request (owner,name,description,max_players,first_bet) VALUES('$user_id','$nome','$descri',
             '$jogadores','$valor')";

        if ($conn->query($sql) == TRUE) {
                $sql = "SELECT id FROM game_request WHERE owner = '$user_id'";
                $result = mysqli_query($conn, $sql);
                while ($rows = mysqli_fetch_array($result, MYSQLI_ASSOC)) {
                    $game_id = $rows['id'];
                }
                $cartas = cartas();
                $sql = "INSERT INTO game_players (id,player_id,player_cards,player_bet,played,gave_up) VALUES('$game_id','$user_id','$cartas',0,'N','N')";
                if ($conn->query($sql) == TRUE) {
                    $start = date("Y-m-d H:i:s");
                    $sql = "INSERT INTO game_status (id,started_at,deck,table_cards,current_player,current_bet,current_pot,row) VALUES ('$game_id','$start','$deck','-','$user_id','$valor',0,0)";
                    if ($conn->query($sql) == TRUE) {
                        header("Location: jogo.php");
                    }else{
                        echo "<p style=color:white;text-align:center;font-family:Sansita;>Falha ao entrar no jogo</p>";
                    }
                }
        }else {
                echo "<p style=color:white;text-align:center;font-family:Sansita;>Erro ao criar o jogo</p>";
        }
    }
    
    // Quando um utilizador entra num jogo existente
    if (isset($_POST ['join'])) {
        $game_id = $_POST ['join'];
        $sql = "SELECT id FROM users WHERE username = '$user'";
        $result = mysqli_query($conn, $sql);
        while ($rows = mysqli_fetch_array($result, MYSQLI_ASSOC)) {
            $user_id = $rows['id'];
        }
        $cartas = cartas();
        $sql = "INSERT INTO game_players (id,player_id,player_cards,played,gave_up) VALUES('$game_id','$user_id','$cartas','N','N')";
            if ($conn->query($sql) == TRUE) {
                header("Location: jogo.php");
                }else {
                    echo "Erro ao adicionar jogadores à tabela game_players";
            }
    }
    
    echo "

    <div id='filtrar'>
        <form action='jogar.php' method='POST' id='filtrarJogo'>
        
            <input type='text' name='owner_name' id='myInput' placeholder='Procurar por criador'>
            <input type='submit' class='float_l' name='submitSearch' value='Filtrar'>
            
            <div id='search_select'>
                <select required name='num_players' name='number' id='margem'>
                    <option value='x' selected>Número de jogadores</option>
                    <option value='2'>2</option>
                    <option value='3'>3</option>
                    <option value='4'>4</option>
                    <option value='5'>5</option>
                    <option value='6'>6</option>
                    <option value='7'>7</option>
                    <option value='8'>8</option>
                    <option value='9'>9</option>
                    <option value='10'>10</option>
                </select>

                <select required name='num_bet'>
                    <option value='x' selected>Valor da aposta</option>
                    <option value='10'>10</option>
                    <option value='20'>20</option>
                    <option value='30'>30</option>
                    <option value='40'>40</option>
                    <option value='50'>50</option>
                    <option value='60'>60</option>
                    <option value='70'>70</option>
                    <option value='80'>80</option>
                    <option value='90'>90</option>
                    <option value='100'>100</option>
                </select>
                <input type='text' placeholder='Data' name='date' id='datepicker'></p>
                  <script>
                  $( function() {
                    var date = $('#datepicker').datepicker({ dateFormat: 'yy-mm-dd' }).val();
                  } );
                  </script>
            </div> 
            
        </form>
    </div>

    
    <form action='jogar.php' method='POST' id='hide'>

            <input type='text' id='newGame' name='Nome' placeholder='Nome' required>
            
            <textarea rows='4' cols='30' name='Descricao'  placeholder='Descrição do Jogo' required></textarea>
          
            <div class='center'>
                <select required name='Jogadores' name='number' id='margem'>
                    <option value='' selected>Número de jogadores</option>
                    <option value='2'>2</option>
                    <option value='3'>3</option>
                    <option value='4'>4</option>
                    <option value='5'>5</option>
                    <option value='6'>6</option>
                    <option value='7'>7</option>
                    <option value='8'>8</option>
                    <option value='9'>9</option>
                    <option value='10'>10</option>
                </select>

                <select required name='Valor'>
                    <option value=''>Valor da aposta</option>
                    <option value='10'>10</option>
                    <option value='20'>20</option>
                    <option value='30'>30</option>
                    <option value='40'>40</option>
                    <option value='50'>50</option>
                    <option value='60'>60</option>
                    <option value='70'>70</option>
                    <option value='80'>80</option>
                    <option value='90'>90</option>
                    <option value='100'>100</option>
                </select>
            </div>

            <br>
                <input type='submit' name='novojogo' value='Criar novo jogo' id='add'>
                <input type='button' onclick='hide(); come();' id='min' value='Cancelar'>
    </form>";
    
    
    
    $sql = "SELECT game_request.id, name, description, max_players, first_bet
            FROM game_request, game_players
            WHERE game_request.id = game_players.id
            GROUP BY game_request.id, name, description, first_bet
            HAVING COUNT(game_players.id) < game_request.max_players";
    $connect = $conn->query($sql);
    if ($connect == TRUE) {
        echo "<div id='hide_tab'><input type='button' onclick='criar_jogo();goAway();' value='Criar novo jogo' id='novoJogo'>";

        echo "<p id='titulo'>Lista de jogos</p>";
        echo "<table id='tab_jogos' class='jogo'>
        <tr>
        <th>" . "Id" . "</th>
        <th>" . "Nome" . "</th>" .
        "<th>" . "Descrição" . "</th>" .
        "<th>" . "Limite de jogadores" . "</th>" .
        "<th>" . "Primeira aposta" . "</th>" .
        "<th>" . "Entrar" ."</th>";
        while($row = mysqli_fetch_array($connect,MYSQLI_ASSOC)){
            echo "<tr>";
        foreach ($row as $chave => $valor){
            echo "<td>" . $valor . "</td>";
        }
            $join_id = $row['id'];
            echo "<td><form action='jogar.php' method='POST'><input type='submit' name='join' href='jogo.php' id='join' value='$join_id'></form></td>";
            echo "</tr>";
        }

    	} else {
        		echo "Error creating table: " . $conn->error;
    	}
    	echo "</table></div><br>";
    
    // pesquisar por jogos dependendo do nome do criador, do numero de jogadores e do valor inicial da aposta
    if (isset($_POST['submitSearch'])) {
        $owner_name = $_POST['owner_name'];
        $max_p = $_POST['num_players'];
        $min_v = $_POST['num_bet'];
        $date = $_POST['date'];
        echo "<script>document.getElementById('hide_tab').style.display='none';</script>";
        
        // se os dropdowns forem preenchidos e input do nome estiver preenchida
        if ($max_p != 'x' && $min_v != 'x' && trim($owner_name) != '' && trim($date) == '') {
            $sql = "SELECT game_request.id, usr.username, game_request.name, description, max_players, first_bet
                    FROM game_request, game_players, users usr, game_status
                    WHERE game_request.id = game_players.id AND '$owner_name' = usr.username AND game_request.owner = usr.id AND game_status.ended_at IS NULL AND game_status.id = game_request.id AND game_request.first_bet = '$min_v' AND game_request.max_players = '$max_p'
                    GROUP BY game_request.id, name, description, first_bet
                    HAVING COUNT(game_players.id) < game_request.max_players";
            $connect = $conn->query($sql);
            if ($connect == TRUE) {
                echo "<p id='titulo'>Resultados da pesquisa</p>";
                echo "<table id='tab_jogos' class='jogo'>
                <tr>
                <th>" . "Id" . "</th>
                <th>" . "Dono" . "</th>" .
                "<th>" . "Nome do jogo" . "</th>" .
                "<th>" . "Descrição" . "</th>" .
                "<th>" . "Max players" . "</th>" .
                "<th>" . "Primeira aposta" . "</th>" .
                "<th>" . "Entrar" ."</th>";
                while($row = mysqli_fetch_array($connect,MYSQLI_ASSOC)){
                    echo "<tr>";
                foreach ($row as $chave => $valor){
                    echo "<td>" . $valor . "</td>";
                }
                    $join_id = $row['id'];
                    echo "<td><form action='jogar.php' method='POST'><input type='submit' name='join' href='jogo.php' id='join' value='$join_id'></form></td>";
                    echo "</tr>";
                }

            } else {
                 echo "Error creating table: " . $conn->error;
            }
            echo "</table><br>";
        // se os dropdowns nao tiverem preenchidos mas o inpit do nome estiver
        }elseif ($max_p == 'x' && $min_v == 'x' && trim($owner_name) != '' && trim($date) == '') {
            $sql = "SELECT game_request.id, usr.username, game_request.name, description, max_players, first_bet
                    FROM game_request, game_players, users usr, game_status
                    WHERE game_request.id = game_players.id AND '$owner_name' = usr.username AND game_request.owner = usr.id AND game_status.ended_at IS NULL AND game_status.id = game_request.id
                    GROUP BY game_request.id, name, description, first_bet
                    HAVING COUNT(game_players.id) < game_request.max_players";
            $connect = $conn->query($sql);
            if ($connect == TRUE) {
                echo "<p id='titulo'>Resultados da pesquisa</p>";
                echo "<table id='tab_jogos' class='jogo'>
                <tr>
                <th>" . "Id" . "</th>
                <th>" . "Dono" . "</th>" .
                "<th>" . "Nome do jogo" . "</th>" .
                "<th>" . "Descrição" . "</th>" .
                "<th>" . "Max players" . "</th>" .
                "<th>" . "Primeira aposta" . "</th>" .
                "<th>" . "Entrar" ."</th>";
                while($row = mysqli_fetch_array($connect,MYSQLI_ASSOC)){
                    echo "<tr>";
                foreach ($row as $chave => $valor){
                    echo "<td>" . $valor . "</td>";
                }
                    $join_id = $row['id'];
                    echo "<td><form action='jogar.php' method='POST'><input type='submit' name='join' href='jogo.php' id='join' value='$join_id'></form></td>";
                    echo "</tr>";
                }

            } else {
                 echo "Ocorreu um erro ao realizar a sua pesquisa " . $conn->error;
            }
            echo "</table><br>";
        }elseif ($max_p != 'x' && $min_v == 'x' && trim($owner_name) != '' && trim($date) == ''){
            $sql = "SELECT game_request.id, usr.username, game_request.name, description, max_players, first_bet
                    FROM game_request, game_players, users usr, game_status
                    WHERE game_request.id = game_players.id AND '$owner_name' = usr.username AND game_request.owner = usr.id AND game_status.ended_at IS NULL AND game_status.id = game_request.id AND game_request.max_players = '$max_p'
                    GROUP BY game_request.id, name, description, first_bet
                    HAVING COUNT(game_players.id) < game_request.max_players";
            $connect = $conn->query($sql);
            if ($connect == TRUE) {
                echo "<p id='titulo'>Resultados da pesquisa</p>";
                echo "<table id='tab_jogos' class='jogo'>
                <tr>
                <th>" . "Id" . "</th>
                <th>" . "Dono" . "</th>" .
                "<th>" . "Nome do jogo" . "</th>" .
                "<th>" . "Descrição" . "</th>" .
                "<th>" . "Max players" . "</th>" .
                "<th>" . "Primeira aposta" . "</th>" .
                "<th>" . "Entrar" ."</th>";
                while($row = mysqli_fetch_array($connect,MYSQLI_ASSOC)){
                    echo "<tr>";
                foreach ($row as $chave => $valor){
                    echo "<td>" . $valor . "</td>";
                }
                    $join_id = $row['id'];
                    echo "<td><form action='jogar.php' method='POST'><input type='submit' name='join' href='jogo.php' id='join' value='$join_id'></form></td>";
                    echo "</tr>";
                }

            } else {
                 echo "Ocorreu um erro ao realizar a sua pesquisa " . $conn->error;
            }
            echo "</table><br>";
        }elseif ($max_p == 'x' && $min_v != 'x' && trim($owner_name) != '' && trim($date) == '') {
            $sql = "SELECT game_request.id, usr.username, game_request.name, description, max_players, first_bet
                    FROM game_request, game_players, users usr, game_status
                    WHERE game_request.id = game_players.id AND '$owner_name' = usr.username AND game_request.owner = usr.id AND game_status.ended_at IS NULL AND game_status.id = game_request.id AND game_request.first_bet = '$min_v'
                    GROUP BY game_request.id, name, description, first_bet
                    HAVING COUNT(game_players.id) < game_request.max_players";
            $connect = $conn->query($sql);
            if ($connect == TRUE) {
                echo "<p id='titulo'>Resultados da pesquisa</p>";
                echo "<table id='tab_jogos' class='jogo'>
                <tr>
                <th>" . "Id" . "</th>
                <th>" . "Dono" . "</th>" .
                "<th>" . "Nome do jogo" . "</th>" .
                "<th>" . "Descrição" . "</th>" .
                "<th>" . "Max players" . "</th>" .
                "<th>" . "Primeira aposta" . "</th>" .
                "<th>" . "Entrar" ."</th>";
                while($row = mysqli_fetch_array($connect,MYSQLI_ASSOC)){
                    echo "<tr>";
                foreach ($row as $chave => $valor){
                    echo "<td>" . $valor . "</td>";
                }
                    $join_id = $row['id'];
                    echo "<td><form action='jogar.php' method='POST'><input type='submit' name='join' href='jogo.php' id='join' value='$join_id'></form></td>";
                    echo "</tr>";
                }

            } else {
                 echo "Ocorreu um erro ao realizar a sua pesquisa " . $conn->error;
            }
            echo "</table><br>";
        }elseif ($max_p != 'x' && $min_v != 'x' && trim($owner_name) == '' && trim($date) == '') {
            $sql = "SELECT game_request.id, usr.username, game_request.name, description, max_players, first_bet
                    FROM game_request, game_players, users usr, game_status
                    WHERE game_request.id = game_players.id AND game_request.owner = usr.id AND game_status.ended_at IS NULL AND game_status.id = game_request.id AND game_request.first_bet = '$min_v' AND game_request.max_players = '$max_p'
                    GROUP BY game_request.id, name, description, first_bet
                    HAVING COUNT(game_players.id) < game_request.max_players";
            $connect = $conn->query($sql);
            if ($connect == TRUE) {
                echo "<p id='titulo'>Resultados da pesquisa</p>";
                echo "<table id='tab_jogos' class='jogo'>
                <tr>
                <th>" . "Id" . "</th>
                <th>" . "Dono" . "</th>" .
                "<th>" . "Nome do jogo" . "</th>" .
                "<th>" . "Descrição" . "</th>" .
                "<th>" . "Max players" . "</th>" .
                "<th>" . "Primeira aposta" . "</th>" .
                "<th>" . "Entrar" ."</th>";
                while($row = mysqli_fetch_array($connect,MYSQLI_ASSOC)){
                    echo "<tr>";
                foreach ($row as $chave => $valor){
                    echo "<td>" . $valor . "</td>";
                }
                    $join_id = $row['id'];
                    echo "<td><form action='jogar.php' method='POST'><input type='submit' name='join' href='jogo.php' id='join' value='$join_id'></form></td>";
                    echo "</tr>";
                }

            } else {
                 echo "Error creating table: " . $conn->error;
            }
            echo "</table><br>";
        }elseif ($max_p != 'x' && $min_v == 'x' && (trim($owner_name) == '' && trim($date) == '')) {
            $sql = "SELECT game_request.id, usr.username, game_request.name, description, max_players, first_bet
                    FROM game_request, game_players, users usr, game_status
                    WHERE game_request.id = game_players.id AND game_request.owner = usr.id AND game_status.ended_at IS NULL AND game_status.id = game_request.id AND game_request.max_players = '$max_p'
                    GROUP BY game_request.id, name, description, first_bet
                    HAVING COUNT(game_players.id) < game_request.max_players";
            $connect = $conn->query($sql);
            if ($connect == TRUE) {
                echo "<p id='titulo'>Resultados da pesquisa</p>";
                echo "<table id='tab_jogos' class='jogo'>
                <tr>
                <th>" . "Id" . "</th>
                <th>" . "Dono" . "</th>" .
                "<th>" . "Nome do jogo" . "</th>" .
                "<th>" . "Descrição" . "</th>" .
                "<th>" . "Max players" . "</th>" .
                "<th>" . "Primeira aposta" . "</th>" .
                "<th>" . "Entrar" ."</th>";
                while($row = mysqli_fetch_array($connect,MYSQLI_ASSOC)){
                    echo "<tr>";
                foreach ($row as $chave => $valor){
                    echo "<td>" . $valor . "</td>";
                }
                    $join_id = $row['id'];
                    echo "<td><form action='jogar.php' method='POST'><input type='submit' name='join' href='jogo.php' id='join' value='$join_id'></form></td>";
                    echo "</tr>";
                }

            } else {
                 echo "Error creating table: " . $conn->error;
            }
            echo "</table><br>";
        }elseif ($max_p == 'x' && $min_v != 'x' && trim($owner_name) == '' && trim($date) == '') {
            $sql = "SELECT game_request.id, usr.username, game_request.name, description, max_players, first_bet
                    FROM game_request, game_players, users usr, game_status
                    WHERE game_request.id = game_players.id AND game_request.owner = usr.id AND game_status.ended_at IS NULL AND game_status.id = game_request.id AND game_request.first_bet = '$min_v'
                    GROUP BY game_request.id, name, description, first_bet
                    HAVING COUNT(game_players.id) < game_request.max_players";
            $connect = $conn->query($sql);
            if ($connect == TRUE) {
                echo "<p id='titulo'>Resultados da pesquisa</p>";
                echo "<table id='tab_jogos' class='jogo'>
                <tr>
                <th>" . "Id" . "</th>
                <th>" . "Dono" . "</th>" .
                "<th>" . "Nome do jogo" . "</th>" .
                "<th>" . "Descrição" . "</th>" .
                "<th>" . "Max players" . "</th>" .
                "<th>" . "Primeira aposta" . "</th>" .
                "<th>" . "Entrar" ."</th>";
                while($row = mysqli_fetch_array($connect,MYSQLI_ASSOC)){
                    echo "<tr>";
                foreach ($row as $chave => $valor){
                    echo "<td>" . $valor . "</td>";
                }
                    $join_id = $row['id'];
                    echo "<td><form action='jogar.php' method='POST'><input type='submit' name='join' href='jogo.php' id='join' value='$join_id'></form></td>";
                    echo "</tr>";
                }

            } else {
                 echo "Error creating table: " . $conn->error;
            }
            echo "</table><br>";
        }elseif ($max_p == 'x' && $min_v == 'x' && trim($owner_name) == '' && trim($date) != '') {
            $sql = "SELECT game_request.id,started_at, name, description, max_players, first_bet
                FROM game_request, game_players, game_status
                WHERE game_request.id = game_players.id AND game_status.id = game_request.id AND game_status.ended_at IS NULL AND DATE(started_at) = '$date'
                GROUP BY game_request.id, name, description, first_bet
                HAVING COUNT(game_players.id) < game_request.max_players";
            $connect = $conn->query($sql);
            if ($connect == TRUE) {
                echo "<p id='titulo'>Resultados da pesquisa</p>";
                echo "<table id='tab_jogos' class='jogo'>
                <tr>
                <th>" . "Id" . "</th>
                <th>" . "Data de criação" . "</th>" .
                "<th>" . "Nome do jogo" . "</th>" .
                "<th>" . "Descrição" . "</th>" .
                "<th>" . "Max players" . "</th>" .
                "<th>" . "Primeira aposta" . "</th>" .
                "<th>" . "Entrar" ."</th>";
                while($row = mysqli_fetch_array($connect,MYSQLI_ASSOC)){
                    echo "<tr>";
                foreach ($row as $chave => $valor){
                    echo "<td>" . $valor . "</td>";
                }
                    $join_id = $row['id'];
                    echo "<td><form action='jogar.php' method='POST'><input type='submit' name='join' href='jogo.php' id='join' value='$join_id'></form></td>";
                    echo "</tr>";
                }

            } else {
                 echo "Error creating table: " . $conn->error;
            }
            echo "</table><br>"; 
        }elseif ($max_p == 'x' && $min_v == 'x' && trim($owner_name) != '' && trim($date) != '') {
            $sql = "SELECT game_request.id,started_at, username, game_request.name, description, max_players, first_bet
                FROM game_request, game_players, game_status, users usr
                WHERE game_request.id = game_players.id AND game_status.id = game_request.id AND game_status.ended_at IS NULL AND DATE(started_at) = '$date' AND '$owner_name' = usr.username AND game_request.owner = usr.id AND game_status.id = game_request.id
                GROUP BY game_request.id, name, description, first_bet
                HAVING COUNT(game_players.id) < game_request.max_players";
            $connect = $conn->query($sql);
            if ($connect == TRUE) {
                echo "<p id='titulo'>Resultados da pesquisa</p>";
                echo "<table id='tab_jogos' class='jogo'>
                <tr>
                <th>" . "Id" . "</th>
                <th>" . "Data de criação" . "</th>" .
                "<th>" . "Dono" . "</th>" .
                "<th>" . "Nome do jogo" . "</th>" .
                "<th>" . "Descrição" . "</th>" .
                "<th>" . "Max players" . "</th>" .
                "<th>" . "Primeira aposta" . "</th>" .
                "<th>" . "Entrar" ."</th>";
                while($row = mysqli_fetch_array($connect,MYSQLI_ASSOC)){
                    echo "<tr>";
                foreach ($row as $chave => $valor){
                    echo "<td>" . $valor . "</td>";
                }
                    $join_id = $row['id'];
                    echo "<td><form action='jogar.php' method='POST'><input type='submit' name='join' href='jogo.php' id='join' value='$join_id'></form></td>";
                    echo "</tr>";
                }

            } else {
                 echo "Error creating table: " . $conn->error;
            }
            echo "</table><br>"; 
        }elseif ($max_p != 'x' && $min_v != 'x' && trim($owner_name) != '' && trim($date) != '') {
            $sql = "SELECT game_request.id,started_at, username, game_request.name, description, max_players, first_bet
                FROM game_request, game_players, game_status, users usr
                WHERE game_request.id = game_players.id AND game_status.id = game_request.id AND game_status.ended_at IS NULL AND DATE(started_at) = '$date' AND '$owner_name' = usr.username AND game_request.owner = usr.id AND game_status.id = game_request.id AND game_request.first_bet = '$min_v' AND game_request.max_players = '$max_p'
                GROUP BY game_request.id, name, description, first_bet
                HAVING COUNT(game_players.id) < game_request.max_players";
            $connect = $conn->query($sql);
            if ($connect == TRUE) {
                echo "<p id='titulo'>Resultados da pesquisa</p>";
                echo "<table id='tab_jogos' class='jogo'>
                <tr>
                <th>" . "Id" . "</th>
                <th>" . "Data de criação" . "</th>" .
                "<th>" . "Dono" . "</th>" .
                "<th>" . "Nome do jogo" . "</th>" .
                "<th>" . "Descrição" . "</th>" .
                "<th>" . "Max players" . "</th>" .
                "<th>" . "Primeira aposta" . "</th>" .
                "<th>" . "Entrar" ."</th>";
                while($row = mysqli_fetch_array($connect,MYSQLI_ASSOC)){
                    echo "<tr>";
                foreach ($row as $chave => $valor){
                    echo "<td>" . $valor . "</td>";
                }
                    $join_id = $row['id'];
                    echo "<td><form action='jogar.php' method='POST'><input type='submit' name='join' href='jogo.php' id='join' value='$join_id'></form></td>";
                    echo "</tr>";
                }

            } else {
                 echo "Error creating table: " . $conn->error;
            }
            echo "</table><br>"; 
        }elseif ($max_p == 'x' && $min_v != 'x' && trim($owner_name) == '' && trim($date) != '') {
            $sql = "SELECT game_request.id,started_at, username, game_request.name, description, max_players, first_bet
                FROM game_request, game_players, game_status, users usr
                WHERE game_request.id = game_players.id AND game_status.id = game_request.id AND game_status.ended_at IS NULL AND DATE(started_at) = '$date' AND game_request.owner = usr.id AND game_status.id = game_request.id AND game_request.first_bet = '$min_v' 
                GROUP BY game_request.id, name, description, first_bet
                HAVING COUNT(game_players.id) < game_request.max_players";
            $connect = $conn->query($sql);
            if ($connect == TRUE) {
                echo "<p id='titulo'>Resultados da pesquisa</p>";
                echo "<table id='tab_jogos' class='jogo'>
                <tr>
                <th>" . "Id" . "</th>
                <th>" . "Data de criação" . "</th>" .
                "<th>" . "Nome do jogo" . "</th>" .
                "<th>" . "Descrição" . "</th>" .
                "<th>" . "Max players" . "</th>" .
                "<th>" . "Primeira aposta" . "</th>" .
                "<th>" . "Entrar" ."</th>";
                while($row = mysqli_fetch_array($connect,MYSQLI_ASSOC)){
                    echo "<tr>";
                foreach ($row as $chave => $valor){
                    echo "<td>" . $valor . "</td>";
                }
                    $join_id = $row['id'];
                    echo "<td><form action='jogar.php' method='POST'><input type='submit' name='join' href='jogo.php' id='join' value='$join_id'></form></td>";
                    echo "</tr>";
                }

            } else {
                 echo "Error creating table: " . $conn->error;
            }
            echo "</table><br>"; 
        }elseif ($max_p != 'x' && $min_v == 'x' && trim($owner_name) == '' && trim($date) != '') {
            $sql = "SELECT game_request.id,started_at, username, game_request.name, description, max_players, first_bet
                FROM game_request, game_players, game_status, users usr
                WHERE game_request.id = game_players.id AND game_status.id = game_request.id AND game_status.ended_at IS NULL AND DATE(started_at) = '$date' AND game_request.owner = usr.id AND game_status.id = game_request.id AND game_request.max_players = '$max_p'
                GROUP BY game_request.id, name, description, first_bet
                HAVING COUNT(game_players.id) < game_request.max_players";
            $connect = $conn->query($sql);
            if ($connect == TRUE) {
                echo "<p id='titulo'>Resultados da pesquisa</p>";
                echo "<table id='tab_jogos' class='jogo'>
                <tr>
                <th>" . "Id" . "</th>
                <th>" . "Data de criação" . "</th>" .
                "<th>" . "Nome do jogo" . "</th>" .
                "<th>" . "Descrição" . "</th>" .
                "<th>" . "Max players" . "</th>" .
                "<th>" . "Primeira aposta" . "</th>" .
                "<th>" . "Entrar" ."</th>";
                while($row = mysqli_fetch_array($connect,MYSQLI_ASSOC)){
                    echo "<tr>";
                foreach ($row as $chave => $valor){
                    echo "<td>" . $valor . "</td>";
                }
                    $join_id = $row['id'];
                    echo "<td><form action='jogar.php' method='POST'><input type='submit' name='join' href='jogo.php' id='join' value='$join_id'></form></td>";
                    echo "</tr>";
                }

            } else {
                 echo "Error creating table: " . $conn->error;
            }
            echo "</table><br>"; 
        }elseif ($max_p != 'x' && $min_v != 'x' && trim($owner_name) == '' && trim($date) != '') {
            $sql = "SELECT game_request.id,started_at, username, game_request.name, description, max_players, first_bet
                FROM game_request, game_players, game_status, users usr
                WHERE game_request.id = game_players.id AND game_status.id = game_request.id AND game_status.ended_at IS NULL AND DATE(started_at) = '$date' AND game_request.owner = usr.id AND game_status.id = game_request.id AND game_request.first_bet = '$min_v' AND game_request.max_players = '$max_p'
                GROUP BY game_request.id, name, description, first_bet
                HAVING COUNT(game_players.id) < game_request.max_players";
            $connect = $conn->query($sql);
            if ($connect == TRUE) {
                echo "<p id='titulo'>Resultados da pesquisa</p>";
                echo "<table id='tab_jogos' class='jogo'>
                <tr>
                <th>" . "Id" . "</th>
                <th>" . "Data de criação" . "</th>" .
                "<th>" . "Nome do jogo" . "</th>" .
                "<th>" . "Descrição" . "</th>" .
                "<th>" . "Max players" . "</th>" .
                "<th>" . "Primeira aposta" . "</th>" .
                "<th>" . "Entrar" ."</th>";
                while($row = mysqli_fetch_array($connect,MYSQLI_ASSOC)){
                    echo "<tr>";
                foreach ($row as $chave => $valor){
                    echo "<td>" . $valor . "</td>";
                }
                    $join_id = $row['id'];
                    echo "<td><form action='jogar.php' method='POST'><input type='submit' name='join' href='jogo.php' id='join' value='$join_id'></form></td>";
                    echo "</tr>";
                }

            } else {
                 echo "Error creating table: " . $conn->error;
            }
            echo "</table><br>"; 
        }
    }
    
    ?>
</body>

</html>
