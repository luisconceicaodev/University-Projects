<!DOCTYPE html>
<html>

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Estatísticas dos jogadores</title>
    <link rel="stylesheet" type="text/css" href="estilo.css">
    <link href="https://fonts.googleapis.com/css?family=Sansita" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.2.1/jquery.min.js"></script>
    <link rel="stylesheet" href="//code.jquery.com/ui/1.12.1/themes/base/jquery-ui.css">
    <script src="https://code.jquery.com/jquery-1.12.4.js"></script>
    <script src="https://code.jquery.com/ui/1.12.1/jquery-ui.js"></script>
    <script src="javascript.js"></script>
</head>

<body>
    <header>
        <img id="logotipo" src="logotipo.png">
        <form id="login" action="Inicial.php" method="POST">
        <ul class="menu cf">
            <li><a href="Inicial.php"><i class="fa fa-home fa-lg"></i></a></li>
            <li><a id="util" onclick="show_form()" href="#">Entrar</a>
            <ul id='sub'>
                    <li id="1"><p>Email/Username:</p>
                <input class="input_log" type="text" name="user"></li>
                    <li id="2"><p>Password:</p>
                <input class="input_log" type="password" name="pass"></li>
                    <li id="4"><input type="submit" name="Login" value="Login" id="log"></li>
                    <li><a id="3" href="registar.php">Registar</a></li>
                </ul>
            </li>
            <li><a href="regras.php">Regras</a></li>
            <li> <a href="jogar.php">Jogar</a></li>
            <li><a href="ranking.php">Ranking</a></li>
            <li><a href="#">Créditos</a>
            <ul class="submenu">
                    <li><p>Chandani Tushar nº48340</p></li>
                    <li><p>Ines Lino nº48311</p></li>
                    <li><p>Luís Conceição nº48303</p></li>
                    <li><p>Aplicações e Serviços na Web</p></li>
                </ul>
            </li>
        </ul>
      </form>
    </header>

    <?php
    include("openconn.php");
    
    $sql = "SELECT username,wins,losses,wins/(wins+losses)*100
            FROM users
            WHERE (wins OR losses) != 0
            ORDER BY wins/(wins+losses)*100  DESC";
    $connect = $conn->query($sql);
    if ($connect == TRUE) {
        echo "<p id='titulo'>Estatísticas dos jogadores</p>";
        echo "<table id='tab_jogos' class='jogo'>
                <tr>
                <th>" . "Jogador" . "</th>
                <th>" . "Vitórias" . "</th>" .
                "<th>" . "Derrotas" . "</th>" .
                "<th>" . "Win Rate" . "</th>";
        while($row = mysqli_fetch_array($connect,MYSQLI_ASSOC)){
            echo "<tr>";
            foreach ($row as $chave => $valor){
                if ($chave == 'wins/(wins+losses)*100') {
                    //$winrate = $row['wins/(wins+losses)*100'];
                    $valor = substr($valor, 0, -2);
                    $valor .= " %";
                    echo "<td>" . $valor . "</td>";
                }else{
                    echo "<td>" . $valor . "</td>";
                }
            }
            echo "</tr>";
        }
    } else {
        echo "Ocorreu um erro ao realizar a pesquisa pelas estatisticas na nossa base de dados" . $conn->error;
    }
    echo "</table><br></div>";
    
    $conn->close();
    ?>
    </body>

</html>
