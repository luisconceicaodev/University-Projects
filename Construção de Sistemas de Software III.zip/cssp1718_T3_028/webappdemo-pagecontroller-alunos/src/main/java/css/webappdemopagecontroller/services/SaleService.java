package css.webappdemopagecontroller.services;

import css.webappdemopagecontroller.persistence.SaleRowDataGateway;

import java.sql.Date;
import java.util.List;

import css.webappdemopagecontroller.persistence.PersistenceException;
import css.webappdemopagecontroller.persistence.SaleFinder;


/**
 * Handles sale transactions. 
 * Each public method implements a transaction script.
 * 
 * @author nº48303
 * @author nº48349
 * @version
 *
 */
public enum SaleService {
	INSTANCE;
	
	public SaleDTO getSaleById (int id) throws ApplicationException {
		try {
			SaleRowDataGateway sale = new SaleFinder().getSaleById(id);
			return new SaleDTO(sale.getSaleId(), sale.getData(), sale.getTotal(), 
					sale.getStatus(), sale.getCustomerVAT());
		} catch (PersistenceException e) {
				throw new ApplicationException ("Sale with Id " + id + " not found.", e);
		}
	}
	
	public SaleDTO getSaleByCustomerVAT (int customerVAT) throws ApplicationException {
		if (!isValidVAT (customerVAT))
			throw new ApplicationException ("Invalid VAT number: " + customerVAT);
		else try {
			SaleRowDataGateway sale = new SaleFinder().getSaleByCustomerVAT(customerVAT);
			return new SaleDTO(sale.getSaleId(), sale.getData(), sale.getTotal(), 
					sale.getStatus(), sale.getCustomerVAT());
		} catch (PersistenceException e) {
				throw new ApplicationException ("Sale with CustomerVAT number " + customerVAT + " not found.", e);
		}
	}
	
	public List<String> getSalesByCustomerVAT (int customerVAT) throws ApplicationException {
		if (!isValidVAT (customerVAT))
			throw new ApplicationException ("Invalid VAT number: " + customerVAT);
		else try {
			List<String> sales = new SaleFinder().getSalesByCustomerVAT(customerVAT);
			return sales;
		} catch (PersistenceException e) {
				throw new ApplicationException ("Sale with CustomerVAT number " + customerVAT + " not found.", e);
		}
	}
	
	public void insertSale(Date data, double total, String status, int customerVAT) throws ApplicationException {
		try {
			SaleRowDataGateway sale = new SaleRowDataGateway(data,total,status,customerVAT);
			sale.insert();
		} catch (PersistenceException e) {
				throw new ApplicationException ("Failled to add the sale", e);
		}
	}
	
	public void updateSaleStatus(int id) throws ApplicationException {
		try {
			SaleRowDataGateway sale = new SaleFinder().getSaleById(id);
			sale.setStatus("C");
			sale.updateStatus();
		} catch (PersistenceException e) {
				throw new ApplicationException ("Sale with id " + id + " not found.", e);
		}
	}
	
	/**
	 * Checks if a VAT number is valid.
	 * 
	 * @param vat The number to be checked.
	 * @return Whether the VAT number is valid. 
	 */
	private boolean isValidVAT(int vat) {
		// If the number of digits is not 9, error!
		if (vat < 100000000 || vat > 999999999)
			return false;
		
		// If the first number is not 1, 2, 5, 6, 8, 9, error!
		int firstDigit = vat / 100000000;
		if (firstDigit != 1 && firstDigit != 2 && 
			firstDigit != 5 && firstDigit != 6 &&
			firstDigit != 8 && firstDigit != 9)
			return false;
		
		// Checks the congruence modules 11.
		int sum = 0;
		int checkDigit = vat % 10;
		vat /= 10;
		
		for (int i = 2; i < 10 && vat != 0; i++) {
			sum += vat % 10 * i;
			vat /= 10;
		}
		
		int checkDigitCalc = 11 - sum % 11;
		if (checkDigitCalc == 10)
			checkDigitCalc = 0;
		return checkDigit == checkDigitCalc;
	}
}