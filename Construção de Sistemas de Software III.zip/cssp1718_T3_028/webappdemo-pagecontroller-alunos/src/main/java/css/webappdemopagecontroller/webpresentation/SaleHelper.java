package css.webappdemopagecontroller.webpresentation;

import java.sql.Date;

import css.webappdemopagecontroller.services.SaleDTO;

/**
 * Helper class to assist in the response of getSaleByCustomerVAT.
 * This class is the response information expert.
 * 
 * @author nº48303
 * @author nº48349
 *
 */
public class SaleHelper extends Helper {
	
	private int id;
	private Date data;
	private double total;
	private String status;
	private int customerVAT;
	
	public void setId(int id) {
		this.id = id;	
	}

	public int getId() {
		return id;	
	}
	
	public void setData(Date data) {
		this.data = data;	
	}

	public Date getData() {
		return data;	
	}
	
	public void setTotal(double total) {
		this.total = total;	
	}

	public double getTotal() {
		return total;	
	}

	public void setStatus(String status) {
		this.status = status;	
	}
	
	public String getStatus() {
		return status;
	}
	
	public void setCustomerVAT(int customerVAT) {
		this.customerVAT = customerVAT;
	}
	
	public int getCustomerVAT() {
		return customerVAT;
	}

	public void fillWithSale(SaleDTO saleDTO) {
		id = saleDTO.id;
		data = saleDTO.data;
		total = saleDTO.total;
		status = saleDTO.status;
		customerVAT = saleDTO.customerVAT;
	}
}
