package css.webappdemopagecontroller.webpresentation;

import java.io.IOException;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import css.webappdemopagecontroller.persistence.PersistenceException;
import css.webappdemopagecontroller.services.ApplicationException;
import css.webappdemopagecontroller.services.DeliveryService;


/**
 * Servlet implementation class InsertDeliveryIIPageController
 * 
 * Handles the http get and post. Decides which model and view to use.
 * 
 * Decode the URL, extract any form data, decide action 
 * Create and invoke any model objects
 * Determine which view should display the result page 
 * (Forward information to it)
 * 
 */
@WebServlet("/InsertDeliveryIIPageController")
public class InsertDeliveryIIPageController extends PageController {

	private static final long serialVersionUID = 1L;

	@Override
	protected void process(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		DeliveryService ds = DeliveryService.INSTANCE;        

		DeliveryHelper dh = new DeliveryHelper();
		try{
			String address = request.getParameter("adrs");
			String saleid = request.getParameter("saleid");
			int intsaleid = intValue(saleid);			
			int customerVAT = ds.getCustomerVATBySaleId(intsaleid);
			ds.insertDelivery(intsaleid,customerVAT,address);
			dh.fillWithDelivery(ds.getDeliveryBySaleId(intsaleid));
			request.setAttribute("helpers", dh);
			request.setAttribute("id", dh.getId());
			request.setAttribute("saleid", dh.getSaleId());
			request.setAttribute("vat", dh.getCustomerVAT());
			request.setAttribute("address", dh.getDeliveryAddress());
			request.getRequestDispatcher("DeliveryInfo.jsp").forward(request, response);
		} catch (ApplicationException | PersistenceException e) {
			dh.addMessage("It was not possible to fulfill the request: " + e.getMessage());
			request.getRequestDispatcher("DeliveryError.jsp").forward(request, response); 
		}
	}

}
