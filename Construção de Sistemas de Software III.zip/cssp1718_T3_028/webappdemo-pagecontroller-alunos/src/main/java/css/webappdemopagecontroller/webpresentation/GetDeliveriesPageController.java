package css.webappdemopagecontroller.webpresentation;

import java.io.IOException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import css.webappdemopagecontroller.services.ApplicationException;
import css.webappdemopagecontroller.services.DeliveryService;


/**
 * Servlet implementation class GetDeliveriesPageController
 * 
 * Handles the http get and post. Decides which model and view to use.
 * 
 * Decode the URL, extract any form data, decide action 
 * Create and invoke any model objects
 * Determine which view should display the result page 
 * (Forward information to it)
 * 
 */
@WebServlet("/GetDeliveriesPageController")
public class GetDeliveriesPageController extends PageController {

	private static final long serialVersionUID = 1L;

	@Override
	protected void process(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		DeliveryService ds = DeliveryService.INSTANCE;

		DeliveryHelper dh = new DeliveryHelper();
		request.setAttribute("helper", dh);
		try {
			String paramid = request.getParameter("id");	
			int cid = intValue(paramid);
			List<List<String>> deliveries = ds.getDeliveriesByCustomerId(cid);
			
			Map<String, List<String>> map = new HashMap<String, List<String>>();
			
			List<String> list;
			for(List<String> d : deliveries) {
				if(map.containsKey(d.get(3))){
				    // if key already exists
				    list = map.get(d.get(3));
				    list.add("Delivery Id: " + d.get(0) + ", " + "Sale Id: " + d.get(1) + ", " + 
				    "Customer VAT: " + d.get(2));
				} else {
				    // if key does not exist
				    list = new ArrayList<String>();
				    list.add("Delivery Id: " + d.get(0) + ", " + "Sale Id: " + d.get(1) + ", " + 
						    "Customer VAT: " + d.get(2));
				    map.put(d.get(3), list);
				}
			}
			request.setAttribute("deliveries", map);
			request.getRequestDispatcher("DeliveriesInfo.jsp").forward(request, response);
		} catch (ApplicationException e) {
			dh.addMessage("It was not possible to fulfill the request: " + e.getMessage());
			request.getRequestDispatcher("DeliveryError.jsp").forward(request, response); 
		}

	}

}