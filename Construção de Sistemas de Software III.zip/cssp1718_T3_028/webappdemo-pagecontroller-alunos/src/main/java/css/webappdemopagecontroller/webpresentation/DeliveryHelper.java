package css.webappdemopagecontroller.webpresentation;

import css.webappdemopagecontroller.services.DeliveryDTO;

/**
 * Helper class to assist in get Delivery.
 * This class is the response information expert.
 * 
 * @author nº48303
 * @author nº48349
 *
 */
public class DeliveryHelper extends Helper {

	private int id;
	private int saleid;
	private int customerVAT;
	private String delivery_address;
	
	public void setId(int id) {
		this.id = id;	
	}

	public int getId() {
		return id;	
	}

	public void setSaleId(int saleid) {
		this.saleid = saleid;
	}
	
	public int getSaleId() {
		return saleid;
	}
	
	public void setCustomerVAT(int customerVAT) {
		this.customerVAT = customerVAT;
	}

	public int getCustomerVAT() {
		return customerVAT;
	}
	
	public String getDeliveryAddress() {
		return delivery_address;
	}
		
	public void setDeliveryAddress(String delivery_address) {
		this.delivery_address = delivery_address;
	}

	public void fillWithDelivery(DeliveryDTO deliveryDTO) {
		id = deliveryDTO.id;
		saleid = deliveryDTO.saleid;
		customerVAT = deliveryDTO.customerVAT;
		delivery_address = deliveryDTO.delivery_address;
	}
}