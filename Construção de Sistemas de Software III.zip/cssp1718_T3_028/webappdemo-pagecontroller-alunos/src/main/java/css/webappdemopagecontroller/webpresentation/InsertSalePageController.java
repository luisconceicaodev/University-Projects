package css.webappdemopagecontroller.webpresentation;

import java.io.IOException;
import java.util.Date;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import css.webappdemopagecontroller.services.ApplicationException;
import css.webappdemopagecontroller.services.SaleService;

/**
 * Servlet implementation class InsertSalePageController
 * 
 * Handles the http get and post. Decides which model and view to use.
 * 
 * Decode the URL, extract any form data, decide action 
 * Create and invoke any model objects
 * Determine which view should display the result page 
 * (Forward information to it)
 * 
 */
@WebServlet("/InsertSalePageController")
public class InsertSalePageController extends PageController{
	
	private static final long serialVersionUID = 1L;

	@Override
	protected void process(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		SaleService ss = SaleService.INSTANCE;        
		SaleHelper sh = new SaleHelper();
		request.setAttribute("helper", sh);
		try{
			Date utilDate = new Date();
			java.sql.Date sqlDate = new java.sql.Date(utilDate.getTime());
			String status = "O";
			String PcustomerVAT = request.getParameter("customerVAT");
			double total = 0;
			int customerVAT = intValue(PcustomerVAT);
			ss.insertSale(sqlDate, total, status, customerVAT);
			sh.fillWithSale(ss.getSaleByCustomerVAT(customerVAT));
			request.getRequestDispatcher("SaleInfo.jsp").forward(request, response);
		} catch (ApplicationException e) {
			sh.addMessage("It was not possible to fulfill the request: " + e.getMessage());
			request.getRequestDispatcher("SaleError.jsp").forward(request, response); 
		}
	}

}