package css.webappdemopagecontroller.services;

import java.util.List;

import css.webappdemopagecontroller.persistence.DeliveryFinder;
import css.webappdemopagecontroller.persistence.DeliveryRowDataGateway;
import css.webappdemopagecontroller.persistence.PersistenceException;

/**
 * Handles delivery transactions. 
 * Each public method implements a transaction script.
 * 
 * @author nº48303
 * @author nº48349
 * @version
 *
 */
public enum DeliveryService {
	INSTANCE;
	
	public void insertDelivery(int saleid, int customerVAT, String delivery_address) throws ApplicationException {
		try {
			DeliveryRowDataGateway delivery = new DeliveryRowDataGateway(saleid,customerVAT,delivery_address);
			delivery.insert();
		} catch (PersistenceException e) {
				throw new ApplicationException ("Failed to add the new delivery", e);
		}
	}
	
	public DeliveryDTO getDeliveryBySaleId (int id) throws ApplicationException {
		try {
			DeliveryRowDataGateway delivery = new DeliveryFinder().getDeliveryBySaleId(id);
			return new DeliveryDTO(delivery.getDeliveryId(), delivery.getSaleId(), delivery.getCustomerVAT(), 
					delivery.getDeliveryAddress());
		} catch (PersistenceException e) {
				throw new ApplicationException ("Delivery with Id " + id + " not found.", e);
		}
	}
	
	public int getCustomerVATBySaleId(int saleid) throws PersistenceException {
		DeliveryRowDataGateway delivery = new DeliveryRowDataGateway(saleid);
		int customerVAT = delivery.getCustomerVATBySaleId();
		return customerVAT;
	}
	
	public List<String> getAddressBySaleId (int sale) throws ApplicationException {
		try {
			DeliveryRowDataGateway delivery = new DeliveryRowDataGateway();
			return delivery.getAddressBySaleId(sale);
		} catch (PersistenceException e) {
				throw new ApplicationException ("Sale with Id " + sale + " not found.", e);
		}
	}

	public List<List<String>> getDeliveriesByCustomerId(int cid) throws ApplicationException {
		try {
			DeliveryRowDataGateway delivery = new DeliveryRowDataGateway();
			return delivery.getDeliveriesByCustomerId(cid);
		} catch (PersistenceException e) {
				throw new ApplicationException ("Deliveries not found.", e);
		}
	}
}
