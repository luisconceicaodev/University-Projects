package css.webappdemopagecontroller.webpresentation;

import java.io.IOException;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import css.webappdemopagecontroller.services.ApplicationException;
import css.webappdemopagecontroller.services.SaleService;


/**
 * Servlet implementation class UpdateSaleStatusPageController
 * 
 * Handles the http get and post. Decides which model and view to use.
 * 
 * Decode the URL, extract any form data, decide action 
 * Create and invoke any model objects
 * Determine which view should display the result page 
 * (Forward information to it)
 * 
 */
@WebServlet("/UpdateSaleStatusPageController")
public class UpdateSaleStatusPageController extends PageController {

	private static final long serialVersionUID = 1L;

	@Override
	protected void process(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		SaleService ss = SaleService.INSTANCE;        

		SaleHelper sh = new SaleHelper();
		request.setAttribute("helper", sh);
		try{
			String param_id = request.getParameter("saleid");
			int id = intValue(param_id);
			ss.updateSaleStatus(id);
			sh.fillWithSale(ss.getSaleById(id));
			request.getRequestDispatcher("SaleInfo.jsp").forward(request, response);
		} catch (ApplicationException e) {
			sh.addMessage("It was not possible to fulfill the request: " + e.getMessage());
			request.getRequestDispatcher("SaleError.jsp").forward(request, response); 
		}
	}

}