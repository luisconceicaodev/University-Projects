package css.webappdemopagecontroller.persistence;

import java.sql.Date;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;


/**
 * Creates a sale row gateway by finding it from the database.
 *	
 * @author nº48303
 * @author nº48349
 *
 */
public class SaleFinder {
	
	/**
	 * The select sale by ID SQL statement
	 */
	private static final String GET_SALE_BY_ID_SQL = 
			   "select * from sale where id = ?";
	
	/**
	 * Gets a sale by its ID 
	 * 
	 * @param id The Sale's ID to search for
	 * @return The result set of the query
	 * @throws PersistenceException When there is an error getting the sale
	 * from the database.
	 */
	public SaleRowDataGateway getSaleById (int id) throws PersistenceException {
		try (PreparedStatement statement = DataSource.INSTANCE.prepare(GET_SALE_BY_ID_SQL)){
			statement.setInt(1, id);
			try (ResultSet rs = statement.executeQuery()) {
				rs.next();
				return new SaleRowDataGateway(rs);
			}
		} catch (SQLException e) {
			throw new PersistenceException("Internal error getting a sale by its id", e);
		}
	}
	
	/**
	 * The select sale by customer VAT SQL statement
	 */
	private static final String GET_SALE_BY_VAT_NUMBER_SQL = 
			   "select * from sale where CUSTOMER_VAT = ? ORDER BY id DESC LIMIT 1";
	
	/**
	 * Gets a sale by its CustomerVAT number 
	 * 
	 * @param vat The CustomerVAT to search for
	 * @return The result set of the query
	 * @throws PersistenceException When there is an error getting the sale
	 * from the database.
	 */
	public SaleRowDataGateway getSaleByCustomerVAT (int customerVAT) throws PersistenceException {
		try (PreparedStatement statement = DataSource.INSTANCE.prepare(GET_SALE_BY_VAT_NUMBER_SQL)){
			statement.setInt(1, customerVAT);
			try (ResultSet rs = statement.executeQuery()) {
				rs.next();
				return new SaleRowDataGateway(rs);
			}
		} catch (SQLException e) {
			throw new PersistenceException("Internal error getting a sale by its CustomerVAT number", e);
		}
	}
	
	/**
	 * The select sales by customer VAT SQL statement
	 */
	private static final String GET_SALES_BY_VAT_NUMBER_SQL = 
			   "select s.id, s.date, s.total, s.status, c.id from sale s, customer c where s.customer_vat = ? and c.vatnumber = ?";
	
	/**
	 * Gets all sales by their CustomerVAT 
	 * 
	 * @param vat The CustomerVAT to search for
	 * @return The result set of the query
	 * @throws PersistenceException When there is an error getting the sale
	 * from the database.
	 */
	public List<String> getSalesByCustomerVAT (int customerVAT) throws PersistenceException {
		try (PreparedStatement statement = DataSource.INSTANCE.prepare(GET_SALES_BY_VAT_NUMBER_SQL)){
			statement.setInt(1, customerVAT);
			statement.setInt(2, customerVAT);
			List<String> sales = new ArrayList<String>();
			ResultSet rs = statement.executeQuery();
			while (rs.next()) {
	            int sid = rs.getInt(1);
	            int cid = rs.getInt(5);
	            Date data = rs.getDate(2);
	            double total = rs.getDouble(3);
	            String status = rs.getString(4);
	            String sale = "Sale id: " + sid + " , " + "Customer id: " + cid + " , " + 
	            "Data: " + data + " , " + "Total: " + total + " , " +  "Status (O: Open, C: Closed): " + status;
	            sales.add(sale);
	        }
		return sales;
		} catch (SQLException e) {
			throw new PersistenceException("Internal error getting sales by CustomerVAT number", e);
		}
	}

}