package css.webappdemopagecontroller.persistence;

import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;


/**
 * Creates a delivery row gateway by finding it from the database.
 *	
 * @author nº48303
 * @author nº48349
 *
 */
public class DeliveryFinder {
	
	/**
	 * The select delivery by saleid SQL statement
	 */
	private static final String GET_DELIVERY_BY_SALEID_SQL = 
			   "select * from delivery where sale_id = ?";
	
	/**
	 * Gets a delivery by its saleid 
	 * 
	 * @param saleid The Delivery's saleid to search for
	 * @return The result set of the query
	 * @throws PersistenceException When there is an error getting the delivery
	 * from the database.
	 */
	public DeliveryRowDataGateway getDeliveryBySaleId (int saleid) throws PersistenceException {
		try (PreparedStatement statement = DataSource.INSTANCE.prepare(GET_DELIVERY_BY_SALEID_SQL)){
			statement.setInt(1, saleid);
			try (ResultSet rs = statement.executeQuery()) {
				rs.next();
				return new DeliveryRowDataGateway(rs);
			}
		} catch (SQLException e) {
			throw new PersistenceException("Internal error getting a delivery by its id", e);
		}
	}
}
