package business;

import dataaccess.WorkerRowDataGateway;
import presentation.CustomerService;
import presentation.SaleService;
import presentation.WorkerService;
import dataaccess.CustomerRowDataGateway;
import dataaccess.DeliveryRowDataGateway;
import dataaccess.PersistenceException;
import dataaccess.SaleRowDataGateway;


/**
 * Handles Delivery transactions. 
 * Each public method implements a transaction script.
 * 
 * @author n�45809
 * @author n�48303
 * @author n�48349
 *
 */
public class DeliveryTransactionScripts {
	
	/**
	 * Adds a new Delivery. 
	 * 
	 * @param id The id of the worker
	 * @param name The name of the worker
	 * @param type The type of the worker
	 * @param department The department of the worker
	 * @throws ApplicationException 
	 */
	
	public void addDelivery (SaleService sale, CustomerService customer, WorkerService salesman, String delivery_address) 
			throws ApplicationException {
		
		// Checks that delivery_address is filled
	    if (!isFilled (delivery_address))
	      throw new ApplicationException(
	             "Delivery Address must be filled");

		try {
			DeliveryRowDataGateway newDelivery = new DeliveryRowDataGateway (sale.toString(), customer.toString(), salesman.toString(), delivery_address);
			newDelivery.insert();
		} catch (PersistenceException e) {
				throw new ApplicationException ("Error inserting the delivery into the database", e);
		}
	}
	
	
	/**
	 * Checks is a string is filled
	 * 
	 * @param value The String to check
	 * @return true if the string is not empty (and not null!)
	 */
	private boolean isFilled(String value) {
		return value != null && !value.isEmpty();
	}
	
}