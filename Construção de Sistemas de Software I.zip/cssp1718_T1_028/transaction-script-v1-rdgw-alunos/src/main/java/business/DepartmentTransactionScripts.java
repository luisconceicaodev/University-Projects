package business;

import dataaccess.DepartmentRowDataGateway;
import dataaccess.PersistenceException;

/**
import dataaccess.DepartmentRowDataGateway;
import dataaccess.PersistenceException;
*/

/**
 * Handles Department transactions. 
 * Each public method implements a transaction script.
 * 
 * @author n�45809
 * @author n�48303
 * @author n�48349
 *
 */
public class DepartmentTransactionScripts {
	
	/**
	 * Adds a new Department. 
	 * 
	 * @param name The namer of the department
	 * @param phoneNumber The department phone number 
	 * @throws ApplicationException 
	 */
	
	public void addDepartment (String name, int phoneNumber, String[] workers, String manager)			throws ApplicationException {
		
		// Checks that name, manager and phoneNumber and filled in
	    if (!isFilled (name) || !isFilled(manager) || phoneNumber == 0)
	      throw new ApplicationException(
	             "Both name and phoneNumber must be filled");

		try {
			DepartmentRowDataGateway newDepartment = new DepartmentRowDataGateway (name, phoneNumber, workers, manager);
			newDepartment.insert();
		} catch (PersistenceException e) {
				throw new ApplicationException ("Error inserting the Department into the database", e);
		}
	}
	
	/**
	 * Checks is a string is filled
	 * 
	 * @param value The String to check
	 * @return true if the string is not empty (and not null!)
	 */
	private boolean isFilled(String value) {
		return value != null && !value.isEmpty();
	}
	
}