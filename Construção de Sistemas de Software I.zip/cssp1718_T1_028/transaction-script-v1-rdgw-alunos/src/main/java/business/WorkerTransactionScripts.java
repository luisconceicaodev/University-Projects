package business;

import dataaccess.WorkerRowDataGateway;
import dataaccess.PersistenceException;


/**
 * Handles Worker transactions. 
 * Each public method implements a transaction script.
 * 
 * @author n�45809
 * @author n�48303
 * @author n�48349
 *
 */
public class WorkerTransactionScripts {
	
	/**
	 * Adds a new Worker. 
	 * 
	 * @param id The id of the worker
	 * @param name The name of the worker
	 * @param department The department of the worker
	 * @throws ApplicationException 
	 */
	
	public void addWorker (String name, int department) 
			throws ApplicationException {
		
		// Checks that name and department and filled in
	    if (!isFilled (name))
	      throw new ApplicationException(
	             "Name, department and type must be filled");

		try {
			WorkerRowDataGateway newWorker = new WorkerRowDataGateway (name, department);
			newWorker.insert();
		} catch (PersistenceException e) {
				throw new ApplicationException ("Error inserting the worker into the database", e);
		}
	}
	
	/**
	 * Changes the department of a worker
	 * 
	 * @param id The id of the worker
	 * @param department_id The id of the department
	 */
	
	public void changeDepartment(int id, int department_id) throws ApplicationException{
		try {
			WorkerRowDataGateway worker = WorkerRowDataGateway.find(id);
			worker.updateWorkerDepartment(id, department_id);
		} catch (PersistenceException e) {
			throw new ApplicationException ("Error updating the worker department into the database", e);
		}
	}
	
	
	/**
	 * Checks is a string is filled
	 * 
	 * @param value The String to check
	 * @return true if the string is not empty (and not null!)
	 */
	private boolean isFilled(String value) {
		return value != null && !value.isEmpty();
	}
	
}