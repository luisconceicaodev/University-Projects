package client;

import java.sql.SQLException;
import java.util.Date;

import presentation.CustomerService;
import presentation.DeliveryService;
import presentation.DepartmentService;
import presentation.SaleService;
import presentation.WorkerService;
import SaleSys.SaleSys;
import business.ApplicationException;
import business.DiscountType;
import business.SaleStatus;
import dataaccess.SaleRowDataGateway;

/**
 * A simple application client that uses both services.
 *	
 * @author fmartins
 * @version 1.2 (11/02/2015)
 * 
 */
public class SimpleClient {

	/**
	 * A simple interaction with the application services
	 * 
	 * @param args Command line parameters
	 */
	public static void main(String[] args) {
		
		SaleSys app = new SaleSys();
		try {
			app.run();
		} catch (ApplicationException e) {
			System.out.println(e.getMessage());
			System.out.println("Application Message: " + e.getMessage());
			SQLException e1 = (SQLException) e.getCause().getCause();
			System.out.println("SQLException: " + e1.getMessage());
			System.out.println("SQLState: " + e1.getSQLState());
			System.out.println("VendorError: " + e1.getErrorCode());
			return;
		}
			
		// Access both available services
		CustomerService cs = app.getCustomerService();
		SaleService ss = app.getSaleService();	
		DepartmentService dd = app.getDepartmentService();
		WorkerService ww = app.getWorkerService();
		DeliveryService ds = app.getDeliveryService();
		
		// the interaction
		try {
			
			cs.addCustomer(168027852, "Customer 1", 217500255, DiscountType.SALE_AMOUNT, new String[] {"Rua 1","Rua 2"});

			// creates a new sale
			int sale = ss.newSale(168027852);

			// adds two products to the database
			ss.addProductToSale(sale, 123, 10);
			
			dd.addDepartment("Logistica", 123456789, new String[] {"Mario","Gabriel"}, "Mario");
			dd.addDepartment("Finan�as", 123456788, new String[] {"Tiago","Joana"}, "Tiago");
			ww.addWorker("Gabriel", 1);
			ww.changeDepartment(1, 2);
			ds.addDelivery(ss, cs, ww, "Rua 1");
			
		} catch (ApplicationException e) {
			System.out.println("Error: " + e.getMessage());
			// for debugging purposes only. Typically, in the application
			// this information can be associated with a "details" button when
			// the error message is displayed.
			if (e.getCause() != null) 
				System.out.println("Cause: ");
			e.printStackTrace();
		}
	
		app.stopRun();
		
	}
}
