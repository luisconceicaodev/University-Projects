package presentation;

import business.ApplicationException;
import business.DeliveryTransactionScripts;
import dataaccess.CustomerRowDataGateway;
import dataaccess.SaleRowDataGateway;
import dataaccess.WorkerRowDataGateway;


public class DeliveryService {

	private DeliveryTransactionScripts deliveryTS;

	public DeliveryService(DeliveryTransactionScripts deliveryTS) {
		this.deliveryTS = deliveryTS;
	}
	
	public void addDelivery (SaleService sale, CustomerService customer, WorkerService salesman, String delivery_address) 
			throws ApplicationException {
		deliveryTS.addDelivery(sale, customer, salesman, delivery_address );
	}
}