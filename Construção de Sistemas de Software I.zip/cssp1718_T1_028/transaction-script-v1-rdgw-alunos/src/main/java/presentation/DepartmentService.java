package presentation;

import business.ApplicationException;
import business.DepartmentTransactionScripts;


public class DepartmentService {

	private DepartmentTransactionScripts departmentTS;

	public DepartmentService(DepartmentTransactionScripts departmentTS) {
		this.departmentTS = departmentTS;
	}
	
	public void addDepartment(String name, int phoneNumber, String[] workers, String manager) throws ApplicationException {
		departmentTS.addDepartment(name, phoneNumber, workers, manager);
	}
}