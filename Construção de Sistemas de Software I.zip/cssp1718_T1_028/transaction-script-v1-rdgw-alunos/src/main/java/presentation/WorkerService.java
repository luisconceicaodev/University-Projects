package presentation;

import business.ApplicationException;
import business.WorkerTransactionScripts;


public class WorkerService {

	private WorkerTransactionScripts workerTS;

	public WorkerService(WorkerTransactionScripts workerTS) {
		this.workerTS = workerTS;
	}
	
	public void addWorker(String name, int department) throws ApplicationException {
		workerTS.addWorker(name, department);
	}
	
	public void changeDepartment(int id, int department_id) throws ApplicationException {
		workerTS.changeDepartment(id, department_id);
	}
}