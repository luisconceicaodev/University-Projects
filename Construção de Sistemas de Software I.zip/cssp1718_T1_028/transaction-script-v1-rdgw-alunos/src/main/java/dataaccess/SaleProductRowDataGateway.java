	package dataaccess;

import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import java.util.HashSet;
import java.util.Set;

/**
 * An in-memory representation of a row gateway for the products composing a sale.	
 * 
 * @author 
 * @version 
 *
 */
public class SaleProductRowDataGateway {
	
	private int product_id;
	private double qty;
	private int id;
	
	
	/**
	 * The insert product in a sale SQL statement
	 */
	private static final String INSERT_PRODUCT_SALE_SQL = 
			"insert into saleProduct (id, product_id, qty)" + "values(?,?,?)"; 

	
	/**
	 * The select the products of a sale by sale Id SQL statement
	 */
	private static final String GET_SALE_PRODUCTS_SQL = 
			"select (id, product_id, qty)" + "from saleProduct" + "where id= ?"; 	

	
public SaleProductRowDataGateway(int id, int product_id, double qty) {
		
		this.product_id = product_id;
		this.qty = qty;
	}


	// 3. getters and setters
	public int getProductId() {
		return product_id;
	}

	public double getQty() {

		return qty;
	}

	// 4. interaction with the repository (a relational database in this simple example)

	/**
	 * Inserts the record in the products sale 
	 */
	public void insert () throws PersistenceException {
		try(PreparedStatement statement = DataSource.INSTANCE.prepareGetGenKey(INSERT_PRODUCT_SALE_SQL)){
			statement.setInt(1, id);
			statement.setInt(2, product_id);
			statement.setDouble(3, qty);
			statement.executeUpdate();
			
			try(ResultSet rs = statement.getGeneratedKeys()){
				rs.next();
				id = rs.getInt(1);
			}
		} catch (SQLException e) {
		
			throw new PersistenceException ("Internal error!", e);
		}
	}
	

	
	
	/**
	 * Gets the products of a sale by its sale id 
	 * 
	 * @param saleId The sale id to get the products of
	 * @return The set of products that compose the sale
	 * @throws PersistenceException When there is an error obtaining the
	 *         information from the database.
	 */
	public static Set<SaleProductRowDataGateway> findSaleProducts (int saleId) throws PersistenceException {
		try (PreparedStatement statement = DataSource.INSTANCE.prepare(GET_SALE_PRODUCTS_SQL)) {			
			// set statement arguments
			statement.setInt(1, saleId);
			// executes SQL
			try (ResultSet rs = statement.executeQuery()) {
				// creates a new customer from the data retrieved from the database
				return loadSaleProduct(rs);
			}
		} catch (SQLException e) {
			throw new PersistenceException("Internal error getting a product by its id", e);
		} 
	}
	
	private static Set<SaleProductRowDataGateway> loadSaleProduct(ResultSet rs) throws RecordNotFoundException {
		Set<SaleProductRowDataGateway> set = new HashSet<>();
		try { 
			while(rs.next()) {
				SaleProductRowDataGateway newsp = new SaleProductRowDataGateway(rs.getInt("saleId"), rs.getInt("productId"), rs.getDouble("qty"));
				newsp.id= rs.getInt("id");
				set.add(newsp);
				
			}
			return set;
		}catch(SQLException e) {
			throw new RecordNotFoundException ("Product does not exist", e);
			
		}
	}	
}