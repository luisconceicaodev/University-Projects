package dataaccess;


import java.util.Date;

import business.SaleStatus;

import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;



/**
 * An in-memory representation of a customer table record. 
 *	
 * Notes:
 * 1. See the notes for the CustomerRowGateway class
 * 
 * 2. Java makes available two Date classes (in fact, more in Java 8, 
 * but we will address it later (with JPA)): one in the package 
 * java.util, which is the one we normally use, and another in
 * java.sql, which is a subclass of java.util.date and that 
 * transforms the milliseconds representation according to the
 * "Date type of databases". For more information refer to 
 * http://download.oracle.com/javase/6/docs/api/java/sql/Date.html.
 * 
 * 3. When creating a new sale, we only pass the date and customer id 
 * parameters to the constructor. Moreover, attribute open is always 
 * set to 'O'. The remaining attributes are either set automatically (id) 
 * or when closing the sale (totalSale and totaldiscount_total). Also, the open 
 * attribute is set to 'C' upon payment. 
 * 
 * @author fmartins
 * @Version 1.2 (13/02/2015)
 *
 */
public class SaleRowDataGateway {

	// Sale attributes 

	private int id;
	private String status;
	private double discount_total;
	private int customerId;
	@SuppressWarnings("unused")
	private Date date;
	@SuppressWarnings("unused")
	private double total;
	
	

	/**
	 * The select a sale by Id SQL statement
	 */
	private static final String GET_SALE_SQL = 
			" select id, date, total, discount_total, status, customer_Id " + "from sale" + " where id = ?";

	/**
	 * The insert sale SQL statement
	 */
	private static final String INSERT_SALE_SQL = 
			"insert into sale (id, date, total, discount_total, status, customer_Id) " + "values (DEFAULT,?,0,0,'O',?)"; 

	private static final String OPEN = "O";
	private static final String CLOSED = "C";

	// 1. constructor 

	/**
	 * Creates a new sale given the customer Id and the date it occurs.
	 * 
	 * @param customerId The customer Id the sale belongs to
	 * @param date The date the sale took place
	 */
	public SaleRowDataGateway(Date date, double total, double discount_total, String status, int customerId) {
		this.date = date;
		this.total = total;
		this.discount_total = discount_total;
		this.status = status;
		this.customerId = customerId;
		
	}

	// 2. getters and setters

	public int getId() {
		
		return id;
	}

	public String getStatus() {

		return status;
	}

	public int getCustomerId() {

		return customerId;
	}

	public double getDiscount() {

		return discount_total;
	}

	public SaleStatus getStatusSale() {
		return status == OPEN ? SaleStatus.OPEN : SaleStatus.CLOSED;
	}
	
	public void setStatus(SaleStatus status) {
		this.status = status == SaleStatus.OPEN ? "O":"C";
	}
	/**
	 * Stores the information in the repository
	 */
	public void insert () throws PersistenceException {	
		try(PreparedStatement statement = DataSource.INSTANCE.prepareGetGenKey(INSERT_SALE_SQL)){
			java.util.Date utilDate = date;
			java.sql.Date sqlStartDate = new java.sql.Date(utilDate.getTime());
			statement.setDate(1, sqlStartDate);
			statement.setInt(2, customerId);
			// executes SQL
			statement.executeUpdate();
			// Gets sale Id generated automatically by the database engine
			try (ResultSet rs = statement.getGeneratedKeys()) {
				rs.next(); 
				id = rs.getInt(1);
			}
		}catch(SQLException e) {
			throw new PersistenceException ("Internal error!", e);
			
		}
		
	}

	/**
	 * Gets a sale by its id 
	 * 
	 * @param id The sale id to search for
	 * @return The new object that represents an in-memory sale
	 * @throws PersistenceException In case there is an error accessing the database.
	 */
	public static SaleRowDataGateway find (int id) throws PersistenceException {
		try (PreparedStatement statement = DataSource.INSTANCE.prepare(GET_SALE_SQL)) {			
			
			statement.setInt(1, id);
		
			try (ResultSet rs = statement.executeQuery()) {
				return loadSale(rs);
			}
		} catch (SQLException e) {
			throw new PersistenceException("Internal error getting a sale by its id", e);
		}
	}
	
	private static SaleRowDataGateway loadSale(ResultSet rs) throws RecordNotFoundException {
		try {
			
			rs.next();
			SaleRowDataGateway newSale = new SaleRowDataGateway(rs.getDate("date"),rs.getDouble("total"),rs.getDouble("discount_total"),rs.getString("status"),rs.getInt("customer_Id"));
			newSale.id = rs.getInt("id");
			newSale.date = rs.getDate("date");
			newSale.total = rs.getDouble("total");
			newSale.discount_total = rs.getDouble("discount_total");
			newSale.status = rs.getString("status");
			newSale.customerId = rs.getInt("customer_Id");
			return newSale;
		} catch (SQLException e) {
			throw new RecordNotFoundException ("Sale does not exist", e);
		}
	}

	public static String getClosed() {
		return CLOSED;
	}


}