package fcul.pco.dentalclinic.domain;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;
import java.util.TreeMap;

/**
 * The class represents the sets of Patients.
 * 
 * @author Catarina Leote 51705
 * @author Luis Conceicao 48303
 *
 */

public class PatientCatalog {
	private TreeMap<Integer,Patient> patientCatalog;
	static PatientCatalog instance;

	/**
	 * Creates an empty catalog.
	 */
	private PatientCatalog() {
		patientCatalog = new TreeMap<Integer, Patient>();
	}

	/**
	 * PatientCatalog instance
	 * @return instance 
	 */
	public static PatientCatalog getInstance() {
		if (instance == null) {
			instance = new PatientCatalog();
		}
		return instance;
	}

	/**
	 * Adds a patient to the catalog.
	 * @param p
	 * @requires A Patient instance
	 * @ensures TreeMap with the patient instance added
	 */
	public void addPatient (Patient p) {
		int key = p.getSns();
		patientCatalog.put(key, p);
	}

	/**
	 * Loads the patient catalog from the PatientCatalog class
	 * @throws IOException if a patientcatalog doenst exist
	 */
	public void load() throws IOException {
		patientCatalog = fcul.pco.dentalclinic.persistence.PatientCatalog.load();
	}

	/**
	 * Saves the patient catalog 
	 * @throws IOException if a patientcatalog doenst exist
	 */
	public void save() throws IOException {
		fcul.pco.dentalclinic.persistence.PatientCatalog.save(patientCatalog);
	}
	
	/**
	 * Returns the patient catalog 
	 * @param sns The Sns number to identify the patient
	 * @return The patient catalog for that sns number
	 */
	public Patient getPatientById (int sns) {
		return patientCatalog.get(sns);
	}
	
	/**
	 * Returns a table with the patient parameters as a string
	 */
	public String toString() {
		List<List<String>> table = new ArrayList<>();
		for (Patient p : patientCatalog.values()) {
			ArrayList<String> row = new ArrayList<>();
			row.add(String.valueOf(p.getSns()));
			row.add(p.getName());
			table.add(row);
		}
		return Utils.tableToString(table);
	}
	
}
