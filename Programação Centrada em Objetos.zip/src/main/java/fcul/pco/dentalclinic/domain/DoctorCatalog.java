package fcul.pco.dentalclinic.domain;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;
import java.util.TreeMap;

/**
 * The class represents the sets of Doctors.
 * 
 * @author Catarina Leote 51705
 * @author Luis Conceicao 48303
 *
 */

public class DoctorCatalog {
	
	private TreeMap<Integer,Doctor> doctorCatalog;
	static DoctorCatalog instance;
	
	/**
     * Creates an empty catalog.
     */
	private DoctorCatalog() {
    	doctorCatalog = new TreeMap<Integer, Doctor>();
    }
	
	/**
	 * DoctorCatalog instance
	 * @return instance 
	 */
	public static DoctorCatalog getInstance() {
		if (instance == null) {
			instance = new DoctorCatalog();
		}
		return instance;
	}
	
	/**
     * Adds a doctor to the catalog.
     * @param d
     * @requires Uma instancia Doctor
     * @ensures TreeMap com a instancia Doctor adicionada 
     */
	public void addDoctor (Doctor d) {
		int key = d.getId();
		doctorCatalog.put(key, d);
	}
	
	/**
     * Given an id, the corresponding doctor is returned. 
     * 
     * @param id a int that contains the id 
     * @return an instance of doctor
     * @requires a int with a doctor's id
     * @ensures returns the doctor with the associated id
     * 
     */
	public Doctor getDoctorById(int id) {
		return doctorCatalog.get(id);
	}
	
	@Override
	/**
	 * Returns de doctor catalog as a string
	 */
	public String toString() {
		List<List<String>> table = new ArrayList<>();
		for (Doctor d : doctorCatalog.values()) {
			ArrayList<String> row = new ArrayList<>();
			row.add(String.valueOf(d.getId()));
			row.add(d.getName());
			table.add(row);
		}
		return Utils.tableToString(table);
	}

	
	/**
	* Saves a catalog to a file.
	*
	* @throws IOException
	*/
	public void save() throws IOException {
		fcul.pco.dentalclinic.persistence.DoctorCatalog.save(doctorCatalog);
	}
	
	/**
	* Loads a catalog from a file and returns a catalog instance.
	*
	* @throws IOException
	*/
	public void load() throws IOException {
		doctorCatalog = fcul.pco.dentalclinic.persistence.DoctorCatalog.load();
	}
	
	
}
