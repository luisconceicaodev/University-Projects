package fcul.pco.dentalclinic.domain;

import java.util.ArrayList;

/**
 * Handles Doctor functions.
 * 
 * @author Catarina Leote 51705
 * @author Luis Conceicao 48303
 *
 */
public class Doctor {
	private int id;
	private String name;
	private Agenda agenda;
	
	/**
	* Make a new Doctor. 
	* @param ArrayList<Appointment>
	*/
	public Doctor(int id, String name, Agenda agenda) {
		this.id = id;
		this.name =  name;
		this.agenda = agenda;
	}

	/**
	 * @return name
	 */
	public String getName() {
		return name;
	}
	
	/**
	 * @return agenda
	 */
	public Agenda getAgenda() {
		return agenda;
	}
	
	/**
	 * @return id
	 */
	public int getId() {
		return id;
	}
	
	
	@Override
	/**
	 * Return the doctor parameters as a string
	 */
	public String toString() {
		return id + "," + name + "," + agenda ;
	}
	
	/**
     * Creates a Doctor instance from a string.
     * 
     * @param s: a string that contains the id, the doctor's name, 
     * and the agenda. 
     * @return an Doctor instance
     * @requires s is a string that contains the Id, the doctor's name and the agenda
     * separated by commas (,). The string must contain at least three commas.
     */
	public static Doctor fromString(String s) {
		String [] a = s.split(",");
		int doc_id = Integer.parseInt(a[0]);
		String doc_name = a[1];
		ArrayList<Appointment> array = new ArrayList<Appointment>();
		Agenda empty = new Agenda(array);
		if(!(a[2].equals("[]"))) {
			String astrAppointments1 = a[2];
			String astrAppointments = astrAppointments1.replaceAll(";", "");
			String strAppointments1 = astrAppointments.substring(1, astrAppointments.length()-1);
			String strAppointments = strAppointments1.replaceAll(" ", "");
			String[] arrayAppointments = strAppointments.split("-");
			for(int i=0;i<arrayAppointments.length;i++) {
				String[] parametrosAppointment = arrayAppointments[i].split("/");
				String[] day_hour = parametrosAppointment[2].split("@");
				String[] parametrosData = day_hour[1].split(":");
				int ano = Integer.parseInt(parametrosAppointment[0]);
				int mes = Integer.parseInt(parametrosAppointment[1]);
				int dia = Integer.parseInt(day_hour[0]);
				int hora = Integer.parseInt(parametrosData[0]);
				int minuto = Integer.parseInt(parametrosData[1]);
				Date data = new Date(ano, mes, dia, hora, minuto);
				PatientCatalog pat = PatientCatalog.getInstance();
	        	Patient patient = pat.getPatientById(Integer.parseInt((parametrosAppointment[5])));
				Appointment ap = new Appointment(data, parametrosAppointment[3], Integer.parseInt(parametrosAppointment[4]),patient);
				array.add(ap);
			}
			
			Agenda doc_agenda = new Agenda(array);
			return new Doctor(doc_id, doc_name, doc_agenda);
		}else {
			return new Doctor(doc_id, doc_name, empty);
		}
	}
}
