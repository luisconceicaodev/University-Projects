package fcul.pco.dentalclinic.domain;

import java.io.IOException;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Iterator;
import java.util.List;

import fcul.pco.dentalclinic.persistence.AgendaPersistence;

/**
 * Handles Agenda functions.
 * 
 * @author Catarina Leote 51705
 * @author Luis Conceicao 48303
 *
 */
public class Agenda implements Iterable<Appointment>{ 
	private ArrayList<Appointment> apts = new ArrayList<Appointment>();

	/**
	 * Make a new Agenda. 
	 * @param ArrayList<Appointment>
	 */
	public Agenda(ArrayList<Appointment> appointments) {
		this.apts = appointments;
	}
	
	/**
	 *Make a new Agenda without previously known appointments list.
	 */
	public Agenda() {
	}
	
	@Override
	
	/**
	 * Returns the iterator corresponding to the appointments list
	 */
	public Iterator<Appointment> iterator() {
		return apts.iterator();
	}

	
	/**
	 * Adds an appointment to the ArrayList appointments
	 * @param a An appointment
	 */
	public void addAppointment (Appointment a) {
		apts.add(a);
	}

	/**
	 * @return A string with the agenda parameters
	 */
	public String toString() {
		String str = apts.toString();
		String nocomma = str.replaceAll(",", "-");
		return nocomma;
	}

	/**
	 * @return a list with all the appointments
	 
	public List<Appointment> getAppointments(){
		return appointments;
	}
	*/

	/**
	 * Saves a doctor into a .csv file
	 * @param d A doctor
	 * @throws IOException
	 */
	public void save(Doctor d) throws IOException {
		AgendaPersistence.save(d);
	}
	
	/**
	 * Loads a doctors agenda from a .cvs file
	 * @param d A doctor
	 * @return A new agenda for the doctor d
	 * @throws IOException
	 */
	public static Agenda load(Doctor d) throws IOException {
		return AgendaPersistence.load(d);
	}
	
	/**
	 * Gets a list of the next dates for the appointments
	 * @param from A date
	 * @return An ArrayList with the appointment dates
	 */
	public List<Date> getNextAppointmentDates(Date from) {
		List<Date> fromApp = new ArrayList<Date>();
		for(Appointment a : apts) {
			Date cycleDate = a.getDate();
			if (cycleDate.afterOrEquals(from)) {
				fromApp.add(cycleDate);
			}
		}
		return fromApp;
	}
	
	/**
	 * Gets a list of the appointments for the day d
	 * @param d A day
	 * @return An ArrayList with the appointment dates
	 */
	public List<Appointment> getDayAppointments(Date d) {
		List<Appointment> list = new ArrayList<>();
		for(Appointment a: apts) {
			if(a.getDate().sameDay(d)) {
				list.add(a);
			}
		}
		Collections.sort(list);
		return list;
	}

}
