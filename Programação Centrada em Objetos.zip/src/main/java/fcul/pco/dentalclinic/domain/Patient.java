package fcul.pco.dentalclinic.domain;

/**
 * Handles Patient functions.
 * 
 * @author Catarina Leote 51705
 * @author Luis Conceicao 48303
 *
 */

public class Patient {
	private String name;
	private int sns;
	
	/**
	* Make a new Patient. 
	* @param name, the patient name
	* @param int, the patient sns
	*/
	public Patient(int sns, String name) {
		this.name = name;
		this.sns = sns;
	}
	
	@Override
	/**
	 * Returns the patient parameters as a string
	 */
	public String toString() {
		return name + "!" + sns;
	}
	
	/**
     * Creates a Patient instance from a string.
     * 
     * @param s: a string that contains the name and the sns. 
     * @return an Patient instance
     * @requires s is a string that contains the name and the sns
     * separated by commas (,). The string must contain at least two commas.
     */
	public static Patient fromString(String s) {
		String [] pt_array = s.split(",");
		String pt_name = pt_array[0];
		int pt_sns = Integer.parseInt(pt_array[1]);
    	return new Patient(pt_sns,pt_name);
	}
	
	/**
	 * @return the Sns number of the patient
	 */
	public int getSns() {
		return sns;
	}
	
	/**
	 * @return the name of the patient
	 */
	public String getName() {
		return name;
	}
}
