package fcul.pco.dentalclinic.domain;

import java.util.ArrayList;
import java.util.List;

/**
 * Handles Appointment functions.
 * 
 * @author Catarina Leote 51705
 * @author Luis Conceicao 48303
 *
 */
public class Appointment implements Comparable<Appointment>{
	private Date date;
	private String subject;
	private int duration;
	private Patient patient;
	
	/**
	* Make a new Appointment. 
	* @param date
	* @param subject
	* @param duration
	*/
	public Appointment (Date date, String subject, int duration, Patient patient) {
		this.date =  date;
		this.subject = subject;
		this.duration = duration;
		this.patient = patient;
	}
	
	/**
	 * @return date
	 */
	public Date getDate() {
		return date ;
	}
	
	/**
	 * @return subject
	 */
	public String getSubject() {
		return subject;
	}
	
	/**
	 * @return duration
	 */
	public int getDuration() {
		return duration;
	}
	
	/**
	 * @return patient
	 */
	public Patient getPatient() {
		return patient;
	}

	@Override
	/**
	 * @return A string with the appointment parameters
	 */
	public String toString(){
		 return date.toString()+"/"+subject+"/"+duration+"/"+patient.getSns();
	}
	
	/**
     * Creates a Appointment instance from a string.
     * @param s A string that contains the date, the name, the id, the time and the patient sns 
     * and the agenda. 
     * @return An Appointment instance
     * @requires s Is a string that contains the date, the name, the id, the time and the patient sns 
     */
	public static Appointment fromString(String s) {
		String [] a = s.split("/");
		String [] parametrosData = a[0].split(":");
		int hora = Integer.parseInt(parametrosData[0]);
		int minuto = Integer.parseInt(parametrosData[1]);
		int dia = Integer.parseInt(parametrosData[2]);
		int mes = Integer.parseInt(parametrosData[3]);
		int ano = Integer.parseInt(parametrosData[4]);
		Date data = new Date(ano, mes, dia, hora, minuto);
		PatientCatalog pat = PatientCatalog.getInstance();
		Appointment app = new Appointment(data, a[1], Integer.parseInt(a[2]),pat.getPatientById(Integer.parseInt(a[3])));
		return app;
	}
	
	/**
     * Creates a List<String> with the values of appointment
     * @return List<String> 
     */
	public List<String> toRow() {
		List<String> toRow = new ArrayList<>();
		Appointment app = this;
		String appStr = app.getDate() + "/" + app.getSubject() + "/" + app.getDuration() + "/" + app.getPatient();
		toRow.add(appStr);
		return toRow;
	}

	@Override
	/**
	 * Compares the appointment o with this appointment
	 * @param o An appointment
	 * @return 0 if the appointment is in the same date as this appointment
	 * @return 1 if the appointment is after this appointment
	 * @return -1 if the appointment is before this appointment
	 */
	public int compareTo(Appointment o) {
		if(this.getDate().sameDate(o.getDate()))
			return 0;
		else if(this.getDate().afterOrEquals(o.getDate()))
			return 1;
		else return -1;
	}
	

}

