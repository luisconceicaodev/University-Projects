package fcul.pco.dentalclinic.domain;

import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.GregorianCalendar;
import java.util.List;

/**
 * Handles Date functions.
 * 
 * @author Catarina Leote 51705
 * @author Luis Conceicao 48303
 *
 */
public class Date {
	private int year, month, day, hour, minute;

	/**
	 * Array with Holidays dates
	 */
	private static final Date[] HOLIDAYS = {
			new Date(1, 1), //New Year's Day
			new Date(4, 25), //Liberty Day
			new Date(5, 1), //Labour Day
			new Date(6, 10), //Portugal Day
			new Date(6, 15), //Corpus Christi
			new Date(8, 15), //Assumption of Mary
			new Date(10, 5), //Republic Implantation
			new Date(11, 1), //All Saints Day
			new Date(12, 1), //Restoration of Independence
			new Date(12,8), //Feast of the Immaculate Conception
			new Date(12, 25), //Christmas Day
	};

	/**
	 * Establish that the start date will be 1 of January of 2000
	 */
	private static final Date STARTDATE = new Date(2000, 1, 1);

	/**
	 * Start date in number of base
	 */
	private static final int STARTDATEINT = STARTDATE.intValue();

	/**
	 * Make a new date. The hour and minute are set to zero.
	 * @param y
	 * @param m
	 * @param d
	 * @requires Date.isValidDate(y, m, d)
	 * @ensures getYear() == y && getMonth() == m && getDay() == d &&
	 * getHour() == 0 && getMinute() == 0
	 */
	public Date(int y, int m, int d) {
		year = y;
		month = m;
		day = d;
	}
	
	/**
	 * Make a new date.
	 * @param y 
	 * @param m
	 * @param d
	 * @param h
	 * @param min
	 * @requires Date.isValidDate(y, m, d, h, min)
	 * @ensures getYear() == y && getMonthe() == m && getDay() == d &&
	 * getHour() == h && getMinute() == min
	 */
	public Date(int y, int m, int d, int h, int min) {
		year = y;
		month = m;
		day = d;
		hour = h;
		minute = min;
	}

	/**
	 * Make a new date.
	 * @param m
	 * @param d
	 * @requires Date.isValidDate(m, d)
	 * @ensures getMonth() == m && getDay() == d
	 */
	private Date(int m, int d) {
		month = m;
		day = d;
	}

	/**
	 * @return day
	 */
	public int getDay() {
		return day;
	}

	/**
	 * @return month
	 */
	public int getMonth() {
		return month;
	}

	/**
	 * @return year
	 */
	public int getYear() {
		return year;
	}

	/**
	 * @return hour
	 */
	public int getHour() {
		return hour;
	}

	/**
	 * @return minute
	 */
	public int getMinute() {
		return minute;
	}

	/**
	 * Returns the current date as a string
	 * @return date in string format
	 */
	@Override
	public String toString(){
		return year+"/"+month+"/"+day+"@"+hour+":"+minute;
	}

	/**
	 * Creates a Date instance from a string.
	 * @param s: a string that contains the year, the month, the day, the hour and minute
	 * @return an Date instance
	 * @requires s is a string that contains the year, the month, the day, the hour and minute
	 * separated by / and @. The string must contain at least two / and one @.
	 */
	public static Date fromString(String s) {
		String [] DateArray = s.split("/");
		String [] day_clock = DateArray[2].split("@");
		String [] hour_minute = day_clock[1].split(":");
		int year = Integer.parseInt(DateArray[0]);
		int month = Integer.parseInt(DateArray[1]);
		int day = Integer.parseInt(day_clock[0]);
		int hour = Integer.parseInt(hour_minute[0]);
		int minute = Integer.parseInt(hour_minute[1]);
		Date d = new Date(year,month,day,hour,minute);
		return d;
	}

	/**
	 * Compares if the other date is equal to the this date
	 * @param other
	 * @return True if this date is equal to other date and False if it isn't
	 */
	public boolean sameDay(Date other) {
		return this.day == other.getDay() && this.month == other.getMonth();
	}

	/**
	 * Checks if this date is an holiday
	 * @return True if this date is an element of holidays array and False if it isn't
	 */
	public boolean isHoliday() {
		for(int i=0;i<HOLIDAYS.length;i++) {
			if(sameDay(HOLIDAYS[i]))
				return true;
		}
		return false;
	}

	/**
	 * Tests if the year is a leap year
	 * @param year
	 * @return True if it's a leap year and False if it isn't
	 */
	private static boolean isLeapYear(int year) {
		return (year%100 == 0 && year%400==0) || (year%100!=0 && year%4==0);
	}

	/**
	 * Return the days in month for leap years and for the different months
	 * @param month
	 * @param year
	 * @return number of days in the given month
	 */
	private static int daysInMonth(int month, int year) {
		if(month==2) {
			if(isLeapYear(year))
				return 29;
			else
				return 28;
		}

		if(month == 1 || month == 3 || month == 5 || month == 7 || month == 8 || month == 10 || month == 12)
			return 31;
		else
			return 30;

	}

	/**
	 * Returns the number of days in the year
	 * @param year
	 * @return 366 days if it is a leap year and 365 days if it isn't
	 */
	private static int daysInYear(int year) {
		if(isLeapYear(year))
			return 366;
		else
			return 365;
	}

	/**
	 * Calculate the number of minutes since the startdate
	 * @return the number of minutes
	 */
	private int intValue() {
		int value = minute;
		value += hour * 60;
		value += (day - 1) * 1440;
		for (int m = 1; m < month; m++) {
			value += daysInMonth(m, year) * 1440;
		}
		for (int y = STARTDATE.year; y < year; y++) {
			value += daysInYear(y) * 1440;
		}
		return value - STARTDATEINT;
	}

	/**
	 * Calculate the number of days since the start date
	 * @return number of days since the start date
	 */
	private int daysSinceStartDate() {
		return this.intValue()/1440;
	}

	/**
	 * Returns the day of the week (0 is monday and 6 is sunday)
	 * @return day of the week (0 is monday and 6 is sunday)
	 */
	public int dayOfWeek() {
		return ((daysSinceStartDate()%7)+5)%7;
	}

	/**
	 * @return The current date
	 */
	public static Date getCurrentDate() {
		LocalDateTime now = LocalDateTime.now();
		return new Date(now.getYear(), now.getMonthValue(),
				now.getDayOfMonth(), now.getHour(), now.getMinute());
	}

	/**
	 * Return the next day at 9 am
	 * @param now The current date
	 * @return The tomorrow Date
	 */
	public static Date getTomorrowMorning(Date now) {
		Date tomorrow = now.addMinutes(24*60);
		tomorrow.setHour(9);
		tomorrow.setMinute(0);
		return tomorrow;

	}

	/**
	 * Changes the minutes of a date
	 * @param minute The minutes to set
	 */
	private void setMinute(int minute) {
		this.minute = minute;
	}
	
	/**
	 * Tests if the day is available excluding a list of Dates, if it is a holiday or a day of the weekend
	 * @param exclude A list of dates do exclude
	 * @param date A date
	 * @return True if the day is available
	 * @return False if the day isn't available
	 */
	public boolean isAvailable(List<Date> exclude, Date date) {
		for(Date data:exclude) {
			if(date.sameDay(data)) {
				return false;
			}
		}
		if(date.isHoliday() || date.dayOfWeek()==6 || date.dayOfWeek()==5 || date.getHour()>18) {
			return false;
		}
		return true;	
	}

	@SuppressWarnings("deprecation")
	/**
	 * Calculate a new date with an increment of minutes
	 * @param every The increment in minutes
	 * @return The new date with the increment
	 */
	public Date addMinutes(int every) {
		long time = 946684800000L;
		Calendar c = new GregorianCalendar();
		long datamin = this.intValue();
		long datamilisec = time + (datamin*60000L);
		java.util.Date d = new java.util.Date(datamilisec);
		c.setTime(d);
		c.add(Calendar.MINUTE, every);
		java.util.Date novaData = c.getTime();
		return new Date(novaData.getYear()+1900,novaData.getMonth()+1,novaData.getDate(),novaData.getHours(),novaData.getMinutes());
	}

	@SuppressWarnings("deprecation")
	/**
	 * Calculate a new Date with less days
	 * @param days Then number of days to subtract
	 * @return The new date days before
	 */
	public Date subtractDays(int days) {
		Calendar c = new GregorianCalendar();
		long time = 946684800000L;
		long datamin = this.intValue();
		long datamilisec = time + (datamin*60000L);
		java.util.Date d = new java.util.Date(datamilisec);
		c.setTime(d);
		c.add(Calendar.DATE, -days);
		java.util.Date novaData = c.getTime();
		return new Date(novaData.getYear()+1900,novaData.getMonth()+1,novaData.getDate(),novaData.getHours(),novaData.getMinutes());
	}
	
	/**
	 * Changes the hours of a date
	 * @param hour The hours to set 
	 */
	public void setHour(int hour) {
		this.hour=hour;
	}
	
	/**
	 * Returns the correct date to schedule an appointment
	 * @param date
	 * @param exclude
	 * @return The correct date to schedule an appointment
	 */
	public Date getCorrectDay(Date date, List<Date> exclude) {
		Date tomorrow = Date.getTomorrowMorning(date);
		while(!isAvailable(exclude, tomorrow)) {
			System.out.println("tomorrow1 "+tomorrow);
			tomorrow= Date.getTomorrowMorning(tomorrow);
			System.out.println("tomorrow2 "+tomorrow);
		}
		return tomorrow;
	}
	
	/**
	 * Makes the list with the available Dates to schedule an appointment
	 * @param every The increment that is the duration of an appointment
	 * @param exclude The list of dates to exclude thant the appointments can not be schedule
	 * @return A list with the 10 Dates to schedule the appointments
	 */
	public List<Date> makeSmartDateList(int every, List<Date> exclude) {
		List<Date> lista = new ArrayList<Date>();
		Date now = this;

		while(lista.size()<10) {
			if(!isAvailable(exclude,now)) {
				now=getCorrectDay(now, exclude);
			}
			if(now.getHour()<9) {
				now.setHour(9);
				lista.add(now);
				now=now.addMinutes(every);
			}
			if(now.getHour()>=12 && now.getHour()<14) {
				now.setHour(14);
				lista.add(now);
				now=now.addMinutes(every);
			}
			lista.add(now);
			now=now.addMinutes(every);
		}
		return lista;
	}

	/**
	 * Returns the date list as a string
	 * @param dateList A list of dates
	 * @return A string of the date list
	 */
	public static String dateListToString(List<Date> dateList) {
		String datas = "";
		int order = 1;
		for (int i=1; i < dateList.size(); i++) {
			Date data = dateList.get(i);
			datas += order++ + ": ";
			datas = datas + data + '\n';
		}
		return datas;
	}

	/**
	 * Compares if the date is after or in the same day of the current date
	 * @param data A date
	 * @return True if it is after or in the same day
	 * @return False if it is before 
	 */
	public boolean afterOrEquals(Date data) {
		if (data.getYear() > year) {
			return false;
		}else if (data.getYear() == year) {
			if (data.getMonth() > month) {
				return false;
			}else if (data.getMonth() == month) {
				if (data.getDay() > day) {
					return false;
				}else if (data.getDay() == day) {
					if (data.getHour() > hour) {
						return false;
					}else if (data.getHour() == hour) {
						if (data.getMinute() > minute) {
							return false;
						}else if (data.getMinute() == minute) {
							return true;
						}else {
							return true;
						}
					}else {
						return true;
					}
				}else {
					return true;
				}
			}else {
				return true;
			}
		}else {
			return true;
		}
	}
	
	/**
	 * Compares if the date is the same as the current date
	 * @param other A date
	 * @return True if it is the same date
	 */
	public boolean sameDate(Date other) {
		return this.day == other.getDay() && this.month == other.getMonth() && this.hour==other.getHour() && this.minute == other.getMinute() && this.year==other.getYear();
	}

}
