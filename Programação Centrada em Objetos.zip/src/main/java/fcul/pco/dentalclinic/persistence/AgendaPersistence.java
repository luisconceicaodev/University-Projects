package fcul.pco.dentalclinic.persistence;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.util.ArrayList;

import fcul.pco.dentalclinic.domain.Agenda;
import fcul.pco.dentalclinic.domain.Appointment;
import fcul.pco.dentalclinic.domain.Date;
import fcul.pco.dentalclinic.domain.Doctor;
import fcul.pco.dentalclinic.domain.Patient;
import fcul.pco.dentalclinic.domain.PatientCatalog;
import fcul.pco.dentalclinic.main.ApplicationConfiguration;

/**
 * This class is responsible for saving and loading the agenda catalog.
 * The filenames are defined in the ApplicationConfiguration class.
 * 
 * @author Catarina Leote 51705
 * @author Luis Conceicao 48303
 */

public class AgendaPersistence extends ApplicationConfiguration{
	
	/**
	 * Saves AgendaCatalog into a .csv file
	 * @param agendas a TreeMap with the format Integer, Agenda
	 * @throws IOException
	 */
	public static void save (Doctor d)  throws IOException {
		BufferedWriter br = new BufferedWriter(new FileWriter(ROOT_DIRECTORY + d.getId() + ".csv"));
		StringBuilder sb = new StringBuilder();
		Agenda list = d.getAgenda();
		for(Appointment a : list) {
			String[] strApp = a.toString().split("/");
			sb.append(strApp[0]+"/"+strApp[1]+"/"+strApp[2]+"/"+strApp[3]+"/"+strApp[4]+"/"+strApp[5]+"\n");
		}	
		br.write(sb.toString());
		br.close();
	}
	
	/**
	 * Loads a AgendaCatalog from a .csv file
	 * @return agendaCatalog 
	 */
	public static Agenda load(Doctor d) throws IOException {
		ArrayList<Appointment> appointments = new ArrayList<Appointment>();
        BufferedReader br = null;
        String line = "";
        String cvsSplitBy = ",";
        try {
            br = new BufferedReader(new FileReader(ROOT_DIRECTORY + d.getId() + ".csv"));
            while ((line = br.readLine()) != null) {
            	String[] app = line.split(cvsSplitBy);
            	String appointment = app[0];
            	String[] array = appointment.split("/");
            	String[] day_time = array[2].split("@");
            	String[] time = day_time[1].split(":");
            	Date data = new Date(Integer.parseInt(array[0]), Integer.parseInt(array[1]),Integer.parseInt(day_time[0]),Integer.parseInt(time[0]),Integer.parseInt(time[1]));
            	PatientCatalog pat = PatientCatalog.getInstance();
            	pat.load();
            	Patient patient = pat.getPatientById(Integer.parseInt(array[5]));
            	if (patient != null ) {
            		Appointment ap = new Appointment(data,array[3],Integer.parseInt(array[4]),patient);
            		appointments.add(ap);
            	}
            }
            
        } catch (FileNotFoundException e) {
            e.printStackTrace();
        } catch (IOException e) {
            e.printStackTrace();
        } finally {
            if (br != null) {
                try {
                    br.close();
                } catch (IOException e) {
                    e.printStackTrace();
                }
            }
        }
        Agenda doc_agenda = new Agenda(appointments);
        return doc_agenda;
    }
}
