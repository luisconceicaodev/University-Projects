package fcul.pco.dentalclinic.persistence;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.util.TreeMap;

import fcul.pco.dentalclinic.domain.Agenda;
import fcul.pco.dentalclinic.domain.Doctor;
import fcul.pco.dentalclinic.main.ApplicationConfiguration;

/**
 * This class is responsible for saving and loading the doctor catalog.
 * The filenames are defined in the ApplicationConfiguration class.
 * 
 * @author Catarina Leote 51705
 * @author Luis Conceicao 48303
 */

public class DoctorCatalog extends ApplicationConfiguration{
	
	/**
	 * Saves DoctorCatalog into a .csv file
	 * @param doctors a TreeMap with the format Integer, Doctor
	 * @throws IOException
	 */
	public static void save(TreeMap<Integer, Doctor> doctors) throws IOException {
		BufferedWriter br = new BufferedWriter(new FileWriter(ROOT_DIRECTORY + DOCTOR_CATALOG_FILENAME + ".csv"));
    	StringBuilder sb = new StringBuilder();
    	for (Integer key : doctors.keySet()) {
    		Doctor cut = doctors.get(key);
    		int id = cut.getId();
			String name = cut.getName();
			Agenda agenda = cut.getAgenda();
			sb.append(id + "," + name + "," + agenda + "\n");
		}
    	br.write(sb.toString());
    	br.close();
	}
	
	/**
	 * Loads a DoctorCatalog from a .csv file
	 * @return doctorCatalog a TreeMap with the format Integer, Doctor
	 * @throws FileNotFoundException
	 */
	public static TreeMap<Integer, Doctor> load() throws FileNotFoundException {
    	TreeMap<Integer, Doctor> doctorCatalog = new TreeMap<Integer, Doctor>();
        BufferedReader br = null;
        String line = "";
        String cvsSplitBy = ",";
        try {
            br = new BufferedReader(new FileReader(ROOT_DIRECTORY + DOCTOR_CATALOG_FILENAME + ".csv"));
            while ((line = br.readLine()) != null) {
            	String[] doctor = line.split(cvsSplitBy);
            	String id = doctor[0];
	            String name = doctor[1];
            	String agenda = doctor[2];
	    		Doctor d = Doctor.fromString(id + "," + name + "," + agenda);
    			doctorCatalog.put(d.getId(), d);

            }
            
        } catch (FileNotFoundException e) {
            e.printStackTrace();
        } catch (IOException e) {
            e.printStackTrace();
        } finally {
            if (br != null) {
                try {
                    br.close();
                } catch (IOException e) {
                    e.printStackTrace();
                }
            }
        }
        return doctorCatalog;
    }
	
	
}
