package fcul.pco.dentalclinic.persistence;

import fcul.pco.dentalclinic.domain.Patient;
import fcul.pco.dentalclinic.main.ApplicationConfiguration;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.util.TreeMap;
import java.io.FileNotFoundException;

/**
 * This class is responsible for saving and loading the patient catalog.
 * The filenames are defined in the ApplicationConfiguration class.
 * 
 * @author Catarina Leote 51705
 * @author Luis Conceicao 48303
 */
public class PatientCatalog extends ApplicationConfiguration{
	
	/**
	 * Saves DoctorCatalog into a .csv file
	 * @param doctors a TreeMap with the format Integer, Doctor
	 * @throws IOException
	 */
	public static void save(TreeMap<Integer, Patient> patients) throws IOException {
		BufferedWriter br = new BufferedWriter(new FileWriter(ROOT_DIRECTORY + PATIENT_CATALOG_FILENAME + ".csv"));
    	StringBuilder sb = new StringBuilder();
    	for (Integer key : patients.keySet()) {
    		Patient cut = patients.get(key);
    		int sns = cut.getSns();
			String name = cut.getName();
			sb.append(name + "!" + sns + "\n");
		}
    	br.write(sb.toString());
    	br.close();
	}
    
    /**
	 * Loads a PatientCatalog from a .csv file
	 * @return patientCatalog a TreeMap with the format Integer, Patient
	 * @throws FileNotFoundException
	 */
    public static TreeMap<Integer, Patient> load() throws FileNotFoundException {
    	TreeMap<Integer, Patient> patientCatalog = new TreeMap<Integer, Patient>();
        BufferedReader br = null;
        String line = "";
        String cvsSplitBy = "!";
        try {
            br = new BufferedReader(new FileReader(ROOT_DIRECTORY + PATIENT_CATALOG_FILENAME + ".csv"));
            while ((line = br.readLine()) != null) {
            	String[] patient = line.split(cvsSplitBy);
            	String name = patient[0];
	            int sns = Integer.parseInt(patient[1]);
	    		Patient p = Patient.fromString(name + "," + sns);
    			patientCatalog.put(p.getSns(), p);

            }
            
        } catch (FileNotFoundException e) {
            e.printStackTrace();
        } catch (IOException e) {
            e.printStackTrace();
        } finally {
            if (br != null) {
                try {
                    br.close();
                } catch (IOException e) {
                    e.printStackTrace();
                }
            }
        }
        return patientCatalog;
    }
}
