package fcul.pco.dentalclinic.main;

import java.io.File;
import java.io.IOException;
import java.text.ParseException;
import java.util.Locale;
import java.util.Scanner;

import fcul.pco.dentalclinic.domain.DoctorCatalog;
import fcul.pco.dentalclinic.domain.PatientCatalog;

/**
 * Tests the project.
 * 
 * @author Catarina Leote 51705
 * @author Luis Conceicao 48303
 *
 */
public class App {
	static DoctorCatalog doctorCatalog;
	static PatientCatalog patientCatalog;

	
	public static void main(String[] args) throws IOException, ParseException {
		initialize();
		interactiveMode();
		executeAllUseCases();
	}

	/**
	 * This method may be called to use the application in default mode i.e.
	 * interacting with the keyboard.
	 *
	 * @throws IOException
	 * @throws ParseException 
	 */
	private static void interactiveMode() throws IOException {
		try (Scanner in = new Scanner(System.in)) {
			in.useLocale(Locale.US);
			Menu.mainMenu(in);
		}
	}

	private static void initialize() {
		doctorCatalog = DoctorCatalog.getInstance();
		patientCatalog = PatientCatalog.getInstance();
		try {
			doctorCatalog.load();
			patientCatalog.load();
		} catch (IOException ex) {
			System.err.println("Error loading DoctorCatalog or PatientCatalog.");
		}
	}


	/**
	 * @param useCaseFileName A String that represents the name of a file that
	 * contains a use-case.
	 * @throws IOException
	 * @throws ParseException 
	 * @requires the contents of the file must be correct with respect of the
	 * menus (see class Menu) and the input data expected by the application,
	 * unless the objective of the test is to verify an illegal situation.
	 */
	private static void executeUseCase(String useCaseFileName) throws IOException, ParseException {
		System.out.println("Test: " + useCaseFileName);
		Scanner in = new Scanner(new File(useCaseFileName));
		in.useLocale(Locale.US);
		in.nextLine();
		Menu.mainMenu(in);
		in.close();
	}

	public static void executeAllUseCases() throws ParseException {
		try {
			executeUseCase("data/addDoctorUsecase.dat");
			executeUseCase("data/addPatientUsecase.dat");
		} catch (IOException ex) {
			System.err.println(ex.getMessage());
			ex.printStackTrace();
		}
	}
	
	/**
	 * @return the doctorCatalog
	 */
	public static DoctorCatalog getDoctorCatalog() {
		return doctorCatalog;
	}
	
	/**
	 * @return the patientCatalog
	 */
	public static PatientCatalog getPatientCatalog() {
		return patientCatalog;
	}

}
