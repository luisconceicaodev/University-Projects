package fcul.pco.dentalclinic.main;

/**
 * This class defines the constants of the application.
 * 
 * @author Catarina Leote 51705
 * @author Luis Conceicao 48303
 */

public class ApplicationConfiguration {

	/**
	* The directory where files are saved.
	*/
	public static final String ROOT_DIRECTORY = "./data/";
	public static String DOCTOR_CATALOG_FILENAME = "doctorCatalog";
	public static String PATIENT_CATALOG_FILENAME = "patientCatalog";
}
