$('.form').find('input, textarea').on('keyup blur focus', function (e) {
  
  var $this = $(this),
      label = $this.prev('label');

	  if (e.type === 'keyup') {
			if ($this.val() === '') {
          label.removeClass('active highlight');
        } else {
          label.addClass('active highlight');
        }
    } else if (e.type === 'blur') {
    	if( $this.val() === '' ) {
    		label.removeClass('active highlight'); 
			} else {
		    label.removeClass('highlight');   
			}   
    } else if (e.type === 'focus') {
      
      if( $this.val() === '' ) {
    		label.removeClass('highlight'); 
			} 
      else if( $this.val() !== '' ) {
		    label.addClass('highlight');
			}
    }

});

$('.tab a').on('click', function (e) {
  
  e.preventDefault();
  
  $(this).parent().addClass('active');
  $(this).parent().siblings().removeClass('active');
  
  target = $(this).attr('href');

  $('.tab-content > div').not(target).hide();
  
  $(target).fadeIn(600);
  
});

var email2 = document.getElementById('email2').value;
var pass2 = document.getElementById('pass2').value;

function checkform(){
    var f = document.forms["registar"].elements;
    var cansubmit = true;

    for (var i = 0; i < f.length; i++) {
        if (f[i].value.length == 0) cansubmit = false;
    }
    if (cansubmit) {
        document.getElementById('res').style.display = "inline";
    }else{
        document.getElementById('res').style.display = "none";
    }
}

function checkform2(){
    var f = document.forms["login"].elements;
    var cansubmit = true;

    for (var i = 0; i < f.length; i++) {
        if (f[i].value.length == 0) cansubmit = false;
    }
    if (cansubmit) {
        document.getElementById('log').style.display = "inline";
    }else{
        document.getElementById('log').style.display = "none";
    }
}

function checkform3(){
    var f = document.forms["nova_mor"].elements;
    var cansubmit = true;

    for (var i = 0; i < f.length; i++) {
        if (f[i].value.length == 0) cansubmit = false;
    }
    if (cansubmit) {
        document.getElementById('mudarMorada2').style.display = "inline";
    }else{
        document.getElementById('mudarMorada2').style.display = "none";
    }
}

function Registar() {
    var nome = document.getElementById("nome").value;
    var apelido = document.getElementById("apelido").value;
    var email = document.getElementById("email").value;
    var pass = document.getElementById("pass").value;
    var morada = document.getElementById("morada").value;
    if (email.indexOf('@') > -1) {
        localStorage.setItem('nome', nome);
        localStorage.setItem('apelido', apelido);
        localStorage.setItem('email', email);
        localStorage.setItem('pass', pass);
        localStorage.setItem('morada', morada);
        localStorage.setItem('sessao',"true");
    }
}

function Login() {
    document.getElementById('erros').style.display = "none";
    email = document.getElementById("email2").value;
    pass = document.getElementById("pass2").value;
    if ((email === localStorage.getItem('email'))) {
        if ((pass === localStorage.getItem('pass'))) {
            localStorage.setItem('sessao',"true");
        }else {
            $("#login2").submit(function(e) {
                e.preventDefault();
            });
            document.getElementById('erros').style.display = "inline";
            document.getElementById('erros').innerHTML = "Erro: Password inserida está incorreta."
        }
    }else {
        $("#login2").submit(function(e) {
                e.preventDefault();
            });
        document.getElementById('erros').style.display = "inline";
        document.getElementById('erros').innerHTML = "Erro: Email inserido não está registado."
    }
}

window.onload = function () {
    if (localStorage.getItem('sessao') === "true") {
        document.getElementById('siga_enc').style.display = "block";
        document.getElementById('siga_txt').innerHTML = "<strong>Utilizador:</strong> " + localStorage.getItem('nome')+ "<br>" + "<strong>Encerrar sessão</strong>";
        document.getElementById('formulario').style.display = "none";
        document.getElementById('sessao').style.display = "inline";
        document.getElementById("nome_user").innerHTML = localStorage.getItem('nome') + " " + localStorage.getItem('apelido');
        document.getElementById("morada_user").innerHTML = localStorage.getItem('morada'); 
    }else{
        document.getElementById('formulario').style.display = "inline";
        document.getElementById('sessao').style.display = "none";
    }
    var modal = document.getElementById('ajuda');
    // Buscar o botão - icone do ? - para o modal
    var btn = document.getElementById("but_top");
    // Vai buscar o elemento que contem o X - que fecha a caixa
    var span = document.getElementsByClassName("close")[0];
    // Funcao que faz aparecer a caixa quando se clica no ?
    btn.onclick = function() {
        modal.style.display = "block";
    }
    // Funcao que fecha a caixa quando se clica no X
    span.onclick = function() {
        modal.style.display = "none";
    }
    // Se clicar em algum lado fora da caixa, ele fecha a caixa
    window.onclick = function(event) {
        if (event.target == modal) {
            modal.style.display = "none";
        }
    }
}