function appearFinal() {
    "use strict";
    if (document.getElementById('entrega1').checked) {
        document.getElementById('buscar_dom').value = "";
        document.getElementById('finalizar').style.display = "none";
        document.getElementById('metodo_pag').style.display = "none";
        document.getElementById('metodo_age').style.display = "block";
        document.getElementById('buscar_dom').style.display = "none";
        if (document.getElementById('dia').value !== "" && document.getElementById('hora').value !== "") {
            document.getElementById('finalizar').style.display = "inline";
        }
    } else if (document.getElementById('entrega2').checked) {
        if (localStorage.getItem('sessao') === "true") {
            document.getElementById("metodo_age").style.display = "block";
        }
        document.getElementById('metodo_age').style.display = "none";
        document.getElementById('finalizar').style.display = "none";
        document.getElementById('buscar_dom').style.display = "inline";
        if (document.getElementById('buscar_dom').value.length !== 0) {
            document.getElementById('metodo_age').style.display = "block";
            if ((document.getElementById('dia').value !== "") && (document.getElementById('hora').value) !== "") {
                document.getElementById('metodo_pag').style.display = "inline";
            }else{
                document.getElementById('metodo_pag').style.display = "none";
            }
        } else {
            document.getElementById('metodo_age').style.display = "none";            
        }
        if ((document.getElementById('pagamento1').checked || document.getElementById('pagamento2').checked) && document.getElementById('buscar_dom').value.length !== 0) {
            document.getElementById('finalizar').style.display = "inline";
            }
        }
    }

function appearPremio() {
    "use strict";
    sessionStorage.setItem("sem_pag", 1);
    if (document.getElementById('entrega1').checked) {
        document.getElementById('buscar_dom').value = "";
        document.getElementById('finalizar').style.display = "inline";
        document.getElementById('buscar_dom').style.display = "none";
        document.getElementById('inserir_dom').style.display = "none";
    }
    if (document.getElementById('entrega2').checked) {
        document.getElementById('finalizar').style.display = "none";
        document.getElementById('buscar_dom').style.display = "inline";
        document.getElementById('inserir_dom').style.display = "inline";
        if (document.getElementById('buscar_dom').value.length !== 0) {
            document.getElementById('finalizar').style.display = "inline";
        }
    }
}

function cancel() {
    "use strict";
    var modal = document.getElementById('cancel');
    // Buscar o botão - icone do ? - para o modal
    var btn = document.getElementById("eliminar");
    // Vai buscar o elemento que contem o X - que fecha a caixa
    var span = document.getElementsByClassName("close2")[0];
    // Funcao que faz aparecer a caixa quando se clica no ?
    modal.style.display = "block";
    // Funcao que fecha a caixa quando se clica no X
    span.onclick = function () {
        modal.style.display = "none";
    };
    // Se clicar em algum lado fora da caixa, ele fecha a caixa
    window.onclick = function (event) {
        if (event.target === modal) {
            modal.style.display = "none";
        }
    };
}

window.onload = function () {
    "use strict";
    if (localStorage.getItem('sessao') === "true") {
        document.getElementById('siga_enc').style.display = "block";
        document.getElementById('siga_txt').innerHTML = "<strong>Utilizador:</strong> " + localStorage.getItem('nome')+ "<br>" + "<strong>Encerrar sessão</strong>"; 
    }
    var total = sessionStorage.getItem('total'),
        path = window.location.pathname.split("/").pop();
    
    if (path === "metodo_entrega.html") {
        if ((sessionStorage.getItem('burguer') !== "null") && (sessionStorage.getItem('burguer') !== "0x Burguer e noodles...0€")) {
            document.getElementById('burguer').innerHTML = sessionStorage.getItem('burguer');
        }
        if ((sessionStorage.getItem('mburguer') !== "null") && (sessionStorage.getItem('mburguer') !== "0x Mega Burger...0€")) {
            document.getElementById('mburguer').innerHTML = sessionStorage.getItem('mburguer');
        }
        if ((sessionStorage.getItem('paramegiana') !== "null") && (sessionStorage.getItem('paramegiana') !== "0x Paramegiana...0€")) {
            document.getElementById('paramegiana').innerHTML = sessionStorage.getItem('paramegiana');
        }
        if ((sessionStorage.getItem('pizza') !== "null") && (sessionStorage.getItem('pizza') !== "0x Pizza...0€")) {
            document.getElementById('pizza').innerHTML = sessionStorage.getItem('pizza');
        }
        if ((sessionStorage.getItem('bife') !== "null") && (sessionStorage.getItem('bife') !== "0x Bife com broculos...0€")) {
            document.getElementById('bife').innerHTML = sessionStorage.getItem('bife');
        }
        if ((sessionStorage.getItem('lasanha') !== "null") && (sessionStorage.getItem('lasanha') !== "0x Lasanha de frango...0€")) {
            document.getElementById('lasanha').innerHTML = sessionStorage.getItem('lasanha');
        }
        if ((sessionStorage.getItem('crepes') !== null) && (sessionStorage.getItem('crepes') !== "0x Crepes com chocolate e morangos...0€")) {
            document.getElementById('crepes').innerHTML = sessionStorage.getItem('crepes');
        }
        if ((sessionStorage.getItem('waffle') !== null) && (sessionStorage.getItem('waffle') !== "0x Waffle com chocolate...0€")) {
            document.getElementById('waffle').innerHTML = sessionStorage.getItem('waffle');
        }
        if ((sessionStorage.getItem('vinho') !== null) && (sessionStorage.getItem('vinho') !== "0x Vinho do porto...0€")) {
            document.getElementById('vinho').innerHTML = sessionStorage.getItem('vinho');
        }
        if ((sessionStorage.getItem('coca') !== null) && (sessionStorage.getItem('coca') !== "0x Coca Cola...0€")) {
            document.getElementById('coca').innerHTML = sessionStorage.getItem('coca');
        }
        if ((sessionStorage.getItem('sumo') !== null) && (sessionStorage.getItem('sumo') !== "0x Sumo natural de manga...0€")) {
            document.getElementById('sumo').innerHTML = sessionStorage.getItem('sumo');
        }
        if ((sessionStorage.getItem('agua') !== null) && (sessionStorage.getItem('agua') !== "0x Água Fiji 0.5L...0€")) {
            document.getElementById('agua').innerHTML = sessionStorage.getItem('agua');
        }
        if ((sessionStorage.getItem('cozido') !== null) && (sessionStorage.getItem('cozido') !== "0x Cozido à portuguesa...0€")) {
            document.getElementById('cozido').innerHTML = sessionStorage.getItem('cozido');
        }
        if ((sessionStorage.getItem('france') !== null) && (sessionStorage.getItem('france') !== "0x Francesinha...0€")) {
            document.getElementById('france').innerHTML = sessionStorage.getItem('france');
        }
        if ((sessionStorage.getItem('bir') !== null) && (sessionStorage.getItem('bir') !== "0x Biryani...0€")) {
            document.getElementById('bir').innerHTML = sessionStorage.getItem('bir');
        }
        if ((sessionStorage.getItem('caril') !== null) && (sessionStorage.getItem('caril') !== "0x Caril de frango...0€")) {
            document.getElementById('caril').innerHTML = sessionStorage.getItem('caril');
        }
        if ((sessionStorage.getItem('bolonhesa') !== null) && (sessionStorage.getItem('bolonhesa') !== "0x Bolonhesa...0€")) {
            document.getElementById('bolonhesa').innerHTML = sessionStorage.getItem('bolonhesa');
        }
        if ((sessionStorage.getItem('risotto') !== null) && (sessionStorage.getItem('risotto') !== "0x Risotto...0€")) {
            document.getElementById('risotto').innerHTML = sessionStorage.getItem('risotto');
        }
        if ((sessionStorage.getItem('quinoa') !== null) && (sessionStorage.getItem('quinoa') !== "0x Quinoa com legumes...0€")) {
            document.getElementById('quinoa').innerHTML = sessionStorage.getItem('quinoa');
        }
        if ((sessionStorage.getItem('hamburguer') !== null) && (sessionStorage.getItem('hamburguer') !== "0x Hamburger...0€")) {
            document.getElementById('hamburguer').innerHTML = sessionStorage.getItem('hamburguer');
        }
        if ((sessionStorage.getItem('beringela') !== null) && (sessionStorage.getItem('beringela') !== "0x Beringela recheada...0€")) {
            document.getElementById('beringela').innerHTML = sessionStorage.getItem('beringela');
        }
        if ((sessionStorage.getItem('chop') !== null) && (sessionStorage.getItem('chop') !== "0x Chop suey de gambas...0€")) {
            document.getElementById('chop').innerHTML = sessionStorage.getItem('chop');
        }
        if ((sessionStorage.getItem('chun') !== null) && (sessionStorage.getItem('chun') !== "0x 12 Rolos Chun Juan...0€")) {
            document.getElementById('chun').innerHTML = sessionStorage.getItem('chun');
        }
        if ((sessionStorage.getItem('sushi') !== null) && (sessionStorage.getItem('sushi') !== "0x 12 Peças de Sushi...0€")) {
            document.getElementById('sushi').innerHTML = sessionStorage.getItem('sushi');
        }
        if ((sessionStorage.getItem('yak') !== null) && (sessionStorage.getItem('yak') !== "0x 5 Espetadas de Yakitori...0€")) {
            document.getElementById('yak').innerHTML = sessionStorage.getItem('yak');
        }
        if ((sessionStorage.getItem('sopa') !== null) && (sessionStorage.getItem('sopa') !== "0x Sopa de espinafres...0€")) {
            document.getElementById('sopa').innerHTML = sessionStorage.getItem('sopa');
        }
        if ((sessionStorage.getItem('peito') !== null) && (sessionStorage.getItem('peito') !== "0x Peito de frango grelhado com legumes...0€")){
            document.getElementById('peito').innerHTML = sessionStorage.getItem('peito');
        }
        if ((sessionStorage.getItem('bacalhau') !== null) && (sessionStorage.getItem('bacalhau') !== "0x Bacalhau com broa...0€")) {
            document.getElementById('bacalhau').innerHTML = sessionStorage.getItem('bacalhau');
        }
        if ((sessionStorage.getItem('salmao') !== null) && (sessionStorage.getItem('salmao') !== "0x Salmão grelhado com legumes...0€")) {
            document.getElementById('salmao').innerHTML = sessionStorage.getItem('salmao');
        }
        if ((sessionStorage.getItem('msalmao') !== null) && (sessionStorage.getItem('msalmao') !== "0x Salmão grelhado, sangria da casa e gelado...0€")) {
            document.getElementById('msalmao').innerHTML = sessionStorage.getItem('msalmao');
        }
        if ((sessionStorage.getItem('salada_f') !== null) && (sessionStorage.getItem('salada_f') !== "0x Salada de frango, limonada e maçã...0€")) {
            document.getElementById('salada_f').innerHTML = sessionStorage.getItem('salada_f');
        }
        if ((sessionStorage.getItem('mbife') !== null) && (sessionStorage.getItem('mbife') !== "0x Bife com ovo estrelado, vinho verde e pastel de nata...0€")) {
            document.getElementById('mbife').innerHTML = sessionStorage.getItem('mbife');
        }
        if ((sessionStorage.getItem('mbolonhesa') !== null) && (sessionStorage.getItem('mbol') !== "0x Bolonhesa, sumo de pêssego e semi-frio...0€")) {
            document.getElementById('mbolonhesa').innerHTML = sessionStorage.getItem('mbolonhesa');
        }
        if ((sessionStorage.getItem('msushi') !== null) && (sessionStorage.getItem('msushi') !== "0x 14 Peças de Sushi, limonada e petit-gâteau...0€")) {
            document.getElementById('msushi').innerHTML = sessionStorage.getItem('msushi');
        }
        if ((sessionStorage.getItem('mcaril') !== null) && (sessionStorage.getItem('mcaril') !== "0x Caril de frango, sangria e doce ghi...0€")) {
            document.getElementById('mcaril').innerHTML = sessionStorage.getItem('mcaril');
        }
        if ((sessionStorage.getItem('mchop') !== null) && (sessionStorage.getItem('mchop') !== "0x Chop suey de frango, sangria e gelado...0€")) {
            document.getElementById('mchop').innerHTML = sessionStorage.getItem('mchop');
        }
        
        if (sessionStorage.getItem('preco_pedido') !== null) {
            document.getElementById('total').innerHTML = sessionStorage.getItem('total');
            total = parseInt(sessionStorage.getItem('preco_pedido'));
        }
        
    }
    if (localStorage.getItem('sessao') === "true") {
        if ((path === "metodo_entrega_roda.html") || path === "metodo_entrega.html")  {
            document.getElementById("morada_user").innerHTML = localStorage.getItem('morada');
            document.getElementById("buscar_dom").value = localStorage.getItem('morada');
        }
        if (path === "metodo_entrega.html") {
            document.getElementById("metodo_age").style.display = "block";
        }
    }
    
    var modal = document.getElementById('ajuda');
    // Buscar o botão - icone do ? - para o modal
    var btn = document.getElementById("but_top");
    // Vai buscar o elemento que contem o X - que fecha a caixa
    var span = document.getElementsByClassName("close")[0];
    // Funcao que faz aparecer a caixa quando se clica no ?
    btn.onclick = function () {
        modal.style.display = "block";
    };
    // Funcao que fecha a caixa quando se clica no X
    span.onclick = function () {
        modal.style.display = "none";
    };
    // Se clicar em algum lado fora da caixa, ele fecha a caixa
    window.onclick = function (event) {
        if (event.target === modal) {
            modal.style.display = "none";
        }
    };
    
    
};