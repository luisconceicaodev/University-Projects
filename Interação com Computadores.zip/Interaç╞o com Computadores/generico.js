var myVar;

function showPage() {
    "use strict";
    document.getElementById("loader").style.display = "none";
    document.getElementById("myDiv").style.display = "block";
    if (localStorage.getItem('agendado') !== null) {
        document.getElementById("dataP2").innerHTML += "Data de entrega do pedido: " + localStorage.getItem('agendado');
        localStorage.removeItem('agendado');
    }else{
        document.getElementById("dataP2").innerHTML = "";
    }
    document.getElementById("fim").style.display = "none";
    if (sessionStorage.getItem("sem_pag") === "1") {
        document.getElementById("pagar").style.display = "none";
        document.getElementById("sem_pagar").style.display = "block";
    } else {
        document.getElementById("pagar").style.display = "block";
        document.getElementById("sem_pagar").style.display = "none";
    }
}

function myFunction() {
    "use strict";
    myVar = setTimeout(showPage, 3500);
    if (localStorage.getItem('agendado') !== null) {
        document.getElementById("dataP").innerHTML += "Data de entrega do pedido: " + localStorage.getItem('agendado');
    }
}

function prox() {
    "use strict";
    var nome_res = document.getElementById("buscar_res").value,
        nome_loc = document.getElementById("buscar_loc").value;
    if (nome_loc !== "") {
        var local = document.getElementById("buscar_loc").value;
        document.getElementsByClassName("hidden1")[0].style.display = "inline";
        document.getElementsByClassName("hidden1")[1].style.display = "inline";
        document.getElementsByClassName("hidden1")[2].style.display = "inline";
        document.getElementsByClassName("hidden2")[0].style.display = "inline";
        document.getElementsByClassName("hidden2")[1].style.display = "inline";
        document.getElementsByClassName("hidden2")[2].style.display = "inline";
        document.getElementById("loc1").innerHTML = local;
        document.getElementById("loc2").innerHTML = local;
    }
    if (nome_res === "italiano" || nome_res === "restaurante italiano" || nome_res === "Italiano" || nome_res === "Restaurante italiano") {
        document.getElementsByClassName("hidden1")[0].style.display = "inline";
        document.getElementsByClassName("hidden1")[1].style.display = "inline";
        document.getElementsByClassName("hidden1")[2].style.display = "inline";
        document.getElementById("jap").style.display = "none !important";
        if (document.getElementById('buscar_loc').value === "") {
            document.getElementById("loc1").innerHTML = "Rua Maria Amália";
        } else {
            document.getElementById("loc1").innerHTML = document.getElementById('buscar_loc').value;
        }
        document.getElementsByClassName("hidden2")[0].style.display = "none";
        document.getElementsByClassName("hidden2")[1].style.display = "none";
        document.getElementsByClassName("hidden2")[2].style.display = "none";
    }
    if (nome_res === "japones" || nome_res === "japonês" || nome_res === "restaurante japones" || nome_res === "Japones" || nome_res === "Japonês" || nome_res === "Restaurante japones") {
        document.getElementsByClassName('hidden2')[1].style.position = "absolute";
        document.getElementsByClassName('hidden2')[1].style.top = "250px";
        document.getElementsByClassName("hidden2")[0].style.display = "inline";
        document.getElementsByClassName("hidden2")[1].style.display = "inline";
        document.getElementsByClassName("hidden2")[2].style.display = "inline";
        if (document.getElementById('buscar_loc').value === "") {
            document.getElementById("loc2").innerHTML = "Rua Maria Amália";
        } else {
            document.getElementById("loc2").innerHTML = document.getElementById('buscar_loc').value;
        }
        document.getElementsByClassName("hidden1")[0].style.display = "none";
        document.getElementsByClassName("hidden1")[1].style.display = "none";
        document.getElementsByClassName("hidden1")[2].style.display = "none";
    }
}

window.onload = function () {
    "use strict";
    if (localStorage.getItem('sessao') === "true") {
        document.getElementById('siga_enc').style.display = "block";
        document.getElementById('siga_txt').innerHTML = "<strong>Utilizador:</strong> " + localStorage.getItem('nome') + "<br>" + "<strong>Encerrar sessão</strong>";
    }
    var path = window.location.pathname.split("/").pop();
    if (localStorage.getItem('sessao') === "true") {
        if (path === "restaurantesProximos.html") {
            document.getElementById("buscar_loc").value = localStorage.getItem('morada');
            var local = localStorage.getItem('morada');
            document.getElementsByClassName("hidden1")[0].style.display = "inline";
            document.getElementsByClassName("hidden1")[1].style.display = "inline";
            document.getElementsByClassName("hidden1")[2].style.display = "inline";
            document.getElementsByClassName("hidden2")[0].style.display = "inline";
            document.getElementsByClassName("hidden2")[1].style.display = "inline";
            document.getElementsByClassName("hidden2")[2].style.display = "inline";
            document.getElementById("loc1").innerHTML = local;
            document.getElementById("loc2").innerHTML = local;
        }
    }
    var modal = document.getElementById('ajuda');
    // Buscar o botão - icone do ? - para o modal
    var btn = document.getElementById("but_top");
    // Vai buscar o elemento que contem o X - que fecha a caixa
    var span = document.getElementsByClassName("close")[0];
    // Funcao que faz aparecer a caixa quando se clica no ?
    btn.onclick = function () {
        modal.style.display = "block";
    };
    // Funcao que fecha a caixa quando se clica no X
    span.onclick = function () {
        modal.style.display = "none";
    };
    // Se clicar em algum lado fora da caixa, ele fecha a caixa
    window.onclick = function (event) {
        if (event.target === modal) {
            modal.style.display = "none";
        }
    };
};