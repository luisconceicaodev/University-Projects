var pedido_final;
var total = 0;
var static_bur = 7;
var static_mbur = 4;
var static_par = 8;
var static_piz = 4;
var static_bif = 8;
var static_las = 7;
var static_cre = 4;
var static_waf = 3;
var static_vin = 1;
var static_coc = 1;
var static_agu = 1;
var static_sum = 2;
var static_coz = 5;
var static_fra = 6;
var static_bir = 5;
var static_car = 6;
var static_bol = 5;
var static_ris = 6;
var static_qui = 4;
var static_ber = 5;
var static_ham = 2;
var static_cho = 7;
var static_chu = 6;
var static_sus = 7;
var static_yak = 4;
var static_sop = 1;
var static_pei = 5;
var static_bac = 5;
var static_sal = 5;
var static_msal = 11;
var static_saf = 4;
var static_mbif = 11;
var static_mbol = 10;
var static_msus = 12;
var static_mcar = 9;
var static_mcho = 9;
    
var preco_bur = 0;
var preco_mbur = 0;
var preco_par = 0;
var preco_piz = 0;
var preco_bif = 0;
var preco_las = 0;
var preco_cre = 0;
var preco_waf = 0;
var preco_vin = 0;
var preco_coc = 0;
var preco_agu = 0;
var preco_sum = 0;
var preco_coz = 0;
var preco_fra = 0;
var preco_bir = 0;
var preco_car = 0;
var preco_bol = 0;
var preco_ris = 0;
var preco_qui = 0;
var preco_ber = 0;
var preco_ham = 0;
var preco_cho = 0;
var preco_chu = 0;
var preco_sus = 0;
var preco_yak = 0;
var preco_sop = 0;
var preco_pei = 0;
var preco_bac = 0;
var preco_sal = 0;
var preco_msal = 0;
var preco_saf = 0;
var preco_mbif = 0;
var preco_mbol = 0;
var preco_msus = 0;
var preco_mcar = 0;
var preco_mcho = 0;

var quant_bur = 0;
var quant_mbur = 0;
var quant_par = 0;
var quant_piz = 0;
var quant_bif = 0;
var quant_las = 0;
var quant_cre = 0;
var quant_waf = 0;
var quant_vin = 0;
var quant_coc = 0;
var quant_agu = 0;
var quant_sum = 0;
var quant_coz = 0;
var quant_fra = 0;
var quant_bir = 0;
var quant_car = 0;
var quant_bol = 0;
var quant_ris = 0;
var quant_qui = 0;
var quant_ber = 0;
var quant_ham = 0;
var quant_cho = 0;
var quant_chu = 0;
var quant_sus = 0;
var quant_yak = 0;
var quant_sop = 0;
var quant_pei = 0;
var quant_bac = 0;
var quant_sal = 0;
var quant_msal = 0;
var quant_saf = 0;
var quant_mbif = 0;
var quant_mbol = 0;
var quant_msus = 0;
var quant_mcar = 0;
var quant_mcho = 0;

var preco_pedido;

function save_request(text) {
    "use strict";
    var quant_bur = sessionStorage.getItem('quant_bur');
    var quant_mbur = sessionStorage.getItem('quant_mbur');
    var quant_par = sessionStorage.getItem('quant_par');
    var quant_piz = sessionStorage.getItem('quant_piz');
    var quant_bif = sessionStorage.getItem('quant_bif');
    var quant_las = sessionStorage.getItem('quant_las');
    var quant_cre = sessionStorage.getItem('quant_cre');
    var quant_waf = sessionStorage.getItem('quant_waf');
    var quant_vin = sessionStorage.getItem('quant_vin');
    var quant_coc = sessionStorage.getItem('quant_coc');
    var quant_agu = sessionStorage.getItem('quant_agu');
    var quant_sum = sessionStorage.getItem('quant_sum');
    var quant_coz = sessionStorage.getItem('quant_coz');
    var quant_fra = sessionStorage.getItem('quant_fra');
    var quant_bir = sessionStorage.getItem('quant_bir');
    var quant_car = sessionStorage.getItem('quant_car');
    var quant_bol = sessionStorage.getItem('quant_bol');
    var quant_ris = sessionStorage.getItem('quant_ris');
    var quant_qui = sessionStorage.getItem('quant_qui');
    var quant_ber = sessionStorage.getItem('quant_ber');
    var quant_ham = sessionStorage.getItem('quant_ham');
    var quant_cho = sessionStorage.getItem('quant_cho');
    var quant_chu = sessionStorage.getItem('quant_chu');
    var quant_sus = sessionStorage.getItem('quant_sus');
    var quant_yak = sessionStorage.getItem('quant_yak');
    var quant_sop = sessionStorage.getItem('quant_sop');
    var quant_pei = sessionStorage.getItem('quant_pei');
    var quant_bac = sessionStorage.getItem('quant_bac');
    var quant_sal = sessionStorage.getItem('quant_sal');
    var quant_msal = sessionStorage.getItem('quant_msal');
    var quant_saf = sessionStorage.getItem('quant_saf');
    var quant_mbif = sessionStorage.getItem('quant_mbif');
    var quant_mbol = sessionStorage.getItem('quant_mbol');
    var quant_msus = sessionStorage.getItem('quant_msus');
    var quant_mcar = sessionStorage.getItem('quant_mcar');
    var quant_mcho = sessionStorage.getItem('quant_mcho');
    
    sessionStorage.setItem('pedido', pedido_final);
    total = (static_piz * quant_piz) + (static_bur * quant_bur) + (static_mbur * quant_mbur) + (static_par * quant_par) + (static_bif * quant_bif) + (static_las * quant_las) + (static_cre * quant_cre) + (static_waf * quant_waf) + (static_vin * quant_vin) + (static_coc * quant_coc) + (static_sum * quant_sum) + (static_agu * quant_agu) + (static_coz * quant_coz) + (static_fra * quant_fra) + (static_bir * quant_bir) + (static_car * quant_car) + (static_bol * quant_bol) + (static_ris * quant_ris) + (static_qui * quant_qui) + (static_ber * quant_ber) + (static_ham * quant_ham) + (static_cho * quant_cho) + (static_chu * quant_chu) + (static_sus * quant_sus) + (static_yak * quant_yak) + (static_sop * quant_sop) + (static_pei * quant_pei) + (static_bac * quant_bac) + (static_sal * quant_sal) + (static_msal * quant_msal) + (static_saf * quant_saf) + (static_mbif * quant_mbif) + (static_mbol * quant_mbol) + (static_msus * quant_msus) + (static_mcar * quant_mcar) + (static_mcho * quant_mcho);
    
    sessionStorage.setItem('preco_pedido', preco_piz + preco_bur + preco_mbur + preco_par + preco_bif + preco_las + preco_cre + preco_waf + preco_vin + preco_coc + preco_sum + preco_agu + preco_coz + preco_fra + preco_bir + preco_car + preco_bol + preco_ris + preco_qui + preco_ber + preco_ham + preco_cho + preco_chu + preco_sus + preco_yak + preco_sop + preco_pei + preco_bac + preco_sal + preco_msal  + preco_saf + preco_mbif + preco_mbol + preco_msus  + preco_mcar + preco_mcho);
    
    sessionStorage.setItem('total', "Total: " + total + "€");
    document.getElementById('total').innerHTML = sessionStorage.getItem('total');
    if (document.getElementById('total').innerHTML === "Total: 0€") {
        document.getElementById('finalizar').style.display = "none";
        document.getElementById('eliminar').style.display = "none";
        document.getElementById("menos").style.display = "none";
        document.getElementById("menos2").style.display = "none";
        document.getElementById("menos3").style.display = "none";
        document.getElementById("menos_l").style.display = "none";
    } else {
        document.getElementById('finalizar').style.display = "inline";
        document.getElementById("menos").style.display = "inline";
    }
}

function addText(text) {
    "use strict";
    document.getElementById('eliminar').style.display = "inline";
    document.getElementById("menos_l").style.display = "inline";
    if (text === "Burguer vegetariano, sopa de noodles e crepes com chocolate") {
        quant_bur += 1;
        preco_bur += 7;
        document.getElementById('burguer').innerHTML = quant_bur + "x " + text + "..." + preco_bur + "€";
        pedido_final = quant_bur + "x " + text + "..." + preco_bur + "€";
        document.getElementById('total').innerHTML = "Total: " + preco_bur + "€";
        sessionStorage.setItem('burguer', pedido_final);
        sessionStorage.setItem('preco_bur', preco_bur);
        sessionStorage.setItem('quant_bur', quant_bur);
        save_request(text);
        document.getElementById('total').innerHTML = "Total: " + total + "€";

    } else if (text === "Mega Burger") {
        quant_mbur += 1;
        preco_mbur += 4;
        document.getElementById('mburguer').innerHTML = quant_mbur + "x " + text + "..." + preco_mbur + "€";
        pedido_final = quant_mbur + "x " + text + "..." + preco_mbur + "€";
        sessionStorage.setItem('mburguer', pedido_final);
        sessionStorage.setItem('preco_mbur', preco_mbur);
        sessionStorage.setItem('quant_mbur', quant_mbur);
        save_request(text);
        document.getElementById('total').innerHTML = "Total: " + total + "€";

    } else if (text === "Paramegiana") {
        quant_par += 1;
        preco_par += 8;
        document.getElementById('paramegiana').innerHTML = quant_par + "x " + text + "..." + preco_par + "€";
        pedido_final = quant_par + "x " + text + "..." + preco_par + "€";
        sessionStorage.setItem('paramegiana', pedido_final);
        sessionStorage.setItem('preco_par', preco_par);
        sessionStorage.setItem('quant_par', quant_par);
        save_request(text);
        document.getElementById('total').innerHTML = "Total: " + total + "€";

    } else if (text === "Pizza e compal de laranja") {
        quant_piz += 1;
        preco_piz += 4;
        sessionStorage.setItem('preco_piz', preco_piz);
        sessionStorage.setItem('quant_piz', quant_piz);
        if (sessionStorage.getItem('pizza') === null) {
            document.getElementById('pizza').innerHTML = quant_piz + "x " + text + "..." + preco_piz + "€";
            pedido_final = quant_piz + "x " + text + "..." + preco_piz + "€";
        } else {
            document.getElementById('pizza').innerHTML = sessionStorage.getItem('quant_piz') + "x " + text + "..." + sessionStorage.getItem('preco_piz') + "€";
            pedido_final = sessionStorage.getItem('quant_piz') + "x " + text + "..." + sessionStorage.getItem('preco_piz') + "€";
        }
        sessionStorage.setItem('pizza', pedido_final);
        save_request(text);
        document.getElementById('total').innerHTML = "Total: " + total + "€";

    } else if (text === "Bife com broculos") {
        quant_bif += 1;
        preco_bif += 8;
        sessionStorage.setItem('preco_bif', preco_bif);
        sessionStorage.setItem('quant_bif', quant_bif);
        document.getElementById("menos3").style.display = "inline";
        if (sessionStorage.getItem('bife') === null) {
            document.getElementById('bife').innerHTML = quant_bif + "x " + text + "..." + preco_bif + "€";
            pedido_final = quant_bif + "x " + text + "..." + preco_bif + "€";
        } else {
            document.getElementById('bife').innerHTML = sessionStorage.getItem('quant_bif') + "x " + text + "..." + sessionStorage.getItem('preco_bif') + "€";
            pedido_final = sessionStorage.getItem('quant_bif') + "x " + text + "..." + sessionStorage.getItem('preco_bif') + "€";
        }
        sessionStorage.setItem('bife', pedido_final);
        save_request(text);
        document.getElementById('total').innerHTML = "Total: " + total + "€";

    } else if (text === "Lasanha de frango") {
        quant_las += 1;
        preco_las += 7;
        sessionStorage.setItem('preco_las', preco_las);
        sessionStorage.setItem('quant_las', quant_las);
        document.getElementById("menos2").style.display = "inline";
        if (sessionStorage.getItem('lasanha') === null) {
            document.getElementById('lasanha').innerHTML = quant_las + "x " + text + "..." + preco_las + "€";
            pedido_final = quant_las + "x " + text + "..." + preco_las + "€";
        } else {
            document.getElementById('lasanha').innerHTML = sessionStorage.getItem('quant_las') + "x " + text + "..." + sessionStorage.getItem('preco_las') + "€";
            pedido_final = sessionStorage.getItem('quant_las') + "x " + text + "..." + sessionStorage.getItem('preco_las') + "€";
        }
        sessionStorage.setItem('lasanha', pedido_final);
        save_request(text);
        document.getElementById('total').innerHTML = "Total: " + total + "€";

    } else if (text === "Crepes com chocolate e morangos") {
        quant_cre += 1;
        preco_cre += 4;
        sessionStorage.setItem('preco_cre', preco_cre);
        sessionStorage.setItem('quant_cre', quant_cre);
        document.getElementById("menos3").style.display = "inline";
        if (sessionStorage.getItem('crepes') === null) {
            document.getElementById('crepes').innerHTML = quant_cre + "x " + text + "..." + preco_cre + "€";
            pedido_final = quant_cre + "x " + text + "..." + preco_cre + "€";
        } else {
            document.getElementById('crepes').innerHTML = sessionStorage.getItem('quant_cre') + "x " + text + "..." + sessionStorage.getItem('preco_cre') + "€";
            pedido_final = sessionStorage.getItem('quant_cre') + "x " + text + "..." + sessionStorage.getItem('preco_cre') + "€";
        }
        sessionStorage.setItem('crepes', pedido_final);
        save_request(text);
        document.getElementById('total').innerHTML = "Total: " + total + "€";

    } else if (text === "Waffle com chocolate") {
        quant_waf += 1;
        preco_waf += 3;
        sessionStorage.setItem('preco_waf', preco_waf);
        sessionStorage.setItem('quant_waf', quant_waf);
        document.getElementById("menos2").style.display = "inline";
        if (sessionStorage.getItem('waffle') === null) {
            document.getElementById('waffle').innerHTML = quant_waf + "x " + text + "..." + preco_waf + "€";
            pedido_final = quant_waf + "x " + text + "..." + preco_waf + "€";
        } else {
            document.getElementById('waffle').innerHTML = sessionStorage.getItem('quant_waf') + "x " + text + "..." + sessionStorage.getItem('preco_waf') + "€";
            pedido_final = sessionStorage.getItem('quant_waf') + "x " + text + "..." + sessionStorage.getItem('preco_waf') + "€";
        }
        sessionStorage.setItem('waffle', pedido_final);
        save_request(text);
        document.getElementById('total').innerHTML = "Total: " + total + "€";
    } else if (text === "Vinho do Porto") {
        quant_vin += 1;
        preco_vin += 1;
        sessionStorage.setItem('preco_vin', preco_vin);
        sessionStorage.setItem('quant_vin', quant_vin);
        document.getElementById("menos").style.display = "inline";
        if (sessionStorage.getItem('vinho') === null) {
            document.getElementById('vinho').innerHTML = quant_vin + "x " + text + "..." + preco_vin + "€";
            pedido_final = quant_vin + "x " + text + "..." + preco_vin + "€";
        } else {
            document.getElementById('vinho').innerHTML = sessionStorage.getItem('quant_vin') + "x " + text + "..." + sessionStorage.getItem('preco_vin') + "€";
            pedido_final = sessionStorage.getItem('quant_vin') + "x " + text + "..." + sessionStorage.getItem('preco_vin') + "€";
        }
        sessionStorage.setItem('vinho', pedido_final);
        save_request(text);
        document.getElementById('total').innerHTML = "Total: " + total + "€";
    } else if (text === "Coca Cola") {
        quant_coc += 1;
        preco_coc += 1;
        sessionStorage.setItem('preco_coc', preco_coc);
        sessionStorage.setItem('quant_coc', quant_coc);
        document.getElementById("menos").style.display = "inline";
        if (sessionStorage.getItem('coca') === null) {
            document.getElementById('coca').innerHTML = quant_coc + "x " + text + "..." + preco_coc + "€";
            pedido_final = quant_coc + "x " + text + "..." + preco_coc + "€";
        } else {
            document.getElementById('coca').innerHTML = sessionStorage.getItem('quant_coc') + "x " + text + "..." + sessionStorage.getItem('preco_coc') + "€";
            pedido_final = sessionStorage.getItem('quant_coc') + "x " + text + "..." + sessionStorage.getItem('preco_coc') + "€";
        }
        sessionStorage.setItem('coca', pedido_final);
        save_request(text);
        document.getElementById('total').innerHTML = "Total: " + total + "€";
    } else if (text === "Sumo natural de manga") {
        quant_sum += 1;
        preco_sum += 2;
        sessionStorage.setItem('preco_sum', preco_sum);
        sessionStorage.setItem('quant_sum', quant_sum);
        document.getElementById("menos2").style.display = "inline";
        if (sessionStorage.getItem('sumo') === null) {
            document.getElementById('sumo').innerHTML = quant_sum + "x " + text + "..." + preco_sum + "€";
            pedido_final = quant_sum + "x " + text + "..." + preco_sum + "€";
        } else {
            document.getElementById('sumo').innerHTML = sessionStorage.getItem('quant_sum') + "x " + text + "..." + sessionStorage.getItem('preco_sum') + "€";
            pedido_final = sessionStorage.getItem('quant_sum') + "x " + text + "..." + sessionStorage.getItem('preco_sum') + "€";
        }
        sessionStorage.setItem('sumo', pedido_final);
        save_request(text);
        document.getElementById('total').innerHTML = "Total: " + total + "€";
    } else if (text === "Água Fiji 0.5L") {
        quant_agu += 1;
        preco_agu += 1;
        sessionStorage.setItem('preco_agu', preco_agu);
        sessionStorage.setItem('quant_agu', quant_agu);
        document.getElementById("menos3").style.display = "inline";
        if (sessionStorage.getItem('agua') === null) {
            document.getElementById('agua').innerHTML = quant_agu + "x " + text + "..." + preco_agu + "€";
            pedido_final = quant_agu + "x " + text + "..." + preco_agu + "€";
        } else {
            document.getElementById('agua').innerHTML = sessionStorage.getItem('quant_agu') + "x " + text + "..." + sessionStorage.getItem('preco_agu') + "€";
            pedido_final = sessionStorage.getItem('quant_agu') + "x " + text + "..." + sessionStorage.getItem('preco_agu') + "€";
        }
        sessionStorage.setItem('agua', pedido_final);
        save_request(text);
        document.getElementById('total').innerHTML = "Total: " + total + "€";
    } else if (text === "Cozido à portuguesa") {
        quant_coz += 1;
        preco_coz += 5;
        sessionStorage.setItem('preco_coz', preco_coz);
        sessionStorage.setItem('quant_coz', quant_coz);
        document.getElementById("menos3").style.display = "inline";
        if (sessionStorage.getItem('cozido') === null) {
            document.getElementById('cozido').innerHTML = quant_coz + "x " + text + "..." + preco_coz + "€";
            pedido_final = quant_coz + "x " + text + "..." + preco_coz + "€";
        } else {
            document.getElementById('cozido').innerHTML = sessionStorage.getItem('quant_coz') + "x " + text + "..." + sessionStorage.getItem('preco_coz') + "€";
            pedido_final = sessionStorage.getItem('quant_coz') + "x " + text + "..." + sessionStorage.getItem('preco_coz') + "€";
        }
        sessionStorage.setItem('cozido', pedido_final);
        save_request(text);
        document.getElementById('total').innerHTML = "Total: " + total + "€";
    } else if (text === "Francesinha") {
        quant_fra += 1;
        preco_fra += 6;
        sessionStorage.setItem('preco_fra', preco_fra);
        sessionStorage.setItem('quant_fra', quant_fra);
        document.getElementById("menos2").style.display = "inline";
        if (sessionStorage.getItem('france') === null) {
            document.getElementById('france').innerHTML = quant_fra + "x " + text + "..." + preco_fra + "€";
            pedido_final = quant_fra + "x " + text + "..." + preco_fra + "€";
        } else {
            document.getElementById('france').innerHTML = sessionStorage.getItem('quant_fra') + "x " + text + "..." + sessionStorage.getItem('preco_fra') + "€";
            pedido_final = sessionStorage.getItem('quant_fra') + "x " + text + "..." + sessionStorage.getItem('preco_fra') + "€";
        }
        sessionStorage.setItem('france', pedido_final);
        save_request(text);
        document.getElementById('total').innerHTML = "Total: " + total + "€";
    } else if (text === "Biryani") {
        quant_bir += 1;
        preco_bir += 5;
        sessionStorage.setItem('preco_bir', preco_bir);
        sessionStorage.setItem('quant_bir', quant_bir);
        document.getElementById("menos3").style.display = "inline";
        if (sessionStorage.getItem('bir') === null) {
            document.getElementById('bir').innerHTML = quant_bir + "x " + text + "..." + preco_bir + "€";
            pedido_final = quant_bir + "x " + text + "..." + preco_bir + "€";
        } else {
            document.getElementById('bir').innerHTML = sessionStorage.getItem('quant_bir') + "x " + text + "..." + sessionStorage.getItem('preco_bir') + "€";
            pedido_final = sessionStorage.getItem('quant_bir') + "x " + text + "..." + sessionStorage.getItem('preco_bir') + "€";
        }
        sessionStorage.setItem('bir', pedido_final);
        save_request(text);
        document.getElementById('total').innerHTML = "Total: " + total + "€";
    } else if (text === "Caril de frango") {
        quant_car += 1;
        preco_car += 6;
        sessionStorage.setItem('preco_car', preco_car);
        sessionStorage.setItem('quant_car', quant_car);
        document.getElementById("menos2").style.display = "inline";
        if (sessionStorage.getItem('caril') === null) {
            document.getElementById('caril').innerHTML = quant_car + "x " + text + "..." + preco_car + "€";
            pedido_final = quant_car + "x " + text + "..." + preco_car + "€";
        } else {
            document.getElementById('caril').innerHTML = sessionStorage.getItem('quant_car') + "x " + text + "..." + sessionStorage.getItem('preco_car') + "€";
            pedido_final = sessionStorage.getItem('quant_car') + "x " + text + "..." + sessionStorage.getItem('preco_car') + "€";
        }
        sessionStorage.setItem('caril', pedido_final);
        save_request(text);
        document.getElementById('total').innerHTML = "Total: " + total + "€";
    } else if (text === "Bolonhesa") {
        quant_bol += 1;
        preco_bol += 5;
        sessionStorage.setItem('preco_bol', preco_bol);
        sessionStorage.setItem('quant_bol', quant_bol);
        document.getElementById("menos3").style.display = "inline";
        if (sessionStorage.getItem('bolonhesa') === null) {
            document.getElementById('bolonhesa').innerHTML = quant_bol + "x " + text + "..." + preco_bol + "€";
            pedido_final = quant_bol + "x " + text + "..." + preco_bol + "€";
        } else {
            document.getElementById('bolonhesa').innerHTML = sessionStorage.getItem('quant_bol') + "x " + text + "..." + sessionStorage.getItem('preco_bol') + "€";
            pedido_final = sessionStorage.getItem('quant_bol') + "x " + text + "..." + sessionStorage.getItem('preco_bol') + "€";
        }
        sessionStorage.setItem('bolonhesa', pedido_final);
        save_request(text);
        document.getElementById('total').innerHTML = "Total: " + total + "€";
    } else if (text === "Risotto") {
        quant_ris += 1;
        preco_ris += 7;
        sessionStorage.setItem('preco_ris', preco_ris);
        sessionStorage.setItem('quant_ris', quant_ris);
        document.getElementById("menos2").style.display = "inline";
        if (sessionStorage.getItem('risotto') === null) {
            document.getElementById('risotto').innerHTML = quant_ris + "x " + text + "..." + preco_ris + "€";
            pedido_final = quant_ris + "x " + text + "..." + preco_ris + "€";
        } else {
            document.getElementById('risotto').innerHTML = sessionStorage.getItem('quant_ris') + "x " + text + "..." + sessionStorage.getItem('preco_ris') + "€";
            pedido_final = sessionStorage.getItem('quant_ris') + "x " + text + "..." + sessionStorage.getItem('preco_ris') + "€";
        }
        sessionStorage.setItem('risotto', pedido_final);
        save_request(text);
        document.getElementById('total').innerHTML = "Total: " + total + "€";
    } else if (text === "Quinoa com legumes") {
        quant_qui += 1;
        preco_qui += 4;
        sessionStorage.setItem('preco_qui', preco_qui);
        sessionStorage.setItem('quant_qui', quant_qui);
        document.getElementById("menos3").style.display = "inline";
        if (sessionStorage.getItem('quinoa') === null) {
            document.getElementById('quinoa').innerHTML = quant_qui + "x " + text + "..." + preco_qui + "€";
            pedido_final = quant_qui + "x " + text + "..." + preco_qui + "€";
        } else {
            document.getElementById('quinoa').innerHTML = sessionStorage.getItem('quant_qui') + "x " + text + "..." + sessionStorage.getItem('preco_qui') + "€";
            pedido_final = sessionStorage.getItem('quant_qui') + "x " + text + "..." + sessionStorage.getItem('preco_qui') + "€";
        }
        sessionStorage.setItem('quinoa', pedido_final);
        save_request(text);
        document.getElementById('total').innerHTML = "Total: " + total + "€";
    } else if (text === "Beringela recheada") {
        quant_ber += 1;
        preco_ber += 5;
        sessionStorage.setItem('preco_ber', preco_ber);
        sessionStorage.setItem('quant_ber', quant_ber);
        document.getElementById("menos2").style.display = "inline";
        if (sessionStorage.getItem('beringela') === null) {
            document.getElementById('beringela').innerHTML = quant_ber + "x " + text + "..." + preco_ber + "€";
            pedido_final = quant_ber + "x " + text + "..." + preco_ber + "€";
        } else {
            document.getElementById('beringela').innerHTML = sessionStorage.getItem('quant_ber') + "x " + text + "..." + sessionStorage.getItem('preco_ber') + "€";
            pedido_final = sessionStorage.getItem('quant_ber') + "x " + text + "..." + sessionStorage.getItem('preco_ber') + "€";
        }
        sessionStorage.setItem('beringela', pedido_final);
        save_request(text);
        document.getElementById('total').innerHTML = "Total: " + total + "€";
    } else if (text === "Hamburger") {
        quant_ham += 1;
        preco_ham += 2;
        document.getElementById('hamburguer').innerHTML = quant_ham + "x " + text + "..." + preco_ham + "€";
        pedido_final = quant_ham + "x " + text + "..." + preco_ham + "€";
        sessionStorage.setItem('hamburguer', pedido_final);
        sessionStorage.setItem('preco_ham', preco_ham);
        sessionStorage.setItem('quant_ham', quant_ham);
        save_request(text);
        document.getElementById('total').innerHTML = "Total: " + total + "€";

    } else if (text === "Chop suey de gambas") {
        quant_cho += 1;
        preco_cho += 7;
        sessionStorage.setItem('preco_cho', preco_cho);
        sessionStorage.setItem('quant_cho', quant_cho);
        document.getElementById("menos3").style.display = "inline";
        if (sessionStorage.getItem('chop') === null) {
            document.getElementById('chop').innerHTML = quant_cho + "x " + text + "..." + preco_cho + "€";
            pedido_final = quant_cho + "x " + text + "..." + preco_cho + "€";
        } else {
            document.getElementById('chop').innerHTML = sessionStorage.getItem('quant_cho') + "x " + text + "..." + sessionStorage.getItem('preco_cho') + "€";
            pedido_final = sessionStorage.getItem('quant_cho') + "x " + text + "..." + sessionStorage.getItem('preco_cho') + "€";
        }
        sessionStorage.setItem('chop', pedido_final);
        save_request(text);
        document.getElementById('total').innerHTML = "Total: " + total + "€";
    } else if (text === "12 Rolos Chun Juan") {
        quant_chu += 1;
        preco_chu += 6;
        sessionStorage.setItem('preco_chu', preco_chu);
        sessionStorage.setItem('quant_chu', quant_chu);
        document.getElementById("menos2").style.display = "inline";
        if (sessionStorage.getItem('chun') === null) {
            document.getElementById('chun').innerHTML = quant_chu + "x " + text + "..." + preco_chu + "€";
            pedido_final = quant_chu + "x " + text + "..." + preco_chu + "€";
        } else {
            document.getElementById('chun').innerHTML = sessionStorage.getItem('quant_chu') + "x " + text + "..." + sessionStorage.getItem('preco_chu') + "€";
            pedido_final = sessionStorage.getItem('quant_chu') + "x " + text + "..." + sessionStorage.getItem('preco_chu') + "€";
        }
        sessionStorage.setItem('chun', pedido_final);
        save_request(text);
        document.getElementById('total').innerHTML = "Total: " + total + "€";
    } else if (text === "12 Peças de Sushi") {
        quant_sus += 1;
        preco_sus += 7;
        sessionStorage.setItem('preco_sus', preco_sus);
        sessionStorage.setItem('quant_sus', quant_sus);
        document.getElementById("menos3").style.display = "inline";
        if (sessionStorage.getItem('sushi') === null) {
            document.getElementById('sushi').innerHTML = quant_sus + "x " + text + "..." + preco_sus + "€";
            pedido_final = quant_sus + "x " + text + "..." + preco_sus + "€";
        } else {
            document.getElementById('sushi').innerHTML = sessionStorage.getItem('quant_sus') + "x " + text + "..." + sessionStorage.getItem('preco_sus') + "€";
            pedido_final = sessionStorage.getItem('quant_sus') + "x " + text + "..." + sessionStorage.getItem('preco_sus') + "€";
        }
        sessionStorage.setItem('sushi', pedido_final);
        save_request(text);
        document.getElementById('total').innerHTML = "Total: " + total + "€";
    } else if (text === "5 Espetadas de Yakitori") {
        quant_yak += 1;
        preco_yak += 4;
        sessionStorage.setItem('preco_yak', preco_yak);
        sessionStorage.setItem('quant_yak', quant_yak);
        document.getElementById("menos2").style.display = "inline";
        if (sessionStorage.getItem('yak') === null) {
            document.getElementById('yak').innerHTML = quant_yak + "x " + text + "..." + preco_yak + "€";
            pedido_final = quant_yak + "x " + text + "..." + preco_yak + "€";
        } else {
            document.getElementById('yak').innerHTML = sessionStorage.getItem('quant_yak') + "x " + text + "..." + sessionStorage.getItem('preco_yak') + "€";
            pedido_final = sessionStorage.getItem('quant_yak') + "x " + text + "..." + sessionStorage.getItem('preco_yak') + "€";
        }
        sessionStorage.setItem('yak', pedido_final);
        save_request(text);
        document.getElementById('total').innerHTML = "Total: " + total + "€";
    } else if (text === "Sopa de espinafres") {
        quant_sop += 1;
        preco_sop += 1;
        sessionStorage.setItem('preco_sop', preco_sop);
        sessionStorage.setItem('quant_sop', quant_sop);
        document.getElementById("menos3").style.display = "inline";
        if (sessionStorage.getItem('sopa') === null) {
            document.getElementById('sopa').innerHTML = quant_sop + "x " + text + "..." + preco_sop + "€";
            pedido_final = quant_sop + "x " + text + "..." + preco_sop + "€";
        } else {
            document.getElementById('sopa').innerHTML = sessionStorage.getItem('quant_sop') + "x " + text + "..." + sessionStorage.getItem('preco_sop') + "€";
            pedido_final = sessionStorage.getItem('quant_sop') + "x " + text + "..." + sessionStorage.getItem('preco_sop') + "€";
        }
        sessionStorage.setItem('sopa', pedido_final);
        save_request(text);
        document.getElementById('total').innerHTML = "Total: " + total + "€";
    } else if (text === "Peito de frango grelhado com legumes") {
        quant_pei += 1;
        preco_pei += 5;
        sessionStorage.setItem('preco_pei', preco_pei);
        sessionStorage.setItem('quant_pei', quant_pei);
        document.getElementById("menos2").style.display = "inline";
        if (sessionStorage.getItem('peito') === null) {
            document.getElementById('peito').innerHTML = quant_pei + "x " + text + "..." + preco_pei + "€";
            pedido_final = quant_pei + "x " + text + "..." + preco_pei + "€";
        } else {
            document.getElementById('peito').innerHTML = sessionStorage.getItem('quant_pei') + "x " + text + "..." + sessionStorage.getItem('preco_pei') + "€";
            pedido_final = sessionStorage.getItem('quant_pei') + "x " + text + "..." + sessionStorage.getItem('preco_pei') + "€";
        }
        sessionStorage.setItem('peito', pedido_final);
        save_request(text);
        document.getElementById('total').innerHTML = "Total: " + total + "€";
    } else if (text === "Bacalhau com broa") {
        quant_bac += 1;
        preco_bac += 5;
        sessionStorage.setItem('preco_bac', preco_bac);
        sessionStorage.setItem('quant_bac', quant_bac);
        document.getElementById("menos3").style.display = "inline";
        if (sessionStorage.getItem('bacalhau') === null) {
            document.getElementById('bacalhau').innerHTML = quant_bac + "x " + text + "..." + preco_bac + "€";
            pedido_final = quant_bac + "x " + text + "..." + preco_bac + "€";
        } else {
            document.getElementById('bacalhau').innerHTML = sessionStorage.getItem('quant_bac') + "x " + text + "..." + sessionStorage.getItem('preco_bac') + "€";
            pedido_final = sessionStorage.getItem('quant_bac') + "x " + text + "..." + sessionStorage.getItem('preco_bac') + "€";
        }
        sessionStorage.setItem('bacalhau', pedido_final);
        save_request(text);
        document.getElementById('total').innerHTML = "Total: " + total + "€";
    } else if (text === "Salmão grelhado com legumes") {
        quant_sal += 1;
        preco_sal += 5;
        sessionStorage.setItem('preco_sal', preco_sal);
        sessionStorage.setItem('quant_sal', quant_sal);
        document.getElementById("menos2").style.display = "inline";
        if (sessionStorage.getItem('salmao') === null) {
            document.getElementById('salmao').innerHTML = quant_sal + "x " + text + "..." + preco_sal + "€";
            pedido_final = quant_sal + "x " + text + "..." + preco_sal + "€";
        } else {
            document.getElementById('salmao').innerHTML = sessionStorage.getItem('quant_sal') + "x " + text + "..." + sessionStorage.getItem('preco_sal') + "€";
            pedido_final = sessionStorage.getItem('quant_sal') + "x " + text + "..." + sessionStorage.getItem('preco_sal') + "€";
        }
        sessionStorage.setItem('salmao', pedido_final);
        save_request(text);
        document.getElementById('total').innerHTML = "Total: " + total + "€";
    } else if (text === "Salmão grelhado, sangria da casa e gelado") {
        quant_msal += 1;
        preco_msal += 11;
        document.getElementById('msalmao').innerHTML = quant_msal + "x " + text + "..." + preco_msal + "€";
        pedido_final = quant_msal + "x " + text + "..." + preco_msal + "€";
        sessionStorage.setItem('msalmao', pedido_final);
        sessionStorage.setItem('preco_msal', preco_msal);
        sessionStorage.setItem('quant_msal', quant_msal);
        save_request(text);
        document.getElementById('total').innerHTML = "Total: " + total + "€";

    } else if (text === "Salada de frango, limonada e maçã") {
        quant_saf += 1;
        preco_saf += 4;
        document.getElementById('salada_f').innerHTML = quant_saf + "x " + text + "..." + preco_saf + "€";
        pedido_final = quant_saf + "x " + text + "..." + preco_saf + "€";
        sessionStorage.setItem('salada_f', pedido_final);
        sessionStorage.setItem('preco_saf', preco_saf);
        sessionStorage.setItem('quant_saf', quant_saf);
        save_request(text);
        document.getElementById('total').innerHTML = "Total: " + total + "€";

    } else if (text === "Bife com ovo estrelado, vinho verde e pastel de nata") {
        quant_mbif += 1;
        preco_mbif += 11;
        document.getElementById('mbife').innerHTML = quant_mbif + "x " + text + "..." + preco_mbif + "€";
        pedido_final = quant_mbif + "x " + text + "..." + preco_mbif + "€";
        sessionStorage.setItem('mbife', pedido_final);
        sessionStorage.setItem('preco_mbif', preco_mbif);
        sessionStorage.setItem('quant_mbif', quant_mbif);
        save_request(text);
        document.getElementById('total').innerHTML = "Total: " + total + "€";
        
    } else if (text === "Bolonhesa, sumo de pêssego e semi-frio") {
        quant_mbol += 1;
        preco_mbol += 10;
        document.getElementById('mbolonhesa').innerHTML = quant_mbol + "x " + text + "..." + preco_mbol + "€";
        pedido_final = quant_mbol + "x " + text + "..." + preco_mbol + "€";
        sessionStorage.setItem('mbolonhesa', pedido_final);
        sessionStorage.setItem('preco_mbol', preco_mbol);
        sessionStorage.setItem('quant_mbol', quant_mbol);
        save_request(text);
        document.getElementById('total').innerHTML = "Total: " + total + "€";
    } else if (text === "14 Peças de Sushi, limonada e petit-gâteau") {
        quant_msus += 1;
        preco_msus += 12;
        document.getElementById('msushi').innerHTML = quant_msus + "x " + text + "..." + preco_msus + "€";
        pedido_final = quant_msus + "x " + text + "..." + preco_msus + "€";
        sessionStorage.setItem('msushi', pedido_final);
        sessionStorage.setItem('preco_msus', preco_msus);
        sessionStorage.setItem('quant_msus', quant_msus);
        save_request(text);
        document.getElementById('total').innerHTML = "Total: " + total + "€";
    } else if (text === "Caril de frango, sumo de laranja e doce ghi") {
        quant_mcar += 1;
        preco_mcar += 9;
        document.getElementById('mcaril').innerHTML = quant_mcar + "x " + text + "..." + preco_mcar + "€";
        pedido_final = quant_mcar + "x " + text + "..." + preco_mcar + "€";
        sessionStorage.setItem('mcaril', pedido_final);
        sessionStorage.setItem('preco_mcar', preco_mcar);
        sessionStorage.setItem('quant_mcar', quant_mcar);
        save_request(text);
        document.getElementById('total').innerHTML = "Total: " + total + "€";
    } else if (text === "Chop suey de frango, sangria e gelado") {
        quant_mcho += 1;
        preco_mcho += 9;
        document.getElementById('mchop').innerHTML = quant_mcho + "x " + text + "..." + preco_mcho + "€";
        pedido_final = quant_mcho + "x " + text + "..." + preco_mcho + "€";
        sessionStorage.setItem('mchop', pedido_final);
        sessionStorage.setItem('preco_mcho', preco_mcho);
        sessionStorage.setItem('quant_mcho', quant_mcho);
        save_request(text);
        document.getElementById('total').innerHTML = "Total: " + total + "€";
    }



    if (pedido_final !== null) {
        document.getElementById('finalizar').style.display = "inline";
    } else {
        document.getElementById('finalizar').style.display = "none";
    }
}

function removeText(text) {
    "use strict";
    if (text === "Burguer vegetariano, sopa de noodles e crepes com chocolate") {
        quant_bur -= 1;
        preco_bur -= 7;
        if (preco_bur <= 0) {
            preco_bur = 0;
            quant_bur = 0;
            pedido_final = "";
            document.getElementById('burguer').innerHTML = quant_bur + "x " + text + "..." + preco_bur + "€";
            pedido_final = quant_bur + "x " + text + "..." + preco_bur + "€";
            sessionStorage.setItem('burguer', pedido_final);
            sessionStorage.setItem('preco_bur', preco_bur);
            sessionStorage.setItem('quant_bur', quant_bur);
            save_request(text);
            document.getElementById('burguer').innerHTML = "";
            document.getElementById("menos").style.display = "none";
            document.getElementById("menos_l").style.display = "none";
        } else {
            document.getElementById('burguer').innerHTML = quant_bur + "x " + text + "..." + preco_bur + "€";
            document.getElementById('total').innerHTML = "Total: " + preco_bur + "€";
            pedido_final = quant_bur + "x " + text + "..." + preco_bur + "€";
            sessionStorage.setItem('burguer', pedido_final);
            sessionStorage.setItem('preco_bur', preco_bur);
            sessionStorage.setItem('quant_bur', quant_bur);
            save_request(text);
            document.getElementById("menos").style.display = "inline";
            document.getElementById("menos_l").style.display = "inline";
        }
    }
    if (text === "Mega Burger") {
        quant_mbur -= 1;
        preco_mbur -= 4;
        if (quant_mbur <= 0) {
            preco_mbur = 0;
            quant_mbur = 0;
            pedido_final = "";
            document.getElementById('mburguer').innerHTML = quant_mbur + "x " + text + "..." + preco_mbur + "€";
            pedido_final = quant_mbur + "x " + text + "..." + preco_mbur + "€";
            sessionStorage.setItem('mburguer', pedido_final);
            sessionStorage.setItem('preco_mbur', preco_mbur);
            sessionStorage.setItem('quant_mbur', quant_mbur);
            save_request(text);
            document.getElementById('mburguer').innerHTML = "";
            document.getElementById("menos").style.display = "none";
            document.getElementById("menos_l").style.display = "none";
        } else {
            document.getElementById('mburguer').innerHTML = quant_mbur + "x " + text + "..." + preco_mbur + "€";
            document.getElementById('total').innerHTML = "Total: " + preco_mbur + "€";
            pedido_final = quant_mbur + "x " + text + "..." + preco_mbur + "€";
            sessionStorage.setItem('mburguer', pedido_final);
            sessionStorage.setItem('preco_mbur', preco_mbur);
            sessionStorage.setItem('quant_mbur', quant_mbur);
            save_request(text);
            document.getElementById("menos").style.display = "inline";
            document.getElementById("menos_l").style.display = "inline";
        }
    }

    if (text === "Paramegiana") {
        quant_par -= 1;
        preco_par -= 8;
        if (quant_par <= 0) {
            preco_par = 0;
            quant_par = 0;
            pedido_final = "";
            document.getElementById('paramegiana').innerHTML = quant_par + "x " + text + "..." + preco_par + "€";
            pedido_final = quant_par + "x " + text + "..." + preco_par + "€";
            sessionStorage.setItem('paramegiana', pedido_final);
            sessionStorage.setItem('preco_par', preco_par);
            sessionStorage.setItem('quant_par', quant_par);
            save_request(text);
            document.getElementById('paramegiana').innerHTML = "";
            document.getElementById("menos").style.display = "none";
            document.getElementById("menos_l").style.display = "none";
        } else {
            document.getElementById('paramegiana').innerHTML = quant_par + "x " + text + "..." + preco_par + "€";
            document.getElementById('total').innerHTML = "Total: " + preco_par + "€";
            pedido_final = quant_par + "x " + text + "..." + preco_par + "€";
            sessionStorage.setItem('paramegiana', pedido_final);
            sessionStorage.setItem('preco_par', preco_par);
            sessionStorage.setItem('quant_par', quant_par);
            save_request(text);
            document.getElementById("menos").style.display = "inline";
            document.getElementById("menos_l").style.display = "inline";
        }
    }

    if (text === "Pizza e compal de laranja") {
        quant_piz -= 1;
        preco_piz -= 4;
        if (quant_piz <= 0) {
            preco_piz = 0;
            quant_piz = 0;
            document.getElementById('pizza').innerHTML = quant_piz + "x " + text + "..." + preco_piz + "€";
            pedido_final = quant_piz + "x " + text + "..." + preco_piz + "€";
            sessionStorage.setItem('pizza', pedido_final);
            sessionStorage.setItem('preco_piz', preco_piz);
            sessionStorage.setItem('quant_piz', quant_piz);
            save_request(text);
            document.getElementById('pizza').innerHTML = "";
            document.getElementById("menos").style.display = "none";
            document.getElementById("menos_l").style.display = "none";
        } else {
            document.getElementById('pizza').innerHTML = quant_piz + "x " + text + "..." + preco_piz + "€";
            document.getElementById('total').innerHTML = "Total: " + preco_piz + "€";
            pedido_final = quant_piz + "x " + text + "..." + preco_piz + "€";
            sessionStorage.setItem('pizza', pedido_final);
            sessionStorage.setItem('preco_piz', preco_piz);
            sessionStorage.setItem('quant_piz', quant_piz);
            save_request(text);
            document.getElementById("menos").style.display = "inline";
            document.getElementById("menos_l").style.display = "inline";
        }
    }

    if (text === "Bife com broculos") {
        quant_bif -= 1;
        preco_bif -= 8;
        if (quant_bif <= 0) {
            preco_bif = 0;
            quant_bif = 0;
            document.getElementById('bife').innerHTML = quant_bif + "x " + text + "..." + preco_bif + "€";
            pedido_final = quant_bif + "x " + text + "..." + preco_bif + "€";
            sessionStorage.setItem('bife', pedido_final);
            sessionStorage.setItem('preco_bif', preco_bif);
            sessionStorage.setItem('quant_bif', quant_bif);
            save_request(text);
            document.getElementById('bife').innerHTML = "";
            document.getElementById("menos").style.display = "none";
            document.getElementById("menos3").style.display = "none";
            if (document.getElementById("menos2").style.display === "none" || document.getElementById("menos2").style.display === "") {
                document.getElementById("menos_l").style.display = "none";
            } else {
                document.getElementById("menos_l").style.display = "inline";
            }
        } else {
            document.getElementById('bife').innerHTML = quant_bif + "x " + text + "..." + preco_bif + "€";
            document.getElementById('total').innerHTML = "Total: " + preco_bif + "€";
            pedido_final = quant_bif + "x " + text + "..." + preco_bif + "€";
            sessionStorage.setItem('bife', pedido_final);
            sessionStorage.setItem('preco_bif', preco_bif);
            sessionStorage.setItem('quant_bif', quant_bif);
            save_request(text);
            document.getElementById("menos").style.display = "inline";
            document.getElementById("menos3").style.display = "inline";
            document.getElementById("menos_l").style.display = "inline";
        }
    }

    if (text === "Lasanha de frango") {
        quant_las -= 1;
        preco_las -= 8;
        if (quant_las <= 0) {
            preco_las = 0;
            quant_las = 0;
            document.getElementById('lasanha').innerHTML = quant_las + "x " + text + "..." + preco_las + "€";
            pedido_final = quant_las + "x " + text + "..." + preco_las + "€";
            sessionStorage.setItem('lasanha', pedido_final);
            sessionStorage.setItem('preco_las', preco_las);
            sessionStorage.setItem('quant_las', quant_las);
            save_request(text);
            document.getElementById('lasanha').innerHTML = "";
            document.getElementById("menos").style.display = "none";
            document.getElementById("menos2").style.display = "none";
            if (document.getElementById("menos3").style.display === "none" || document.getElementById("menos3").style.display === "") {
                document.getElementById("menos_l").style.display = "none";
            } else {
                document.getElementById("menos_l").style.display = "inline";
            }
        } else {
            document.getElementById('lasanha').innerHTML = quant_las + "x " + text + "..." + preco_las + "€";
            document.getElementById('total').innerHTML = "Total: " + preco_las + "€";
            pedido_final = quant_las + "x " + text + "..." + preco_las + "€";
            sessionStorage.setItem('lasanha', pedido_final);
            sessionStorage.setItem('preco_las', preco_las);
            sessionStorage.setItem('quant_las', quant_las);
            save_request(text);
            document.getElementById("menos").style.display = "inline";
            document.getElementById("menos2").style.display = "inline";
            document.getElementById("menos_l").style.display = "inline";
        }
    }

    if (text === "Crepes com chocolate e morangos") {
        quant_cre -= 1;
        preco_cre -= 4;
        if (quant_cre <= 0) {
            preco_cre = 0;
            quant_cre = 0;
            document.getElementById('crepes').innerHTML = quant_cre + "x " + text + "..." + preco_cre + "€";
            pedido_final = quant_cre + "x " + text + "..." + preco_cre + "€";
            sessionStorage.setItem('crepes', pedido_final);
            sessionStorage.setItem('preco_cre', preco_cre);
            sessionStorage.setItem('quant_cre', quant_cre);
            save_request(text);
            document.getElementById('crepes').innerHTML = "";
            document.getElementById("menos").style.display = "none";
            document.getElementById("menos3").style.display = "none";
            if (document.getElementById("menos2").style.display === "none" || document.getElementById("menos2").style.display === "") {
                document.getElementById("menos_l").style.display = "none";
            } else {
                document.getElementById("menos_l").style.display = "inline";
            }
        } else {
            document.getElementById('crepes').innerHTML = quant_cre + "x " + text + "..." + preco_cre + "€";
            document.getElementById('total').innerHTML = "Total: " + preco_cre + "€";
            pedido_final = quant_cre + "x " + text + "..." + preco_cre + "€";
            sessionStorage.setItem('crepes', pedido_final);
            sessionStorage.setItem('preco_cre', preco_cre);
            sessionStorage.setItem('quant_cre', quant_cre);
            save_request(text);
            document.getElementById("menos").style.display = "inline";
            document.getElementById("menos3").style.display = "inline";
            document.getElementById("menos_l").style.display = "inline";
        }
    }
    if (text === "Waffle com chocolate") {
        quant_waf -= 1;
        preco_waf -= 3;
        if (quant_waf <= 0) {
            preco_waf = 0;
            quant_waf = 0;
            document.getElementById('waffle').innerHTML = quant_waf + "x " + text + "..." + preco_waf + "€";
            pedido_final = quant_waf + "x " + text + "..." + preco_waf + "€";
            sessionStorage.setItem('waffle', pedido_final);
            sessionStorage.setItem('preco_waf', preco_waf);
            sessionStorage.setItem('quant_waf', quant_waf);
            save_request(text);
            document.getElementById('waffle').innerHTML = "";
            document.getElementById("menos").style.display = "none";
            document.getElementById("menos2").style.display = "none";
            if (document.getElementById("menos3").style.display === "none" || document.getElementById("menos3").style.display === "") {
                document.getElementById("menos_l").style.display = "none";
            } else {
                document.getElementById("menos_l").style.display = "inline";
            }
        } else {
            document.getElementById('waffle').innerHTML = quant_waf + "x " + text + "..." + preco_waf + "€";
            document.getElementById('total').innerHTML = "Total: " + preco_waf + "€";
            pedido_final = quant_waf + "x " + text + "..." + preco_waf + "€";
            sessionStorage.setItem('waffle', pedido_final);
            sessionStorage.setItem('preco_waf', preco_waf);
            sessionStorage.setItem('quant_waf', quant_waf);
            save_request(text);
            document.getElementById("menos").style.display = "inline";
            document.getElementById("menos2").style.display = "inline";
            document.getElementById("menos_l").style.display = "inline";
        }
    }
    if (text === "Vinho do Porto") {
        quant_vin -= 1;
        preco_vin -= 1;
        if (preco_vin <= 0) {
            preco_vin = 0;
            quant_vin = 0;
            pedido_final = "";
            document.getElementById('vinho').innerHTML = quant_vin + "x " + text + "..." + preco_vin + "€";
            pedido_final = quant_vin + "x " + text + "..." + preco_vin + "€";
            sessionStorage.setItem('vinho', pedido_final);
            sessionStorage.setItem('preco_vin', preco_bur);
            sessionStorage.setItem('quant_vin', quant_bur);
            save_request(text);
            document.getElementById('vinho').innerHTML = "";
            document.getElementById("menos").style.display = "none";
            document.getElementById("menos_l").style.display = "none";
        } else {
            document.getElementById('vinho').innerHTML = quant_vin + "x " + text + "..." + preco_vin + "€";
            document.getElementById('total').innerHTML = "Total: " + preco_vin + "€";
            pedido_final = quant_vin + "x " + text + "..." + preco_vin + "€";
            sessionStorage.setItem('vinho', pedido_final);
            sessionStorage.setItem('preco_vin', preco_vin);
            sessionStorage.setItem('quant_vin', quant_vin);
            save_request(text);
            document.getElementById("menos").style.display = "inline";
            document.getElementById("menos_l").style.display = "inline";
        }
    }
    if (text === "Crepes com chocolate e morangos") {
        quant_cre -= 1;
        preco_cre -= 4;
        if (quant_cre <= 0) {
            preco_cre = 0;
            quant_cre = 0;
            document.getElementById('crepes').innerHTML = quant_cre + "x " + text + "..." + preco_cre + "€";
            pedido_final = quant_cre + "x " + text + "..." + preco_cre + "€";
            sessionStorage.setItem('crepes', pedido_final);
            sessionStorage.setItem('preco_cre', preco_cre);
            sessionStorage.setItem('quant_cre', quant_cre);
            save_request(text);
            document.getElementById('crepes').innerHTML = "";
            document.getElementById("menos").style.display = "none";
            document.getElementById("menos3").style.display = "none";
            if (document.getElementById("menos2").style.display === "none" || document.getElementById("menos2").style.display === "") {
                document.getElementById("menos_l").style.display = "none";
            } else {
                document.getElementById("menos_l").style.display = "inline";
            }
        } else {
            document.getElementById('crepes').innerHTML = quant_cre + "x " + text + "..." + preco_cre + "€";
            document.getElementById('total').innerHTML = "Total: " + preco_cre + "€";
            pedido_final = quant_cre + "x " + text + "..." + preco_cre + "€";
            sessionStorage.setItem('crepes', pedido_final);
            sessionStorage.setItem('preco_cre', preco_cre);
            sessionStorage.setItem('quant_cre', quant_cre);
            save_request(text);
            document.getElementById("menos").style.display = "inline";
            document.getElementById("menos3").style.display = "inline";
            document.getElementById("menos_l").style.display = "inline";
        }
    }
    if (text === "Coca Cola") {
        quant_coc -= 1;
        preco_coc -= 1;
        if (quant_coc <= 0) {
            preco_coc = 0;
            quant_coc = 0;
            document.getElementById('coca').innerHTML = quant_coc + "x " + text + "..." + preco_coc + "€";
            pedido_final = quant_coc + "x " + text + "..." + preco_coc + "€";
            sessionStorage.setItem('coca', pedido_final);
            sessionStorage.setItem('preco_coc', preco_coc);
            sessionStorage.setItem('quant_coc', quant_coc);
            save_request(text);
            document.getElementById('coca').innerHTML = "";
            document.getElementById("menos").style.display = "none";
            document.getElementById("menos_l").style.display = "none";
        } else {
            document.getElementById('coca').innerHTML = quant_coc + "x " + text + "..." + preco_coc + "€";
            document.getElementById('total').innerHTML = "Total: " + preco_coc + "€";
            pedido_final = quant_coc + "x " + text + "..." + preco_coc + "€";
            sessionStorage.setItem('coca', pedido_final);
            sessionStorage.setItem('preco_coc', preco_coc);
            sessionStorage.setItem('quant_coc', quant_coc);
            save_request(text);
            document.getElementById("menos").style.display = "inline";
            document.getElementById("menos_l").style.display = "inline";
        }
    }
    if (text === "Sumo natural de manga") {
        quant_sum -= 1;
        preco_sum -= 2;
        if (quant_sum <= 0) {
            preco_sum = 0;
            quant_sum = 0;
            document.getElementById('sumo').innerHTML = quant_sum + "x " + text + "..." + preco_sum + "€";
            pedido_final = quant_sum + "x " + text + "..." + preco_sum + "€";
            sessionStorage.setItem('sumo', pedido_final);
            sessionStorage.setItem('preco_sum', preco_sum);
            sessionStorage.setItem('quant_sum', quant_sum);
            save_request(text);
            document.getElementById('sumo').innerHTML = "";
            document.getElementById("menos").style.display = "none";
            document.getElementById("menos2").style.display = "none";
            if (document.getElementById("menos3").style.display === "none" || document.getElementById("menos3").style.display === "") {
                document.getElementById("menos_l").style.display = "none";
            } else {
                document.getElementById("menos_l").style.display = "inline";
            }
        } else {
            document.getElementById('sumo').innerHTML = quant_sum + "x " + text + "..." + preco_sum + "€";
            document.getElementById('total').innerHTML = "Total: " + preco_sum + "€";
            pedido_final = quant_sum + "x " + text + "..." + preco_sum + "€";
            sessionStorage.setItem('sumo', pedido_final);
            sessionStorage.setItem('preco_sum', preco_sum);
            sessionStorage.setItem('quant_sum', quant_sum);
            save_request(text);
            document.getElementById("menos").style.display = "inline";
            document.getElementById("menos2").style.display = "inline";
            document.getElementById("menos_l").style.display = "inline";
        }
    }
    if (text === "Água Fiji 0.5L") {
        quant_agu -= 1;
        preco_agu -= 1;
        if (quant_agu <= 0) {
            preco_agu = 0;
            quant_agu = 0;
            document.getElementById('agua').innerHTML = quant_agu + "x " + text + "..." + preco_agu + "€";
            pedido_final = quant_agu + "x " + text + "..." + preco_agu + "€";
            sessionStorage.setItem('agua', pedido_final);
            sessionStorage.setItem('preco_agu', preco_agu);
            sessionStorage.setItem('quant_agu', quant_agu);
            save_request(text);
            document.getElementById('agua').innerHTML = "";
            document.getElementById("menos").style.display = "none";
            document.getElementById("menos3").style.display = "none";
            if (document.getElementById("menos2").style.display === "none" || document.getElementById("menos2").style.display === "") {
                document.getElementById("menos_l").style.display = "none";
            } else {
                document.getElementById("menos_l").style.display = "inline";
            }
        } else {
            document.getElementById('agua').innerHTML = quant_agu + "x " + text + "..." + preco_agu + "€";
            document.getElementById('total').innerHTML = "Total: " + preco_agu + "€";
            pedido_final = quant_agu + "x " + text + "..." + preco_agu + "€";
            sessionStorage.setItem('agua', pedido_final);
            sessionStorage.setItem('preco_agu', preco_agu);
            sessionStorage.setItem('quant_agu', quant_agu);
            save_request(text);
            document.getElementById("menos").style.display = "inline";
            document.getElementById("menos2").style.display = "inline";
            document.getElementById("menos_l").style.display = "inline";
        }
    }
    if (text === "Cozido à portuguesa") {
        quant_coz -= 1;
        preco_coz -= 5;
        if (quant_coz <= 0) {
            preco_coz = 0;
            quant_coz = 0;
            document.getElementById('cozido').innerHTML = quant_coz + "x " + text + "..." + preco_coz + "€";
            pedido_final = quant_coz + "x " + text + "..." + preco_coz + "€";
            sessionStorage.setItem('cozido', pedido_final);
            sessionStorage.setItem('preco_coz', preco_coz);
            sessionStorage.setItem('quant_coz', quant_coz);
            save_request(text);
            document.getElementById('cozido').innerHTML = "";
            document.getElementById("menos").style.display = "none";
            document.getElementById("menos3").style.display = "none";
            if (document.getElementById("menos2").style.display === "none" || document.getElementById("menos2").style.display === "") {
                document.getElementById("menos_l").style.display = "none";
            } else {
                document.getElementById("menos_l").style.display = "inline";
            }
        } else {
            document.getElementById('cozido').innerHTML = quant_coz + "x " + text + "..." + preco_coz + "€";
            document.getElementById('total').innerHTML = "Total: " + preco_coz + "€";
            pedido_final = quant_coz + "x " + text + "..." + preco_coz + "€";
            sessionStorage.setItem('cozido', pedido_final);
            sessionStorage.setItem('preco_coz', preco_coz);
            sessionStorage.setItem('quant_coz', quant_coz);
            save_request(text);
            document.getElementById("menos").style.display = "inline";
            document.getElementById("menos3").style.display = "inline";
            document.getElementById("menos_l").style.display = "inline";
        }
    }
    if (text === "Francesinha") {
        quant_fra -= 1;
        preco_fra -= 6;
        if (quant_fra <= 0) {
            preco_fra = 0;
            quant_fra = 0;
            document.getElementById('france').innerHTML = quant_fra + "x " + text + "..." + preco_fra + "€";
            pedido_final = quant_fra + "x " + text + "..." + preco_fra + "€";
            sessionStorage.setItem('france', pedido_final);
            sessionStorage.setItem('preco_fra', preco_fra);
            sessionStorage.setItem('quant_fra', quant_fra);
            save_request(text);
            document.getElementById('france').innerHTML = "";
            document.getElementById("menos").style.display = "none";
            document.getElementById("menos2").style.display = "none";
            if (document.getElementById("menos3").style.display === "none" || document.getElementById("menos3").style.display === "") {
                document.getElementById("menos_l").style.display = "none";
            } else {
                document.getElementById("menos_l").style.display = "inline";
            }
        } else {
            document.getElementById('france').innerHTML = quant_fra + "x " + text + "..." + preco_fra + "€";
            document.getElementById('total').innerHTML = "Total: " + preco_fra + "€";
            pedido_final = quant_fra + "x " + text + "..." + preco_fra + "€";
            sessionStorage.setItem('france', pedido_final);
            sessionStorage.setItem('preco_fra', preco_fra);
            sessionStorage.setItem('quant_fra', quant_fra);
            save_request(text);
            document.getElementById("menos").style.display = "inline";
            document.getElementById("menos2").style.display = "inline";
            document.getElementById("menos_l").style.display = "inline";
        }
    }
    if (text === "Biryani") {
        quant_bir -= 1;
        preco_bir -= 5;
        if (quant_bir <= 0) {
            preco_bir = 0;
            quant_bir = 0;
            document.getElementById('bir').innerHTML = quant_bir + "x " + text + "..." + preco_bir + "€";
            pedido_final = quant_bir + "x " + text + "..." + preco_bir + "€";
            sessionStorage.setItem('bir', pedido_final);
            sessionStorage.setItem('preco_bir', preco_bir);
            sessionStorage.setItem('quant_bir', quant_bir);
            save_request(text);
            document.getElementById('bir').innerHTML = "";
            document.getElementById("menos").style.display = "none";
            document.getElementById("menos3").style.display = "none";
            if (document.getElementById("menos2").style.display === "none" || document.getElementById("menos2").style.display === "") {
                document.getElementById("menos_l").style.display = "none";
            } else {
                document.getElementById("menos_l").style.display = "inline";
            }
        } else {
            document.getElementById('bir').innerHTML = quant_bir + "x " + text + "..." + preco_bir + "€";
            document.getElementById('total').innerHTML = "Total: " + preco_bir + "€";
            pedido_final = quant_bir + "x " + text + "..." + preco_bir + "€";
            sessionStorage.setItem('bir', pedido_final);
            sessionStorage.setItem('preco_bir', preco_bir);
            sessionStorage.setItem('quant_bir', quant_bir);
            save_request(text);
            document.getElementById("menos").style.display = "inline";
            document.getElementById("menos3").style.display = "inline";
            document.getElementById("menos_l").style.display = "inline";
        }
    }
    if (text === "Caril de frango") {
        quant_car -= 1;
        preco_car -= 6;
        if (quant_car <= 0) {
            preco_car = 0;
            quant_car = 0;
            document.getElementById('caril').innerHTML = quant_car + "x " + text + "..." + preco_car + "€";
            pedido_final = quant_car + "x " + text + "..." + preco_car + "€";
            sessionStorage.setItem('caril', pedido_final);
            sessionStorage.setItem('preco_car', preco_car);
            sessionStorage.setItem('quant_car', quant_car);
            save_request(text);
            document.getElementById('caril').innerHTML = "";
            document.getElementById("menos").style.display = "none";
            document.getElementById("menos2").style.display = "none";
            if (document.getElementById("menos3").style.display === "none" || document.getElementById("menos3").style.display === "") {
                document.getElementById("menos_l").style.display = "none";
            } else {
                document.getElementById("menos_l").style.display = "inline";
            }
        } else {
            document.getElementById('caril').innerHTML = quant_car + "x " + text + "..." + preco_car + "€";
            document.getElementById('total').innerHTML = "Total: " + preco_car + "€";
            pedido_final = quant_car + "x " + text + "..." + preco_car + "€";
            sessionStorage.setItem('caril', pedido_final);
            sessionStorage.setItem('preco_car', preco_car);
            sessionStorage.setItem('quant_car', quant_car);
            save_request(text);
            document.getElementById("menos").style.display = "inline";
            document.getElementById("menos2").style.display = "inline";
            document.getElementById("menos_l").style.display = "inline";
        }
    }
    if (text === "Bolonhesa") {
        quant_bol -= 1;
        preco_bol -= 5;
        if (quant_bol <= 0) {
            preco_bol = 0;
            quant_bol = 0;
            document.getElementById('bolonhesa').innerHTML = quant_bol + "x " + text + "..." + preco_bol + "€";
            pedido_final = quant_bol + "x " + text + "..." + preco_bol + "€";
            sessionStorage.setItem('bolonhesa', pedido_final);
            sessionStorage.setItem('preco_bol', preco_bol);
            sessionStorage.setItem('quant_bol', quant_bol);
            save_request(text);
            document.getElementById('bolonhesa').innerHTML = "";
            document.getElementById("menos").style.display = "none";
            document.getElementById("menos3").style.display = "none";
            if (document.getElementById("menos2").style.display === "none" || document.getElementById("menos2").style.display === "") {
                document.getElementById("menos_l").style.display = "none";
            } else {
                document.getElementById("menos_l").style.display = "inline";
            }
        } else {
            document.getElementById('bolonhesa').innerHTML = quant_bol + "x " + text + "..." + preco_bol + "€";
            document.getElementById('total').innerHTML = "Total: " + preco_bol + "€";
            pedido_final = quant_bol + "x " + text + "..." + preco_bol + "€";
            sessionStorage.setItem('bolonhesa', pedido_final);
            sessionStorage.setItem('preco_bol', preco_bol);
            sessionStorage.setItem('quant_bol', quant_bol);
            save_request(text);
            document.getElementById("menos").style.display = "inline";
            document.getElementById("menos3").style.display = "inline";
            document.getElementById("menos_l").style.display = "inline";
        }
    }
    if (text === "Risotto") {
        quant_ris -= 1;
        preco_ris -= 7;
        if (quant_ris <= 0) {
            preco_ris = 0;
            quant_ris = 0;
            document.getElementById('risotto').innerHTML = quant_ris + "x " + text + "..." + preco_ris + "€";
            pedido_final = quant_ris + "x " + text + "..." + preco_ris + "€";
            sessionStorage.setItem('risotto', pedido_final);
            sessionStorage.setItem('preco_ris', preco_ris);
            sessionStorage.setItem('quant_ris', quant_ris);
            save_request(text);
            document.getElementById('risotto').innerHTML = "";
            document.getElementById("menos").style.display = "none";
            document.getElementById("menos2").style.display = "none";
            if (document.getElementById("menos3").style.display === "none" || document.getElementById("menos3").style.display === "") {
                document.getElementById("menos_l").style.display = "none";
            } else {
                document.getElementById("menos_l").style.display = "inline";
            }
        } else {
            document.getElementById('risotto').innerHTML = quant_ris + "x " + text + "..." + preco_ris + "€";
            document.getElementById('total').innerHTML = "Total: " + preco_ris + "€";
            pedido_final = quant_ris + "x " + text + "..." + preco_ris + "€";
            sessionStorage.setItem('risotto', pedido_final);
            sessionStorage.setItem('preco_ris', preco_ris);
            sessionStorage.setItem('quant_ris', quant_ris);
            save_request(text);
            document.getElementById("menos").style.display = "inline";
            document.getElementById("menos2").style.display = "inline";
            document.getElementById("menos_l").style.display = "inline";
        }
    }
    if (text === "Quinoa com legumes") {
        quant_qui -= 1;
        preco_qui -= 4;
        if (quant_qui <= 0) {
            preco_qui = 0;
            quant_qui = 0;
            document.getElementById('quinoa').innerHTML = quant_qui + "x " + text + "..." + preco_qui + "€";
            pedido_final = quant_qui + "x " + text + "..." + preco_qui + "€";
            sessionStorage.setItem('quinoa', pedido_final);
            sessionStorage.setItem('preco_qui', preco_qui);
            sessionStorage.setItem('quant_qui', quant_qui);
            save_request(text);
            document.getElementById('quinoa').innerHTML = "";
            document.getElementById("menos").style.display = "none";
            document.getElementById("menos3").style.display = "none";
            if (document.getElementById("menos2").style.display === "none" || document.getElementById("menos2").style.display === "") {
                document.getElementById("menos_l").style.display = "none";
            } else {
                document.getElementById("menos_l").style.display = "inline";
            }
        } else {
            document.getElementById('quinoa').innerHTML = quant_qui + "x " + text + "..." + preco_qui + "€";
            document.getElementById('total').innerHTML = "Total: " + preco_qui + "€";
            pedido_final = quant_qui + "x " + text + "..." + preco_qui + "€";
            sessionStorage.setItem('quinoa', pedido_final);
            sessionStorage.setItem('preco_qui', preco_qui);
            sessionStorage.setItem('quant_qui', quant_qui);
            save_request(text);
            document.getElementById("menos").style.display = "inline";
            document.getElementById("menos3").style.display = "inline";
            document.getElementById("menos_l").style.display = "inline";
        }
    }
    if (text === "Beringela recheada") {
        quant_ber -= 1;
        preco_ber -= 5;
        if (quant_ber <= 0) {
            preco_ber = 0;
            quant_ber = 0;
            document.getElementById('beringela').innerHTML = quant_ber + "x " + text + "..." + preco_ber + "€";
            pedido_final = quant_ber + "x " + text + "..." + preco_ber + "€";
            sessionStorage.setItem('beringela', pedido_final);
            sessionStorage.setItem('preco_ber', preco_ber);
            sessionStorage.setItem('quant_ber', quant_ber);
            save_request(text);
            document.getElementById('beringela').innerHTML = "";
            document.getElementById("menos").style.display = "none";
            document.getElementById("menos2").style.display = "none";
            if (document.getElementById("menos3").style.display === "none" || document.getElementById("menos3").style.display === "") {
                document.getElementById("menos_l").style.display = "none";
            } else {
                document.getElementById("menos_l").style.display = "inline";
            }
        } else {
            document.getElementById('beringela').innerHTML = quant_ber + "x " + text + "..." + preco_ber + "€";
            document.getElementById('total').innerHTML = "Total: " + preco_ber + "€";
            pedido_final = quant_ber + "x " + text + "..." + preco_ber + "€";
            sessionStorage.setItem('beringela', pedido_final);
            sessionStorage.setItem('preco_ber', preco_ber);
            sessionStorage.setItem('quant_ber', quant_ber);
            save_request(text);
            document.getElementById("menos").style.display = "inline";
            document.getElementById("menos2").style.display = "inline";
            document.getElementById("menos_l").style.display = "inline";
        }
    }
    if (text === "Hamburger") {
        quant_ham -= 1;
        preco_ham -= 2;
        if (quant_ham <= 0) {
            preco_ham = 0;
            quant_ham = 0;
            pedido_final = "";
            document.getElementById('hamburguer').innerHTML = quant_ham + "x " + text + "..." + preco_ham + "€";
            pedido_final = quant_ham + "x " + text + "..." + preco_ham + "€";
            sessionStorage.setItem('hamburguer', pedido_final);
            sessionStorage.setItem('preco_ham', preco_ham);
            sessionStorage.setItem('quant_ham', quant_ham);
            save_request(text);
            document.getElementById('hamburguer').innerHTML = "";
            document.getElementById("menos").style.display = "none";
            document.getElementById("menos_l").style.display = "none";
        } else {
            document.getElementById('hamburguer').innerHTML = quant_ham + "x " + text + "..." + preco_ham + "€";
            document.getElementById('total').innerHTML = "Total: " + preco_ham + "€";
            pedido_final = quant_ham + "x " + text + "..." + preco_ham + "€";
            sessionStorage.setItem('hamburguer', pedido_final);
            sessionStorage.setItem('preco_ham', preco_ham);
            sessionStorage.setItem('quant_ham', quant_ham);
            save_request(text);
            document.getElementById("menos").style.display = "inline";
            document.getElementById("menos_l").style.display = "inline";
        }
    }
    if (text === "Chop suey de gambas") {
        quant_cho -= 1;
        preco_cho -= 7;
        if (quant_cho <= 0) {
            preco_cho = 0;
            quant_cho = 0;
            document.getElementById('chop').innerHTML = quant_cho + "x " + text + "..." + preco_cho + "€";
            pedido_final = quant_cho + "x " + text + "..." + preco_cho + "€";
            sessionStorage.setItem('chop', pedido_final);
            sessionStorage.setItem('preco_cho', preco_cho);
            sessionStorage.setItem('quant_cho', quant_cho);
            save_request(text);
            document.getElementById('chop').innerHTML = "";
            document.getElementById("menos").style.display = "none";
            document.getElementById("menos3").style.display = "none";
            if (document.getElementById("menos2").style.display === "none" || document.getElementById("menos2").style.display === "") {
                document.getElementById("menos_l").style.display = "none";
            } else {
                document.getElementById("menos_l").style.display = "inline";
            }
        } else {
            document.getElementById('chop').innerHTML = quant_cho + "x " + text + "..." + preco_cho + "€";
            document.getElementById('total').innerHTML = "Total: " + preco_cho + "€";
            pedido_final = quant_cho + "x " + text + "..." + preco_cho + "€";
            sessionStorage.setItem('chop', pedido_final);
            sessionStorage.setItem('preco_cho', preco_cho);
            sessionStorage.setItem('quant_cho', quant_cho);
            save_request(text);
            document.getElementById("menos").style.display = "inline";
            document.getElementById("menos3").style.display = "inline";
            document.getElementById("menos_l").style.display = "inline";
        }
    }
    if (text === "12 Rolos Chun Juan") {
        quant_chu -= 1;
        preco_chu -= 6;
        if (quant_chu <= 0) {
            preco_chu = 0;
            quant_chu = 0;
            document.getElementById('chun').innerHTML = quant_chu + "x " + text + "..." + preco_chu + "€";
            pedido_final = quant_chu + "x " + text + "..." + preco_chu + "€";
            sessionStorage.setItem('chun', pedido_final);
            sessionStorage.setItem('preco_chu', preco_chu);
            sessionStorage.setItem('quant_chu', quant_chu);
            save_request(text);
            document.getElementById('chun').innerHTML = "";
            document.getElementById("menos").style.display = "none";
            document.getElementById("menos2").style.display = "none";
            if (document.getElementById("menos3").style.display === "none" || document.getElementById("menos3").style.display === "") {
                document.getElementById("menos_l").style.display = "none";
            } else {
                document.getElementById("menos_l").style.display = "inline";
            }
        } else {
            document.getElementById('chun').innerHTML = quant_chu + "x " + text + "..." + preco_chu + "€";
            document.getElementById('total').innerHTML = "Total: " + preco_chu + "€";
            pedido_final = quant_chu + "x " + text + "..." + preco_chu + "€";
            sessionStorage.setItem('chun', pedido_final);
            sessionStorage.setItem('preco_chu', preco_chu);
            sessionStorage.setItem('quant_chu', quant_chu);
            save_request(text);
            document.getElementById("menos").style.display = "inline";
            document.getElementById("menos2").style.display = "inline";
            document.getElementById("menos_l").style.display = "inline";
        }
    }
    if (text === "12 Peças de Sushi") {
        quant_sus -= 1;
        preco_sus -= 7;
        if (quant_sus <= 0) {
            preco_sus = 0;
            quant_sus = 0;
            document.getElementById('sushi').innerHTML = quant_sus + "x " + text + "..." + preco_sus + "€";
            pedido_final = quant_sus + "x " + text + "..." + preco_sus + "€";
            sessionStorage.setItem('sushi', pedido_final);
            sessionStorage.setItem('preco_sus', preco_sus);
            sessionStorage.setItem('quant_sus', quant_sus);
            save_request(text);
            document.getElementById('sushi').innerHTML = "";
            document.getElementById("menos").style.display = "none";
            document.getElementById("menos3").style.display = "none";
            if (document.getElementById("menos2").style.display === "none" || document.getElementById("menos2").style.display === "") {
                document.getElementById("menos_l").style.display = "none";
            } else {
                document.getElementById("menos_l").style.display = "inline";
            }
        } else {
            document.getElementById('sushi').innerHTML = quant_sus + "x " + text + "..." + preco_sus + "€";
            document.getElementById('total').innerHTML = "Total: " + preco_sus + "€";
            pedido_final = quant_sus + "x " + text + "..." + preco_sus + "€";
            sessionStorage.setItem('sushi', pedido_final);
            sessionStorage.setItem('preco_sus', preco_sus);
            sessionStorage.setItem('quant_sus', quant_sus);
            save_request(text);
            document.getElementById("menos").style.display = "inline";
            document.getElementById("menos3").style.display = "inline";
            document.getElementById("menos_l").style.display = "inline";
        }
    }
    if (text === "5 Espetadas de Yakitori") {
        quant_yak -= 1;
        preco_yak -= 4;
        if (quant_yak <= 0) {
            preco_yak = 0;
            quant_yak = 0;
            document.getElementById('yak').innerHTML = quant_yak + "x " + text + "..." + preco_yak + "€";
            pedido_final = quant_yak + "x " + text + "..." + preco_yak + "€";
            sessionStorage.setItem('yak', pedido_final);
            sessionStorage.setItem('preco_yak', preco_yak);
            sessionStorage.setItem('quant_yak', quant_yak);
            save_request(text);
            document.getElementById('yak').innerHTML = "";
            document.getElementById("menos").style.display = "none";
            document.getElementById("menos2").style.display = "none";
            if (document.getElementById("menos3").style.display === "none" || document.getElementById("menos3").style.display === "") {
                document.getElementById("menos_l").style.display = "none";
            } else {
                document.getElementById("menos_l").style.display = "inline";
            }
        } else {
            document.getElementById('yak').innerHTML = quant_yak + "x " + text + "..." + preco_yak + "€";
            document.getElementById('total').innerHTML = "Total: " + preco_yak + "€";
            pedido_final = quant_yak + "x " + text + "..." + preco_yak + "€";
            sessionStorage.setItem('yak', pedido_final);
            sessionStorage.setItem('preco_yak', preco_yak);
            sessionStorage.setItem('quant_yak', quant_yak);
            save_request(text);
            document.getElementById("menos").style.display = "inline";
            document.getElementById("menos2").style.display = "inline";
            document.getElementById("menos_l").style.display = "inline";
        }
    }
    if (text === "Sopa de espinafres") {
        quant_sop -= 1;
        preco_sop -= 1;
        if (quant_sop <= 0) {
            preco_sop = 0;
            quant_sop = 0;
            document.getElementById('sopa').innerHTML = quant_sop + "x " + text + "..." + preco_sop + "€";
            pedido_final = quant_sop + "x " + text + "..." + preco_sop + "€";
            sessionStorage.setItem('sopa', pedido_final);
            sessionStorage.setItem('preco_sop', preco_sop);
            sessionStorage.setItem('quant_sop', quant_sop);
            save_request(text);
            document.getElementById('sopa').innerHTML = "";
            document.getElementById("menos").style.display = "none";
            document.getElementById("menos3").style.display = "none";
            if (document.getElementById("menos2").style.display === "none" || document.getElementById("menos2").style.display === "") {
                document.getElementById("menos_l").style.display = "none";
            } else {
                document.getElementById("menos_l").style.display = "inline";
            }
        } else {
            document.getElementById('sopa').innerHTML = quant_sop + "x " + text + "..." + preco_sop + "€";
            document.getElementById('total').innerHTML = "Total: " + preco_sop + "€";
            pedido_final = quant_sop + "x " + text + "..." + preco_sop + "€";
            sessionStorage.setItem('sopa', pedido_final);
            sessionStorage.setItem('preco_sop', preco_sop);
            sessionStorage.setItem('quant_sop', quant_sop);
            save_request(text);
            document.getElementById("menos").style.display = "inline";
            document.getElementById("menos3").style.display = "inline";
            document.getElementById("menos_l").style.display = "inline";
        }
    }
    if (text === "Peito de frango grelhado com legumes") {
        quant_pei -= 1;
        preco_pei -= 5;
        if (quant_pei <= 0) {
            preco_pei = 0;
            quant_pei = 0;
            document.getElementById('peito').innerHTML = quant_pei + "x " + text + "..." + preco_pei + "€";
            pedido_final = quant_pei + "x " + text + "..." + preco_pei + "€";
            sessionStorage.setItem('peito', pedido_final);
            sessionStorage.setItem('preco_pei', preco_pei);
            sessionStorage.setItem('quant_pei', quant_pei);
            save_request(text);
            document.getElementById('peito').innerHTML = "";
            document.getElementById("menos").style.display = "none";
            document.getElementById("menos2").style.display = "none";
            if (document.getElementById("menos3").style.display === "none" || document.getElementById("menos3").style.display === "") {
                document.getElementById("menos_l").style.display = "none";
            } else {
                document.getElementById("menos_l").style.display = "inline";
            }
        } else {
            document.getElementById('peito').innerHTML = quant_pei + "x " + text + "..." + preco_pei + "€";
            document.getElementById('total').innerHTML = "Total: " + preco_pei + "€";
            pedido_final = quant_pei + "x " + text + "..." + preco_pei + "€";
            sessionStorage.setItem('peito', pedido_final);
            sessionStorage.setItem('preco_pei', preco_pei);
            sessionStorage.setItem('quant_pei', quant_pei);
            save_request(text);
            document.getElementById("menos").style.display = "inline";
            document.getElementById("menos2").style.display = "inline";
            document.getElementById("menos_l").style.display = "inline";
        }
    }
    if (text === "Bacalhau com broa") {
        quant_bac -= 1;
        preco_bac -= 5;
        if (quant_bac <= 0) {
            preco_bac = 0;
            quant_bac = 0;
            document.getElementById('bacalhau').innerHTML = quant_bac + "x " + text + "..." + preco_bac + "€";
            pedido_final = quant_bac + "x " + text + "..." + preco_bac + "€";
            sessionStorage.setItem('bacalhau', pedido_final);
            sessionStorage.setItem('preco_bac', preco_bac);
            sessionStorage.setItem('quant_bac', quant_bac);
            save_request(text);
            document.getElementById('bacalhau').innerHTML = "";
            document.getElementById("menos").style.display = "none";
            document.getElementById("menos3").style.display = "none";
            if (document.getElementById("menos2").style.display === "none" || document.getElementById("menos2").style.display === "") {
                document.getElementById("menos_l").style.display = "none";
            } else {
                document.getElementById("menos_l").style.display = "inline";
            }
        } else {
            document.getElementById('bacalhau').innerHTML = quant_bac + "x " + text + "..." + preco_bac + "€";
            document.getElementById('total').innerHTML = "Total: " + preco_bac + "€";
            pedido_final = quant_bac + "x " + text + "..." + preco_bac + "€";
            sessionStorage.setItem('bacalhau', pedido_final);
            sessionStorage.setItem('preco_bac', preco_bac);
            sessionStorage.setItem('quant_bac', quant_bac);
            save_request(text);
            document.getElementById("menos").style.display = "inline";
            document.getElementById("menos3").style.display = "inline";
            document.getElementById("menos_l").style.display = "inline";
        }
    }
    if (text === "Salmão grelhado com legumes") {
        quant_sal -= 1;
        preco_sal -= 5;
        if (quant_sal <= 0) {
            preco_sal = 0;
            quant_sal = 0;
            document.getElementById('salmao').innerHTML = quant_sal + "x " + text + "..." + preco_sal + "€";
            pedido_final = quant_sal + "x " + text + "..." + preco_sal + "€";
            sessionStorage.setItem('salmao', pedido_final);
            sessionStorage.setItem('preco_sal', preco_sal);
            sessionStorage.setItem('quant_sal', quant_sal);
            save_request(text);
            document.getElementById('salmao').innerHTML = "";
            document.getElementById("menos").style.display = "none";
            document.getElementById("menos2").style.display = "none";
            if (document.getElementById("menos3").style.display === "none" || document.getElementById("menos3").style.display === "") {
                document.getElementById("menos_l").style.display = "none";
            } else {
                document.getElementById("menos_l").style.display = "inline";
            }
        } else {
            document.getElementById('salmao').innerHTML = quant_sal + "x " + text + "..." + preco_sal + "€";
            document.getElementById('total').innerHTML = "Total: " + preco_sal + "€";
            pedido_final = quant_sal + "x " + text + "..." + preco_sal + "€";
            sessionStorage.setItem('salmao', pedido_final);
            sessionStorage.setItem('preco_sal', preco_sal);
            sessionStorage.setItem('quant_sal', quant_sal);
            save_request(text);
            document.getElementById("menos").style.display = "inline";
            document.getElementById("menos2").style.display = "inline";
            document.getElementById("menos_l").style.display = "inline";
        }
    }
    if (text === "Salmão grelhado, sangria da casa e gelado") {
        quant_msal -= 1;
        preco_msal -= 11;
        if (quant_msal <= 0) {
            preco_msal = 0;
            quant_msal = 0;
            pedido_final = "";
            document.getElementById('msalmao').innerHTML = quant_msal + "x " + text + "..." + preco_msal + "€";
            pedido_final = quant_msal + "x " + text + "..." + preco_msal + "€";
            sessionStorage.setItem('msalmao', pedido_final);
            sessionStorage.setItem('preco_msal', preco_msal);
            sessionStorage.setItem('quant_msal', quant_msal);
            save_request(text);
            document.getElementById('msalmao').innerHTML = "";
            document.getElementById("menos").style.display = "none";
            document.getElementById("menos_l").style.display = "none";
        } else {
            document.getElementById('msalmao').innerHTML = quant_msal + "x " + text + "..." + preco_msal + "€";
            document.getElementById('total').innerHTML = "Total: " + preco_msal + "€";
            pedido_final = quant_msal + "x " + text + "..." + preco_msal + "€";
            sessionStorage.setItem('msalmao', pedido_final);
            sessionStorage.setItem('preco_msal', preco_msal);
            sessionStorage.setItem('quant_msal', quant_msal);
            save_request(text);
            document.getElementById("menos").style.display = "inline";
            document.getElementById("menos_l").style.display = "inline";
        }
    }
    if (text === "Salada de frango, limonada e maçã") {
        quant_saf -= 1;
        preco_saf -= 4;
        if (quant_saf <= 0) {
            preco_saf = 0;
            quant_saf = 0;
            pedido_final = "";
            document.getElementById('salada_f').innerHTML = quant_saf + "x " + text + "..." + preco_saf + "€";
            pedido_final = quant_saf + "x " + text + "..." + preco_saf + "€";
            sessionStorage.setItem('salada_f', pedido_final);
            sessionStorage.setItem('preco_saf', preco_saf);
            sessionStorage.setItem('quant_saf', quant_saf);
            save_request(text);
            document.getElementById('salada_f').innerHTML = "";
            document.getElementById("menos").style.display = "none";
            document.getElementById("menos_l").style.display = "none";
        } else {
            document.getElementById('salada_f').innerHTML = quant_saf + "x " + text + "..." + preco_saf + "€";
            document.getElementById('total').innerHTML = "Total: " + preco_saf + "€";
            pedido_final = quant_saf + "x " + text + "..." + preco_saf + "€";
            sessionStorage.setItem('salada_f', pedido_final);
            sessionStorage.setItem('preco_saf', preco_saf);
            sessionStorage.setItem('quant_saf', quant_saf);
            save_request(text);
            document.getElementById("menos").style.display = "inline";
            document.getElementById("menos_l").style.display = "inline";
        }
    }
    if (text === "Bife com ovo estrelado, vinho verde e pastel de nata") {
        quant_mbif -= 1;
        preco_mbif -= 11;
        if (quant_mbif <= 0) {
            preco_mbif = 0;
            quant_mbif = 0;
            pedido_final = "";
            document.getElementById('mbife').innerHTML = quant_mbif + "x " + text + "..." + preco_mbif + "€";
            pedido_final = quant_mbif + "x " + text + "..." + preco_mbif + "€";
            sessionStorage.setItem('mbife', pedido_final);
            sessionStorage.setItem('preco_mbif', preco_mbif);
            sessionStorage.setItem('quant_mbif', quant_mbif);
            save_request(text);
            document.getElementById('mbife').innerHTML = "";
            document.getElementById("menos").style.display = "none";
            document.getElementById("menos_l").style.display = "none";
        } else {
            document.getElementById('mbife').innerHTML = quant_mbif + "x " + text + "..." + preco_mbif + "€";
            document.getElementById('total').innerHTML = "Total: " + preco_mbif + "€";
            pedido_final = quant_mbif + "x " + text + "..." + preco_mbif + "€";
            sessionStorage.setItem('mbife', pedido_final);
            sessionStorage.setItem('preco_mbif', preco_mbif);
            sessionStorage.setItem('quant_mbif', quant_mbif);
            save_request(text);
            document.getElementById("menos").style.display = "inline";
            document.getElementById("menos_l").style.display = "inline";
        }
    }
    if (text === "Bolonhesa, sumo de pêssego e semi-frio") {
        quant_mbol -= 1;
        preco_mbol -= 10;
        if (quant_mbol <= 0) {
            preco_mbol = 0;
            quant_mbol = 0;
            pedido_final = "";
            document.getElementById('mbolonhesa').innerHTML = quant_mbol + "x " + text + "..." + preco_mbol + "€";
            pedido_final = quant_mbol + "x " + text + "..." + preco_mbol + "€";
            sessionStorage.setItem('mbolonhesa', pedido_final);
            sessionStorage.setItem('preco_mbol', preco_mbol);
            sessionStorage.setItem('quant_mbol', quant_mbol);
            save_request(text);
            document.getElementById('mbolonhesa').innerHTML = "";
            document.getElementById("menos").style.display = "none";
            document.getElementById("menos_l").style.display = "none";
        } else {
            document.getElementById('mbolonhesa').innerHTML = quant_mbol + "x " + text + "..." + preco_mbol + "€";
            document.getElementById('total').innerHTML = "Total: " + preco_mbol + "€";
            pedido_final = quant_mbol + "x " + text + "..." + preco_mbol + "€";
            sessionStorage.setItem('mbolonhesa', pedido_final);
            sessionStorage.setItem('preco_mbol', preco_mbol);
            sessionStorage.setItem('quant_mbol', quant_mbol);
            save_request(text);
            document.getElementById("menos").style.display = "inline";
            document.getElementById("menos_l").style.display = "inline";
        }
    }
    if (text === "14 Peças de Sushi, limonada e petit-gâteau") {
        quant_msus -= 1;
        preco_msus -= 12;
        if (quant_msus <= 0) {
            preco_msus = 0;
            quant_msus = 0;
            pedido_final = "";
            document.getElementById('msushi').innerHTML = quant_msus + "x " + text + "..." + preco_msus + "€";
            pedido_final = quant_msus + "x " + text + "..." + preco_msus + "€";
            sessionStorage.setItem('msushi', pedido_final);
            sessionStorage.setItem('preco_msus', preco_msus);
            sessionStorage.setItem('quant_msus', quant_msus);
            save_request(text);
            document.getElementById('msushi').innerHTML = "";
            document.getElementById("menos").style.display = "none";
            document.getElementById("menos_l").style.display = "none";
        } else {
            document.getElementById('msushi').innerHTML = quant_msus + "x " + text + "..." + preco_msus + "€";
            document.getElementById('total').innerHTML = "Total: " + preco_msus + "€";
            pedido_final = quant_msus + "x " + text + "..." + preco_msus + "€";
            sessionStorage.setItem('msushi', pedido_final);
            sessionStorage.setItem('preco_msus', preco_msus);
            sessionStorage.setItem('quant_msus', quant_msus);
            save_request(text);
            document.getElementById("menos").style.display = "inline";
            document.getElementById("menos_l").style.display = "inline";
        }
    }
    if (text === "Caril de frango, sumo de laranja e doce ghi") {
        quant_mcar -= 1;
        preco_mcar -= 9;
        if (quant_mcar <= 0) {
            preco_mcar = 0;
            quant_mcar = 0;
            pedido_final = "";
            document.getElementById('mcaril').innerHTML = quant_mcar + "x " + text + "..." + preco_mcar + "€";
            pedido_final = quant_mcar + "x " + text + "..." + preco_mcar + "€";
            sessionStorage.setItem('mcaril', pedido_final);
            sessionStorage.setItem('preco_mcar', preco_mcar);
            sessionStorage.setItem('quant_mcar', quant_mcar);
            save_request(text);
            document.getElementById('mcaril').innerHTML = "";
            document.getElementById("menos").style.display = "none";
            document.getElementById("menos_l").style.display = "none";
        } else {
            document.getElementById('mcaril').innerHTML = quant_mcar + "x " + text + "..." + preco_mcar + "€";
            document.getElementById('total').innerHTML = "Total: " + preco_mcar + "€";
            pedido_final = quant_mcar + "x " + text + "..." + preco_mcar + "€";
            sessionStorage.setItem('mcaril', pedido_final);
            sessionStorage.setItem('preco_mcar', preco_mcar);
            sessionStorage.setItem('quant_mcar', quant_mcar);
            save_request(text);
            document.getElementById("menos").style.display = "inline";
            document.getElementById("menos_l").style.display = "inline";
        }
    }
    if (text === "Chop suey de frango, sangria e gelado") {
        quant_mcho -= 1;
        preco_mcho -= 9;
        if (quant_mcho <= 0) {
            preco_mcho = 0;
            quant_mcho = 0;
            pedido_final = "";
            document.getElementById('mchop').innerHTML = quant_mcho + "x " + text + "..." + preco_mcho + "€";
            pedido_final = quant_mcho + "x " + text + "..." + preco_mcho + "€";
            sessionStorage.setItem('mchop', pedido_final);
            sessionStorage.setItem('preco_mcho', preco_mcho);
            sessionStorage.setItem('quant_mcho', quant_mcho);
            save_request(text);
            document.getElementById('mchop').innerHTML = "";
            document.getElementById("menos").style.display = "none";
            document.getElementById("menos_l").style.display = "none";
        } else {
            document.getElementById('mchop').innerHTML = quant_mcho + "x " + text + "..." + preco_mcho + "€";
            document.getElementById('total').innerHTML = "Total: " + preco_mcho + "€";
            pedido_final = quant_mcho + "x " + text + "..." + preco_mcho + "€";
            sessionStorage.setItem('mchop', pedido_final);
            sessionStorage.setItem('preco_mcho', preco_mcho);
            sessionStorage.setItem('quant_mcho', quant_mcho);
            save_request(text);
            document.getElementById("menos").style.display = "inline";
            document.getElementById("menos_l").style.display = "inline";
        }
    }
    

}

function cancel() {
    "use strict";
    var modal = document.getElementById('cancel'),
    // Buscar o botão - icone do ? - para o modal
        btn = document.getElementById("eliminar"),
    // Vai buscar o elemento que contem o X - que fecha a caixa
        span = document.getElementsByClassName("close2")[0];
    // Funcao que faz aparecer a caixa quando se clica no ?
    modal.style.display = "block";
    // Funcao que fecha a caixa quando se clica no X
    span.onclick = function () {
        modal.style.display = "none";
    };
        // Se clicar em algum lado fora da caixa, ele fecha a caixa
    window.onclick = function (event) {
        if (event.target === modal) {
            modal.style.display = "none";
        }
    };
}



window.onload = function () {
    "use strict";
    if (localStorage.getItem('sessao') === "true") {
        document.getElementById('siga_enc').style.display = "block";
        document.getElementById('siga_txt').innerHTML = "<strong>Utilizador:</strong> " + localStorage.getItem('nome') + "<br>" + "<strong>Encerrar sessão</strong>";
    }
    var path = window.location.pathname.split("/").pop();
    if ((sessionStorage.getItem('burguer') !== null) && (sessionStorage.getItem('burguer') !== "0x Burguer vegetariano, sopa de noodles e crepes com chocolate...0€")) {
        document.getElementById('burguer').innerHTML = sessionStorage.getItem('burguer');
        document.getElementById('finalizar').style.display = "inline";
        document.getElementById('eliminar').style.display = "inline";
        
        if (path === "vegetarianos.html") {
            document.getElementById('menos').style.display = "inline";
            document.getElementById('menos_l').style.display = "inline";
        }
        var new_value =  parseInt(sessionStorage.getItem('quant_bur'));
        var new_value2 =  parseInt(sessionStorage.getItem('preco_bur'));
        quant_bur = new_value;
        preco_bur = new_value2;
    } else {
        sessionStorage.setItem('preco_bur', 0);
        if (path === "vegetarianos.html") {
            document.getElementById('menos').style.display = "none";
        }
    }
    if ((sessionStorage.getItem('mburguer') !== null) && (sessionStorage.getItem('mburguer') !== "0x Mega Burger...0€")) {
        document.getElementById('mburguer').innerHTML = sessionStorage.getItem('mburguer');
        document.getElementById('finalizar').style.display = "inline";
        document.getElementById('eliminar').style.display = "inline";
        if (path === "fast_food.html") {
            document.getElementById('menos').style.display = "inline";
            document.getElementById('menos_l').style.display = "inline";
            console.log("here");
        }
        var new_value =  parseInt(sessionStorage.getItem('quant_mbur'));
        var new_value2 =  parseInt(sessionStorage.getItem('preco_mbur'));
        quant_mbur = new_value;
        preco_mbur = new_value2;
    } else {
        sessionStorage.setItem('preco_mbur', 0);
        if (path === "fast_food.html") {
            document.getElementById('menos').style.display = "none";
        }
    }
    if ((sessionStorage.getItem('paramegiana') !== null) && (sessionStorage.getItem('paramegiana') !== "0x Paramegiana...0€")) {
        document.getElementById('paramegiana').innerHTML = sessionStorage.getItem('paramegiana');
        document.getElementById('finalizar').style.display = "inline";
        document.getElementById('eliminar').style.display = "inline";
        if (path === "italiano.html") {
            document.getElementById('menos').style.display = "inline";
            document.getElementById('menos_l').style.display = "inline";
        }
        var new_value =  parseInt(sessionStorage.getItem('quant_par'));
        var new_value2 =  parseInt(sessionStorage.getItem('preco_par'));
        quant_par = new_value;
        preco_par = new_value2;
    } else {
        sessionStorage.setItem('preco_par', 0);
        if (path === "italiano.html") {
            document.getElementById('menos').style.display = "none";
        }
    }
    if ((sessionStorage.getItem('pizza') !== null) && (sessionStorage.getItem('pizza') !== "0x Pizza e compal de laranja...0€")) {
        document.getElementById('pizza').innerHTML = sessionStorage.getItem('pizza');
        document.getElementById('finalizar').style.display = "inline";
        document.getElementById('eliminar').style.display = "inline";
        if (path === "promocoes.html") {
            document.getElementById('menos').style.display = "inline";
            document.getElementById('menos_l').style.display = "inline";
        }
        var new_value =  parseInt(sessionStorage.getItem('quant_piz'));
        var new_value2 =  parseInt(sessionStorage.getItem('preco_piz'));
        quant_piz = new_value;
        preco_piz = new_value2;
    } else {
        sessionStorage.setItem('preco_piz', 0);
        if (path === "promocoes.html") {
            document.getElementById('menos').style.display = "none";
        }
    }
    if ((sessionStorage.getItem('bife') !== null) && (sessionStorage.getItem('bife') !== "0x Bife com broculos...0€")) {
        document.getElementById('bife').innerHTML = sessionStorage.getItem('bife');
        document.getElementById('finalizar').style.display = "inline";
        document.getElementById('eliminar').style.display = "inline";
        
        if (path === "sugestoes.html") {
            document.getElementById('menos3').style.display = "inline";
            document.getElementById('menos_l').style.display = "inline";
        }
        var new_value =  parseInt(sessionStorage.getItem('quant_bif'));
        var new_value2 =  parseInt(sessionStorage.getItem('preco_bif'));
        quant_bif = new_value;
        preco_bif = new_value2;
    } else {
        sessionStorage.setItem('preco_bif', 0);
        if (path === "sugestoes.html") {
            document.getElementById('menos3').style.display = "none";
        }
    }
    if ((sessionStorage.getItem('lasanha') !== null) && (sessionStorage.getItem('lasanha') !== "0x Lasanha de frango...0€")) {
        document.getElementById('lasanha').innerHTML = sessionStorage.getItem('lasanha');
        document.getElementById('finalizar').style.display = "inline";
        document.getElementById('eliminar').style.display = "inline";
        if (path === "sugestoes.html") {
            document.getElementById('menos2').style.display = "inline";
            document.getElementById('menos_l').style.display = "inline";
        }
        var new_value =  parseInt(sessionStorage.getItem('quant_las'));
        var new_value2 =  parseInt(sessionStorage.getItem('preco_las'));
        quant_las = new_value;
        preco_las = new_value2;
    } else {
        sessionStorage.setItem('preco_las', 0);
        if (path === "sugestoes.html") {
            document.getElementById('menos2').style.display = "none";
        }
    }
    if ((sessionStorage.getItem('crepes') !== null) && (sessionStorage.getItem('crepes') !== "0x Crepes com chocolate e morangos...0€")) {
        document.getElementById('crepes').innerHTML = sessionStorage.getItem('crepes');
        document.getElementById('finalizar').style.display = "inline";
        document.getElementById('eliminar').style.display = "inline";
        if (path === "sobremesas.html") {
            document.getElementById('menos3').style.display = "inline";
            document.getElementById('menos_l').style.display = "inline";
        }
        var new_value =  parseInt(sessionStorage.getItem('quant_cre'));
        var new_value2 =  parseInt(sessionStorage.getItem('preco_cre'));
        quant_cre = new_value;
        preco_cre = new_value2;
    } else {
        sessionStorage.setItem('preco_cre', 0);
        if (path === "sobremesas.html") {
            document.getElementById('menos3').style.display = "none";
        }
    }
    if ((sessionStorage.getItem('waffle') !== null) && (sessionStorage.getItem('waffle') !== "0x Waffle com chocolate...0€")) {
        document.getElementById('waffle').innerHTML = sessionStorage.getItem('waffle');
        document.getElementById('finalizar').style.display = "inline";
        document.getElementById('eliminar').style.display = "inline";
        if (path === "sobremesas.html") {
            document.getElementById('menos2').style.display = "inline";
            document.getElementById('menos_l').style.display = "inline";
        }
        var new_value =  parseInt(sessionStorage.getItem('quant_waf'));
        var new_value2 =  parseInt(sessionStorage.getItem('preco_waf'));
        quant_waf = new_value;
        preco_waf = new_value2;
    } else {
        sessionStorage.setItem('preco_waf', 0);
        if (path === "sobremesas.html") {
            document.getElementById('menos2').style.display = "none";
        }
    }
    if ((sessionStorage.getItem('vinho') !== null) && (sessionStorage.getItem('vinho') !== "0x Vinho do porto...0€")) {
        document.getElementById('vinho').innerHTML = sessionStorage.getItem('vinho');
        document.getElementById('finalizar').style.display = "inline";
        document.getElementById('eliminar').style.display = "inline";
        if (path === "alcool.html") {
            document.getElementById('menos').style.display = "inline";
            document.getElementById('menos_l').style.display = "inline";
        }
        var new_value =  parseInt(sessionStorage.getItem('quant_vin'));
        var new_value2 =  parseInt(sessionStorage.getItem('preco_vin'));
        quant_vin = new_value;
        preco_vin = new_value2;
    } else {
        sessionStorage.setItem('preco_vin', 0);
        if (path === "alcool.html") {
            document.getElementById('menos').style.display = "none";
        }
    }
    if ((sessionStorage.getItem('coca') !== null) && (sessionStorage.getItem('coca') !== "0x Coca Cola...0€")) {
        document.getElementById('coca').innerHTML = sessionStorage.getItem('coca');
        document.getElementById('finalizar').style.display = "inline";
        document.getElementById('eliminar').style.display = "inline";
        if (path === "refrigerantes.html") {
            document.getElementById('menos').style.display = "inline";
            document.getElementById('menos_l').style.display = "inline";
        }
        var new_value =  parseInt(sessionStorage.getItem('quant_coc'));
        var new_value2 =  parseInt(sessionStorage.getItem('preco_coc'));
        quant_coc = new_value;
        preco_coc = new_value2; 
    } else {
        sessionStorage.setItem('preco_coc', 0);
        if (path === "refrigerantes.html") {
            document.getElementById('menos').style.display = "none";
        }
    }
    if ((sessionStorage.getItem('sumo') !== null) && (sessionStorage.getItem('sumo') !== "0x Sumo natural de manga...0€")) {
        document.getElementById('sumo').innerHTML = sessionStorage.getItem('sumo');
        document.getElementById('finalizar').style.display = "inline";
        document.getElementById('eliminar').style.display = "inline";
        if (path === "agua_sumos.html") {
            document.getElementById('menos2').style.display = "inline";
            document.getElementById('menos_l').style.display = "inline";
        }
        var new_value =  parseInt(sessionStorage.getItem('quant_sum'));
        var new_value2 =  parseInt(sessionStorage.getItem('preco_sum'));
        quant_sum = new_value;
        preco_sum = new_value2;
    } else {
        sessionStorage.setItem('preco_sum', 0);
        if (path === "agua_sumos.html") {
            document.getElementById('menos2').style.display = "none";
        }
    }
    if ((sessionStorage.getItem('agua') !== null) && (sessionStorage.getItem('agua') !== "0x Água Fiji 0.5L...0€")) {
        document.getElementById('agua').innerHTML = sessionStorage.getItem('agua');
        document.getElementById('finalizar').style.display = "inline";
        document.getElementById('eliminar').style.display = "inline";
        if (path === "agua_sumos.html") {
            document.getElementById('menos3').style.display = "inline";
            document.getElementById('menos_l').style.display = "inline";
        }
        var new_value =  parseInt(sessionStorage.getItem('quant_agu'));
        var new_value2 =  parseInt(sessionStorage.getItem('preco_agu'));
        quant_agu = new_value;
        preco_agu = new_value2;
    } else {
        sessionStorage.setItem('preco_agu', 0);
        if (path === "agua_sumos.html") {
            document.getElementById('menos3').style.display = "none";
        }
    }
    if ((sessionStorage.getItem('cozido') !== null) && (sessionStorage.getItem('cozido') !== "0x Cozido à portuguesa...0€")) {
        document.getElementById('cozido').innerHTML = sessionStorage.getItem('cozido');
        document.getElementById('finalizar').style.display = "inline";
        document.getElementById('eliminar').style.display = "inline";
        if (path === "portugal.html") {
            document.getElementById('menos3').style.display = "inline";
            document.getElementById('menos_l').style.display = "inline";
        }
        var new_value =  parseInt(sessionStorage.getItem('quant_coz'));
        var new_value2 =  parseInt(sessionStorage.getItem('preco_coz'));
        quant_coz = new_value;
        preco_coz = new_value2;
    } else {
        sessionStorage.setItem('preco_coz', 0);
        if (path === "portugal.html") {
            document.getElementById('menos3').style.display = "none";
        }
    }
    if ((sessionStorage.getItem('france') !== null) && (sessionStorage.getItem('france') !== "0x Francesinha...0€")) {
        document.getElementById('france').innerHTML = sessionStorage.getItem('france');
        document.getElementById('finalizar').style.display = "inline";
        document.getElementById('eliminar').style.display = "inline";
        if (path === "portugal.html") {
            document.getElementById('menos2').style.display = "inline";
            document.getElementById('menos_l').style.display = "inline";
        }
        var new_value =  parseInt(sessionStorage.getItem('quant_fra'));
        var new_value2 =  parseInt(sessionStorage.getItem('preco_fra'));
        quant_fra = new_value;
        preco_fra = new_value2;
    } else {
        sessionStorage.setItem('preco_fra', 0);
        if (path === "portugal.html") {
            document.getElementById('menos2').style.display = "none";
        }
    }
    if ((sessionStorage.getItem('bir') !== null) && (sessionStorage.getItem('bir') !== "0x Biryani...0€")) {
        document.getElementById('bir').innerHTML = sessionStorage.getItem('bir');
        document.getElementById('finalizar').style.display = "inline";
        document.getElementById('eliminar').style.display = "inline";
        if (path === "india.html") {
            document.getElementById('menos3').style.display = "inline";
            document.getElementById('menos_l').style.display = "inline";
        }
        var new_value =  parseInt(sessionStorage.getItem('quant_bir'));
        var new_value2 =  parseInt(sessionStorage.getItem('preco_bir'));
        quant_bir = new_value;
        preco_bir = new_value2;
    } else {
        sessionStorage.setItem('preco_bir', 0);
        if (path === "india.html") {
            document.getElementById('menos3').style.display = "none";
        }
    }
    if ((sessionStorage.getItem('caril') !== null) && (sessionStorage.getItem('caril') !== "0x Caril de frango...0€")) {
        document.getElementById('caril').innerHTML = sessionStorage.getItem('caril');
        document.getElementById('finalizar').style.display = "inline";
        document.getElementById('eliminar').style.display = "inline";
        if (path === "india.html") {
            document.getElementById('menos2').style.display = "inline";
            document.getElementById('menos_l').style.display = "inline";
        }
        var new_value =  parseInt(sessionStorage.getItem('quant_car'));
        var new_value2 =  parseInt(sessionStorage.getItem('preco_car'));
        quant_car = new_value;
        preco_car = new_value2;
    } else {
        sessionStorage.setItem('preco_car', 0);
        if (path === "india.html") {
            document.getElementById('menos2').style.display = "none";
        }
    }
    if ((sessionStorage.getItem('bolonhesa') !== null) && (sessionStorage.getItem('bolonhesa') !== "0x Bolonhesa...0€")) {
        document.getElementById('bolonhesa').innerHTML = sessionStorage.getItem('bolonhesa');
        document.getElementById('finalizar').style.display = "inline";
        document.getElementById('eliminar').style.display = "inline";
        if (path === "italia.html") {
            document.getElementById('menos3').style.display = "inline";
            document.getElementById('menos_l').style.display = "inline";
        }
        var new_value =  parseInt(sessionStorage.getItem('quant_bol'));
        var new_value2 =  parseInt(sessionStorage.getItem('preco_bol'));
        quant_bol = new_value;
        preco_bol = new_value2;
    } else {
        sessionStorage.setItem('preco_bol', 0);
        if (path === "italia.html") {
            document.getElementById('menos3').style.display = "none";
        }
    }
    if ((sessionStorage.getItem('risotto') !== null) && (sessionStorage.getItem('risotto') !== "0x Risotto...0€")) {
        document.getElementById('risotto').innerHTML = sessionStorage.getItem('risotto');
        document.getElementById('finalizar').style.display = "inline";
        document.getElementById('eliminar').style.display = "inline";
        if (path === "italia.html") {
            document.getElementById('menos2').style.display = "inline";
            document.getElementById('menos_l').style.display = "inline";
        }
        var new_value =  parseInt(sessionStorage.getItem('quant_ris'));
        var new_value2 =  parseInt(sessionStorage.getItem('preco_ris'));
        quant_ris = new_value;
        preco_ris = new_value2;
    } else {
        sessionStorage.setItem('preco_ris', 0);
        if (path === "italia.html") {
            document.getElementById('menos2').style.display = "none";
        }
    }
    if ((sessionStorage.getItem('quinoa') !== null) && (sessionStorage.getItem('quinoa') !== "0x Quinoa com legumes...0€")) {
        document.getElementById('quinoa').innerHTML = sessionStorage.getItem('quinoa');
        document.getElementById('finalizar').style.display = "inline";
        document.getElementById('eliminar').style.display = "inline";
        if (path === "pratosVeg.html") {
            document.getElementById('menos2').style.display = "inline";
            document.getElementById('menos_l').style.display = "inline";
            console
        }
        var new_value =  parseInt(sessionStorage.getItem('quant_qui'));
        var new_value2 =  parseInt(sessionStorage.getItem('preco_qui'));
        quant_qui = new_value;
        preco_qui = new_value2;
    } else {
        sessionStorage.setItem('preco_qui', 0);
        if (path === "pratosVeg.html") {
            document.getElementById('menos2').style.display = "none";
        }
    }
    if ((sessionStorage.getItem('hamburguer') !== null) && (sessionStorage.getItem('hamburguer') !== "0x Hamburger...0€")) {
        document.getElementById('hamburguer').innerHTML = sessionStorage.getItem('hamburguer');
        document.getElementById('finalizar').style.display = "inline";
        document.getElementById('eliminar').style.display = "inline";
        if (path === "pratosFast.html") {
            document.getElementById('menos').style.display = "inline";
            document.getElementById('menos_l').style.display = "inline";
        }
        var new_value =  parseInt(sessionStorage.getItem('quant_ham'));
        var new_value2 =  parseInt(sessionStorage.getItem('preco_ham'));
        quant_ham = new_value;
        preco_ham = new_value2;
    } else {
        sessionStorage.setItem('preco_ham', 0);
        if (path === "pratosFast.html") {
            document.getElementById('menos').style.display = "none";
        }
    }
    if ((sessionStorage.getItem('beringela') !== null) && (sessionStorage.getItem('beringela') !== "0x Beringela recheada...0€")) {
        document.getElementById('beringela').innerHTML = sessionStorage.getItem('beringela');
        document.getElementById('finalizar').style.display = "inline";
        document.getElementById('eliminar').style.display = "inline";
        if (path === "pratosVeg.html") {
            document.getElementById('menos3').style.display = "inline";
            document.getElementById('menos_l').style.display = "inline";
        }
        var new_value =  parseInt(sessionStorage.getItem('quant_ber'));
        var new_value2 =  parseInt(sessionStorage.getItem('preco_ber'));
        quant_ber = new_value;
        preco_ber = new_value2;
    } else {
        sessionStorage.setItem('preco_ber', 0);
        if (path === "pratosVeg.html") {
            document.getElementById('menos3').style.display = "none";
        }
    }
    if ((sessionStorage.getItem('chop') !== null) && (sessionStorage.getItem('chop') !== "0x Chop suey de gambas...0€")) {
        document.getElementById('chop').innerHTML = sessionStorage.getItem('chop');
        document.getElementById('finalizar').style.display = "inline";
        document.getElementById('eliminar').style.display = "inline";
        if (path === "china.html") {
            document.getElementById('menos3').style.display = "inline";
            document.getElementById('menos_l').style.display = "inline";
        }
        var new_value =  parseInt(sessionStorage.getItem('quant_cho'));
        var new_value2 =  parseInt(sessionStorage.getItem('preco_cho'));
        quant_cho = new_value;
        preco_cho = new_value2;
    } else {
        sessionStorage.setItem('preco_cho', 0);
        if (path === "china.html") {
            document.getElementById('menos3').style.display = "none";
        }
    }
    if ((sessionStorage.getItem('chun') !== null) && (sessionStorage.getItem('chun') !== "0x 12 Rolos Chun Juan...0€")) {
        document.getElementById('chun').innerHTML = sessionStorage.getItem('chun');
        document.getElementById('finalizar').style.display = "inline";
        document.getElementById('eliminar').style.display = "inline";
        if (path === "china.html") {
            document.getElementById('menos2').style.display = "inline";
            document.getElementById('menos_l').style.display = "inline";
        }
        var new_value =  parseInt(sessionStorage.getItem('quant_chu'));
        var new_value2 =  parseInt(sessionStorage.getItem('preco_chu'));
        quant_chu = new_value;
        preco_chu = new_value2;
    } else {
        sessionStorage.setItem('preco_chu', 0);
        if (path === "china.html") {
            document.getElementById('menos2').style.display = "none";
        }
    }
    if ((sessionStorage.getItem('sushi') !== null) && (sessionStorage.getItem('sushi') !== "0x 12 Peças de Sushi...0€")) {
        document.getElementById('sushi').innerHTML = sessionStorage.getItem('sushi');
        document.getElementById('finalizar').style.display = "inline";
        document.getElementById('eliminar').style.display = "inline";
        if (path === "japao.html") {
            document.getElementById('menos3').style.display = "inline";
            document.getElementById('menos_l').style.display = "inline";
        }
        var new_value =  parseInt(sessionStorage.getItem('quant_sus'));
        var new_value2 =  parseInt(sessionStorage.getItem('preco_sus'));
        quant_sus = new_value;
        preco_sus = new_value2;
    } else {
        sessionStorage.setItem('preco_sus', 0);
        if (path === "japao.html") {
            document.getElementById('menos3').style.display = "none";
        }
    }
    if ((sessionStorage.getItem('yak') !== null) && (sessionStorage.getItem('yak') !== "0x 5 Espetadas de Yakitori...0€")) {
        document.getElementById('yak').innerHTML = sessionStorage.getItem('yak');
        document.getElementById('finalizar').style.display = "inline";
        document.getElementById('eliminar').style.display = "inline";
        if (path === "japao.html") {
            document.getElementById('menos2').style.display = "inline";
            document.getElementById('menos_l').style.display = "inline";
        }
        var new_value =  parseInt(sessionStorage.getItem('quant_yak'));
        var new_value2 =  parseInt(sessionStorage.getItem('preco_yak'));
        quant_yak = new_value;
        preco_yak = new_value2;
    } else {
        sessionStorage.setItem('preco_yak', 0);
        if (path === "japao.html") {
            document.getElementById('menos2').style.display = "none";
        }
    }
    if ((sessionStorage.getItem('sopa') !== null) && (sessionStorage.getItem('sopa') !== "0x Sopa de espinafres...0€")) {
        document.getElementById('sopa').innerHTML = sessionStorage.getItem('sopa');
        document.getElementById('finalizar').style.display = "inline";
        document.getElementById('eliminar').style.display = "inline";
        if (path === "pratosBaixos.html") {
            document.getElementById('menos3').style.display = "inline";
            document.getElementById('menos_l').style.display = "inline";
        }
        var new_value =  parseInt(sessionStorage.getItem('quant_sop'));
        var new_value2 =  parseInt(sessionStorage.getItem('preco_sop'));
        quant_sop = new_value;
        preco_sop = new_value2;
    } else {
        sessionStorage.setItem('preco_sop', 0);
        if (path === "pratosBaixos.html") {
            document.getElementById('menos3').style.display = "none";
        }
    }
    if ((sessionStorage.getItem('peito') !== null) && (sessionStorage.getItem('peito') !== "0x Peito de frango grelhado com legumes...0€")) {
        document.getElementById('peito').innerHTML = sessionStorage.getItem('peito');
        document.getElementById('finalizar').style.display = "inline";
        document.getElementById('eliminar').style.display = "inline";
        if (path === "pratosBaixos.html") {
            document.getElementById('menos2').style.display = "inline";
            document.getElementById('menos_l').style.display = "inline";
        }
        var new_value =  parseInt(sessionStorage.getItem('quant_pei'));
        var new_value2 =  parseInt(sessionStorage.getItem('preco_pei'));
        quant_pei = new_value;
        preco_pei = new_value2;
    } else {
        sessionStorage.setItem('preco_pei', 0);
        if (path === "pratosBaixos.html") {
            document.getElementById('menos2').style.display = "none";
        }
    }
    if ((sessionStorage.getItem('bacalhau') !== null) && (sessionStorage.getItem('bacalhau') !== "0x Bacalhau com broa...0€")) {
        document.getElementById('bacalhau').innerHTML = sessionStorage.getItem('bacalhau');
        document.getElementById('finalizar').style.display = "inline";
        document.getElementById('eliminar').style.display = "inline";
        if (path === "pratosPeixe.html") {
            document.getElementById('menos3').style.display = "inline";
            document.getElementById('menos_l').style.display = "inline";
        }
        var new_value =  parseInt(sessionStorage.getItem('quant_bac'));
        var new_value2 =  parseInt(sessionStorage.getItem('preco_bac'));
        quant_bac = new_value;
        preco_bac = new_value2;
    } else {
        sessionStorage.setItem('preco_bac', 0);
        if (path === "pratosPeixes.html") {
            document.getElementById('menos3').style.display = "none";
        }
    }
    if ((sessionStorage.getItem('salmao') !== null) && (sessionStorage.getItem('salmao') !== "0x Salmão grelhado com legumes...0€")) {
        document.getElementById('salmao').innerHTML = sessionStorage.getItem('salmao');
        document.getElementById('finalizar').style.display = "inline";
        document.getElementById('eliminar').style.display = "inline";
        if (path === "pratosPeixe.html") {
            document.getElementById('menos2').style.display = "inline";
            document.getElementById('menos_l').style.display = "inline";
        }
        var new_value =  parseInt(sessionStorage.getItem('quant_sal'));
        var new_value2 =  parseInt(sessionStorage.getItem('preco_sal'));
        quant_sal = new_value;
        preco_sal = new_value2;
    } else {
        sessionStorage.setItem('preco_sal', 0);
        if (path === "pratosPeixes.html") {
            document.getElementById('menos2').style.display = "none";
        }
    }
    if ((sessionStorage.getItem('msalmao') !== null) && (sessionStorage.getItem('msalmao') !== "0x Salmão grelhado, sangria da casa e gelado...0€")) {
        document.getElementById('msalmao').innerHTML = sessionStorage.getItem('msalmao');
        document.getElementById('finalizar').style.display = "inline";
        document.getElementById('eliminar').style.display = "inline";
        if (path === "menusPeixe.html") {
            document.getElementById('menos').style.display = "inline";
            document.getElementById('menos_l').style.display = "inline";
        }
        var new_value =  parseInt(sessionStorage.getItem('quant_msal'));
        var new_value2 =  parseInt(sessionStorage.getItem('preco_msal'));
        quant_msal = new_value;
        preco_msal = new_value2; 
    } else {
        sessionStorage.setItem('preco_msal', 0);
        if (path === "menusPeixe.html") {
            document.getElementById('menos').style.display = "none";
        }
    }
    if ((sessionStorage.getItem('salada_f') !== null) && (sessionStorage.getItem('salada_f') !== "0x Salada de frango, limonada e maçã...0€")) {
        document.getElementById('salada_f').innerHTML = sessionStorage.getItem('salada_f');
        document.getElementById('finalizar').style.display = "inline";
        document.getElementById('eliminar').style.display = "inline";
        if (path === "menusBaixo.html") {
            document.getElementById('menos').style.display = "inline";
            document.getElementById('menos_l').style.display = "inline";
        }
        var new_value =  parseInt(sessionStorage.getItem('quant_saf'));
        var new_value2 =  parseInt(sessionStorage.getItem('preco_saf'));
        quant_saf = new_value;
        preco_saf = new_value2; 
    } else {
        sessionStorage.setItem('preco_saf', 0);
        if (path === "menusBaixo.html") {
            document.getElementById('menos').style.display = "none";
        }
    }
    if ((sessionStorage.getItem('mbife') !== null) && (sessionStorage.getItem('mbife') !== "0x Bife com ovo estrelado, vinho verde e pastel de nata...0€")) {
        document.getElementById('mbife').innerHTML = sessionStorage.getItem('mbife');
        document.getElementById('finalizar').style.display = "inline";
        document.getElementById('eliminar').style.display = "inline";
        if (path === "mportugal.html") {
            document.getElementById('menos').style.display = "inline";
            document.getElementById('menos_l').style.display = "inline";
        }
        var new_value =  parseInt(sessionStorage.getItem('quant_mbif'));
        var new_value2 =  parseInt(sessionStorage.getItem('preco_mbif'));
        quant_mbif = new_value;
        preco_mbif = new_value2; 
    } else {
        sessionStorage.setItem('preco_mbif', 0);
        if (path === "mportugal.html") {
            document.getElementById('menos').style.display = "none";
        }
    }
    if ((sessionStorage.getItem('mbolonhesa') !== null) && (sessionStorage.getItem('mbol') !== "0x Bolonhesa, sumo de pêssego e semi-frio...0€")) {
        document.getElementById('mbolonhesa').innerHTML = sessionStorage.getItem('mbolonhesa');
        document.getElementById('finalizar').style.display = "inline";
        document.getElementById('eliminar').style.display = "inline";
        if (path === "mitalia.html") {
            document.getElementById('menos').style.display = "inline";
            document.getElementById('menos_l').style.display = "inline";
        }
        var new_value =  parseInt(sessionStorage.getItem('quant_mbol'));
        var new_value2 =  parseInt(sessionStorage.getItem('preco_mbol'));
        quant_mbol = new_value;
        preco_mbol = new_value2; 
    } else {
        sessionStorage.setItem('preco_mbol', 0);
        if (path === "mitalia.html") {
            document.getElementById('menos').style.display = "none";
        }
    }
    if ((sessionStorage.getItem('msushi') !== null) && (sessionStorage.getItem('msushi') !== "0x 14 Peças de Sushi, limonada e petit-gâteau...0€")) {
        document.getElementById('msushi').innerHTML = sessionStorage.getItem('msushi');
        document.getElementById('finalizar').style.display = "inline";
        document.getElementById('eliminar').style.display = "inline";
        if (path === "mjapao.html") {
            document.getElementById('menos').style.display = "inline";
            document.getElementById('menos_l').style.display = "inline";
        }
        var new_value =  parseInt(sessionStorage.getItem('quant_msus'));
        var new_value2 =  parseInt(sessionStorage.getItem('preco_msus'));
        quant_msus = new_value;
        preco_msus = new_value2; 
    } else {
        sessionStorage.setItem('preco_msus', 0);
        if (path === "mjapao.html") {
            document.getElementById('menos').style.display = "none";
        }
    }
    if ((sessionStorage.getItem('mcaril') !== null) && (sessionStorage.getItem('mcaril') !== "0x Caril de frango, sumo de laranja e doce ghi...0€")) {
        document.getElementById('mcaril').innerHTML = sessionStorage.getItem('mcaril');
        document.getElementById('finalizar').style.display = "inline";
        document.getElementById('eliminar').style.display = "inline";
        if (path === "mindia.html") {
            document.getElementById('menos').style.display = "inline";
            document.getElementById('menos_l').style.display = "inline";
        }
        var new_value =  parseInt(sessionStorage.getItem('quant_mcar'));
        var new_value2 =  parseInt(sessionStorage.getItem('preco_mcar'));
        quant_mcar = new_value;
        preco_mcar = new_value2; 
    } else {
        sessionStorage.setItem('preco_mcar', 0);
        if (path === "mindia.html") {
            document.getElementById('menos').style.display = "none";
        }
    }
    if ((sessionStorage.getItem('mchop') !== null) && (sessionStorage.getItem('mchop') !== "0x Chop suey de frango, sangria e gelado...0€")) {
        document.getElementById('mchop').innerHTML = sessionStorage.getItem('mchop');
        document.getElementById('finalizar').style.display = "inline";
        document.getElementById('eliminar').style.display = "inline";
        if (path === "mchina.html") {
            document.getElementById('menos').style.display = "inline";
            document.getElementById('menos_l').style.display = "inline";
        }
        var new_value =  parseInt(sessionStorage.getItem('quant_mcho'));
        var new_value2 =  parseInt(sessionStorage.getItem('preco_mcho'));
        quant_mcho = new_value;
        preco_mcho = new_value2; 
    } else {
        sessionStorage.setItem('preco_mcho', 0);
        if (path === "mchina.html") {
            document.getElementById('menos').style.display = "none";
        }
    }
    if (sessionStorage.getItem('preco_pedido') !== null) {
        document.getElementById('total').innerHTML = sessionStorage.getItem('total');
        total = parseInt(sessionStorage.getItem('preco_pedido'));
        preco_pedido = parseInt(sessionStorage.getItem('preco_pedido'));
    } else {
        preco_pedido = 0;
    }
    var modal = document.getElementById('ajuda');
    // Buscar o botão - icone do ? - para o modal
    var btn = document.getElementById("but_top");
    // Vai buscar o elemento que contem o X - que fecha a caixa
    var span = document.getElementsByClassName("close")[0];
    // Funcao que faz aparecer a caixa quando se clica no ?
    btn.onclick = function () {
        modal.style.display = "block";
    };
        // Funcao que fecha a caixa quando se clica no X
    span.onclick = function () {
        modal.style.display = "none";
    };
        // Se clicar em algum lado fora da caixa, ele fecha a caixa
    window.onclick = function (event) {
        if (event.target === modal) {
            modal.style.display = "none";
        }
    };
};