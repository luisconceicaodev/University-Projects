package business;

import static org.junit.Assert.*;

import java.util.GregorianCalendar;
import java.util.List;
import java.util.Random;

import org.junit.AfterClass;  // cf. API at http://junit.org/junit4/javadoc/latest/
import org.junit.Before; 
import org.junit.BeforeClass;
import org.junit.Test;

import dataaccess.ProductMapper;

/**
 * This class tests the ReturnRentedItems.
 * 
 * @author Joao Maia 48208
 * @author Luis Conceicao 48303
 * @author Diogo Catalao 48756
 *
 */
public class ReturnTests {
	
	private ReturnRentedItems returnal;

	private static SaleSys app;
	private static ProductSpec prod1, prod2, prod3;
	
	@BeforeClass   // run once
	public static void setUpBeforeClass() {
		
		try {
			app = new SaleSys();
			app.start();
			
			prod1 = ProductMapper.getProductById(1011); // assumes they are already there
			prod2 = ProductMapper.getProductById(1012);
			prod3 = ProductMapper.getProductById(1013);
		} catch (Exception e) {
			fail("App didn't start or products could not be retrieved");
		}
	}
	
	@Before   // run before each test
	public void setup() {
		returnal = new ReturnRentedItems(1, new GregorianCalendar(2016,12,31).getTime());
	}
	
	@Test
	public void test_emptyPenaltyTotal() {
		assertEquals(returnal.penalty_total(), 0.0, 0.001);
	}
	
	@Test
	public void test_emptyReturnProducts() {
		assertTrue(returnal.getReturnedProducts().isEmpty());
	}
	
	@Test
	public void test_returnWithProducts_length() {
		
		returnal.addProductToReturn(prod1);
		returnal.addProductToReturn(prod2);
		
		assertEquals(returnal.getReturnedProducts().size(), 2);
	}
	
	@Test
	public void test_ReturnWith_Penalty() {
		
		// compute returnal total late delivery penalty cost
		returnal.addProductToReturn(prod1);
		returnal.addProductToReturn(prod2);
		double expectedPenalty = 190.0;
		List<RentProduct> list_test = returnal.getReturnedProducts();
		for (RentProduct rp : list_test) {
			rp.CalculateInTime(returnal.getReturnDate(), rp.getProduct().getSoftlimit());
			rp.CalculatePenalty(returnal.getReturnDate(), rp.getProduct().getSoftlimit(), rp.getProduct().getHardlimit());
		}
		
		assertEquals(expectedPenalty, returnal.penalty_total(), 0.001);
	}
	
	/**
	 * This is an eg of a random generated test, useful for heavy testing
	 */
	@Test
	public void test_returnWithProducts_budget_large() {
		
		Random random = new Random();
		
		long sizeTest = 1000;  // number of products to insert into the sale
		
		ProductSpec[] prodArray = new ProductSpec[] {prod1, prod2, prod3};  // available products
		
		// generate valid indexes for prodArray in order to pick products at random
		int [] prods = random.ints().limit(sizeTest).map(n -> Math.abs(n) % prodArray.length).toArray(); 

		for(int i=0; i<sizeTest; i++) { 
			returnal.addProductToReturn(prodArray[prods[i]]); 
		}
		
		assertEquals(returnal.getReturnedProducts().size(), sizeTest); // size ok?
	}
		
	@AfterClass
	public static void finishAfterClass() {
		
		try {
			app.stop();
		} catch (Exception e) {
			fail("App unable to finish");
		}
	}
}