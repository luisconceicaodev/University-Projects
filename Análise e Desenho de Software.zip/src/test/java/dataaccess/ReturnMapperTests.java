package dataaccess;

import static org.junit.Assert.*;

import java.util.GregorianCalendar;
import java.util.List;
import java.util.stream.Collectors;

import org.junit.After;
import org.junit.AfterClass;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Test;

import business.CatalogReturnedItems;
import business.ProductSpec;
import business.Rent;
import business.ReturnRentedItems;
import business.SaleSys;

/**
 * This class tests the ReturnRentedItemsMapper.
 * 
 * This requires attention since we are testing the database access, and 
 * must not change anything in the database after the tests end
 * 
 * @author Joao Maia 48208
 * @author Luis Conceicao 48303
 * @author Diogo Catalao 48756
 *
 */
public class ReturnMapperTests {

	private static SaleSys app;
	private static ProductSpec prod1, prod2, prod3;
	
	private CatalogReturnedItems returnedCatalog;
	private ReturnRentedItems returnal;
	private Rent rent;
	
	private String initialReport;

	
	@BeforeClass
	public static void setUpBeforeClass() throws Exception {
		
		try {
			app = new SaleSys();
			app.start();
			
			prod1 = ProductMapper.getProductById(1011); // assumes they are already there
			prod2 = ProductMapper.getProductById(1012);
			prod3 = ProductMapper.getProductById(1013);
			
			
		} catch (Exception e) {
			fail("App didn't start or products could not be retrieved");
		}

	}

	@Before
	public void setUp() throws Exception {
		
		returnedCatalog = new CatalogReturnedItems();
		returnal = new ReturnRentedItems(1, new GregorianCalendar(2016,12,31).getTime());
		initialReport = returnedCatalog.toString();
		
		int rent_id = RentMapper.insert(new GregorianCalendar(2016,12,31).getTime());
		
		RentProductMapper.insert(rent_id, prod1.getId());
		RentProductMapper.insert(rent_id, prod2.getId());
		
		rent = RentMapper.getRentalById(rent_id);
		
		RentMapper.update(rent.getId(), rent.getStatus());
		
		int return_id = ReturnRentedItemsMapper.insert(new GregorianCalendar(2016,12,31).getTime()); 
		String intime1 = returnedCatalog.CalculateInTime(returnal.getReturnDate(), prod1.getSoftlimit());
		String intime2 = returnedCatalog.CalculateInTime(returnal.getReturnDate(), prod2.getSoftlimit());
		String intime3 = returnedCatalog.CalculateInTime(returnal.getReturnDate(), prod3.getSoftlimit());
		
		String penalty1 = returnedCatalog.CalculatePenalty(returnal.getReturnDate(), prod1.getSoftlimit(), prod1.getHardlimit());
		String penalty2 = returnedCatalog.CalculatePenalty(returnal.getReturnDate(), prod2.getSoftlimit(), prod2.getHardlimit());
		String penalty3 = returnedCatalog.CalculatePenalty(returnal.getReturnDate(), prod3.getSoftlimit(), prod3.getHardlimit());
		
		double penalty_total = returnal.penalty_total();

		ReturnRentedItemsMapper.returnProduct(return_id, rent_id, prod1.getId(), intime1, penalty1, penalty_total);
		ReturnRentedItemsMapper.returnProduct(return_id, rent_id, prod2.getId(), intime2, penalty2, penalty_total);
		ReturnRentedItemsMapper.returnProduct(return_id, rent_id, prod3.getId(), intime3, penalty3, penalty_total);
		
		returnal = ReturnRentedItemsMapper.getReturnById(returnal.getId());
	}

	@Test
	public void test_correctReturnedId() {
		try {
			ReturnRentedItems returnal2 = ReturnRentedItemsMapper.getReturnById(returnal.getId());
			
			assertEquals(returnal.getId(), returnal2.getId());
		} catch (PersistenceException e) {
			fail("Saved sale could not be retrieved");
		}
	}

	@Test
	public void test_correctGetAll() {
		List<ReturnRentedItems> list = getReturnInList();               // uses getAllReturnals()

		assertTrue(list.size() == 1);                    // there's one and only one sale 
		assertTrue(list.get(0).getId() == returnal.getId()); // and it has the correct id
	}

	@After
	public void finish() {
		// check if the database saved correctly and is not empty
		String finalReport = returnedCatalog.toString();
		assertNotEquals(initialReport, finalReport); 		
	}
	
	@AfterClass
	public static void finishAfterClass() {
		
		try {
			app.stop();
		} catch (Exception e) {
			fail("App unable to finish");
		}
	}

	/**
	 * Returns a list with a three elements, the current returnal retrieved from 
	 * the database. If the current return is not in the database, the returned 
	 * list will be empty
	 * 
	 * @return list with the current returnal retrieved from the database (empty, otherwise)
	 */
	private List<ReturnRentedItems> getReturnInList() {
		try {
			return ReturnRentedItemsMapper.getAllReturns()   // get all returns and filter for the return id
					          .stream()
					          .filter(aReturn -> aReturn.getId() == returnal.getId())
					          .collect(Collectors.toList());   // java 8 magic!
		} catch (PersistenceException e) {
			return null; // something wrong happened, prepare for Null Pointer Explosion
		}
	}
}
