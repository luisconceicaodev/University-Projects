package use_cases;

import business.ApplicationException;
import business.CatalogRent;
import business.Rent;

/**
 * Handles use case process rent. Version with two operations: 
 * newRent followed by an arbitrary number of addProductToRent
 * 
 * @author Joao Maia 48208
 * @author Luis Conceicao 48303
 * @author Diogo Catalao 48756
 */
public class HandlerProcessRent {
	
	private CatalogRent    rentCatalog;
	
	/**
	 * Creates a handler for the process rent use case given 
	 * the rent, and product catalogs which contain the relevant
	 * operators to execute this use case methods
	 * 
	 * @param rentCatalog    A rental's catalog
	 * @param productCatalog A product's catalog
	 */
	public HandlerProcessRent(CatalogRent rentCatalog) {
		this.rentCatalog = rentCatalog;
	}

	/**
	 * Creates a new rent
	 * 
	 * @throws ApplicationException In case the rental fails to be created
	 */
	public Rent newRent() throws ApplicationException {
		return rentCatalog.newRent();
	}

	/**
	 * Adds a product to a rental
	 * 
	 * @param rental      The current rental 
	 * @param prod_code The product id to be added to the rental 
	 * @throws ApplicationException When the rental is closed, the product code
	 * is not part of the product's catalog, or when there is not enough stock
	 * to proceed with the rental
	 */
	public void addProductToRent (Rent rental, int prod_code) throws ApplicationException {
		rentCatalog.addProductToRent(rental, prod_code);
	}

    /**
     * Closes an open rental
     * @param rental   The current rent 
     * @throws ApplicationException 
     */
	public void closeRent(Rent rental) throws ApplicationException {
		rentCatalog.closeRent(rental);
	}

    /**
     * Deletes rental
     * @param rental   The current rental 
     * @throws ApplicationException 
     */
	public void deleteRent(Rent rental) throws ApplicationException {
		rentCatalog.deleteRent(rental);		
	}
}