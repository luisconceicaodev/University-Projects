package use_cases;

import business.ApplicationException;
import business.CatalogReturnedItems;
import business.Rent;
import business.ReturnRentedItems;

/**
 * Handles use case return rented items. Version with two operations: 
 * newReturnRentedItems followed by an arbitrary number of addProductToRent
 * 
 * @author Joao Maia 48208
 * @author Luis Conceicao 48303
 * @author Diogo Catalao 48756
 */
public class HandlerReturnRentedItems {
	
	private CatalogReturnedItems    returnCatalog;
	
	/**
	 * Creates a handler for the return rented items use case given 
	 * the rent, and product catalogs which contain the relevant
	 * operators to execute this use case methods
	 * 
	 * @param rentCatalog    A rental's catalog
	 * @param productCatalog A product's catalog
	 */
	public HandlerReturnRentedItems(CatalogReturnedItems returnCatalog) {
		this.returnCatalog = returnCatalog;
	}
	
	/**
	 * Creates a new return
	 * 
	 * @throws ApplicationException In case the return fails to be created
	 */
	public ReturnRentedItems newReturn() throws ApplicationException {
		return returnCatalog.newReturn();
	}

	/**
	 * Returns a product
	 * 
	 * @param rental      The current rental 
	 * @param prod_code The product id to be returned 
	 * @throws ApplicationException 
	 */
	public void returnRentedItem(ReturnRentedItems returnal, Rent rental, int prod_code) throws ApplicationException {
		returnCatalog.addProductToReturn(returnal, rental, prod_code);
	}

}