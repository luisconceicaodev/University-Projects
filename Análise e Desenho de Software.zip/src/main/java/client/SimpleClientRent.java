package client;

import java.sql.SQLException;

import use_cases.HandlerProcessRent;
import use_cases.HandlerReturnRentedItems;
import business.*;

/**
 * A simple application client that uses both rent items and return rented items services.
 *	
 * @author Joao Maia 48208
 * @author Luis Conceicao 48303
 * @author Diogo Catalao 48756
 * 
 */
public class SimpleClientRent {

	/**
	 * A simple interaction with the application services
	 * 
	 * @param args Command line parameters
	 */
	public static void main(String[] args) {
		
		SaleSys app = new SaleSys();
		
		try {
			app.start();
		} catch (ApplicationException e) {
			System.out.println(e.getMessage());
			System.out.println("Application Message: " + e.getMessage());
			SQLException e1 = (SQLException) e.getCause().getCause();
			System.out.println("SQLException: " + e1.getMessage());
			System.out.println("SQLState: " + e1.getSQLState());
			System.out.println("VendorError: " + e1.getErrorCode());
			return;
		}
		
		// create catalog(s)
		CatalogRent rentCatalog = new CatalogRent();
		
		CatalogReturnedItems returnedCatalog = new CatalogReturnedItems();
		
		// this client deals with the Process Rent use case
		HandlerProcessRent hpr = new HandlerProcessRent(rentCatalog); 
		
		// this client deals with the Return Rented Product use case
		HandlerReturnRentedItems hrri = new HandlerReturnRentedItems(returnedCatalog);
			
		try { // sample interaction		
			
					
			
			System.out.println("\n-- Add rental and print it ----------------------------");
			
			// creates a new rental (returns it)
			Rent rental = hpr.newRent();

			// adds two products to the database
			hpr.addProductToRent(rental, 105);
			hpr.addProductToRent(rental, 106);
			
			// close rental
			hpr.closeRent(rental);
			
			//////////////////
			
			rental = rentCatalog.getRent(rental.getId());
			System.out.println(rental);		
			
			//////////////////
			
			System.out.println("\n-- Print all rentals ----------------------------------");

			System.out.println(rentCatalog);
			
			//////////////////
			
			hpr.deleteRent(rental);
			
			System.out.println("\n-- Print all rentals after delete of previous rental ---------------------");

			System.out.println(rentCatalog);	
			
			System.out.println("\n-- Return rented products from a new rental  ---------------------");
			
			// creates a new rental
			Rent rental2 = hpr.newRent();

			// adds two products to the database
			hpr.addProductToRent(rental2, 109);
			hpr.addProductToRent(rental2, 110);
			
			hpr.closeRent(rental2);
			
			rental2 = rentCatalog.getRent(rental2.getId());
			System.out.println(rental2);	
			
			// creates a new return
			ReturnRentedItems returnal = hrri.newReturn();
			
			// return two products
			hrri.returnRentedItem(returnal, rental2, 109);
			hrri.returnRentedItem(returnal, rental2, 110);
			
			returnal = returnedCatalog.getReturn(returnal.getId());
			
			//////////////////
			
			System.out.println(returnal);
			
			System.out.println("\n-- Print all returns ----------------------------------");

			System.out.println(returnedCatalog);
			
			
		} catch (ApplicationException e) {
			System.out.println("Error: " + e.getMessage());
			// for debugging purposes only. Typically, in the application this information 
			// can be associated with a "details" button when the error message is displayed.
			if (e.getCause() != null) 
				System.out.println("Cause: ");
			e.printStackTrace();
		}
	
		app.stop();
	}
}