package business;

import java.util.Date;

public class ProductSpec {

	private int    id;          // the database's id
	private int    itemID;      // the product's code
	private String description;
	private Date softlimit;
	private Date hardlimit;
	private double price;       // value per unit
	private double qty;         // units in stock
	@SuppressWarnings("unused")
	private String rentable;
	private double full_value;
	
	public static final String RENTABLE   = "Y";
	public static final String NOT_RENTABLE = "N";
	
	/**
	 * Creates a new product given its code, description, face value, 
	 * stock quantity, if it is eligible for discount, and its units.
	 * 
	 * @param code        The product code
	 * @param description The product description
	 * @param price       The value by which the product should be sold
	 * @param qty         The number of units available in stock
	 */
	public ProductSpec(int id, int code, String description, double price, double qty) {
		this.id          = id;
		this.itemID      = code;
		this.description = description;
		this.price       = price;
		this.qty         = qty;
	}
	
	/**
	 * Creates a new product given its code, description, face value, 
	 * stock quantity, if it is eligible for discount, and its units.
	 * 
	 * @param code        The product code
	 * @param description The product description
	 * @param price       The value by which the product should be sold
	 * @param qty         The number of units available in stock
	 * @param softlimit   The date that will result in a penalty
	 * @param hardlimit   The final date
	 */
	public ProductSpec(int id, int code, String description, double price, Date softlimit, Date hardlimit, String rentable, double full_value) {
		this.id          = id;
		this.itemID      = code;
		this.description = description;
		this.price       = price;
		this.softlimit = softlimit;
		this.hardlimit = hardlimit;
		this.rentable = rentable;
		this.full_value = full_value;
	}
	
	public int getId() {
		return id;
	}
	
	/**
	 * Comment: there is a business rule to not allow product code changes.
	 * That is why there is no method for updating the product code.
	 * @return The code of the product.
	 */
	public int getProductCode() {
		return itemID;
	}

	/**
	 * @return The product's description
	 */
	public String getDescription() {
		return description;
	}
	
	/**
	 * @return The product's price
	 */
	public double getPrice() {
		return price;
	}

	/**
	 * @return The product's quantity
	 */
	public double getStock() {
		return qty;
	}
	
	/**
	 * @return The product's softlimit
	 */
	public Date getSoftlimit() {
		return softlimit;
	}
	
	/**
	 * @return The product's hardlimit
	 */
	public Date getHardlimit() {
		return hardlimit;
	}


	/**
	 * Updates the product's stock quantity
	 * @param qty The new stock quantity
	 */
	public void setStock(double qty) {
		this.qty = qty;
	}
	
	public double getFullValue() {
		return full_value;
	}
	
	public String toString() {
		return description + " [code " + itemID + " with unit price �" + price + " and stock " + qty + "]"; 
	}
}
