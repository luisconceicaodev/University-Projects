package business;

import java.util.*;

public class Rent {
	
	private int id;
	private Date date;
	private String status;		
	private List<RentProduct> rentProducts;
	
	public static final String OPEN   = "O";
	public static final String CLOSED = "C";
	
	/**
	 * Creates a new rent given the date it occurred and the customer that
	 * made the purchase.
	 * 
	 * @param date The date that the rental occurred
	 */
	public Rent(int id, Date date) {
		this.id           = id;
		this.date         = date;
		this.status       = OPEN;
		this.rentProducts = new LinkedList<RentProduct>();
	}
	
	public Date getDate() {
		return date;
	}
	
	public int getId() {
		return id;
	}

	public List<RentProduct> getRentProducts() {
		return rentProducts;
	}
	/**
	 * @return Whether the rent is open
	 */
	public boolean isOpen() {
		return status.equals(OPEN);
	}
	
	public void close() {
		 status = CLOSED;
	}
	
	public void open() {
		 status = OPEN;
	}
	
	public String getStatus() {
		return status;
	}

	/**
	 * @return The rent's total 
	 */
	public double total() {
		double total = 0.0;
		for (RentProduct rp : rentProducts)
			total += rp.getSubTotal();
		return total;
	}

	/**
	 * Adds a product to the rent
	 * 
	 * @requires qty >= 0 (zero is useful for database tests)
	 * @param product The product to sale
	 * @throws ApplicationException 
	 */
	public void addProductToRent(ProductSpec product) {
		rentProducts.add(new RentProduct(product));
	}
	
	@Override
	public String toString() {
		StringBuilder sb = new StringBuilder();
		sb.append("Rental @ " + date.toString() + "; " + (isOpen()?"open":"closed") + "; total of �" + total() + " with products:");
		for (RentProduct rp : rentProducts) {
				sb.append(" [code " + rp.getProduct().getProductCode() + ", soft limit: " + rp.getProduct().getSoftlimit() + ", hard limit: " + rp.getProduct().getHardlimit() + "]");
		}
		return sb.toString();
	}

}
