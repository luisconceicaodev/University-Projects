package business;

import java.util.Date;

public class RentProduct {
	private int         id;
	private ProductSpec product;
	private int return_id;
	private String intime;
	private String penalty;
	
	public static final String INTIME   = "Y";
	public static final String NOT_INTIME = "N";
	
	private static final String NO_PENALTY = "N";
	private static final String SOFT_PENALTY = "S";
	private static final String HARD_PENALTY = "H";
	
	/**
	 * Creates a product that is part of a rental.
	 * 
	 * @param product The product to be associated with the rental.
	 */
	public RentProduct (ProductSpec produto) {
		this.product = produto;
	}

	/**
	 * @return The product of the product rental
	 */
	public ProductSpec getProduct() {
		return product;
	}

	/**
	 * @return The sub total of the product rental
	 */
	public double getSubTotal() {
		return product.getPrice();
	}

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}
	
	public int getReturnId() {
		return return_id;
	}

	public void setReturnId(int return_id) {
		this.return_id = return_id;
	}
	
	public String getInTime() {
		return intime;
	}
	
	public String getPenalty() {
		return penalty;
	}
	
	public void IsInTime() {
		intime = INTIME;
	}
	
	public void IsNotInTime() {
		intime = NOT_INTIME;
	}
	
	public void NoPenalty() {
		penalty = NO_PENALTY;
	}
	
	public void SoftPenalty() {
		penalty = SOFT_PENALTY;
	}
	
	public void HardPenalty() {
		penalty = HARD_PENALTY;
	}
	
	/**
	 * @return Whether the product was returned in time or not
	 */
	public String CalculateInTime(Date date_returned, Date softlimit) {
		if (date_returned.after(softlimit)) {
			return NOT_INTIME;
		}else {
			return INTIME;
		}
	}
	
	/**
	 * @return Whether there will be a penalty, if so, which one
	 */
	public String CalculatePenalty(Date date_returned, Date softlimit, Date hardlimit) {
		if (date_returned.before(softlimit)) {
			this.penalty = NO_PENALTY;
			return NO_PENALTY;
		}else {
			if (date_returned.after(hardlimit)) {
				this.penalty = HARD_PENALTY;
				return HARD_PENALTY;
			}else {
				this.penalty = SOFT_PENALTY;
				return SOFT_PENALTY;
			}
		}
	}
}
