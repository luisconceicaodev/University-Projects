package business;

import java.util.Date;
import java.util.List;

import dataaccess.PersistenceException;
import dataaccess.ProductMapper;
import dataaccess.ReturnRentedItemsMapper;

/** 
 * Includes operations regarding returns
 * 
 * @author Luis Conceicao 48303
 *
 */
public class CatalogReturnedItems {
	
	public static final String INTIME   = "Y";
	public static final String NOT_INTIME = "N";
	
	private static final String NO_PENALTY = "N";
	private static final String SOFT_PENALTY = "S";
	private static final String HARD_PENALTY = "H";
	
	/**
	 * Creates a new rental, initially it is open, and has a total of zero 
	 * @return 
	 * @throws ApplicationException
	 */
	public ReturnRentedItems newReturn() throws ApplicationException {
		try {
			int return_id = ReturnRentedItemsMapper.insert(new Date());  // create new entry in the database
			return ReturnRentedItemsMapper.getReturnById(return_id);       
		} catch (PersistenceException e) {
			throw new ApplicationException("Unable to create new return", e);
		}
	}
	
	/**
	 * Add a product to an open return
	 * 
	 * @param rental    The rental (must be closed)
	 * @param prod_id The product id to return (must exist)
	 * @throws ApplicationException If some of these assumptions does not hold
	 */
	public void addProductToReturn(ReturnRentedItems returnal, Rent rental, int prod_code) 
			throws ApplicationException {
		
		if (rental.isOpen())    // check if it's open
			throw new ApplicationException("Rental " + rental.getId() + " needs to close before returning items!");
		    
		ProductSpec product;
		
		// check if product exists
		try {
			product = ProductMapper.getProductByProdCod(prod_code);
			
		} catch (PersistenceException e) {
			throw new ApplicationException("Product " + prod_code + " does not exist!", e);
		}
		String intime = CalculateInTime(returnal.getReturnDate(), product.getSoftlimit());
		String penalty = CalculatePenalty(returnal.getReturnDate(), product.getSoftlimit(), product.getHardlimit());
		returnal.addProductToReturn(product);
		double penalty_total = returnal.penalty_total();
		//System.out.println(penalty_total); 0.0 
		//System.out.println(product.getFullValue()); 500
		
		
		try {
			ReturnRentedItemsMapper.returnProduct(returnal.getId(), rental.getId(), product.getId(), intime, penalty, penalty_total);  // add it to the database
		} catch (PersistenceException e) {
			throw new ApplicationException("Unable to add " + product.getProductCode() + 
					" to rental id " + rental.getId(), e);
		}
	}
	
	public ReturnRentedItems getReturn(int return_id) throws ApplicationException {
		try {
			return ReturnRentedItemsMapper.getReturnById(return_id);
		} catch (PersistenceException e) {
			throw new ApplicationException("Unable to retrieve return " + return_id, e);
		}
	}
	
	public String CalculateInTime(Date date_returned, Date softlimit) {
		if (date_returned.after(softlimit)) {
			return NOT_INTIME;
		}else {
			return INTIME;
		}
	}
	
	public String CalculatePenalty(Date date_returned, Date softlimit, Date hardlimit) {
		if (date_returned.before(softlimit)) {
			return NO_PENALTY;
		}else {
			if (date_returned.after(hardlimit)) {
				return HARD_PENALTY;
			}else {
				return SOFT_PENALTY;
			}
		}
	}
	
	/**
	 * returns a list of all the return objects
		 * 
		 * @throws ApplicationException
		 * 
	 */

		public List<ReturnRentedItems> getAllReturns() throws ApplicationException {
			try {
				return ReturnRentedItemsMapper.getAllReturns();
			} catch (PersistenceException e) {
				throw new ApplicationException("Unable to retrieve all returns.", e);
			}
		}
		
		
		 /**
		* String representation of all return (attention: might produce a quite large output)
		*/
		public String toString() {
			try {

				List<ReturnRentedItems> returns = ReturnRentedItemsMapper.getAllReturns();
				StringBuffer sb = new StringBuffer();
				for(ReturnRentedItems returnal : returns) {
				  sb.append(returnal);
				  sb.append("\n");
				}
				
				return sb.toString();			
			} catch (PersistenceException e) {
				System.out.println(e);
				return "N/A"; // something went wrong
			}
		}
	
}