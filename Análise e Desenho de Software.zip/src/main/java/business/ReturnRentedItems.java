package business;

import java.util.Date;
import java.util.LinkedList;
import java.util.List;

public class ReturnRentedItems {
	private int id;
	private int rent_id;
	private List<RentProduct> rentProducts;	
	private Date return_date;
	
	
	/**
	 * Creates a new returned product registry 
	 * given the id, rent_id, product_id, return_date and whether it was returned in time or not and if so
	 * the penalty associated with the return_date
	 * 
	 * @param rent_id The rent_id of the rental
	 * @param product_id The product_id of the product being returned
	 * @param return_date The return date of the product being returned
	 * @param intime Whether the product was returned in time or not
	 * @param penalty Whether there will be a penalty, if so, which one it is
	 */
	public ReturnRentedItems(int id, int rent_id, Date return_date) {
		this.id = id;
		this.rent_id = rent_id;
		this.rentProducts = new LinkedList<RentProduct>();
		this.return_date = return_date;
	}
	
	public ReturnRentedItems(int id, Date date) {
		this.id = id;
		this.return_date = date;
		this.rentProducts = new LinkedList<RentProduct>();
	}

	public int getId() {
		return id;
	}
	
	public int getRentId() {
		return rent_id;
	}

	public Date getReturnDate() {
		return return_date;
	}
	
	public void setReturnDate(Date return_date) {
		this.return_date = return_date;
	}
	
	public List<RentProduct> getReturnedProducts() {
		return rentProducts;
	}
	
	/**
	 * @return The returnal total penalty if the producs were delivered late 
	 */
	public double penalty_total() {
		double penalty_total = 0.0;
		for (RentProduct rp : rentProducts) {
			if (rp.getPenalty().equals("S")) {
				penalty_total += 10;
			}else if (rp.getPenalty().equals("H")) {
				penalty_total += rp.getProduct().getFullValue() - rp.getProduct().getPrice();
			}
		}
		return penalty_total;
	}
	
	public void addProductToReturn(ProductSpec product) {
		rentProducts.add(new RentProduct(product));
		for (RentProduct rp : rentProducts) {
			rp.CalculateInTime(this.getReturnDate(), rp.getProduct().getSoftlimit());
			rp.CalculatePenalty(this.getReturnDate(), rp.getProduct().getSoftlimit(), rp.getProduct().getHardlimit());
		}
	}
	
	
	@Override
	public String toString() {
		StringBuilder sb = new StringBuilder();
		sb.append("Return @ date " + return_date.toString() + ", penalty cost: �" + penalty_total() + " with products:");
		for (RentProduct rp : rentProducts) 
			sb.append(" [code " + rp.getProduct().getProductCode() + ", soft limit: " + rp.getProduct().getSoftlimit() + 
					", hard limit: " + rp.getProduct().getHardlimit() + ", returned date: " + this.getReturnDate() + 
					", in time: " + rp.CalculateInTime(this.getReturnDate(), rp.getProduct().getSoftlimit()) + ", penalty: " +
					rp.CalculatePenalty(this.getReturnDate(), rp.getProduct().getSoftlimit(), rp.getProduct().getHardlimit()) + "]");
		return sb.toString();
	}

}
