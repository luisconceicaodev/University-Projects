package business;

import java.util.Date;
import java.util.List;

import dataaccess.PersistenceException;
import dataaccess.ProductMapper;
import dataaccess.RentMapper;
import dataaccess.RentProductMapper;

/** 
 * Includes operations regarding Rentals
 * 
 * @author Joao Maia 48208
 * @author Luis Conceicao 48303
 * @author Diogo Catalao 48756
 *
 */
public class CatalogRent {
	
	/**
	 * Creates a new rental, initially it is open, and has a total of zero 
	 * @return
	 * @throws ApplicationException
	 */
	public Rent newRent() throws ApplicationException {

		try {
			int rent_id = RentMapper.insert(new Date());  // create new entry in the database
			return RentMapper.getRentalById(rent_id);       
		} catch (PersistenceException e) {
			throw new ApplicationException("Unable to create new rental", e);
		}
	}
	
	/**
	 * Add a product to an open rental
	 * 
	 * @param rental    The current rental (must be open)
	 * @param prod_id The product id to add (must exist)
	 * @throws ApplicationException If some of these assumptions does not hold
	 */
	public void addProductToRent(Rent rental, int prod_id) 
			throws ApplicationException {
		
		if (!rental.isOpen())    // check if it's open
			throw new ApplicationException("Rental " + rental.getId() + " is already closed!");
		    
		ProductSpec product;
		
		try {
			product = ProductMapper.getProductByProdCod(prod_id);
			
		} catch (PersistenceException e) {
			throw new ApplicationException("Product " + prod_id + " does not exist!", e);
		}

		rental.addProductToRent(product);  // add it to the object rent
		
		try {
			RentProductMapper.insert(rental.getId(), product.getId());  // add it to the database
		} catch (PersistenceException e) {
			throw new ApplicationException("Unable to add " + product.getProductCode() + 
					" to rental id " + rental.getId(), e);
		}
	}

	/**
	 * Close rental, updating the total and its status.
	 * If the rental was already closed, nothing happens.
	 * 
	 * @param rental the rental to be closed
	 * @throws ApplicationException 
	 */
	public void closeRent(Rent rental) throws ApplicationException {
		
		if (rental.isOpen()) {
			try {
				rental.close();
				RentMapper.update(rental.getId(), rental.getStatus());
			} catch (PersistenceException e) {
				throw new ApplicationException("Unable to close " + rental.getId() + 
						", or unable to find it", e);
			}
		}
	}
	
	/**
	 * delete rental and its rent products
	 * 
	 * @param rental the rental to be deleted
	 * @throws ApplicationException
	 */
	public void deleteRent(Rent rental) throws ApplicationException {
		try {
			RentMapper.delete(rental.getId());
		} catch (PersistenceException e) {
			throw new ApplicationException("Unable to delete rental " + rental.getId(), e);
		}
	}
	
	/**
	 * returns a rent object
	 * 
	 * @param rental the rental to be returned
	 * @throws ApplicationException
	 */
	public Rent getRent(int rent_id) throws ApplicationException {
		try {
			return RentMapper.getRentalById(rent_id);
		} catch (PersistenceException e) {
			throw new ApplicationException("Unable to retrieve rental " + rent_id, e);
		}
	}
	/**
	 * returns a list of all the rent objects
	 * 
	 * @throws ApplicationException
	 */
	public List<Rent> getAllRentals() throws ApplicationException {
		try {
			return RentMapper.getAllRentals();
		} catch (PersistenceException e) {
			throw new ApplicationException("Unable to retrieve all rentals.", e);
		}
	}
	
	/**
	 * String representation of all rentals (attention: might produce a quite large output)
	 */
	public String toString() {
		try {
			List<Rent> rentals = RentMapper.getAllRentals();
			StringBuffer sb = new StringBuffer();

			for(Rent rental : rentals) {
			  sb.append(rental);
			  sb.append("\n");
			}
			
			return sb.toString();			
		} catch (PersistenceException e) {
			System.out.println(e);
			return "N/A"; // something went wrong
		}
	}
}
