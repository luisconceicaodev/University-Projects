package dataaccess;

import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import java.util.List;
import java.util.Map;
import java.util.Date;
import java.util.HashMap;
import java.util.LinkedList;

import business.RentProduct;
import business.ReturnRentedItems;

/**
 * Este e' um exemplo do padr�o Mapper (Fowler cap.18) que estabelece
 * a comunica��o entre dois sistemas: a camada de neg�cio e a base de dados
 * disponibilizada via DataSource.
 * 
 * Este e' um padrao adequado para lidar com o domain model, dado que cada
 * conceito do domain model corresponde a uma classe Mapper. Por exemplo,
 * a classe Rent tem o RentMapper, o ProductSpec tem o ProductMapper, etc.
 * 
 * Tem a desvantagem de precisar do acesso das classes da camada de negocio
 * 
 * A classe tem as opera��es CRUD (create, read, update, delete) em relacao
 * 'as vendas
 * 
 * Nesta classe foi incluido tambem uma cache, que permite reduzir o acesso
 * 'a base de dados.
 * 
 * Todos os metodos e atributos sao static. Estes Mappers poderiam ter sido
 * implementados como Singletons.
 * 
 * @author Joao Maia 48208
 * @author Luis Conceicao 48303
 * @author Diogo Catalao 48756
 * @version 1.0 (23/May/2018)
 */
public class ReturnRentedItemsMapper {
	
	// the cache keeps all rents that were accessed during the current runtime
	static Map<Integer, ReturnRentedItems> cachedReturnedItems;
	
	static {
		// this code is initialized once per class
		cachedReturnedItems= new HashMap<Integer, ReturnRentedItems>();
	}
	
	/////////////////////////////////////////////////////////////////////////
	// SQL statement: inserts a new returnal
	private static final String INSERT_RETURN_SQL = 
		"INSERT INTO returned (id, date, penalty_total) VALUES (DEFAULT, ?, ?)";
	
	/**
	 * Inserts a new returnal into the database
	 * @param date The rental's date
	 * @return the rental's id
	 */
	public static int insert(Date date) throws PersistenceException {	
		try (PreparedStatement statement =       // get new id
				DataSource.INSTANCE.prepareGetGenKey(INSERT_RETURN_SQL)) {  
			// set statement arguments
			statement.setDate(1, new java.sql.Date(date.getTime()));
			statement.setDouble(2, 0.0);
			// execute SQL
			statement.executeUpdate();
			// get sale Id generated automatically by the database engine
			try (ResultSet rs = statement.getGeneratedKeys()) {
				rs.next(); 
				return rs.getInt(1);
			}
		} catch (SQLException e) {
			throw new PersistenceException ("Error inserting a new item return!", e);
		}
	}
	
	/////////////////////////////////////////////////////////////////////////
	// SQL statement: inserts a new returned item
	private static final String UPDATE_RETURN_SQL = 
	"UPDATE returned SET rent_id = ?, product_id = ?, penalty_total = ? WHERE id = ?";
	
	/**
	* Inserts a new returnal into the database
	* @param date The rental's date
	* @return the rental's id
	 * @throws PersistenceException 
	*/
	public static void returnProduct(int return_id, int rent_id, int product_id, String intime, String penalty, double penalty_total) throws PersistenceException {
		try (PreparedStatement statement =       // get new id
				DataSource.INSTANCE.prepareGetGenKey(UPDATE_RETURN_SQL)) {  
			// set statement arguments
			statement.setInt(1, rent_id);
			statement.setInt(2, product_id);
			statement.setDouble(3, penalty_total);
			statement.setInt(4, return_id);
			// updates the rentproduct entry with the return details
			RentProductMapper.updateIntimePenalty(product_id, return_id, intime, penalty);
			// execute SQL
			statement.executeUpdate();
			// get sale Id generated automatically by the database engine
		} catch (SQLException e) {
			throw new PersistenceException ("Error inserting a new item return!", e);
		}
		cachedReturnedItems.remove(return_id);
	}
	
	/////////////////////////////////////////////////////////////////////////
	// SQL statement: selects a rental by its id 
	private static final String GET_RETURN_SQL = 
			"SELECT id, rent_id, product_id, date FROM returned WHERE id = ?";
	
	/**
	 * Gets a return by its id 
	 * 
	 * @param return_id The rental id to search for
	 * @return The new object that represents an in-memory sale
	 * @throws PersistenceException In case there is an error accessing the database.
	 */
	public static ReturnRentedItems getReturnById(int return_id) throws PersistenceException {
		
		if (cachedReturnedItems.containsKey(return_id))  
			return cachedReturnedItems.get(return_id);   
		
		try (PreparedStatement statement = DataSource.INSTANCE.prepare(GET_RETURN_SQL)) {		
			// set statement arguments
			statement.setInt(1, return_id);		
			// execute SQL
			try (ResultSet rs = statement.executeQuery()) {
				rs.next();
				ReturnRentedItems returnal = loadReturn(rs);             // creates rent object from result set
				cachedReturnedItems.put(returnal.getId(), returnal);  // inserts it into cache
				return returnal;
			}
		} catch (SQLException e) {
			throw new PersistenceException("Internal error getting returnal " + return_id, e);
		} 
	}
	
	/////////////////////////////////////////////////////////////////////////
	// SQL statement: get all returns
	private static final String GET_ALL_RETURNS_SQL = "SELECT * FROM returned";
	
	/**
	 * Retrieve all returns kept on database
	 * @return A list with all the returnals
	 * @throws PersistenceException
	 */
	public static List<ReturnRentedItems> getAllReturns() throws PersistenceException {
		
		try (PreparedStatement statement = DataSource.INSTANCE.prepare(GET_ALL_RETURNS_SQL)) {		
			try (ResultSet rs = statement.executeQuery()) {
				List<ReturnRentedItems> returnals = new LinkedList<ReturnRentedItems>();
				while(rs.next()) { // for each return
					int return_id = rs.getInt("id");          // get id of current return
					if (cachedReturnedItems.containsKey(return_id))   // check if it is cached
						returnals.add(cachedReturnedItems.get(return_id));
					else {
						ReturnRentedItems returnal = loadReturn(rs);           // if not, create a new rental object
						returnals.add(returnal);                    //  insert it to result list,
						cachedReturnedItems.put(return_id, returnal);     //  and cache it
					}
				}
				return returnals;
			}
		} catch (SQLException e) {
			throw new PersistenceException("Unable to fetch all returnals", e);
		} 
	}
	
	/**
	 * Creates a returned item object from a result set retrieved from the database.
	 * 
	 * @requires rs.next() was already executed
	 * @param rs The result set with the information to create the return.
	 * @return A new returned item loaded from the database.
	 * @throws PersistenceException 
	 */
	private static ReturnRentedItems loadReturn(ResultSet rs) throws PersistenceException {
		ReturnRentedItems returnal;
		try {
			if (rs.getInt("rent_id") != 0) {
				returnal = new ReturnRentedItems(rs.getInt("id"), rs.getInt("rent_id")
						, rs.getDate("date"));
					
				List<RentProduct> rentProducts = RentProductMapper.getReturnProducts(rs.getInt("id"));
					for(RentProduct rp : rentProducts) {
						returnal.addProductToReturn(rp.getProduct());
					}
			}else {
				returnal = new ReturnRentedItems(rs.getInt("id"), rs.getDate("date"));
			}
			
		} catch (SQLException e) {
			throw new RecordNotFoundException ("Return does not exist	", e);
		}		
		return returnal;
	}
}