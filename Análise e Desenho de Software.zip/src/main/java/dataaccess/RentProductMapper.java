package dataaccess;

import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import java.util.LinkedList;
import java.util.List;

import business.ProductSpec;
import business.RentProduct;

/**
 * Conferir RentMapper para mais informacao
 * 
 * @author Joao Maia 48208
 * @author Luis Conceicao 48303
 * @author Diogo Catalao 48756
 */
public class RentProductMapper {
	
	/////////////////////////////////////////////////////////////////////////
	// SQL statement: insert product in a rental 
	private static final String INSERT_PRODUCT_RENTAL_SQL = 
		"INSERT INTO rentproduct (id, rent_id, product_id) VALUES (DEFAULT, ?, ?)";
	
	/**
	 * Inserts the record in the rent products table 
	 * 
	 * @requires qty >= 0
	 * @param rent_id current sale's id
	 * @param prod_id current product's id
	 * @return the saleProduct's id
	 * @throws PersistenceException
	 */
	public static int insert (int rent_id, int prod_id) throws PersistenceException {
		try (PreparedStatement statement = DataSource.INSTANCE.prepareGetGenKey(INSERT_PRODUCT_RENTAL_SQL)) {
			statement.setInt(1, rent_id);    // set statement arguments
			statement.setInt(2, prod_id);		
			statement.executeUpdate();      // execute SQL
			  // Gets sale product Id generated automatically by the database engine
			try (ResultSet rs = statement.getGeneratedKeys()) {
				rs.next(); 
				return rs.getInt(1);
			}
		} catch (SQLException e) {
			throw new PersistenceException ("Internal error inserting product " + prod_id + " into rental " + rent_id, e);
		}
	}
	
	/////////////////////////////////////////////////////////////////////////
	// SQL statement: deletes rentProducts of rental
	private static final String DELETE_RENTALPRODUCT_SQL = 
			"DELETE FROM rentproduct WHERE rent_id = ?";
	
	/**
	 * Deletes the rental's data in the database.
	 * Notice that current product stocks are not changed!
	 * 
	 * @param rent_id The rental id to delete
	 * @throws PersistenceException If an error occurs during the operation
	 */
	public static void delete(int rent_id) throws PersistenceException {
		try (PreparedStatement statement = DataSource.INSTANCE.prepare(DELETE_RENTALPRODUCT_SQL)) {
			statement.setDouble(1, rent_id);
			statement.executeUpdate();
		} catch (SQLException e) {
			throw new PersistenceException ("Internal error!", e);
		}
	}

	/////////////////////////////////////////////////////////////////////////
	// SQL statement: select the products of a rental products by rent id 
	private static final String GET_RENTAL_PRODUCTS_SQL = 
			"SELECT id, rent_id, product_id FROM rentproduct WHERE rent_id = ?";
		
	/**
	 * Gets the products of a rental by its rent id 
	 * 
	 * @param rent_id The rent id to get the products of
	 * @return The set of products that compose the sale
	 * @throws PersistenceException When there is an error obtaining the
	 *         information from the database.
	 */
	public static List<RentProduct> getRentProducts(int rent_id) throws PersistenceException {
		try (PreparedStatement statement = DataSource.INSTANCE.prepare(GET_RENTAL_PRODUCTS_SQL)) {
			// set statement arguments
			statement.setInt(1, rent_id);			
			// execute SQL
			try (ResultSet rs = statement.executeQuery()) {
				// creates the sale's products set with the data retrieved from the database
				return loadRentProducts(rs);
			}
		} catch (SQLException e) {
			throw new PersistenceException("Internal error getting the products of rental " + rent_id, e);
		}
	}
	
	/////////////////////////////////////////////////////////////////////////
	// SQL statement: select the products of a return by return id 
	private static final String GET_RETURN_PRODUCTS_SQL = 
			"SELECT id, rent_id, product_id, return_id, intime, penalty FROM rentproduct WHERE return_id = ?";
		
	/**
	 * Gets the products of a return by its return id 
	 * 
	 * @param return id The return id to get the products of
	 * @return The set of products that compose the return
	 * @throws PersistenceException When there is an error obtaining the
	 *         information from the database.
	 */
	public static List<RentProduct> getReturnProducts(int return_id) throws PersistenceException {
		try (PreparedStatement statement = DataSource.INSTANCE.prepare(GET_RETURN_PRODUCTS_SQL)) {
			// set statement arguments
			statement.setInt(1, return_id);			
			// execute SQL
			try (ResultSet rs = statement.executeQuery()) {
				// creates the sale's products set with the data retrieved from the database
				return loadRentProducts(rs);
			}
		} catch (SQLException e) {
			throw new PersistenceException("Internal error getting the products of return " + return_id, e);
		}
	}
	
	/////////////////////////////////////////////////////////////////////////
	// SQL statement: select the products of a rental products by rent id 
	private static final String GET_RENTAL_PRODUCT_BY_ID_SQL = 
			"SELECT id, rent_id, product_id FROM rentproduct WHERE product_id = ?";
		
	/**
	 * Get a product of a rental by its id 
	 * 
	 * @param id The id to get the product
	 * @return The product
	 * @throws PersistenceException When there is an error obtaining the
	 *         information from the database.
	 */
	public static RentProduct getRentProductById(int id) throws PersistenceException {
		try (PreparedStatement statement = DataSource.INSTANCE.prepare(GET_RENTAL_PRODUCT_BY_ID_SQL)) {
			// set statement arguments
			statement.setInt(1, id);			
			// execute SQL
			try (ResultSet rs = statement.executeQuery()) {
				// creates the sale's products set with the data retrieved from the database
				return loadRentProduct(rs);
			}
		} catch (SQLException e) {
			throw new PersistenceException("Internal error getting the products of rental " + id, e);
		}
	}
	
	/////////////////////////////////////////////////////////////////////////
	// SQL statement: inserts a new returned item
	private static final String UPDATE_RETURNED_SQL = 
	"UPDATE rentproduct SET return_id = ?, intime = ?, penalty = ? WHERE product_id = ?";
	
	/**
	* Inserts a new returnal into the database
	* @param date The rental's date
	* @return the rental's id
	 * @throws PersistenceException 
	*/
	public static void updateIntimePenalty(int product_id, int return_id, String intime, String penalty) throws PersistenceException {
		try (PreparedStatement statement =       // get new id
				DataSource.INSTANCE.prepareGetGenKey(UPDATE_RETURNED_SQL)) {  
			// set statement arguments
			statement.setInt(1, return_id);
			statement.setString(2, intime);
			statement.setString(3, penalty);
			statement.setInt(4, product_id);
			// execute SQL
			statement.executeUpdate();
			// get sale Id generated automatically by the database engine
		} catch (SQLException e) {
			throw new PersistenceException ("Error updating!", e);
		}
	}
	
	/**
	 * Creates THE product of a rental from a result set retrieved from the database.
	 * 
	 * @param rs The result set with the information to create the set of products from a rental product.
	 * @return The set of products of a sale loaded from the database.
	 * @throws SQLException When there is an error reading from the database.
	 * @throws PersistenceException 
	 */
	private static RentProduct loadRentProduct(ResultSet rs) throws SQLException, PersistenceException {
		rs.next();
		ProductSpec product = ProductMapper.getProductById(rs.getInt("product_id"));
			RentProduct RentProduct1 = new RentProduct(product);
			RentProduct1.setId(rs.getInt("id"));
		return RentProduct1;		
	}
		
	/**
	 * Creates the set of products of a rental from a result set retrieved from the database.
	 * 
	 * @param rs The result set with the information to create the set of products from a sale.
	 * @return The set of products of a sale loaded from the database.
	 * @throws SQLException When there is an error reading from the database.
	 * @throws PersistenceException 
	 */
	private static List<RentProduct> loadRentProducts(ResultSet rs) throws SQLException, PersistenceException {
		List<RentProduct> result = new LinkedList<RentProduct>();
		while (rs.next()) {
			ProductSpec product = ProductMapper.getProductById(rs.getInt("product_id"));
			RentProduct newRentProduct = new RentProduct(product);
			newRentProduct.setId(rs.getInt("id"));
			result.add(newRentProduct);
		}
		return result;		
	}

}