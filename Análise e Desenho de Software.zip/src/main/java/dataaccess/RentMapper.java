package dataaccess;

import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import java.util.List;
import java.util.Map;
import java.util.HashMap;
import java.util.LinkedList;

import business.Rent;
import business.RentProduct;

/**
 * Este e' um exemplo do padr�o Mapper (Fowler cap.18) que estabelece
 * a comunica��o entre dois sistemas: a camada de neg�cio e a base de dados
 * disponibilizada via DataSource.
 * 
 * Este e' um padrao adequado para lidar com o domain model, dado que cada
 * conceito do domain model corresponde a uma classe Mapper. Por exemplo,
 * a classe Rent tem o RentMapper, o ProductSpec tem o ProductMapper, etc.
 * 
 * Tem a desvantagem de precisar do acesso das classes da camada de negocio
 * 
 * A classe tem as opera��es CRUD (create, read, update, delete) em relacao
 * 'as vendas
 * 
 * Nesta classe foi incluido tambem uma cache, que permite reduzir o acesso
 * 'a base de dados.
 * 
 * Todos os metodos e atributos sao static. Estes Mappers poderiam ter sido
 * implementados como Singletons.
 * 
 * @author Joao Maia 48208
 * @author Luis Conceicao 48303
 * @author Diogo Catalao 48756
 * @version 1.0 (23/May/2018)
 */
public class RentMapper {
	
	// the cache keeps all rents that were accessed during the current runtime
	static Map<Integer, Rent> cachedRentals;
	
	static {
		// this code is initialized once per class
		cachedRentals = new HashMap<Integer, Rent>();
	}
	
	/////////////////////////////////////////////////////////////////////////
	// SQL statement: inserts a new rental
	private static final String INSERT_RENTAL_SQL = 
		"INSERT INTO rent (id, date, total, status) VALUES (DEFAULT, ?, ?, '" + Rent.OPEN + "')";
	
	/**
	 * Inserts a new rental into the database
	 * @param date The rental's date
	 * @return the rental's id
	 */
	public static int insert(java.util.Date date) throws PersistenceException {	
		try (PreparedStatement statement =       // get new id
				DataSource.INSTANCE.prepareGetGenKey(INSERT_RENTAL_SQL)) {  
			// set statement arguments
			statement.setDate(1, new java.sql.Date(date.getTime()));
			statement.setDouble(2, 0.0); // total
			// execute SQL
			statement.executeUpdate();
			// get sale Id generated automatically by the database engine
			try (ResultSet rs = statement.getGeneratedKeys()) {
				rs.next(); 
				return rs.getInt(1);
			}
		} catch (SQLException e) {
			throw new PersistenceException ("Error inserting a new rental!", e);
		}
	}
	
	/////////////////////////////////////////////////////////////////////////
	// SQL statement: updates total and status from existing rental
	private static final String UPDATE_RENTAL_SQL = 
			"UPDATE rent SET status = ? WHERE id = ?";
	
	/**
	 * Updates the rental's data in the database
	 * 
	 * @param rental_id The rental id to update
	 * @param status is the rental open or closed
	 * @throws PersistenceException If an error occurs during the operation
	 */
	public static void update(int rental_id, String status) throws PersistenceException {
		try (PreparedStatement statement = DataSource.INSTANCE.prepare(UPDATE_RENTAL_SQL)) {
			statement.setString(1, status);
			statement.setInt(2, rental_id);
			statement.executeUpdate();
		} catch (SQLException e) {
			throw new PersistenceException ("Internal error!", e);
		}
		
		cachedRentals.remove(rental_id);  // rental was changed, remove from cache
	}
	
	/////////////////////////////////////////////////////////////////////////
	// SQL statement: deletes rental 
	private static final String DELETE_RENTAL_SQL = 
			"DELETE FROM rent WHERE id = ?";
	
	/**
	 * Deletes the rental's data in the database.
	 * Current product stocks are not changed
	 * 
	 * @param rental_id The rental id to delete
	 * @throws PersistenceException If an error occurs during the operation
	 */
	public static void delete(int rental_id) throws PersistenceException {
		
		SaleProductMapper.delete(rental_id);  // first remove its sale products
		
		try (PreparedStatement statement = DataSource.INSTANCE.prepare(DELETE_RENTAL_SQL)) {
			statement.setDouble(1, rental_id);
			statement.executeUpdate();
		} catch (SQLException e) {
			throw new PersistenceException ("Internal error!", e);
		}
		
		cachedRentals.remove(rental_id);  // rental was deleted, remove from cache
	}
	
	/////////////////////////////////////////////////////////////////////////
	// SQL statement: selects a rental by its id 
	private static final String GET_RENTAL_SQL = 
			"SELECT id, date, total, status FROM rent WHERE id = ?";
	
	/**
	 * Gets a rental by its id 
	 * 
	 * @param rental_id The rental id to search for
	 * @return The new object that represents an in-memory sale
	 * @throws PersistenceException In case there is an error accessing the database.
	 */
	public static Rent getRentalById(int rental_id) throws PersistenceException {
		
		if (cachedRentals.containsKey(rental_id))  
			return cachedRentals.get(rental_id);   
		
		try (PreparedStatement statement = DataSource.INSTANCE.prepare(GET_RENTAL_SQL)) {		
			// set statement arguments
			statement.setInt(1, rental_id);		
			// execute SQL
			try (ResultSet rs = statement.executeQuery()) {
				rs.next();
				Rent rental = loadRental(rs);             // creates rent object from result set
				cachedRentals.put(rental.getId(), rental);  // inserts it into cache
				return rental;
			}
		} catch (SQLException e) {
			throw new PersistenceException("Internal error getting rental " + rental_id, e);
		} 
	}
	
	/////////////////////////////////////////////////////////////////////////
	// SQL statement: get all rentals 
	private static final String GET_ALL_RENTALS_SQL = "SELECT * FROM rent";
	
	/**
	 * Retrieve all rentals kept on database
	 * @return A list with all the rentals
	 * @throws PersistenceException
	 */
	public static List<Rent> getAllRentals() throws PersistenceException {
		
		try (PreparedStatement statement = DataSource.INSTANCE.prepare(GET_ALL_RENTALS_SQL)) {		
			try (ResultSet rs = statement.executeQuery()) {

				List<Rent> rentals = new LinkedList<Rent>();
				while(rs.next()) { // for each sale
					int rental_id = rs.getInt("id");          // get id of current rental
					if (cachedRentals.containsKey(rental_id))   // check if it is cached
						rentals.add(cachedRentals.get(rental_id));
					else {
						Rent rental = loadRental(rs);           // if not, create a new rental object
						rentals.add(rental);                    //  insert it to result list,
						cachedRentals.put(rental_id, rental);     //  and cache it
					}
				}
				return rentals;
			}
		} catch (SQLException e) {
			throw new PersistenceException("Unable to fetch all rentals", e);
		} 
	}
	
	/**
	 * Creates a rental object from a result set retrieved from the database.
	 * 
	 * @requires rs.next() was already executed
	 * @param rs The result set with the information to create the rental.
	 * @return A new rental loaded from the database.
	 * @throws PersistenceException 
	 */
	private static Rent loadRental(ResultSet rs) throws PersistenceException {
		Rent rental;
		try {
			rental = new Rent(rs.getInt("id"), rs.getDate("date"));
			
			List<RentProduct> rentProducts = RentProductMapper.getRentProducts(rs.getInt("id"));
			for(RentProduct rp : rentProducts) 
				rental.addProductToRent(rp.getProduct());
			
			
			if (rs.getString("status").equals(Rent.CLOSED))
				rental.close();
			
		} catch (SQLException e) {
			throw new RecordNotFoundException ("Rental does not exist	", e);
		}		
		return rental;
	}
}